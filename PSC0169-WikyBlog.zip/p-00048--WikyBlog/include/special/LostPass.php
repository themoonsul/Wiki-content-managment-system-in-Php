<?php

defined('WikyBlog') or die("Not an entry point...");


global $page,$pageOwner,$langA,$dbObject,$wbConfig;
wbLang::getFile('specLostPass');
$page->displayTitle = $langA['lost_password'];

if( empty($_POST['username']) ){
	$_POST['username'] = '';
}


$page->regLink($langA['log_in'],'/Special/'.$GLOBALS['wbConfig']['pUser'].'/LogIn');
$page->regLink($langA['register'],'/Special/'.$GLOBALS['wbConfig']['pUser'].'/Register');
$contentUri = $page->regLink($langA['lost_password'],'/Special/'.$GLOBALS['wbConfig']['pUser'].'/LostPassword');
$page->autoForm = true;


ob_start();

echo '<br/>'.$langA['CHANGE_PASS_INTRO'];

switch( $page->userCmd ){
	
	case wbStrtolower($langA['next_step']);
		changePassTxt();
	break;
	
	case wbStrtolower($langA['change_password']):
		changePassword();
	break;
	
	case wbStrtolower($langA['send_key']);
		sendKey();
	break;
	
	case wbStrtolower($langA['back']);
	default:
		sendPassTxt();
	break;
	
}

$page->contentB[$contentUri] = wb::get_clean();


function sendKey(){
	global $pageOwner,$serverName2,$serverName1,$langA,$wbTables;
	
	
	if( empty($_POST['username']) ){
		message('ENTER_USERNAME');
		sendPassTxt();
		return;
	}
	
	
	// Get Key
		$query = 'SELECT password, data FROM '.$wbTables['users'].' WHERE username = "'.wbDB::escape(tostorage($_POST['username']) ).'" LIMIT 1';
		$result = wbDB::runQuery($query);
		
		$num = mysql_num_rows($result);
		if( $num !== 1){
			message('NOT_A_USER',$_POST['username']);
			sendPassTxt();
			return;
		}
		$row = mysql_fetch_assoc($result);
		
		
	//	email address
		$temp = unserialize($row['data']);
		if( empty($temp['email']) ){
			message('NO_EMAIL_FOR_ACCOUNT');
			sendPassTxt();
			return;
		}
		
		
	
	//	1)	Send Message
		$to = $temp['email'];
		$subject = wbLang::text('PASS_EMAIL_SUBJECT',$serverName1);
		$headers = 'From: <noreply@'.$serverName2.'>'."\r\n";
		$headers .= 'Content-Type: text/plain; charset=UTF-8;'."\r\n";
		$message = wbLang::text('PASS_EMAIL_TEXT',$serverName1,$row['password']);

		
	if(!@mail($to, $subject, $message, $headers)){
		message('PERMISSION_KEY_NOT_SENT');
		sendPassTxt();
	}else{
		message('PERMISSION_KEY_SENT');
		changePassTxt();
	}
}

function changePassword(){
	global $pageOwner,$wbTables,$wbNow;
	
	if( empty($_POST['username']) ){
		message('ENTER_USERNAME');
		changePassTxt();
		return;
	}
	if( empty($_POST['pkey']) ){
		message('PROVIDE_PERMISSION_KEY');
		changePassTxt();
		return;
	}
	if( empty($_POST['password']) ){
		message('PROVIDE_PASSWORD');
		changePassTxt();
		return;
	}
	$_POST['username'] = toStorage($_POST['username']);
	
	includeFile('tool/sessionActions.php');
	$attempts = sessLog::checkAttempts($_POST['username']);
	if( $attempts === false){
		changePassTxt();
		return;
	}
	
	$update['password'] = md5($_POST['password']);
	$update['modified'] = $wbNow;
	$where['username'] = $_POST['username']; //wbDB::escape is done by dbUpdate2
	$where['password'] = $_POST['pkey'];
	
	$num = wbDB::dbUpdate2($wbTables['users'],$update,$where);

	if( $num > 1){
		trigger_error('Change Password affected more than one user!');
	}
	
	if( $num === 1){
		message('PASSWORD_CHANGED',$_POST['username']);
		return;
	}
	
	message('PASSWORD_CHANGE_FAILED');
	changePassTxt();
	
	sessLog::addAttempt(wbDB::escape($_POST['username']),$attempts);
}


function sendPassTxt(){
	global $langA;
	
	?>
	
	<h3><?php echo $langA['get_your_key'] ?></h3>
	<?php echo $langA['GET_YOUR_KEY'] ?>
	<p>
	<table>
	
	<tr>
		<td><?php echo $langA['username'] ?>:</td>
		<td><input type="text" name="username" value="<?php echo wbHtmlspecialchars($_POST['username']) ?>" size="30"/></td>
		</tr>
	<tr>
		<td></td>
		<td><input type="submit" name="cmd" value="<?php echo $langA['send_key'] ?>" /> 
		<input type="submit" name="cmd" value="<?php echo $langA['next_step'] ?>" /></td>
		</tr>
	</table>
	
	<?php

}



function changePassTxt(){
	global $pageOwner,$langA;
	
	?>
	
	<h3><?php echo $langA['change_password'] ?></h3>
	<table>
	
	<tr>
		<td><?php echo $langA['username'] ?>:</td>
		<td><input type="text" name="username" value="<?php echo wbHtmlspecialchars($_POST['username']) ?>" size="30"/></td>
		</tr>
		
	<tr>
		<td><?php echo $langA['permission_key'] ?>:</td>
		<td><input type="text" name="pkey" value="" size="30" /></td>
		</tr>
		
	<tr>
		<td><?php echo $langA['new_password'] ?>:</td>
		<td><input type="password" name="password" value="" size="30" /></td>
		</tr>
	
	
	<tr>
		<td></td>
		<td><input type="submit" name="cmd" value="<?php echo $langA['change_password'] ?>" /> <input type="submit" name="cmd" value="<?php echo $langA['back'] ?>" /></td>
		</tr>
	</table>
	
	<?php

}