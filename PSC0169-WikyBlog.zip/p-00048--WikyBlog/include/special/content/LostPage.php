<?php
//$langA checked
// issues to address
//
//	owners that would like to register
//	pages that used an incorrect link

defined('WikyBlog') or die("Not an entry point...");

header("HTTP/1.0 404 Not Found");
global $page,$unknownName,$langA,$pageOwner,$dbObject,$serverName1;
wbLang::getFile('lostPage');


if( !empty($unknownName) ){
	$pageOwner['username'] = htmlspecialchars($unknownName);
}
$url = htmlspecialchars($_SERVER['REDIRECT_URL']);


$page->regLink($serverName1,'/'.$GLOBALS['wbConfig']['pUser'].'/'.$GLOBALS['wbDefaultTitle']);
$link = $page->regLink($langA['lost_page'],$url);

$page->displayTitle = '404 Page Not Found';
$page->contentB[$link] = lostPageContent($url);

function lostPageContent($url){
	global $page, $langA,$unknownName;
	
	includeFile('tool/SpecialContent.php');
	$content = specialContent::get('Lost_Page');
	if( $content !== false){
		return $content;
	}
	
	
	ob_start();
		
		echo '<br />';
		echo wbLang::text('PAGE_NOT_FOUND',$url);
		
		echo '<p>';
		
		$link = wbLinks::special('Register?username='.$unknownName,wbStrtolower($langA['register']),'',$GLOBALS['wbConfig']['pUser']);
		echo wbLang::text('REGISER_AS_USER',$unknownName,$link);
		echo '</p>';
		
		echo '<b>'. $langA['options'] .'</b><br />';
		echo '<ul>';
		
		echo '<li>'.$langA['LINK_TYPO'];
		if( !empty($_SERVER['HTTP_REFERER']) ){
			echo '<i>'. $_SERVER['HTTP_REFERER'].'</i>';
		}else{
			echo '<i>'.$langA['undefined'].'</i>';
		}
		echo '</li>';
		
		
		echo '<li>'.wbLang::text('REGISTER_TO_CREATE',$unknownName).'</li>';
		echo '</ul>';
		
	return wb::get_clean();
}

