<?php
defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$wbConfig,$page;
$page->displayTitle = $langA['friends'];
$page->regLink($langA['permissions'],'/Special/'.$pageOwner['username'].'/Permissions');
$page->regLink('?',$langA['friends'].'?en=Friends');

if( !isOwner(true,false) ) return false;

includeFile('search/all.php');

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//

	class friends extends query{
		function friends(){
			global $wbTables,$pageOwner,$dbObject,$langA,$page;
			$this->classes[] = 'class="tableRowEven" ';
			$this->classes[] = 'class="tableRowOdd" ';
	
			$page->regLink($langA['friends'],'/Special/'.$pageOwner['username'].'/Friends');
			$this->searchUrl = '/Special/'.$pageOwner['username'].'/Friends';
	
			$this->rowLimit = 25;
			
			$this->query = 'SELECT SQL_CALC_FOUND_ROWS ';
			$this->query .= ' `owner`, `userlevel` ';
			$this->query .= 'FROM '.$wbTables['workgroup'];
			$this->query .= ' WHERE `guest` = "'.wbDB::escape($pageOwner['username']).'" ';
			$this->query .= ' AND `userlevel` > 0 ';
			$this->query .= ' ORDER BY `userlevel` DESC, `owner` ';
			
			$this->browse($langA['friends']);
		}
		function mysqlFetch(&$result){
			return mysql_fetch_assoc($result);
		}
		function displayEmpty(){
			parent::displayEmpty();
			return true;
		}		
		function displayPre(){
			global $langA;
			echo '<table cellspacing="0" width="100%" class="tableRows"><tr>';
			echo '<th>'.$langA['user'].'</th>';
			echo '<th>'.$langA['my_status'].'</th>';
			echo '<th colspan="2">'.$langA['view_users'].'</th>';
			echo '<th>'.$langA['permissions'].'</th>';
			echo '</tr>';
		}
		function displayPost(&$prev,&$pages,&$next){
			echo '</table>';
			parent::displayPost($prev,$pages,$next);
		}		
		function abbrevOutput($row,$i){
			global $langA;
			echo '<tr '.$this->classes[($i%2)].'>';
			echo '<td>'.toDisplay($row['owner']).'</td>';
			echo '<td>'.translateLevel($row['userlevel']).'</td>';
			
			$temp = wbStr_replace('.','',$row['owner']);
			if( !is_numeric($temp) ){
				
				echo '<td class="sm">'.wbLinks::user($row['owner'],$langA['homepage']).'</td>';
				echo '<td class="sm">'.wbLinks::special('ControlPanel','control_panel','',$row['owner']).'</td>';
			}else{
				echo '<td> </td><td> </td>';
			}
			
			echo '<td class="sm">';
			$img = '<img src="'.wbLinks::getDir('/imgs/icons/pencil.gif').'">';
			echo wbLinks::special('Permissions?guest='.$row['owner'],$img,'title="'.$langA['SET_USER_PERMISSIONS'].$row['owner'].'"',$_SESSION['username']);
			
			echo '</td>';
			
			
			echo '</tr>';
		}

	
	}
	
	new friends();


//
//
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//

	function translateLevel($arg){
		global $page,$pageOwner,$langA;
		global $wbConfig;
	
		
		if(is_numeric($arg) ){
		
			switch((int)$arg){		
				//
				case 5:
				return $langA['admin'];
				
				case 4:
				case 3:
				return $langA['full_owner'];
				
				case 2:
				return $langA['workgroup'];
				
				case -1:
				return $langA['banned'];
				
				default:
					trigger_error('Unknown User Level: '.$arg);
				return $langA['undefined'];
			}
		}
		
		switch($arg){
			case $langA['admin'];
			
				if( isOwner(false,true) && strcasecmp($pageOwner['username'],$GLOBALS['wbAdminUser']) === 0 ){
					return 5;
				}else{
					return -1;
				}
				
			
			case $langA['full_owner'];
			return 3;
			
			
			case $langA['workgroup'];
			return 2;
			
			case $langA['banned'];
			default:
			return -1;
		}
		return;
	}