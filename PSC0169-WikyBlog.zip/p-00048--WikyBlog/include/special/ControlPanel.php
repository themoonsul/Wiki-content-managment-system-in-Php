<?php
defined('WikyBlog') or die("Not an entry point...");



class cPanel{
	
	
	function cPanel(){
		global $pageOwner,$langA,$page,$dbObject,$wbAdminUser;
		
		$contentUri = $page->regLink($langA['control_panel'],'/Special/'.$pageOwner['username'].'/ControlPanel');
		if( isAdmin(false) ){
			$adminUri = $page->regLink($langA['administration'],'/Special/'.$wbAdminUser.'/ControlPanel?a');
			//$adminUri = $page->regLink($langA['administration'],'/Admin/'.$wbAdminUser.'/ControlPanel');
		}
		
		$getAdmin = false;
		if( isAdmin(false) && isset($_GET['a'])  ){
			$getAdmin = true;
		}
		
		$this->pluginLangFiles();
		
		// if( !isset($_GET['a']) || !$getAdmin){
		// 	$this->newAll($contentUri);
		// }
		
		if( $getAdmin ){
			$this->adminPanel($adminUri);
			$page->regLink('?','Admin/Control_Panel?en=Admin/Control_Panel');

		}else{
			$this->newAll($contentUri);
			$page->regLink('?',$langA['control_panel'].'?en=Control_Panel'); //'Control_Panel'
		}
	}
	
	//
	//	All Users
	//
	function newAll($contentUri){
		global $wbTables,$langA, $page, $pageOwner;
		$page->css2 = true;
		ob_start();
		
		echo '<table style="margin:0 auto 1em auto" >';
		echo '<tr><td style="text-align:center">';
		echo '<h1 class="heading">';
		echo wbLinks::user($pageOwner['username']);
		echo '</h1>';
		$users = array();
		$users[] = $GLOBALS['wbConfig']['pUser'];
		
		if( !empty($_SESSION['username']) ){
			if( !wbStrcasecmp($GLOBALS['wbConfig']['pUser'],$_SESSION['username']) ){
				$users[] = $_SESSION['username'];
			}
			$query = 'SELECT IF(`owner` = "'. wbDB::escape($_SESSION['username']) .'", `guest`,`owner`) as `username` FROM '.$wbTables['workgroup'];
			$query .= ' WHERE ';
			$query .= ' `userlevel` > 0 ';
			$query .= ' AND `type` = "username" ';
			$query .= ' AND (`owner` = "'. wbDB::escape($_SESSION['username']) .'" OR `guest` = "'. wbDB::escape($_SESSION['username']) .'" ) ';
			$result = wbDB::runQuery($query);
			while($row = mysql_fetch_assoc($result) ){
				$users[] = $row['username'];
			}
		}
		$users = array_unique( $users );
		sort($users);
		if( count($users) > 1 ){
			$action = wbLinks::getUrl('/redir');
			//echo '<div class="WBeditArea1">';
			echo '<form onsubmit="return WB.RS(event)" action="'.$action.'" method="post" style="margin:0;padding:0;display:inline;" enctype="application/x-www-form-urlencoded">';
			echo '<input type="hidden" name="wbRedir" value="wbRedir" /> ';
			echo '<input type="hidden" name="root" value="/Special" /> ';
			
			echo '<select name="title">';
			foreach($users as $username){
				echo '<option value="/'.$username.'/ControlPanel">'.$username.'</option>';
				//echo showArray($users);
			}
			echo '</select>';
			echo ' &nbsp; ';
			echo '<input type="submit" name="cmd" value="'.$langA['go'].'" />';
			echo '</form>';
			
			//echo '</div>';
		}
		
		echo '</td></tr></table>';
		
		
		// if( isset($_SESSION['username']) && $_SESSION['username'] != $pageOwner['username'] ){
		// 	$link = wbLinks::special('ControlPanel','control_panel','',$_SESSION['username']);
		// 	echo '<div style="margin-bottom:1em">';
		// 	echo wbLang::text('CONTROL_PANEL_1',$pageOwner['username']);
		// 	echo '<br/>';
		// 	echo wbLang::text('CONTROL_PANEL_2',$link);
		// 	echo '</div>';
		// }
		
					
		$query = 'SELECT * FROM '.$wbTables['config_links'];
		$query .= ' WHERE ';
		$query .= ' `visible` > 0';
		$query .= ' AND `enabled` > 0';
		$query .= ' AND `userlevel` <= "'. wbDB::escape($_SESSION['userlevel']) .'" ';
		$query .= ' AND `userlevel` < 5 '; //don't show admin  scripts yet
		$query .= ' ORDER BY `order_group`, `order_link` ';
		$result = wbDB::runQuery($query);
		
		cPanel::showResult($result);
		
		//credits
		echo '<div class="sm" style="text-align:center">';
		echo wbLinks::special('Credits','Credits');
		echo '</div>';
		
		$page->contentB[$contentUri] = wb::get_clean();
	}
	
	
	//
	//	Show
	//
	function showResult($result, $editLink = false ){
		global $langA;
		
		if( $editLink ){
			if( strpos($editLink,'?') === false ){
				$editLink .= '?';
			}else{
				$editLink .= '&';
			}
		}
		
		//organize
		$links = array();
		$headers = array();
		while( $row = mysql_fetch_assoc($result) ){
			$header = $row['header'];
			if( isset($langA[$header]) ){
				$header = $langA[$header];
			}
			if( !isset($links[$header]) ){
				$links[$header] = '';
			}
			$links[$header] .= cPanel::organizeLink($row);
			
			if( !isset($headers[$header]) ){
				$headers[$header] = $row['order_group'];
			}
		}
		
		//show
		echo '<table width="95%">';
		$n = 0;
		foreach($links as $area => $txt){
			if( empty($txt) ){
				continue;
			}
			
			if( $n%3 == 0){
				if( $n > 0 ){
					echo '</td></tr>';
				}
				echo '<tr>';
			}else{
				echo '</td>';
			}
			//this isn't going to work with createnew
			if(  $editLink ){
				echo '<td width="33%"  onmouseover="WB.SI(this.firstChild)" onmouseout="WB.HI(this.firstChild)" class="wbCPanelBlock">';
				echo '<h3 class="underline" style="white-space:nowrap;height:17px;">';
				echo $area;
				echo ' <span style="display:none" class="sm">';
				if( $n > 0 ){
					$label =  '<img alt="" height="16" style="vertical-align:middle" width="16" src="'.wbLinks::getDir('/imgs/icons/arrow_up.gif').'" />';
					echo wbLinks::local($editLink.'cmd=groupup&grp='.$headers[$area],$label);
					echo '  ';
				}
				$label =  '<img alt="" height="16" style="vertical-align:middle" width="16" src="'.wbLinks::getDir('/imgs/icons/link.gif').'" />';
				echo wbLinks::admin('ConfigLinks',$label);
				echo '</span>';
				echo '</h3>';
			}else{
				echo '<td width="33%" class="wbCPanelBlock">';
				echo '<h3 class="underline" style="white-space:nowrap">';
				echo $area;
				echo ' &nbsp; ';
				echo '</h3>';
			}
			
			echo '<ul class="wbCPanelList">';
			echo $txt;
			echo '</ul>';

			$n++;
		}
		echo '</td></tr>';
		echo '</table>';				
	}
			
	
	function organizeLink(&$row){
		if( !isset($row['label']) ){
			$row['label'] = $row['link'];
		}
		
		//special display cases
		switch($row['display']){
			case 'createnew':
			return cPanel::getCreateNew();
			
			case 'login':
			return cPanel::getLogin();
			
			case 'register':
			return cPanel::getRegister();
			
			case 'lostpass':
			return cPanel::getLostPass();
			
			case 'manageimages':
			return cPanel::getManageImages();
			
			case 'managefiles':
			return cPanel::getManageFiles();
			
			case 'uploadfiles':
			return cPanel::getUploadFiles();
			
			case 'edittemplate':
			return cPanel::getEditTemplate();
			
			case 'search':
			return cPanel::getSearch();
			
			case 'blog':
			return cPanel::getBlog();
			
			case 'browsemaps':
			return cPanel::getBrowsemaps();
			
			case 'atom_blog':
			return cPanel::getAtomBlog();
			
			case 'atom':
			return cPanel::getAtomModified();
			
			case 'atom_posted':
			return cPanel::getAtomPosted();
			
			case 'google_gadget':
			return cPanel::getGoogleGadget();

			//admin cases
			case 'scheduled_tasks':
			return cPanel::getScheduledTasks();
			
			case 'software_content':
			return cPanel::getSoftwareContent();
			
			case 'software_version':
			return cPanel::getVersion();
		}
			
		
		$linkTemp = '<li>';
		if( empty($row['img']) ){
			$linkTemp .= '<img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> ';
		}else{
			$linkTemp .= '<img alt="" height="16" width="16" src="'.wbLinks::getDir($row['img']).'" /> ';
		}
		if( (int)$row['userlevel'] ===  5 ){
			$linkTemp .= wbLinks::admin($row['link'],$row['label']);
		}else{
			$linkTemp .= wbLinks::special($row['link'],$row['label']);
		}
		
		$linkTemp .= '</li>';
		return $linkTemp;
		
	}
	
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//	Special display functions
	//

	function getCreateNew(){
		global $pageOwner;
		
		if( isset($wbConfig['allUsers']) && $wbConfig['allUsers'] == 'Off'){
			if( toStorage($GLOBALS['wbAdminUser'],true) !== toStorage($pageOwner['username'],true) ){
				if( toStorage($GLOBALS['wbConfig']['pUser'],true) !== toStorage($pageOwner['username'],true) ){
					return '';
				}
			}
		}
		$createNew = createNew($pageOwner['username'],' style="font-size:100%;width:12em;" ');
		if( !$createNew ){
			return '';
		}
		
		$text = '<li>';
		$text .= '<table cellpadding="0" cellspacing="0" border="0"><tr><td>';
		$text .= '<img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white_add.gif').'" />&nbsp;';
		$text .= '</td><td>';
		$text .= '';
		$text .= $createNew;
		$text .= '</td></tr></table>';
		$text .= '</li>';
		
		return $text;
	}
	
	function getLogin(){
		global $pageOwner, $langA;
		
		$links = '';
		
		if( empty($_SESSION['username']) ){
			$_POST += array('username'=>'');
			
			$action = wbLinks::getUrl('/Special/'.$pageOwner['username'].'/ControlPanel');
			$temp = '<form onsubmit="return WB.RS(event)" action="'.$action.'" method="post" style="margin:0;padding:0;display:inline;">';
			
			$temp .= '<table border="0" cellpadding="0" cellspacing="0" style="margin:0;padding:0;display:inline;">';
				$temp .= '<tr><td>';
					$temp .= $langA['username'].': ';
				$temp .= '</td><td class="sm">';
					$temp .= ' <input type="text" name="username" size="15" value="'.wbHtmlspecialchars($_POST['username']).'" />';
				$temp .= '</td></tr>';
				
				$temp .= '<tr><td style="white-space:nowrap">';
					$temp .= $langA['password'].': ';
				$temp .= '</td><td class="sm">';
					$temp .= ' <input type="password" name="password" size="15" />';
				$temp .= '</td></tr>';
				
				$temp .= '<tr><td style="white-space:nowrap">';
					$temp .= $langA['remember_me'].': ';
				$temp .= '</td><td class="sm">';
					$temp .= ' <input type="checkbox" name="remember" value="on" checked="checked" /> ';
				$temp .= '</td></tr>';
				
				$temp .= '<tr><td colspan="2" class="sm" style="text-align:center">';
					$temp .= ' <input type="submit" name="none" value="'. $langA['log_in'] .'" />';
				$temp .= '</td></tr>';
				
			$temp .= '</table>';
			$temp .= '<input type="hidden" name="session" value="log in" />';
			$temp .= '</form>';
			
			$links .= '<li>'.$temp.'</li>';	
		}
		return $links;
	}
	
	function getRegister(){
		
		if( empty($_SESSION['username']) ){
			return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/user_add.gif').'" /> '.wbLinks::special('Register','register','',$GLOBALS['wbConfig']['pUser']).'</li>';
		}
		return '';
	}
	
	function getLostPass(){
		if( empty($_SESSION['username']) ){
			return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/email.gif').'" /> '.wbLinks::special('LostPassword','lost_password','',$GLOBALS['wbConfig']['pUser']).'</li>';
		}
		return '';
	}
	
	function getManageImages(){
		global $pageOwner, $langA;
		
		$label = $langA['manage_images'];
		// if( isset($pageOwner['imgs']) && count($pageOwner['imgs']) > 0){
		// 	$label .= ' <span class="sm">('.count($pageOwner['imgs']).')</span>';
		// }
		
		return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/folder_image.gif').'" /> '.wbLinks::special('ImageManager',$label).'</li>';
	}
	
	function getManageFiles(){
		global $pageOwner, $langA;
		
		$label = $langA['manage_files'];
		
		// if( isset($pageOwner['files']) && count($pageOwner['files']) > 0){
		// 	$label .= ' <span class="sm">('.count($pageOwner['files']).')</span>';
		// }
		return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/folder_page.gif').'" /> '.wbLinks::special('FileManager',$label).'</li>';
	}
	
	function getUploadFiles(){
		global $pageOwner;
		
		$link = '/Attach/'.$pageOwner['username'].'?cmd=uploadform';
		return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/picture_save.gif').'" /> '.wbLinks::local($link,'upload_files').'</li>';
	}
		
	function getEditTemplate(){
		global $pageOwner;
		
		if( isset($pageOwner['template']) ){
			$link = '/Theme/'.$pageOwner['template'].'?cmd=edit';
			return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/layout.gif').'" /> '.wbLinks::local($link,'current_theme').'</li>';
		}else{
			return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/layout.gif').'" /> '.wbLinks::special('Templates?cmd=copy&which='.$pageOwner['pTemplate'],'customize_this_theme').'</li>';
		}
	}

	
	function getSearch(){
		global $pageOwner, $langA;
		
		if( isset($GLOBALS['wbConfig']['search']) && $GLOBALS['wbConfig']['search'] ){
			$_GET += array('key'=>'');
			
			$action = wbLinks::getUrl('/Special/'.$pageOwner['username'].'/Search');
			$temp = '<form onsubmit="return WB.RS(event)" action="'.$action.'" method="get" style="margin:0;padding:0;display:inline;">';
			$temp .= '<input type="text" name="key" size="20" />';
			$temp .= '<input type="text" name="search" value="" size="5"  style="display:none" /> '; //so that explorer will react correctly with a return
			$temp .= ' <input type="submit" value="'.$langA['search'].'"  />';
			$temp .= '</form>';
			$temp =  '<li>'.$temp.'</li>';
			
			$temp .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/magnifier.gif').'" /> '.wbLinks::special('Search','advanced_search').'</li>';
			return $temp;
		}
		return '';
	}
	
	function getBlog(){
		global $pageOwner, $langA;
		return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::special('Blog','blog').'</li>';
	}
	
	function getBrowsemaps(){
		global $googleMapKeys, $langA;
		
		if( !empty($googleMapKeys) && (count($googleMapKeys) > 0) ){
			return '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/map.gif').'"/> '.wbLinks::special('BrowseAll?space=map','CLASSmap').'</li>';
		}
		return '';
	}
	
	function getAtomBlog(){
		global $pageOwner, $langA;
		
		$atomFeed = wbLinks::getUrl('/Special/'.$pageOwner['username'].'/atom');
		
		return '<li><img alt="" height="11" width="30" src="'.wbLinks::getDir('/imgs/atom.gif').'" /> <a href="'.$atomFeed.'?field=blog" target="_blank">'.$langA['blog'].'</a></li>';
		
	}
	
	function getAtomModified(){
		global $pageOwner, $langA;
		$atomFeed = wbLinks::getUrl('/Special/'.$pageOwner['username'].'/atom');
		return '<li><img alt="" height="11" width="30" src="'.wbLinks::getDir('/imgs/atom.gif').'" /> <a href="'.$atomFeed.'" target="_blank">'.$langA['recently_modified'].'</a></li>';
	}
	
	function getAtomPosted(){
		global $pageOwner, $langA;
		$atomFeed = wbLinks::getUrl('/Special/'.$pageOwner['username'].'/atom');
		return '<li><img alt="" height="11" width="30" src="'.wbLinks::getDir('/imgs/atom.gif').'" /> <a href="'.$atomFeed.'?field=1" target="_blank">'.$langA['recently_posted'].'</a></li>';
	}
	
	function getGoogleGadget(){
		global $serverName4, $pageOwner;
		$return = '';
		 
		$googleGadget = $serverName4.'/Special/'.$pageOwner['username'].'/ChangeLogGadget';
		
		$atomFeed = wbLinks::getUrl('/Special/'.$pageOwner['username'].'/atom?field=blog');
		$atomFeed = rawurlencode($atomFeed);

		//	Google
		//http://www.google.com/webmasters/add.html
		//small image <img src="http://gmodules.com/ig/images/plus_google.gif" border="0" alt="Add to Google">
		$return .= '<li><a href="http://fusion.google.com/add?moduleurl='.$atomFeed.'"><img src="http://buttons.googlesyndication.com/fusion/add.gif" width="104" height="17" border="0" alt="Add to Google" /></a></li>';

		//	Yahoo
		//	http://publisher.yahoo.com/rss_guide/submit.php#addtomy
		//$return .= '<li><a href="http://us.rd.yahoo.com/my/atm/'.$pageOwner['username'].'/Blog/*http://add.my.yahoo.com/rss?url='.$googleGadget.'""><img src="http://us.i1.yimg.com/us.yimg.com/i/us/my/addtomyyahoo4.gif" width="91" height="17" border="0" align="middle" alt="Add to My Yahoo!"></a></li>';
		
		return $return;
		
		
	}
		
	function getScheduledTasks(){
		global $wbMaintain;
		
		$text = '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/database_gear.gif').'" /> '.wbLinks::admin('ScheduledTasks','run_scheduled_tasks');
		$text .= '<br/><span class="sm">Last run: '.$wbMaintain.'</span></li>';
		return $text;
	}
	function getSoftwareContent(){
		global $wbAdminUser;
		$text = '';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Register','register').'</li>';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Registered','registered').'</li>';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Logged_In','Logged In').'</li>';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Lost Page','lost_page').'</li>';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Suspended','suspended').'</li>';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Disabled','disabled').'</li>';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Pending','pending').'</li>';
		$text .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/page_white.gif').'" /> '.wbLinks::local('/'.$wbAdminUser.'/Template:Restricted','restricted').'</li>';
		return $text;
	}
	
	function getVersion(){
		global $wbConfig,$packageVersion, $wbWritable;
		
		if( isset($wbConfig['newVersion']) && !version_compare($wbConfig['newVersion'],$packageVersion,'=') ){
			$message = '<img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/error.gif').'" style="vertical-align:middle" /> WikyBlog <a href="http://sourceforge.net/project/showfiles.php?group_id=148518&package_id=163821" target="_blank">Version '.$wbConfig['newVersion'].'</a> is now available.';
		}else{
			$message = '<img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/tick.gif').'" /> Version '.$packageVersion;
		}
		if( isset($wbWritable) && $wbWritable === false ){
			if( ini_get('safe_mode') ){
				$message .= '<br/><span class="sm">(In Safe Mode)</span>';
			}
			$message .= '<br/><span class="sm">(Limited Writability)</span>';
		}
		return '<li>'.$message.'</li>';			
	}
	

	
	///////////////////////////////////////////////////////////////////////////
	//
	//	Administration
	//
		function confirmPassword(){
			global $wbDirPrefix,$wbTablePrefix,$wbTables;
			if( empty($_POST['password'])){
				message('ENTER_PASSWORD');
				return false;
			}
			
			$query = 'SELECT username FROM '.$wbTables['users'];
			$query .= ' WHERE username = "'. wbDB::escape($_SESSION['username']) .'" ';
			$query .= ' AND password = "'. md5($_POST['password']) .'" ';
			$query .= ' LIMIT 1 OFFSET 0';
			$result = wbDB::runQuery($query);
			$num = mysql_num_rows($result);
			if( $num === 1){
				$_SESSION['adminConfirmed'] = mktime();
				return true;
			}else{
				message('confirmation_failed');
				return false;
			}
		}
		function confirmPasswordForm(){
			global $page,$langA,$pageOwner,$dbObject;
			$page->css2 = true;
			
			$action = wbLinks::getUrl('/Special/'.$GLOBALS['wbConfig']['pUser'].'/ControlPanel?a');
			//$action = wbLinks::getUrl('/Admin/'.$GLOBALS['wbConfig']['pUser'].'/ControlPanel');
			echo '<form onsubmit="return WB.RS(event)" action="'.$action.'" method="post" >';
				
			echo '<table  cellpadding="7" class="WBeditArea1" style="margin: 2em auto 1em auto">';
			echo '<tr><td colspan="2"><b>';
				echo $langA['CONFIRM_PASSWORD'];
				echo '</b></td></tr>';
			echo '<tr><td style="text-align:right">';
				echo $langA['username'];
				echo ':</td><td>';
				echo '<b>'.$_SESSION['username'].'</b>';
				echo '</td></tr>';
			echo '<tr><td style="text-align:right">';
				echo $langA['password'];
				echo ':</td><td>';
				echo '<input type="password" name="password" size="20" />';
				echo '</td></tr>';
			echo '<tr><td style="text-align:right">';
				echo '</td><td>';
				echo '<input type="submit" name="confirmPass" value="'.$langA['log_in'].'" />';
				echo '</td></tr>';
			echo '</table>';
			
			if( isset($_POST['requested']) ){
				echo '<input type="hidden" name="requested" value="'.wbHtmlspecialchars($_POST['requested']).'" >';
				echo '<input type="hidden" name="req_title" value="'.wbHtmlspecialchars($_POST['req_title']).'" >';
			}elseif(isset($dbObject->uniqLink)){
				echo '<input type="hidden" name="requested" value="'.wbHtmlspecialchars($dbObject->uniqLink).'" >';
				echo '<input type="hidden" name="req_title" value="'.wbHtmlspecialchars($dbObject->pluginTitle).'" >';
			}
			echo '<input type="text" name="none" value="none" style="display:none" />';//need another input so hittting the return button will work correctly in Explorer
				
			echo '</form>';
			
		}
		
		function adminPanel($adminUri){
			global $page;
			
			$cleared = false;
			wbLang::getFile('ADMIN');
			ob_start();
			
			
			//if the user hasn't been confirmed yet
			//	no actions should be done
			if( isset($_SESSION['adminConfirmed']) ){
				$diff = mktime()-$_SESSION['adminConfirmed'];
				
				if($diff > 3600){//one hour
					unset($_SESSION['adminConfirmed']);
				}else{
					$cleared = true;
					if( $diff > 1200 ){
						$_SESSION['adminConfirmed'] = mktime();
					}
				}
			}
			
			if( !$cleared && isset($_POST['password']) ){
				$cleared = $this->confirmPassword();
			}
			if( $cleared ){
				$this->newAdminLinks($adminUri);
				//$this->adminLinks();
			}else{
				$this->confirmPasswordForm();
			}
			
			$page->contentB[$adminUri] = wb::get_clean();
		}
				
		
	//
	//	Admin Links
	//
		function newAdminLinks($adminUri){
			global $wbTables,$langA, $page, $pageOwner;
			$links = array();
			
			
			switch($page->userCmd){
				case 'groupup':
					includeFile('admin/ConfigLinks.php',false);
					ConfigLinks::groupUp(true,true);
				break;
			}
				
			if( !empty($_POST['requested']) ){
				message('go_to',wbLinks::local($_POST['requested'],$_POST['req_title']));
			}
						
			$query = 'SELECT * FROM '.$wbTables['config_links'];
			$query .= ' WHERE ';
			$query .= ' `visible` > 0';
			$query .= ' AND `enabled` > 0';
			$query .= ' AND `userlevel` = 5 ';
			$query .= ' ORDER BY `order_group`, `order_link` ';
			$result = wbDB::runQuery($query);
			cPanel::showResult($result,$adminUri);
		}

		
		function adminLinks(){
			
			//$links['Software'] .= '<li><img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/error.gif').'" /> '.wbLinks::admin('potfile','Create POT file').'</li>';
			// $links['Software'] .= '<li class="sm" style="white-space:normal">Note: You can easily print out messages with the use of the "message()" function. </li>';
			// $links['Software'] .= '<li class="sm" style="white-space:normal">Note: Query analysis can be seen by setting <tt>wbDebugQueryInfo</tt> and <tt>wbDebugQueryMess</tt> values to true in your wiki2.php file.</li>';
			// $links['Software'] .= '<li class="sm" style="white-space:normal">If your installation of WikyBlog is not accessible via the internet, and you would like to play around with the php code, I recommend uncommenting or adding the line "define(\'wbDebug\',true);" to the beginning of your wiki.php file.</li>';
					
		}
		
		
		//not currently being used
		function findSimilar($title){
			global $wbTables;
			
			$langA['LOOKING_FOR'] = 'Were you looking for one of these links: %s';

			if( strlen($title) < 3 ){
				return;
			}
			
			
			$query = 'SELECT `link`, `id` FROM '.$wbTables['config_links'];
			$query .= ' WHERE `userlevel` <= "'.$_SESSION['userlevel'].'" ';
			$query .= ' AND INSTR(`link`, "'.$title{0}.'") ';
			$query .= ' AND INSTR(`link`, "'.$title{1}.'") ';
			$query .= ' AND INSTR(`link`, "'.$title{2}.'") ';
			$query .= ' AND !INSTR(`link`, "?") ';
			$result = wbDB::runQuery($query);
			$similar = array();
			$maxPerc = 0;
			$maxLink = false;
			while($row = mysql_fetch_assoc($result) ){
				similar_text ($row['link'],$title,$perc);
				if( $perc > $maxPerc ){
					$maxPerc = $perc;
					$maxLink = $row['id'];
				}
			}
			if( $maxLink ){
				$query = 'SELECT * FROM '.$wbTables['config_links'];
				$query .= ' WHERE `id` = "'.$maxLink.'" ';
				$result = wbDB::runQuery($query);
				$row = mysql_fetch_assoc($result);
				$link = cPanel::organizeLink($row);
				
				$mess = wbLang::text('LOOKING_FOR','<ul class="wbCPanelList">'.$link.'</ul>');
				message($mess);
				//message('Were you looking for '.$maxLink);
			}
			
		}
		
		
	
		function pluginLangFiles(){
			global $wbTables,$wbPluginDir;
			
			
			//language files
			$query = 'SELECT `data`,`selector` FROM '.$wbTables['ad_objects'];
			$query .= ' WHERE ';
			$query .= ' `selector` LIKE "adminLang:%" ';
			$result = wbDB::runQuery($query);
			while($row = mysql_fetch_assoc($result) ){
				$wbPluginDir = substr($row['selector'],'10');
				wbLang::pluginFile($row['data']);
			}
			$wbPluginDir = false;
		}


}

global $initiateFileClass;

if( $initiateFileClass === true){
	new cPanel();
}
