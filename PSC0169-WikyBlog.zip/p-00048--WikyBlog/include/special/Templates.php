<?php
//$langA checked

defined('WikyBlog') or die("Not an entry point...");

/*

screenShot.png	height=140 width=250

*/

class specTemplates{
	var $themes = array();
	var $themesDir;
	var $contentUri;
	
	function specTemplates(){
		global $page,$langA,$dbObject,$pageOwner,$includeDir,$jsNum;
		
		$this->contentUri = $page->regLink($langA['pTemplate'],'/Special/'.$pageOwner['username'].'/Templates');
		$page->regLink('?',$langA['pTemplate'].'?en=Package Themes');
		$page->displayTitle = $langA['pTemplate'];
		
		$this->themesDir = $includeDir.'/themes';
		$this->isOwner  = isOwner(false,false);

		//$page->scripts[] = '/include/js/templates.js?'.$jsNum;
		
		//	Set the Names of the Templates here
		//
		
		includeFile('themes/data.php');
		$this->themes = returnThemeData();
		
		ob_start();
		
		//$this->getAll();
		
		switch($page->userCmd){
			
			case 'view':
				$this->loremIpsum();
			break;
			
			case 'copy':
				$this->copyOne();
			break;
			
			case 'overlay':
				$this->overlay();
			break;
			
			default:
				$this->displayAll();
			break;
		}
		
		
		$page->contentB[$this->contentUri] = wb::get_clean();
	}
	
	
	//
	//	Overlay with Iframe
	//
	function overlay(){
		global $page,$jsNum;
		
		
		if( $page->ajaxRequest ){
			
			//show as overlay
			includeFile('tool/ShowAsOverlay.php');
			ShowAsOverlay($this->contentUri .'?cmd=view&which='.$_GET['which']);
			
		}else{
			
			//show whole page;
			$this->loremIpsum();
		}
		
		
		return true;
	}
	
	function isTheme($fullPath){
		
		list($style,$color) = explode('/',$fullPath);
		if( isset($this->themes[$style][$color]) ){
			return true;
		}
		return false;
		
	}
	
	function loremIpsum(){
		global $page,$dbObject,$langA,$pageOwner;
		
		$theme = $_GET['which'];
		if( !$this->isTheme($theme) ){
			message('INVALID_REQUEST');
			return false;
		}
		
		$page->packageTemplate($theme);

		?>
		<p>
		Lorem ipsum dolor sit amet, <a href="#">consectetuer</a> adipiscing elit. Nam condimentum eros eu orci. Pellentesque et tellus eget diam aliquet venenatis. Maecenas tellus. Donec at diam ut nisi fringilla congue. Nunc convallis diam sed mi. Fusce vel tellus quis <a href="#">libero suscipit</a> lobortis. Vivamus purus enim, tincidunt a, ullamcorper quis, semper sit amet, velit. Donec porttitor, massa eu dignissim auctor, ipsum massa elementum nunc, vitae aliquet sem arcu ac magna.
		</p>

		
		<h2>Sed Euismod</h2>
		<p>
		Sed euismod mollis purus. Duis ante eros, molestie eget, mattis vel, tempor sed, sapien. <a href="#">Etiam iaculis</a> ligula. Sed laoreet porttitor turpis. Donec pellentesque. Ut ligula tellus, auctor et, rutrum id, laoreet ac, urna. Nulla <a href="#">fringilla nibh</a> sit amet libero. Etiam ut tellus. Donec sapien arcu, accumsan eget, consectetuer in, fermentum non, sem. Maecenas urna. Nulla nonummy, nunc et condimentum sollicitudin, ante sapien ullamcorper justo, at ultricies tellus pede ut ante. 
		</p>
		
		<ul>
		<li>Tincidunt consequat ligula</li>
		<li>Pellentesque et tellus</li>
		<li>Ultricies tellus</li>
		</ul>
		
		
		<h2>Aenean cursus</h2>
		<p>
		Aenean cursus, orci non feugiat tempor, pede <a href="#">justo</a> venenatis velit, euismod ultrices purus libero ac nibh. Duis velit. Morbi fermentum, mi non fermentum tempor, orci odio condimentum dolor, tincidunt consequat ligula dui sit amet dui. In sed augue a erat venenatis iaculis. Duis sit amet ipsum eget eros imperdiet adipiscing. Suspendisse potenti.
		</p>
		<?php
	}
	
	//
	//	copyOne
	//
	function copyOne(){
		global $langA, $page;
		$_GET += array('which'=>'');
		$page->css2 = true;
		
		echo '<table style="margin: 2em auto 2em auto;width:20em;padding:2em;">';
		echo '<tr><td>';

		$action = wbLinks::getUrl('/redir');

		$root = '/Theme/'.$_SESSION['username'].'/';
		
		echo '<form onsubmit="return WB.RS(event)" action="'.$action.'" method="post" style="margin:0;padding:0;display:inline;">';
		echo '<input type="hidden" name="wbRedir" value="wbRedir" /> ';
		echo '<input type="hidden" name="root" value="'.wbHtmlspecialchars($root).'" />';
		echo '<input type="hidden" name="cmd" value="copyDefault" />';
		echo '<input type="hidden" name="which" value="'.wbHtmlspecialchars($_GET['which']).'" />';
		
		echo '<b>'.$langA['copy'].'</b>';
		echo '<table class="WBeditArea1" cellpadding="7"><tr><td>';
			echo '<strong>'.$langA['theme'].'</strong>';
			echo '</td><td>';
			echo $_GET['which'];
		echo '</td></tr><tr><td>';
			echo '<strong>'.$langA['title'].'</strong>';
			echo '</td><td>';
			echo '<input type="text" size="20" name="title" value="" />';
		echo '</td></tr><tr><td>';
			echo '</td><td>';
			echo '<input type="submit" name="null" value="'.$langA['copy'].'" />';
			echo ' &nbsp; ';
			echo wbLinks::special('Templates?a=1','cancel');
		echo '</td></tr></table>';
		echo '</form>';
		
		echo '<td><tr>';
		echo '</table>';
	}
	
	//
	//	displayOne
	//
	function displayOne($name=falsef){
		global $langA,$page,$dbObject,$pageOwner,$wbWritable;
		
		echo '<table border="0">';
			echo '<tr>';
			echo '<td>';
				$fullPath = $this->themesDir.'/'.$name;
				if( !is_file($fullPath.'/screenShot.png') ){
					echo '<img src="'.wbLinks::getDir('/imgs/unavailable.png').'" height="140" width="250" style="margin-right:2em" alt="Screenshot Unavailable" />';
				}else{
					echo '<img src="'.wbLinks::getDir('/include/themes/'.$name.'/screenShot.png').'" height="140" width="250" style="margin-right:2em" alt="Screenshot" />';
				}
				$colors = $this->themes[$name];
				echo '&nbsp;<br/>';
			echo '</td>';
			echo '<td>';
				$this->showColors($name,$colors);
	
			echo '</td>';
			echo '</tr>';
		echo '</table>';
	}
	function showColors($name,$colors){
		global $langA,$pageOwner;

		echo '<table cellpadding="7">';
		$html = $colors['html'];
		
		$i = 0;
		$more = false;
		$total = count($colors)-1; //subtract one because of the html
		foreach($colors as $color => $array){
			
			if( $color === 'html'){
				continue;
			}
			
			if( $i%3 == 0 ){
				if( $i !== 0 ){
					echo '</tr>';
				}
				echo '<tr>';
			}

			echo '<td onmouseover="WB.SI(this)" onmouseout="WB.HI(this)">';
			
			if( is_array($array)){
				array_unshift($array,$html);
				echo call_user_func_array('sprintf',$array);
			}else{
				echo $langA['colors'][$color];
			}
			
			echo '&nbsp;<span style="white-space:nowrap;" class="loadHide">';
			$pTemplate = $name.'/'.$color;
			$viewLink = wbLinks::getUrl('/Special/'.$pageOwner['username'].'/Templates?cmd=view&which='.$pTemplate);
			//echo '<a href="'.$viewLink.'" target="_blank">'.$langA['view'].'</a>';
			
			//echo wbLinks::special('Templates?cmd=overlay&which='.$pTemplate,'view');
			echo wbLinks::js('/Special/'.$pageOwner['username'].'/Templates?cmd=overlay&which='.$pTemplate,'view');
			if( $this->isOwner ){
				echo ' - ';
				echo wbLinks::special('Preferences?cmd=set&pTemplate='.$pTemplate,'use');
				
				if( !isset($wbWritable) || $wbWritable === true){
					echo ' - '; //echo '<br/>';
					echo wbLinks::special('Templates?cmd=copy&which='.$pTemplate,'copy');
					
	 			}
 			}
 			echo '</span>';
			echo '</td>';
			$i++;	
		}
		echo '</tr>';
		echo '</table>';		
	}
	
	
	function displayAll(){
		global $langA;
		
		
		$i=0;
		echo '<table cellpadding="10" width="100%" border="0">';
		
		foreach($this->themes as $name => $null){
			$fullPath = $this->themesDir.'/'.$name;
			
			if( !is_dir($fullPath)){
				continue;
			}
			
			if( $i === 0){
				echo '<tr>';
			}else{
				echo '</tr><tr>';
			}
			echo '<td>';
			
			echo '<h3 class="underline" id="theme'.$name.'">';
			if( isset($langA['themes'][$name]) ){
				echo $langA['themes'][$name];
			}else{
				echo toDisplay($name);
			}
			echo '</h3>';
			
			$this->displayOne($name);
			
			echo '</td>';
			
			$i++;
		}
		echo '</tr></table>';

		
	}
	
}

new specTemplates();