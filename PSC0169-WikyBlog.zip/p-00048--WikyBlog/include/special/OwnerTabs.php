<?php
defined('WikyBlog') or die("Not an entry point...");

if( !isOwner(true,false) ) return false;



class ownerTabs{
	var $special = array();
	
	function ownerTabs(){
		global $page,$pageOwner,$dbObject,$langA,$wbTables;

		$link = $page->regLink($langA['tabs'],'/Special/'.$pageOwner['username'].'/Tabs');
		$page->regLink('?','Owner Tabs?en=Owner Tabs');
		$page->displayTitle = $langA['tabs'];
		$page->autoForm = true;
		$page->css2 = true;
		
		
		if( empty($pageOwner['data2']['tabs']) ){
			
			$homeTitle =toDisplay( $GLOBALS['wbDefaultTitle']);
			if( !empty($pageOwner['homeTitle'])){
				$homeTitle = $pageOwner['homeTitle'];
			}
			
			$list['/'.$pageOwner['username'].'/'.$GLOBALS['wbDefaultTitle']]= $homeTitle;
			$list['/Special/'.$pageOwner['username'].'/ControlPanel']= 'control_panel';
			$list['/Special/'.$pageOwner['username'].'/ChangeLog']= 'change_log';
			$list['/Special/'.$pageOwner['username'].'/BrowsePages']= $langA['browse'].' '.$langA['CLASSpage'];
			$pageOwner['data2']['tabs'] = $list;
		}
		
		//
		//	Special Pages
		//
			$query = 'SELECT `link`, `label` FROM  '.$wbTables['config_links'];
			$query .= ' WHERE ';
			$query .= ' `enabled` > 0 ';
			$query .= ' AND `visible` > 0 ';
			$query .= ' AND `userlevel` < 1 ';
			$query .= ' AND `display` = "" ';
			$result = wbDB::runQuery($query);
			while($row = mysql_fetch_assoc($result) ){
				$this->special[$row['link']] = $row['label'];
			}
			
			
			$this->special['ControlPanel'] =	'control_panel';
			// $this->special['ChangeLog'] = 		'change_log';
			// $this->special['Search'] = 			'search';
			// $this->special['WantedFiles'] = 	'wanted_files';
			// $this->special['DeadEnd'] = 		'dead_end';
			// $this->special['OrphanedFiles'] =	'orphaned_files';
			// $this->special['MostLinked'] =		'most_linked';
			// $this->special['Blog?offset=5'] =	'blog';
			//$this->special['BrowsePages'] = 	$langA['browse'].' '.$langA['CLASSpage'];
			
		//
		//	act
		//
		ob_start();
		
			$show = true;
			$changed = false;
			switch($page->userCmd){
				case 'addpage':
					$this->pageForm();
				break;
				case 'add page':
					$changed = true;
					$this->addPage();
				break;
				case 'add tab':
					$changed = true;
					$this->addTab();
				break;
				case 'remove tab':
					$this->removeTab();
				break;
				
				case wbStrtolower($langA['save']):
					if( $this->saveTab() ){
						break;
					}
				case 'edit':
					$this->editTab();
					$show = false;
				break;
				
				case 'up':
					$this->moveUp();
				break;
				
				case 'optadd':
					$changed = true;
					$this->addFromOptions();
				break;
			}
			
			if( $show ){
				$this->showAll();
			}
// 			if( $changed ){
// 				$this->sendUpdated();
// 			}
			
		$page->contentB[$link] = wb::get_clean();
	}
	
	
// 	//dynamically update links
// 	function sendUpdated(){
// 		global $page, $pageOwner;
// 		
// 		if( !$page->ajaxRequest ){
// 			return;
// 		}
// 		if( $page->interRequest ){
// 			return;
// 		}
// 		
// 		if( isset($_GET['wb']['o']) && ($_GET['wb']['o'] != $pageOwner['user_id'])){
// 			return;
// 		}
// 		
// 		$addContent = new content();
// 		$addContent->aa = 'eval';
// 		$addContent->bb = 'WB.Links';
// 		
// 			var t = dcg('WBtab'+rev);
// 			if(!t){
// 			t = wbCA.NT(lbl,tab,rev,lb2);

// 		
// 		ob_start();
// 		wbPageNormal::getLinks();
// 		$addContent->cc = wb::get_clean();
// 		
// 		$page->contentClasses[] = $addContent;	
// 	}
	
	
	function encode($link){
		$link = base64_encode($link);
		return str_replace(array('/','='),array('.','_'),$link);
	}
	function decode($link){
		$link = str_replace(array('.','_'),array('/','='),$link);
		return base64_decode($link);
	}

	
	//
	//	Show
	//
	function showAll(){
		global $langA;
			

			echo '<table cellpadding="7" cellspacing="0" border="0" style="margin:1em auto 0 auto"  class="WBeditArea1">';
			
			echo '<tr class="tableRows">';
				echo '<th colspan="2">';
				echo $langA['possible'];
				echo '</th>';
				echo '<th>';
				echo $langA['current'];
				echo '</th>';
				echo '</tr>';
			
			
			echo '<tr>';
			echo '<td style="text-align:right;padding:3em;white-space:nowrap">';
			
			$this->newForm();
			echo '<br/>';
			echo '<div class="underline"></div>';
			echo '<br/>';
			$this->showPossible();
			
			echo '</td>';
			
			echo '<td class="historyTimeline">';
			echo '</td>';
			
			echo '<td style="text-align:right;padding:3em;white-space:nowrap">';
			$this->showCurrent();
			
			echo '</td>';
			echo '</tr>';
			
			echo '</table>';
		
	}

	
	function showPossible(){
		global $pageOwner,$langA;
		
		foreach($this->special as $pageName => $langValue){
			
			$link = toStorage('/Special/'.$pageOwner['username'].'/'.$pageName);
			if( isset($pageOwner['data2']['tabs'][$link]) ){
				continue;
			}
			
			
			echo wbLinks::special($pageName,$langValue);
			
			echo ' &nbsp; ';
			echo wbLinks::special('tabs?cmd['.urlencode($pageName).']=Add%20Tab','<img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/add.gif').'" />');
			
			echo '<br/>';
		}	
	}
	
	function newForm(){
		global $langA,$pageOwner;
		
		$homeTitle = toDisplay($GLOBALS['wbDefaultTitle']);
		if( !empty($pageOwner['homeTitle'])){
			$homeTitle = $pageOwner['homeTitle'];
		}
		
		$_POST += array('ownerPage'=>'/Main/'.$GLOBALS['wbDefaultTitle'],'label'=>$homeTitle);
		
		echo '<table border="0" cellpadding="0" cellspacing="0" style="padding:0;margin-right:0;margin-left:auto;">';
		echo '<tr>';
			echo '<td style="text-align:right;padding:0;">';
			echo $langA['link'];
			echo ':&nbsp;';
			echo '</td>';
			echo '<td style="padding:0;">';
			echo ' <input type="text" name="ownerPage" value="'.wbHtmlspecialchars($_POST['ownerPage']).'" size="20" />';
			echo '</td>';
			echo '</tr>';
			
		echo '<tr>';
			echo '<td style="text-align:right;padding:0;">';
			echo $langA['label'];
			echo ':&nbsp;';
			echo '</td>';
			echo '<td style="padding:0;">';
			echo '<input type="text" name="label" value="'.wbHtmlspecialchars($_POST['label']).'" size="20" />';
			echo '</td>';
			echo '</tr>';
			
		echo '<tr>';
			echo '<td>';
			echo '</td>';
			echo '<td style="padding:0;text-align:right">';
			echo '<input type="submit" name="cmd" value="'.$langA['add_page'].'" />';
			echo '</td>';
			echo '</tr>';
			
		echo '</table>';
	}
	
	function showCurrent(){
		global $pageOwner,$langA;
		
		$i = 0;
		foreach($pageOwner['data2']['tabs'] as $pageLink => $langValue){
			
			echo wbLinks::local($pageLink,$langValue);
			
			echo ' &nbsp; ';
			
			
			if( $i == 0 ){
				echo ' <img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/blank.gif').'" />';
			}else{
				$label = ' <img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/arrow_up.gif').'" />';
				echo wbLinks::special('tabs?cmd['.$this->encode($pageLink).']=up',$label);
			}
			
			echo ' &nbsp; ';
			$label = ' <img alt="'.$langA['edit'].'" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/pencil.gif').'" />';
			echo wbLinks::special('tabs?cmd=edit&uri='.$this->encode($pageLink).'',$label);
			
			echo ' &nbsp; ';
			$label = ' <img alt="" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/delete.gif').'" />';
			echo wbLinks::special('tabs?cmd['.$this->encode($pageLink).']=Remove%20Tab',$label);
			
			echo '<br/>';
			$i++;
		}
	}
	
	function saveTab(){
		global $pageOwner,$langA;
		
		if( ($_POST['original_uri'] == $_POST['uri']) && ($_POST['original_label'] == $_POST['label']) ){
			return true;
		}
		$_POST['uri'] = toStorage($_POST['uri']);
		
		$newTabs = array();
		foreach($pageOwner['data2']['tabs'] as $uri => $label){
			if( $uri == $_POST['original_uri'] ){
				$newTabs[$_POST['uri']] = $_POST['label'];
			}else{
				$newTabs[$uri] = $label;
			}
		}
		$pageOwner['data2']['tabs'] = $newTabs;
		return true;
	}
	
	function editTab(){
		global $pageOwner,$langA;
		
		if( isset($_GET['uri']) ){
			$uri = $this->decode($_GET['uri']);
		}else{
			$uri = $_POST['uri'];
		}
		
		
		if( !isset($pageOwner['data2']['tabs'][$uri]) ){
			message('INVALID_REQUEST');
			return;
		}
		$label = $pageOwner['data2']['tabs'][$uri];
		if( isset($langA[$label]) ){
			$label = $langA[$label];
		}
		
		$_POST += array('label'=>$label,'uri'=>$uri);
		
		echo '<input type="hidden" name="original_uri" value="'.wbHtmlspecialchars($uri).'"  />';
		echo '<input type="hidden" name="original_label" value="'.wbHtmlspecialchars($label).'"  />';
		
		echo '<table style="margin:1em auto 1em auto;" cellpadding="7" cellspacing="0" border="0" >';
		echo '<tr><td style="text-align:center">';
		
		echo '<table class="WBeditArea1"  cellspacing="7" border="0" >';
		
		echo '<tr>';
			echo '<td style="text-align:right;padding:0;">';
			echo $langA['link'];
			echo ':&nbsp;';
			echo '</td>';
			echo '<td style="padding:0;">';
			echo ' <input type="text" size="50" name="uri" value="'.wbHtmlspecialchars($_POST['uri']).'" />';
			echo '</td>';
			echo '</tr>';
			
		echo '<tr>';
			echo '<td style="text-align:right;padding:0;">';
			echo $langA['label'];
			echo ':&nbsp;';
			echo '</td>';
			echo '<td style="padding:0;">';
			echo '<input type="text"  size="50" name="label" value="'.wbHtmlspecialchars($_POST['label']).'" />';
			echo '</td>';
			echo '</tr>';		
		
		echo '</table>';
		
		echo '<input type="submit" name="cmd" value="'.$langA['save'].'" />';
		echo ' &nbsp; ';
		echo '<input type="submit" name="cmd" value="'.$langA['cancel'].'" />';
		echo '</td></tr></table>';
		
	}
	
	function addFromOptions(){
		global $pageOwner;
		
		//$links = $_GET['link']
		$pos = strrpos($_GET['uri'],'/');
		if( ($pos > 0) && ($pos != strlen($_GET['uri'])) ){
			$label = substr($_GET['uri'],$pos+1);
		}else{
			$label = $_GET['uri'];
		}
		$_GET['uri'] = toStorage($_GET['uri']);
		$label = toDisplay($label);
		$pageOwner['data2']['tabs'][$_GET['uri']] = $label;
	}
	
	function addPage(){
		global $page,$pageOwner;
		
		$_POST += array('ownerPage'=>'','label'=>'');

		
		$_POST['ownerPage'] = trim($_POST['ownerPage']);
		if( empty($_POST['ownerPage']) ){
			return;
		}
		
		$label = $_POST['ownerPage'];
		if( $_POST['ownerPage']{0} == '/'){
			$link = $_POST['ownerPage'];
			$label = substr($label,1);
		}else{
			$link = '/'.$pageOwner['username'].'/'.$_POST['ownerPage'];
		}
		
		$_POST['label'] = trim($_POST['label']);
		if( !empty($_POST['label']) ){
			$label = $_POST['label'];
		}
		$link = toStorage($link);
		$pageOwner['data2']['tabs'][$link] = $label;
	}
	
	function addTab(){
		global $page,$pageOwner;
		if( isset($this->special[$page->cmdArg[0]]) ){
			$link = toStorage('/Special/'.$pageOwner['username'].'/'.$page->cmdArg[0]);
			$pageOwner['data2']['tabs'][$link] = $this->special[$page->cmdArg[0]];
		}
	}
	function removeTab(){
		global $page,$pageOwner;
		
		if( count($pageOwner['data2']['tabs']) <= 1){
			continue;
		}
		
		$link = $this->decode($page->cmdArg[0]);
		unset($pageOwner['data2']['tabs'][$link]);
	}
	
	function moveUp(){
		global $pageOwner,$page;
		
		$which = $this->decode($page->cmdArg[0]);
		$i = 0;
		$foundAt = false;
		foreach($pageOwner['data2']['tabs'] as $link => $langValue){
			
			if( $link == $which){
				$foundAt = $i;
			}
			$i++;
		}
		if( !$foundAt || $foundAt < 1 ){
			return;
		}
		$whichLang = $pageOwner['data2']['tabs'][$which];
		unset($pageOwner['data2']['tabs'][$which]);
		
		$temp = array();
		
		$i = 0;
		foreach($pageOwner['data2']['tabs'] as $link => $langValue){
			if( $i == ($foundAt-1)){
				$temp[$which] = $whichLang;
			}
			$temp[$link] = $langValue;
			$i++;
		}
		$pageOwner['data2']['tabs'] = $temp;
		
	}
	
}
new ownerTabs();
