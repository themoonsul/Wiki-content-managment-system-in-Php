<?php

defined('WikyBlog') or die("Not an entry point...");

global $dbObject,$page;
$page->regLink('Credits','/Special/Main/Credits');
$page->displayTitle = 'Credits';

?>
	<style>
	.credit{width:50%;}
	.credit h3{margin:0;padding:0;border-bottom: 1px solid #ccc;text-decoration:none;}
	.credit a{text-decoration:none;font-size:90%;}
	.credit p{margin:0;padding: 0 0 0 1em;}
	</style>

<table width="100%" cellpadding="20">
	<td class="credit">
	<h3>Graphics</h3>
	<p>
	<a href="http://www.famfamfam.com">Icons by FamFamFam.com</a>
	</p>
	</td>
</tr>
</table>
<h1>Translators</h1>
<table cellspacing="20" border="0">
<tr>
	<td class="credit"><h4>MuhammetKara</h4>Language: Turkish<p><a href="http://www.muhammetkara.com">http://www.muhammetkara.com</a><br/><a href="/Special/MuhammetKara/pt/UserInfo" rev="L3NwZWNpYWwvbXVoYW1tZXRrYXJhL3B0L3VzZXJpbmZv" >MuhammetKara @ Project Translator</a></p></td>
	<td class="credit"><h4>anindita_basu</h4>Languages: French, Hindi, Bengali<p><a href="/Special/anindita_basu/pt/UserInfo" rev="L3NwZWNpYWwvYW5pbmRpdGFfYmFzdS9wdC91c2VyaW5mbw" >anindita_basu @ Project Translator</a></p></td></tr>
<tr>
	<td class="credit"><h4>ryvkin</h4>Language: Russian<p><a href="mailto:to (at) ryvkin.com">to (at) ryvkin.com</a><br/><a href="/Special/ryvkin/pt/UserInfo" rev="L3NwZWNpYWwvcnl2a2luL3B0L3VzZXJpbmZv" >ryvkin @ Project Translator</a></p></td>
	<td class="credit"><h4>Linostar</h4>Language: Arabic<p>PHP and Python Developer<br/><a href="/Special/Linostar/pt/UserInfo" rev="L3NwZWNpYWwvbGlub3N0YXIvcHQvdXNlcmluZm8" >Linostar @ Project Translator</a></p></td></tr>
<tr>
	<td class="credit"><h4>admin_codru_dot_eu</h4>Languages: Romanian, Italian<p><a href="/Special/admin_codru_dot_eu/pt/UserInfo" rev="L3NwZWNpYWwvYWRtaW5fY29kcnVfZG90X2V1L3B0L3VzZXJpbmZv" >admin_codru_dot_eu @ Project Translator</a></p></td>
	<td class="credit"><h4>z1pher</h4>Language: French<p>First-year computer science student at Dawson College, Montreal.<br/><a href="mailto:z1pher666 (at) gmail.com">z1pher666 (at) gmail.com</a><br/><a href="/Special/z1pher/pt/UserInfo" rev="L3NwZWNpYWwvejFwaGVyL3B0L3VzZXJpbmZv" >z1pher @ Project Translator</a></p></td></tr>
<tr>
	<td class="credit"><h4>NightingaleJ</h4>Language: Japanese<p><a href="/Special/NightingaleJ/pt/UserInfo" rev="L3NwZWNpYWwvbmlnaHRpbmdhbGVqL3B0L3VzZXJpbmZv" >NightingaleJ @ Project Translator</a></p></td>
	<td class="credit"><h4>sunyruru</h4>Language: Korean<p>PHP, .NET, JAVA Developer
Republic of Korea<br/><a href="http://i-ruru.com/">http://i-ruru.com/</a><br/><a href="/Special/sunyruru/pt/UserInfo" rev="L3NwZWNpYWwvc3VueXJ1cnUvcHQvdXNlcmluZm8" >sunyruru @ Project Translator</a></p></td></tr>
<tr>
	<td class="credit"><h4>italian-translate</h4>Language: Italian<p><a href="/Special/italian-translate/pt/UserInfo" rev="L3NwZWNpYWwvaXRhbGlhbi10cmFuc2xhdGUvcHQvdXNlcmluZm8" >italian-translate @ Project Translator</a></p></td>
	<td class="credit"><h4>mavbaby</h4>Language: Dutch<p><a href="http://www.sandstorms-kookboek.nl">http://www.sandstorms-kookboek.nl</a><br/><a href="/Special/mavbaby/pt/UserInfo" rev="L3NwZWNpYWwvbWF2YmFieS9wdC91c2VyaW5mbw" >mavbaby @ Project Translator</a></p></td></tr>
<tr>
	<td class="credit"><h4>Roby_Ajith</h4>Languages: Japanese, Malayalam<p><a href="/Special/Roby_Ajith/pt/UserInfo" rev="L3NwZWNpYWwvcm9ieV9haml0aC9wdC91c2VyaW5mbw" >Roby_Ajith @ Project Translator</a></p></td>
	<td class="credit"><h4>lowfii</h4>Language: Chinese Simplified<p><a href="/Special/lowfii/pt/UserInfo" rev="L3NwZWNpYWwvbG93ZmlpL3B0L3VzZXJpbmZv" >lowfii @ Project Translator</a></p></td></tr>
<tr>
	<td class="credit"><h4>sp200x</h4>Language: Spanish<p>I just love chinese food!
<br/><a href="mailto:reg (at) cafedesign.com.ar">reg (at) cafedesign.com.ar</a><br/><a href="/Special/sp200x/pt/UserInfo" rev="L3NwZWNpYWwvc3AyMDB4L3B0L3VzZXJpbmZv" >sp200x @ Project Translator</a></p></td>
	<td class="credit"><h4>Naweb</h4>Language: Spanish<p><a href="mailto:nawebnaweb (at) hotmail.com">nawebnaweb (at) hotmail.com</a><br/><a href="/Special/Naweb/pt/UserInfo" rev="L3NwZWNpYWwvbmF3ZWIvcHQvdXNlcmluZm8" >Naweb @ Project Translator</a></p></td></tr>
<tr>
	<td class="credit"><h4>jlake</h4>Language: Chinese Traditional<p><a href="/Special/jlake/pt/UserInfo" rev="L3NwZWNpYWwvamxha2UvcHQvdXNlcmluZm8" >jlake @ Project Translator</a></p></td></tr>
</table>


<h1>Powered by WikyBlog</h1>
For more information, see <a href="http://www.wikyblog.com">WikyBlog.com</a>.

