<?php

defined('WikyBlog') or die("Not an entry point...");



class wikyBlogInfo{
	function xml(){
		global $packageVersion;
		header('Content-type: text/xml; charset=UTF-8');
		echo '<wbinfo>';
		//echo '<version>'.$packageVersion.'</version>';
		echo '<version>1.6.1.7</version>';
		echo '</wbinfo>';
		exit();
	}
	function normal(){
		global $page,$pageOwner,$dbObject,$packageVersion,$rootDir;
		
		$page->displayTitle = 'WikyBlog Info';
		$link = $page->regLink('WikyBlog Info','/Special/'.$pageOwner['username'].'/Info');
		
		//
		
		
		ob_start();
		
		
		echo '<blockquote>';
		
		echo '<ul>';
		echo '<li>Current Package: '.$packageVersion.'</li>';
		//echo '<li>Current Package: '.$GLOBALS['wbConfig']['version'].'</li>';
		
		//installed time based on modified time of wiki.php
		// $stats = stat( $rootDir.'/wiki.php');
		// echo '<li>Installed: '.date('D, j M Y G:i:s ',$stats['mtime']).'</li>';

		echo '<li>PHP: '.phpversion().'</li>';
				
		
		$query = 'SHOW VARIABLES LIKE "VERSION";';
		$result = wbDB::runQuery($query);
		$row = mysql_fetch_assoc($result);
		if( array_key_exists('Value',$row) ){
			echo '<li>MySQL: '.$row['Value'].'</li>';
		}
		
		
		
		echo '</blockquote>';
		
		
		$page->contentB[$link] = wb::get_clean();
	}
}

if( isset($_GET['xml']) ){
	wikyBlogInfo::xml();
}else{
	wikyBlogInfo::normal();
}