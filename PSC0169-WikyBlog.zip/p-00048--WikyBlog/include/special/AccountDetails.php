<?php
defined('WikyBlog') or die("Not an entry point...");


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Detailed Info
//

class detailedInfo{
	function detailedInfo(){
		global $page,$dbInfo,$pageOwner,$dbObject,$langA,$wbTables;
		
		switch($page->userCmd){
			case 'export':
				includeFile('special/Export.php');
			return;
		}
		
		ob_start();
		
		////	Start
			$username = wbDB::escape(wbStrtolower($pageOwner['username']));
			$field = $langA['account'].': '.$pageOwner['username'];
			$field = $langA['account_details'];
			
			$contentUri = $page->regLink($field,'/Special/'.$pageOwner['username'].'/AccountDetails');
			$page->regLink('?',$langA['account_details'].'?en=Account_Details');
			
	
		
	
		////	Users Table Query
			echo '<table cellspacing="3" cellpadding="3" border="0">';
			echo '<tr><td>'.$langA['username'].': &nbsp; </td><td>'.$pageOwner['username'].'</td></tr>';
			
			echo '<tr><td>'.$langA['email'].': </td><td>';
				if( isset($pageOwner['email']) ){
					
					echo $pageOwner['email'];
				}
				echo '</td></tr>';
			
				
			$langA['disk_usage'] = 'Disk Usage';
			echo '<tr><td>'.$langA['disk_usage'].': </td><td>';
			if( 	($GLOBALS['maxUserDiskUsage'] > 0) 
				&& !wbStrcasecmp($GLOBALS['wbConfig']['pUser'], $pageOwner['username'])
				){
				if( function_exists('bcdiv') ){
					$perc = bcdiv($pageOwner['totalUsage'], $GLOBALS['maxUserDiskUsage'], 2);
				}else{
					$perc = (float)$pageOwner['totalUsage']/(float)$GLOBALS['maxUserDiskUsage'];
				}
				
				
				echo round($perc*100).'%';
				echo ' of ';
				echo $this->convert($GLOBALS['maxUserDiskUsage']);
				
				echo '<br/>';
				$x = min(60,(60*$perc));
				echo '<span title="'.round($perc*100).'%" class="wbRelevance" style="cursor:pointer">';	
				echo '<img src="'.wbLinks::getDir('/imgs/blank.gif').'" class="wbRelevancePos" alt="" align="absmiddle" border="0" height="7" width="'.ceil($x).'">';
				echo '<img src="'.wbLinks::getDir('/imgs/blank.gif').'" class="wbRelevanceNeg" alt="" align="absmiddle" border="0" height="7" width="'.(60-ceil($x)).'">';
				echo '</span> ';
			}else{
				echo $langA['unlimited'];
			}
			echo '</td>';
			echo '</tr>';
		
								
			echo '</table>';
			
			
			
		////	Table Sizes
			foreach($dbInfo as $space => $info){
				if( !isset($info['dbTable']) ){
					continue;
				}
				if( ($space == 'help') && ($pageOwner['username'] != $GLOBALS['wbAdminUser'])){
					continue;
				}
				
				if( isset($langA[$info['class']]) ){
					
					$showName = $langA[$info['class']];
					
				}elseif($langA[$space]){
					
					$showName = $langA[$space];
					
				}else{
					
					$showName = $info['class'];
				}
				
				$query = ' SELECT "'.$info['dbTable'].'" as `name`, "'.$showName.'" as `showName` , count(*) as `count`, ';
				$query .= ' SUM(`size`) as `sum` ';
				$query .= ' FROM '.$info['dbTable'];
				$query .= ' JOIN '.$wbTables['all_files'].' USING(`file_id` ) ';
				$query .= ' WHERE `owner` = "'.$username.'"';
				$query .= ' GROUP BY `owner` ';
				
				$queryA[] .= '( '.$query.' )';
			}
			
			$query = implode(' UNION ',$queryA);
			
			$result = wbDB::runQuery($query);
			echo '<table border="0" class="tableRows sortable" width="100%">';
			echo '<tr class="sortbottom" ><th>'.$langA['entries'].'</th><th>'.$langA['files'].'</th><th>'.$langA['size'].'</th><th>'.$langA['average'].'</th></tr>';
			$totals['count'] = 0;
			$totals['size'] = 0;
			$classes[] = 'class="tableRowEven" ';
			$classes[] = 'class="tableRowOdd" ';
			$i = 1;
			while($row = mysql_fetch_assoc($result) ){
				$odd = $classes[($i%2)];
				$i++;
	
				echo '<tr '.$odd.'>';
				echo '<td>'.$row['showName'].'</td>';
				echo '<td>'.$row['count'].'</td>';
				$totals['count'] += $row['count'];
				
				//size
				$val = $row['sum'];
				if( is_numeric($row['sum']) && ($row['sum'] > 0) ){
					$echo = $this->convert($row['sum']);
					$totals['size'] += $row['sum'];
				}else{
					$echo = '-';
					$val = 0;
				}
				echo '<td  abbr="'.$val.'">';
				echo $echo;
				echo '</td>';
				
				//averabe size
				if( is_numeric($row['sum']) && ($row['count'] > 0) ){
					$val = round($row['sum']/$row['count']);
					$echo = $this->convert($val);
				}else{
					$echo = '-';
					$val = 0;
				}
				echo '<td abbr="'.$val.'">';
				echo $echo;
				echo '</td>';
				
				echo '</tr>';
			}
			
			echo '<tr class="sortbottom"><th>'.$langA['total'].'</th><th>'.$langA['files'].' </th><th>'.$langA['size'].'</th><th>'.$langA['average'].'</th></tr>';
			if( $totals['count'] != 0){
				echo '<tr class="tableRowEven sortbottom">';
				echo '<td>'.$langA['all'].' </td>';
				echo '<td>'.$totals['count'].'</td>';
				
				
				echo '<td>';
				echo $this->convert($totals['size']);
				echo '</td>';
				
				$val = round($totals['size']/$totals['count']);
				echo '<td abbr="'.$val.'">';
				echo $this->convert($val);
				echo '</td>';
				echo '</tr>';
			}else{
				echo '<tr '.$classes[1].'><td>'.$langA['all'].'</td><td> 0 </td><td> - </td><td> - </td></tr>';
			}
			echo '</table>';
			
			
			echo '<div class="WBfileFooter">';
			echo '<span>';
			echo wbLinks::special('AccountDetails?cmd=export','Export XML');
			//echo '<a href="'.wbLinks::getUrl('/Special/'.$pageOwner['username'].'/AccountDetails?cmd=export').'">Export XML</a>';
			echo '</span>';
			echo '</div>';
			
		////	Output
			$page->contentB[$contentUri] = wb::get_clean();
			
			
		////	Check $pageOwner total
		//	This includes deleted files in the totals
// 			if( $totals['size'] != $pageOwner['totalUsage']){
// 				message('diff ');
// 				message($totals['size']);
// 				message($pageOwner['totalUsage']);
// 			}else{
// 				message('same');
// 			}
	}
	
	function convert( $bytes ){
		global $langA;
		$bytes = floatval($bytes);
		$types = array();
		
		$types[1] = $langA['kb'];
		$types[2] = $langA['mb'];
		$types[3] = $langA['gb'];
		
		
		$i = 0;
		while( ($bytes > 1500) && ($i < 3) ){
			$bytes /= 1024;
			$i++;
		}
		if( $i == 0 ){
			return number_format($bytes).' '.$langA['bytes'];
		}
		
		return number_format($bytes,2).' '.$types[$i];
	}	
}

new detailedInfo();