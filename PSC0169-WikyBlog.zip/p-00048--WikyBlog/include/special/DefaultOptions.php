<?php
defined('WikyBlog') or die("Not an entry point...");

global $dbObject,$page,$dbInfo,$pageOwner,$langA;
if( !isOwner(true,false) ) return false;

//includeFile('tool/Options.php');


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//				FUNCTIONS

class defaultOptions{

	function defaultOptions(){
		global $dbInfo,$page,$langA,$pageOwner;
		
		$contentUri = $page->regLink($langA['default_options'],'/Special/'.$pageOwner['username'].'/defaultOptions');
		$page->regLink('?',$langA['default_options'].'?en=Default_Options');
		$page->autoForm = true;
		
		
		ob_start();
		
		$_GET += array('type' => '');
		$_POST += array('currentType'=>$_GET['type']);
		if( isset($page->cmdArg[0]) && isset($dbInfo[$page->cmdArg[0]]) ){
			$_POST['currentType'] = $page->cmdArg[0];
		}
		
		$this->classSelect();
		
		if( !empty($_POST['currentType']) ){
			$this->classThing($_POST['currentType']);
		}

		$page->contentB[$contentUri] = wb::get_clean();
	}
	
	function classSelect(){
		global $langA,$dbInfo;
		echo '<table id="update" border="0" style="margin-left:auto;margin-right:auto"><tr><td>';
		echo '<h3 class="underline">'.$langA['select_a_file_type'].'</h3> ';
		foreach($dbInfo as $space => $info){
			if( ($space == 'help') ){
				if( $_SESSION['username'] != $GLOBALS['wbConfig']['pUser']){
					continue;
				}
			}
			
			$className = wbData::getClass($space,true);
			if( !$className ){
				continue;
			}
			if( !is_callable(array($className,'options')) ){
				continue;
			}
				
			if( $space == $_POST['currentType']){
				echo ' &nbsp; <b>'.$langA[$space].'</b> &nbsp; ';
				echo '<input type="hidden" name="currentType" value="'.wbHtmlspecialchars($space).'" />';
				continue;
			}
			$label = $langA[$space];
			echo ' <input type="submit" name="cmd['.$space.']" value="'.$label.'" /> ';
		}
		echo '</td></tr></table>';		
	}
	
	function saveOptions($className){
		global $pageOwner,$wbTables,$dbObject;
		$afterFlags = $beforeFlags = array();
		//$dbObject->options(false);
		
		//
		//	Before Flags
		//
			if( !empty($pageOwner['flags'][$className]) ){
				$beforeFlags = explode(',',$pageOwner['flags'][$className]);
			}
		
		
		//
		//	after flags
		//
		
			$do = options::setNewFlags(); //sets $dbObject->flags from POST
			if( !$do ){
				return;
			}
			$afterFlags = explode(',',$dbObject->flags);
		
			$similar = array_intersect($beforeFlags,$afterFlags);
			$beforeFlags = array_diff($beforeFlags,$similar);
			$afterFlags = array_diff($afterFlags,$similar);
			
		//
		//	Update all rows
		//
			$query = 'UPDATE '.$wbTables['all_files'];
			$query .= ' INNER JOIN '.$dbObject->dbInfo['dbTable'];
			$query .= ' USING (`file_id`) ';
			$query .= ' SET `modified` = `modified` ';
			$query .= ', `flags` = ';
			$flagSql = ' IF(`flags` = "",NULL,`flags`) ';//to avoid data truncated warning
			
			foreach($beforeFlags as $flag){
				$flagSql = '  REPLACE('.$flagSql.',"'.wbDB::escape($flag).'","") ';
			}
			foreach($afterFlags as $flag){
				$flagSql = ' CONCAT_WS(",",'.$flagSql.',"'.wbDB::escape($flag).'") '; 
			}
			$flagSql = ' REPLACE('.$flagSql.',",,",",") ';
			$flagSql = ' TRIM("," FROM '.$flagSql.')';
			
			$query .= $flagSql;
			if( (strpos($dbObject->flags,'hidden') !== false)
				|| (strpos($dbObject->flags,'relvisible') !== false)
				){
					$query .= ', `visible` = 0 ';
				}else{
					$query .= ', `visible` = IF( FIND_IN_SET("deleted",`flags`), 0, 1) ';
			}
			
			$query .= ' WHERE FIND_IN_SET("default",`flags`) ';
			$query .= ' and `owner` = "'.$pageOwner['username'].'" ';
			$result = wbDB::runQuery($query);
			
		//
		//	save in $pageOwner
		//
			if( !empty($dbObject->flags) ){
				$pageOwner['flags'][$className] = $dbObject->flags;
				
			}elseif( !empty($pageOwner['flags'][$className]) ){
				unset($pageOwner['flags'][$className]);
			}
			message('OPTIONS_UPDATED');
	}
	
	function classThing($type){
		global $page,$langA,$dbObject;
		
		
		$className = $this->setClass($type);
		$dbObject->options(false);
		
		/////	ACT
			if( $page->userCmd === wbStrtolower($langA['save_options'])){
				$this->saveOptions($className);
			}
		
		echo options::form();
	}
	
	function setClass($type){
		global $dbObject,$dbInfo,$pageOwner;
		
		$type = wbStrtolower($type);
		$className = wbData::getClass($type,true);
		wbData::newObject($type,$dbObject,true);
		
		$dbObject->exists = false;
		
		if( isset($pageOwner['flags'][$className]) ){
			$dbObject->flags = $pageOwner['flags'][$className]; 
		}else{
			$dbObject->flags = '';
		}
		
		return $className;
	}
	
}


	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//				FLOW CONTROL


new defaultOptions();


