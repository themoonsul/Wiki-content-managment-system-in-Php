<?php
defined('WikyBlog') or die("Not an entry point...");



function ccLicenseStep1(){
	global $pageOwner,$langA,$page,$jsNum,$serverName4;
	
	
	$page->scripts[] = '/include/js/licenseCC.js?'.$jsNum;
	
	$exitUrl = $serverName4.'/Special/'.$pageOwner['username'].'/CCLicense';
		
	$exitUrl .= '?license_url=[license_url]';
	$exitUrl .= '%26license_name=[license_name]';
	$exitUrl .= '%26cmd=check';
	
	$ccUrl = 'http://creativecommons.org/license/';
	$ccUrl .= '?partner=WikyBlog.com';
	//$ccUrl .= '&jurisdiction=en';
	$ccUrl .= '&amp;jurisdiction_choose=1';
	$ccUrl .= '&amp;exit_url='.$exitUrl;
	
	
	
	?>
	
	<table class="tableRows" style="margin-left:auto;margin-right:auto">
	<tr><td colspan="2">
	<h3 class="underline"><?php echo $langA['options'] ?></h3>
	</td></tr>
	
	<tr><td>
	<a href="javascript:void(0);" onclick="getLicense('<?php echo $ccUrl ?>');return false;"><?php echo $langA['select_license'] ?></a>
	</td><td class="sm"><?php echo $langA['SELECT_LICENSE_DESC'] ?></td></tr>
	
	
	<?php
	
	echo '<tr><td>';
	if( !empty($pageOwner['licenseTxt']) ){
		echo wbLinks::special('cclicense?cmd=delete','delete');
	}else{
		echo $langA['delete'];
	}
	echo '</td><td class="sm">'.$langA['DELETE_LICENSE_DESC'].'</td></tr>';
	
	echo '</table>';
	
}


function getRDF(){
	global $page,$pageOwner,$langA,$serverName4;
	$page->autoForm = true;
	$rdfContent = false;
	
	//	set values from Creative Commons
	//
	//
	if( isset($_GET['license_url'])){
		$_POST['license_url'] = $_GET['license_url'];
		$_POST['license_name'] = $_GET['license_name'];
		
		//$langA defaults
		$_POST['textBefore'] = $langA['LICENSE_TEXT_BEFORE'];
		$_POST['textLink'] = $langA['LICENSE_TEXT_LINK'];
		$_POST['textAfter'] = $langA['LICENSE_TEXT_AFTER'];
		
	}elseif( empty($_POST['license_url']) ){
		trigger_error('Not a valid request');
		return;
	}
	
	//wbHtmlspecialchars all
	$_POST['license_url'] = wbHtmlspecialchars($_POST['license_url']);
	$_POST['license_name'] = wbHtmlspecialchars($_POST['license_name']);
	$_POST['textBefore'] = wbHtmlspecialchars($_POST['textBefore']);
	$_POST['textLink'] = wbHtmlspecialchars($_POST['textLink']);
	$_POST['textAfter'] = wbHtmlspecialchars($_POST['textAfter']);
		
	
	//GET RDF from Creative Commons
	//		these values that can be passed
	//		license_url, creator, copyright_holder, copyright_year, description, format, source_work_url
	$rdfUrl = 'www.creativecommons.org/license/get-rdf';
	$rdfUrl .= '?license_url='.$_POST['license_url'];
	$rdfUrl .= '&work_url='.wbHtmlspecialchars($serverName4.'/'.$pageOwner['username']); //If not set, RDF will refer to the page it is included in.. didn't seem to work..

//	need to retrieve rdf data from creative commons
// 	if( !isset($wbConfig['online']) || $wbConfig['online']==='On' ){
// 		$fp = fsockopen('www.creativecommons.org', 80, $errno, $errstr, 5);
// 		
// 		$request = 'GET '.$path.' HTTP/1.0'.$newLine;
// 		$request .= 'User-Agent: WikyBlog Version Checker'.$newLine;
// 		$request .= 'Host: '.$host.$newLine;
// 		$request .= $newLine.$newLine;
// 			
// 		fputs($handle, $request);
// 	}
	
	
	$rdfContent = '<!-- '.$rdfContent.' -->';

	$content = $_POST['textBefore'] ;
	$content .= '<a href="'.$_POST['license_url'].'" title="'.$_POST['license_name'].'">'.$_POST['textLink'].'</a>';
	$content .= $_POST['textAfter'];
	$content .= $rdfContent;
	
	$pageOwner['licenseTxt'] = $content;
					
	message('LICENSE_UPDATED');
	echo '<h2>'.$langA['preview'].'</h2>';
	echo '<div class="WBfileFooter"><span>';
	echo $content;
	echo '</span></div>';
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//			Editing form
	//
	
	echo '<h2>'.$langA['customize_license'].'</h2>';
	
	//Link Text
	echo '<table width="98%">';
	echo '<tr><td>'.$langA['text_before'].'</td><td> <input type="text" size="70" name="textBefore" value="'.$_POST['textBefore'].'" /></td></tr>';
	echo '<tr><td>'.$langA['link_text'].'</td><td> <input type="text" size="70" name="textLink" value="'.$_POST['textLink'].'" /></td></tr>';
	echo '<tr><td>'.$langA['text_after'].'</td><td> <input type="text" size="70" name="textAfter" value="'.$_POST['textAfter'].'" /></td></tr>';
	echo '</table>';
	echo '<input type="submit" name="cmd" value="'.$langA['save'].'" /> ';
	echo '<input type="reset" name="cmd" value="'.$langA['reset'].'" /> ';
	
	//Hidden Values
	echo '<input type="hidden" name="license_url" value="'.$_POST['license_url'].'" />';
	echo '<input type="hidden" name="license_name" value="'.$_POST['license_name'].'" />';

}

function deleteLicense(){
	global $pageOwner;
	
	if( empty($pageOwner['licenseTxt']) ){
		message('LICENSE_DELETED2');
		return;
	}
	unset($pageOwner['licenseTxt']);
	unset($pageOwner['license']);
	message('LICENSE_DELETED');
}

//
//			Functions
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//			Control Flow
//


global $page,$pageOwner,$dbObject,$langA,$wbConfig;

$contentUri = $page->regLink($langA['content_license'],'/Special/'.$pageOwner['username'].'/CCLicense');
$page->regLink('?',$langA['content_license'].'?en=Content_License');
$page->displayTitle = $langA['content_license'];


if( !isOwner(true,true) ) return false;

ob_start();

switch($page->userCmd){

	case 'check':
		getRDF();
	break;
	
	case 'delete':
		deleteLicense();
	break;
	default:
		ccLicenseStep1();
	break;
}

$page->contentB[$contentUri] = wb::get_clean();