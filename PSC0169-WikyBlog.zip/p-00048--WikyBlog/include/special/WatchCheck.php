<?php
/*

	need to check the timestamp..

*/

includeFile('search/all.php');

class WatchCheck extends query{
	
	function WatchCheck(){
		global $page,$wbTables,$wbNow;
		
		$this->rowLimit = 1;
		$this->selectFrom = $wbTables['all_watch'].' INNER JOIN '.$wbTables['all_files'].' USING(`file_id`) ';
		$this->joinAllTo = $wbTables['all_watch'];
		$this->allSelect = array(' COUNT(*) '=>'COUNT');
		$this->infoSelect = array();
		
		$this->queryAllFiles();
		$this->query .= ' AND '.$wbTables['all_watch'].'.`user_id` = "'.wbDB::escape($_SESSION['user_id']).'" ';
		$this->query .= ' AND ( '.$wbTables['all_files'].'.`username` != "'.wbDB::escape($_SESSION['username']).'" ';
		$this->query .= ' OR '.$wbTables['all_files'].'.`username` IS NULL )';
		if( !empty($_GET['t']) ){
			$this->query .= ' AND '.$wbTables['all_files'].'.`modified` >= "'.wbDB::escape($_GET['t']).'" ';
		}
		
		$this->query .= ' LIMIT 1 OFFSET 0';
		
		$result = wbDB::runQuery($this->query);
		if( $row = mysql_fetch_assoc($result) ){
			if( (int)$row['COUNT'] > 0 ){
				$this->sendUserMenu();
				return;
			}
		}
		$this->updateChck();

	}
	
	function updateChck(){
		global $page,$wbNow;
		$addContent = new content();
		$addContent->aa = 'eval';
		$addContent->bb = 'WB.chck="'.$wbNow.'";';
		$page->contentClasses[] = $addContent;
		$_SESSION['checked'] = $wbNow;
	}
	
	function sendUserMenu(){
		global $page,$wbNow;
		
		$addContent = new content();
		$addContent->aa = 'addcontent';
		$addContent->bb = 'WBuserMenu';
		$addContent->dd = getUserMenu(true,true);
		$page->contentClasses[] = $addContent;
		
		//don't check more
		$addContent = new content();
		$addContent->aa = 'eval';
		$addContent->bb = 'WB.chck=false;';
		$page->contentClasses[] = $addContent;
		$_SESSION['checked'] = $wbNow;
		
	}
}
new WatchCheck();