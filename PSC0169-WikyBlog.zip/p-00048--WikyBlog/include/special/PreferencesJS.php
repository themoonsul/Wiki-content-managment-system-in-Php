<?php
defined('WikyBlog') or die("Not an entry point...");
includeFile('special/Preferences.php',false);

class JSPrefs extends specPreferences{
	
	function JSPrefs(){
		global $page,$langA,$pageOwner;
		
		$contentUri = $page->regLink($langA['javascript_preferences'],'/Special/'.$pageOwner['username'].'/JSPrefs');
		$page->regLink('?',$langA['user_preferences'].'?en=User_Preferences');
		
		$this->setValues();
		
		ob_start();
		switch($page->userCmd){
			
			case 'js':
				$this->setJs();
				if( !$page->ajaxRequest ){
					$this->show();
				}
			break;
			
			case 'set':
				$this->setJs();
			default:
				$this->show();
			break;
		}
		$page->contentB[$contentUri] = wb::get_clean();
		
		
	}
	
	function show(){
		global $langA,$page,$pageOwner;
		$page->css2 = true;
		
		echo '<table  style="margin:1em auto 1em auto">';
		echo '<tr><td style="text-align:center">';
		
		echo '<table class="WBeditArea1" cellspacing="9" >';
		
		
		//enhanced tabbed browsing
		echo '<tr>';
		echo '<th>'. $langA['enhanced_tabs'] . '</th>';
		echo '<td>';
		if( $_SESSION['ajax'] == 'Off' ){
			$label = '<img alt="'.$langA['off'].'" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/delete.gif').'" style="vertical-align:middle" />';
			//echo wbLinks::special('JSPrefs?cmd=set&k=ajax&v=On',$label);
			echo wbLinks::js('/Special/'.$pageOwner['username'].'/JSPrefs?cmd=set&k=ajax&v=On',$label);
			
			
		}else{
			$label = '<img alt="'.$langA['on'].'" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/tick.gif').'" style="vertical-align:middle" />';
			//echo wbLinks::special('JSPrefs?cmd=set&k=ajax&v=Off',$label);
			echo wbLinks::js('/Special/'.$pageOwner['username'].'/JSPrefs?cmd=set&k=ajax&v=Off',$label);
		}		
		echo '</td>';
		echo '<td>';
		echo $langA['ENHANCED_TABS'];
		echo '</td></tr>';
		
		
		//enhanced scrolling
		echo '<tr>';
		echo '<th>'. $langA['scrl'] . '</th>';
		echo '<td>';
		if( $_SESSION['scrl'] == 'Off' ){
			$label = '<img alt="'.$langA['off'].'" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/delete.gif').'" style="vertical-align:middle" />';
			echo wbLinks::special('JSPrefs?cmd=set&k=scrl&v=On',$label);
			
		}else{
			$label = '<img alt="'.$langA['on'].'" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/tick.gif').'" style="vertical-align:middle" />';
			echo wbLinks::special('JSPrefs?cmd=set&k=scrl&v=Off',$label);
		}		
		echo '</td>';
		echo '<td>';
		echo $langA['SCROLL_CONTENT'];
		echo '</td></tr>';
		
		
		//external links in new window
		echo '<tr>';
		echo '<th>'. $langA['nWin'] .'</th>';
		echo '<td>';
		if( $_SESSION['nWin'] == 'Off' ){
			$label = '<img alt="'.$langA['off'].'" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/delete.gif').'" style="vertical-align:middle" />';
			echo wbLinks::special('JSPrefs?cmd=set&k=nWin&v=On',$label);
		}else{
			$label = '<img alt="'.$langA['on'].'" height="16" width="16" src="'.wbLinks::getDir('/imgs/icons/tick.gif').'" style="vertical-align:middle" />';
			echo wbLinks::special('JSPrefs?cmd=set&k=nWin&v=Off',$label);
		}
		echo '</td>';
		echo '<td>';
		echo $langA['EXTERNAL_LINKS'];
		echo '</td></tr>';
		
		echo '</table>';
		
		if( isset( $_SESSION['username'] ) ){
			echo wbLinks::special('Preferences','user_preferences','',$_SESSION['username']);
		}else{
			echo wbLinks::special('Register','register');
		}
		echo '</td></tr>';
		echo '</table>';
		

		
		
	}

	function setJs(){
		global $page;
		
		
		$_GET += array('k'=>'','v'=>'');
		if( !isset($this->javascriptEval[$_GET['k']]) ){
			return;
		}
		if( !isset($this->values['bool'][$_GET['v']]) ){
			return;
		}
		
		$page->session = true; //update the user session menu
		$_SESSION[$_GET['k']] = $_GET['v'];
		$evalSet[$_GET['k']] = $_GET['v'];
		$this->sendJavascript($evalSet);

	}
}
new JSPrefs();