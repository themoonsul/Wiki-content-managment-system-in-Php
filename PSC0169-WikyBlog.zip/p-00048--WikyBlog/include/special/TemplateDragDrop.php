<?php

class templateDragDrop{
	
	function templateDragDrop(){
		global $page;
		$this->setTemplate();
		ob_start();
		
			?>
			<div id="lyr0" style="position:relative;width:200px;height:50px;background:red;padding:3px;margin:3px;"></div>
			<div id="lyr1" style="position:relative;width:200px;height:50px;background:green;padding:3px;margin:3px;"></div>
			<div id="lyr2" style="position:relative;width:200px;height:50px;background:blue;padding:3px;margin:3px;"></div>
			<div style="border:0;padding:0;margin:0;">
			<div id="lyr3" style="position:relative;width:200px;height:50px;background:yellow;padding:3px;margin:3px;"></div>     
			</div>
			<div style="border:0;padding:0;margin:0;">
			<div id="lyr4" style="position:relative;width:200px;height:50px;background:purple;padding:3px;margin:3px;"></div>     
			</div>
			<?php
	
	  
		$page->contentA['Drag `n Drop'] = wb::get_clean();
	}
	
	function setTemplate(){
		global $page,$pageOwner,$jsNum,$includeDir;
		
		if( isset($pageOwner['pTemplate']) ){
			$which =& $pageOwner['pTemplate'];
		
			$page->navbar = '<div style="border: 1px solid #ccc">Area used for map links</div>';
			
			$templateDir = $includeDir.'/themes/'.dirname($which).'/template.php';
			$page->template = file_get_contents($templateDir);
			
			
			$replace = '<body id="WB.BODY"><script type="text/javascript" src="'.wbLinks::getDir('/include/js/wz_dragdrop.js?'.$jsNum).'"></script>';
			$page->template = str_replace('<body>',$replace,$page->template);
			
			$replace = '<head><script type="text/javascript" src="'.wbLinks::getDir('/include/'.$jsNum.'/mydrag.js?'.rand()).'"></script>';
			$page->template = str_replace('<head>',$replace,$page->template);
			
			$args = 'var list = new Array("WB.Links","WB.UserMenu","WB.Keywords","WBnavbar");';
			
			$page->template = str_replace('</body>','</body><script type="text/javascript">SET_DHTML();'.$args.'setTemplate(list);</script>',$page->template);
			
			
		}

		
		//$page->template = str_replace($replace,"\n<style>\n".$this->css1."\n".$this->css2."\n</style>\n</head>",$this->template);
	}
	
}
new templateDragDrop();