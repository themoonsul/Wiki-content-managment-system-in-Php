<?php
defined('WikyBlog') or die("Not an entry point...");



class reorganize{
	
	function reorganize(){
		global $page,$langA,$pageOwner,$dbObject;
		includeFile('tool/Tags.php');
		$page->css2 = true;
		
		$page->displayTitle = $langA['reorganize'];
		$link = $page->regLink($langA['reorganize'],'/Special/'.$pageOwner['username'].'/Reorganize');
		$page->autoForm = true;
		
		if( !isOwner(true,false) ) return; //not strict

		$_POST += array('to'=>'','from'=>'');
		
		switch($page->userCmd){
			case 'save':
				$this->save();
			break;
		}
		
		
		ob_start();
		echo $langA['REORGANIZE'];
		
		
		echo '<table style="margin: 2em auto 2em auto;">';
		echo '<tr><td style="text-align:center">';
		if( !empty($pageOwner['keywords']) && is_array($pageOwner['keywords']) && (count($pageOwner['keywords']) > 0) ){
			$this->showForm();
		}else{
			echo wbLang::text('KEYWORDS_EMPTY');

		}
		echo '</td></tr>';
		echo '</table>';
		
		
		$page->contentB[$link] = wb::get_clean();
	}
	function showForm(){
		global $langA,$pageOwner,$wbTables;
		
		$query = 'SELECT `keywords` FROM '.$wbTables['all_files'];
		$query .= ' WHERE (`owner_id` = "'.$pageOwner['user_id'].'") ';
		$query .= ' AND `keywords` IS NOT NULL AND `keywords` != "" ';
		$query .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';
		
		$result = wbDB::runQuery($query);
		$keywords = array();
		while( $row = mysql_fetch_assoc($result) ){
			$temp = explode(',',$row['keywords']);
			foreach($temp as $key){
				$keywords[$key] = true;
			}
		}
		uksort($keywords,'strnatcasecmp2');

		
		echo '<table class="WBeditArea1" cellspacing="9">';
		echo '<tr>';
		echo '<th>'.$langA['from'].'</th>';
		echo '<th>'.$langA['to'].'</th>';
		echo '</tr>';
		echo '<tr><td>';
		echo '<select name="from">';
		foreach($keywords as $key => $null){
			if( $key == $_POST['from'] ){
				echo '<option value="'.$key.'" selected="selected">'.$key.'</option>';
			}else{
				echo '<option value="'.$key.'">'.$key.'</option>';
			}
		}
		echo '</select>';
		echo '</td>';
		echo '<td>';
		echo '<input type="text" size="20" name="to" value="'.$_POST['to'].'" />';
		echo ' &nbsp; <input type="submit" name="cmd" value="'.$langA['save'].'" />';
		echo '</td></tr>';
		echo '<tr><td colspan="2" class="sm">';
		//echo 'Note: This feature bypasses versioning.';
		echo '</td></tr>';
		echo '</table>';
	}
	
	function save(){
		global $wbTables, $pageOwner;
		
		//	three cases
		//		"keyword_To_Change"
		//		"keyword_To_Change,another"
		//		"another,keyword_To_Change"
		//		"keyword_To_Change:not_changing,keyword_To_Change"
		
		$from =& $_POST['from'];
		$to =& $_POST['to'];
		$to = wbHtmlspecialchars($to);
		$from = wbHtmlspecialchars($from);
		
		if( empty($from) || empty($to) ){
			message('Please supply values to change.');
			return;
		}
		
		
		//In case we have this
		//		"keyword_to_change:dont_change,keyword_to_change"	=> we only want to change the second part
		//		"dont_change:keyword_to_change,keyword_to_change"	=> we only want to change the first part
		
		// REPLACE IS CASE SENSITIVE
		$replace[] = ' REPLACE(`keywords`,",'.wbDB::escape($from).',",",'.wbDB::escape($to).',") ';		//	case "...,keyword_to_change,..."
		$replace[] = ' REPLACE(`keywords`,",'.wbDB::escape($from).'",",'.wbDB::escape($to).'") ';		//	case "...,keyword_to_change"
		$replace[] = ' REPLACE(`keywords`,"'.wbDB::escape($from).',","'.wbDB::escape($to).',") ';		//	case "keyword_to_change,..."
		$replace[] = ' REPLACE(`keywords`,"'.wbDB::escape($from).'","'.wbDB::escape($to).'") ';			//	case "keyword_to_change"
		foreach($replace as $sql){
			$query = 'UPDATE '.$wbTables['all_files'].' SET ';
			$query .= ' `modified` = `modified`, ';
			$query .= '`keywords` = '.$sql;
			$query .= ' WHERE (`owner_id` = "'.$pageOwner['user_id'].'") ';
			$query .= ' AND FIND_IN_SET("'.wbDB::escape($from).'",`keywords`) ';
			wbDB::runQuery($query);
		}
		
		message('KEYWORDS_UPDATED');
		includeFile('maintenance/tags1.php');
		fixTags();
	}
	
	
}
new reorganize();
