

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title><?php echo $templateTitle ?></title>

<style type="text/css" >

li{margin-bottom:1em}
body{}

body{	
	font-size:x-small; 
	FONT-FAMILY: ARIAL,verdana,helvetica,geneva,sans-serfif;
	background-color:white;
	letter-spacing:.05em;
	margin:0;
	padding:0;}
	
td{text-align:left;}
form{padding:0;margin:0;}

h2{
	font-size:200%;
	margin:0;}
	
a{color:#334466;}

strong{font-weight:bold}
input{font-size:11px}

#globalWrapper {
	font-size: 130%;
	width:100%;
	padding:0;}
	
#main{
	margin: 1em 1em 3em 1em;}
	
.stepsTd{vertical-align:top;}
	
.contentTd{
	padding: 1em;
	margin: 3em;
	vertical-align:top;
	background-color:#f1f3f5;
	border:1px solid #ccc;
	}

	
#title{
	background-color:#334466;
	color:white;
	border-width:0 0 5px 0;
	border-color:#ff9900;
	border-style:solid;
	font-size:200%;
	font-weight:bold;
	padding:.3em;}

.steps{
	padding:.3em;
	margin-right:1em;
	border: 1px solid #ccc;
	background-color:#f1f3f5; }
	
.steps td{
	font-size:85%;
	font-weight:bold;
	border-color:#bbbbbb;
	border-style:solid;
	border-width:1px 1px 1px 1px;
	padding: 5px 20px 5px 20px;}
	

.stepHead th{
	font-weight:bold;font-size:130%;padding: 7px 1em 7px 1em;
	border-color:#ff9900;border-style:solid;border-width:0 0 3px 0;
	background-color:#334466;color:white;text-align:center;}

.stepAt td{
	border-width:1px 1px 1px 7px;border-color:#334466;
	padding: 7px 20px 7px 14px;
	background-color:white;white-space:nowrap;}
	
.stepDone td{	color:#aaaaaa;white-space:nowrap;border-color:#f1f3f5;}
.stepToDo td{	color:#444444;white-space:nowrap;border-color:#f1f3f5;}
.stepFoot td{	font-size:85%;font-weight:normal;color:#999999;text-align:center;border:0;}

.about{font-style:italic;font-size:90%;padding-left:1em;}

.left{text-align:right;}


.submit{ 
	color:black;
	width:100%;
	background-color:white;
	font-weight:bold;
	border:1px #334466 solid;
	padding:.4em .8em .4em .8em;}
	
.WBmessages a{
	display:none;
}
.WBmessages{ border:1px solid #ccc; background-color:white;}

h3 a:link, h3 a:visited{text-decoration:none;}

	
</style>


</head>
<body>
<div id="globalWrapper">
<div id="title"><?php echo $templateTitle ?> > <?php echo $pageTitle ?></div>
<form action="install.php" method="post">
<table id="main" border="0" cellspacing="9">

<tr>

<tr>


<?php
	global $pageContent,$pageSteps;
		
	echo '<td class="stepsTd" rowspan="2">';
	echo $pageSteps;
	echo '</td>';
		
	echo '<td class="contentTd" width="70%" rowspan="2">';
	echo '<div class="pageContent">';
	echo returnMessages();
	echo $pageContent;
	echo '</div>';
	echo '</td>';

	

	
?>

</tr>
</table>

</form>
<div style="text-align:center">

<?php
//Display an email address for installers
//

if( !defined('WikyBlog_Installed') ){
	echo '<a href="mailto:oyejorge@users.sourceforge.net">Contact</a> - ';
}


echo '<a href="http://www.wikyblog.com">WikyBlog.com</a>';
echo '</div>';
echo '</div>';
echo '</body></html>';