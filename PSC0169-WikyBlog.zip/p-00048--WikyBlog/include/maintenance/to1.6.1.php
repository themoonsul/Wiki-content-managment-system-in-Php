<?php
/*

need to update the database first!

*/


class to161 extends fromSkeleton{
	var $MySQL41;

	function to161($updateObj=null,$versionNum=null){
		$this->updateObj = $updateObj;
		$this->versionNum = $versionNum;
	}
	
	function go($MySQL41){
		global $wbTablePrefix;
		$this->done = false;
		$this->MySQL41 = $MySQL41;
		
		
		$_GET += array('cmd'=>'');
		switch( $_GET['cmd']){
			
			case 'start':
				if( !$this->start() ){
					message('The first step was not successful');
					message('<a href="?cmd=start">Try Again</a>');
					return;
				}
				message('<a href="?cmd=end">Finish</a>');
			break;
			
			case 'end':
				$this->done = true;
			break;
			
			default:
				message('<a href="?cmd=start">Start</a>');
			break;
		}
	}
	
	function modConfig(){
		global $wbTables,$wbTablePrefix,$wbWritable, $maxUserDiskUsage, $maxHistory;
		includeFile('tool/Variables.php');
		
		//get config
		$query = 'SELECT `revision`, `maintained`, `data` FROM '.$wbTables['config'];
		$query .= ' ORDER BY revision DESC  LIMIT 1 OFFSET 0;';
		$result = wbDB::runQuery($query);
		if( !$result ){
			return false;
		}
		$row = mysql_fetch_assoc($result);
		$config = unserialize($row['data']);
		
		
		//Move DefaultUser to config_vars
		$values = array('homeTitle', 'textareaY', 'isBlog', 'timezone', 'ajax', 'maxHistory','pTemplate','sBlog','lang','quickComment', 'fEdits');
		$newArray = array();
		foreach($values as $key){
			if( !isset($config['defaultUser'][$key]) ){
				continue;
			}
			
			$newArray['defaultUser:'.$key] = $config['defaultUser'][$key];
			unset($config['defaultUser'][$key]);
		}
		
		$newArray['max_usage'] = $maxUserDiskUsage;
		$newArray['abs_max_history'] = $maxHistory;
		
		wbVariables::saveArray($newArray);
		
		//Unset $maxUserDiskUsage and $maxHistory in config
		unset($config['maxUserDiskUsage']);
		unset($config['maxHistory']);
		
		//change template to theme
		if( isset($wbWritable) && ($wbWritable === false) && isset($config['dbInfo']['template']) ){
			unset($config['dbInfo']['template']);
		}
		if( isset($config['dbInfo']['template']) ){
			$config['dbInfo']['theme'] = $config['dbInfo']['template'];
			unset($config['dbInfo']['template']);
		}
		if( isset($config['wbConfig']['createNew']['template']) ){
			$config['wbConfig']['createNew']['theme'] = $config['wbConfig']['createNew']['template'];
			unset($config['wbConfig']['createNew']['template']);
		}
			
			
		
		

		//save new config
		$data = serialize($config);
		$query = 'UPDATE '.$wbTables['config'].' SET `modified`=`modified`, `data`="'.wbDB::escape($data).'" ';
		$query .= ' WHERE `revision` = "'.$row['revision'].' " ';
		wbDB::runQuery($query);
		return true;
	}
	
	
	function start(){
		global $wbTables, $dbInfo, $wbTablePrefix, $maxUserDiskUsage,$maxHistory;

		$this->updateDB();
		
		if( empty($maxUserDiskUsage) ){
			$maxUserDiskUsage = '1000000000';
		}
		if( empty($maxHistory) ){
			$maxHistory = '0';
		}
		

		//max usage to user table
		$query = 'UPDATE '.$wbTables['users'];
		$query .= ' SET `modified` = `modified` ';
		$query .= ', `max_usage` = "'.wbDB::escape($maxUserDiskUsage).'" ';
		$query .= ', `max_history` = "'.wbDB::escape($maxHistory).'" ';
		$query .= ' , `flags` = '. wbDB::remove_from_set('userflag1','`flags`');
		$result = wbDB::runQuery($query);
		if( !$result ){
			return false;
		}
		
		
		//create groups for the different flags
		$query = 'SELECT count(*) as `user_count`, `flags` ';
		$query .= ', `max_history`, `max_usage` ';
		$query .= ' FROM '.$wbTables['users'];
		$query .= ' WHERE `ugroup_id` = 0 ';
		$query .= ' GROUP BY `ugroup_id`,`flags` ';
		$result = wbDB::runQuery($query);
		
		while( $row = mysql_fetch_assoc($result) ){
			if( empty($row['flags']) ){
				continue;
			}
			
			//get groups
			$query = 'INSERT INTO ';
			$query .= $wbTables['config_ugroups'];
			$query .= ' SET ';
			$query .= ' `name` = "'.wbDB::escape($row['flags']).'" ';
			$query .= ', `max_usage` = "'.wbDB::escape($row['max_usage']).'" ';
			$query .= ', `max_history` = "'.wbDB::escape($row['max_history']).'" ';
			$query .= ', `flags` = "'.wbDB::escape($row['flags']).'" ';
			wbDB::runQuery($query);
			$id = mysql_insert_id();
			
			//update users
			$query = 'UPDATE ';
			$query .= $wbTables['users'];
			$query .= ' SET ';
			$query .= ' `modified` = `modified` ';
			$query .= ', `max_usage` = "'.wbDB::escape($row['max_usage']).'" ';
			$query .= ', `max_history` = "'.wbDB::escape($row['max_history']).'" ';
			$query .= ', `ugroup_id` = "'.wbDB::escape($id).'" ';
			$query .= ' WHERE ';
			$query .= ' `flags` = "'.$row['flags'].'" ';
			wbDB::runQuery($query);
		}
		
		
		
		//comment count
		$query = 'UPDATE '.$wbTables['all_files'];
		$query .= ' SET `modified` = `modified` ';
		$query .= ', `comments` =  65535';		//Max num for smallint	65535
		$result = wbDB::runQuery($query);
		if( !$result ){
			return false;
		}
		
		if( !$this->modConfig() ){
			return false;
		}
		
		return true;
	}
}