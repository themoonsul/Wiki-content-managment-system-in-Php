<?php
/*

need to update the database first!


*/


class to14 extends fromSkeleton{
	var $MySQL41;

	function to14($updateObj=null,$versionNum=null){
		$this->updateObj = $updateObj;
		$this->versionNum = $versionNum;
	}
	
	function go($MySQL41){
		global $wbTablePrefix;
		$this->done = false;
		$this->MySQL41 = $MySQL41;
		
		
		$_GET += array('cmd'=>'');
		switch( $_GET['cmd']){
			case 'start':
				if( !$this->updateFlags() ){
					message('the first step was not successful');
					message('<a href="?cmd=start">Start</a>');
					return;
				}
				message('<a href="?cmd=end">Finish</a>');
				
			break;
			
			case 'end':
				$this->done = true;
			break;
			
			default:
				message('<a href="?cmd=start">Start</a>');
			break;
		}
	}
	function updateFlags(){
		global $wbTables;
		$this->updateDB();
		
		$query = 'DELETE FROM '.$wbTables['all_links'].' WHERE  1';
		if( !wbDB::runQuery($query) ){
			return false;
		}
		

		$query = 'UPDATE '.$wbTables['all_files'];
		$query .= ' SET `modified` = `modified` ';
		$query .= ' , `flags` = CONCAT_WS(",",`flags`,"old") ';
		message($query);
		if( wbDB::runQuery($query) ){
			return true;
		}
		return false;
	}
}