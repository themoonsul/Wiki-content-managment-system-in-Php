<?php

if ( !defined('WikyBlog') ){
	die("Not an entry point...");
}

////////////////////////////////
//
//	2006-March
//	changing the way keywords are stored..
//	fixTags() is used to transform the old data to the new format
//		- must run before the new getKeywords() function is used so we reset $pageOwner['keywords'] immediately
//		- 
//

//use updateTags($delete,$add) to add the keywords from each row
includeFile('tool/Tags.php');

function fixTags(){
	global $pageOwner,$dbInfo,$wbTables;
	$newArray = array();
	
	//message('Updating Tags');
	
	$query = 'SELECT keywords ';
	$query .= ' FROM '.$wbTables['all_files'];
	$query .= ' WHERE (`keywords` IS NOT NULL) ';
	$query .= ' AND (`keywords` != "") ';
	$query .= ' AND (owner_id="'.$pageOwner['user_id'].'") ';
	$query .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';//deleted, hidden, redirect and relvisible flags
	
	$result = wbDB::runQuery($query);
	$num = mysql_num_rows($result);
	while( $row = mysql_fetch_assoc($result) ){
		$newArray = updateTags('',$row['keywords'],$newArray);
	}
	$pageOwner['keywords'] = $newArray;
	//$pageOwner['keyupdated'] = 4; //removed 1.6.2b1
	
	$query = 'UPDATE '.$wbTables['users'];
	$query .= ' SET `modified` = `modified` ';
	$query .= ' ,`keyword_count` = "" ';
	$query .= ' WHERE `user_id` = "'.$pageOwner['user_id'].'" ';
	wbDB::runQuery($query);
}

