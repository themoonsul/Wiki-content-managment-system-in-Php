<?php

defined('WikyBlog') or die("Not an entry point...");

class versions{
	function getVersions(){
		
		// $ver['1.0'] = array('to1.0.php','to10');
		// $ver['1.1'] = array('to1.1.php','to11');
		// $ver['1.2.1'] = array('','fromSkeleton');
		// $ver['1.3'] = array('to1.3.php','to13');
		// $ver['1.4.0'] = array('to1.4.php','to14');
		// $ver['1.4.4'] = array('','fromSkeleton');
		// $ver['1.4.9'] = array('','fromSkeleton');
		// $ver['1.5.0.1'] = array('to1.5.php','to15');
		$ver['1.6'] = array('to1.6.php','to16');
		$ver['1.6.1'] = array('to1.6.1.php','to161');
		$ver['1.7.1'] = array('to1.7.1.php','to171');
		
		return $ver;
	}
	
	/////////////////////////////////////////////////////////
	//
	//	check
	//
	function update(){
		global $wbConfig,$packageVersion,$wbTables;
		
		versions::majorCheck();
		versions::minorCheck();
	}
	
	function majorCheck(){
		global $wbConfig,$packageVersion,$wbTables;
		
		
		$versions = versions::getVersions();
		foreach($versions as $version => $data){
			$version = str_replace('rc','RC',$version); //the version_compare function works only when RC is in caps
			
			if( version_compare($version,$wbConfig['version'],'<=') ){
				continue;
			}
			
			if( version_compare($version,$packageVersion,'>') ){
				continue;
			}
			if( is_array($data) ){
				includeFile('admin/UnderConstruction.php');
				die();
			}
		}
	}
	
	//if we've made it to the minorCheck, the major check has already been done
	//	so we just need to update the version
	function minorCheck(){
		global $wbConfig,$packageVersion,$wbTables;
		
		if( !isAdmin(false) ){
			return;
		}
		
// 		//check the php files
// 		includeFile('admin/checkInstallation.php',false);
// 		$temp = new checkInstallation();
// 		if( !$temp->complete ){
// 			message($temp->message);
// 		}
		
		//update links
		includeFile('admin/ConfigLinks.php',false);
		ConfigLinks::setDefaults();
		
		$query = 'UPDATE '.$wbTables['config'].' SET `modified`=`modified`, `version`="'.wbDB::escape($packageVersion).'"';
		@mysql_query($query);
	}
}
