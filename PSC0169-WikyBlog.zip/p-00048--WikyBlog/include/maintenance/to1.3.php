<?php

//	Can I just update the database?
//		..no! because the primary key for `pages` won't be right .. we'll get a duplicate entry for `file_id`
//


/*

need to update the database first!

UPDATE `users` SET `visited` = `modified`


*/


class to13 extends fromSkeleton{
	var $MySQL41;

	function to13($updateObj=null,$versionNum=null){
		$this->updateObj = $updateObj;
		$this->versionNum = $versionNum;
	}
	
	function go($MySQL41){
		$this->done = false;
		$this->MySQL41 = $MySQL41;
		
		$_GET += array('cmd'=>'');
		switch( $_GET['cmd']){
			case 'start':
				$this->updateDB();
				$this->updateQueries();
				message('<a href="?cmd=second">Second</a>');
			break;
			
			case 'second';
				$this->config();
				message('<a href="?cmd=end">End</a>');
			break;
			
			case 'end':
				$this->done = true;
			break;
			
			default:
				message('<a href="?cmd=start">Start</a>');
			break;
		}
	}
	///////////////////////////////////////////////////////
	//
	//		Populate the `visited` column
	//		Turn "This_Title" into "This Title" in the all_search table
	//		
	//
	function updateQueries(){
		global $wbTables;
		$query = 'UPDATE '.$wbTables['users'].' SET `visited` = `modified`, `modified` =`modified` ';
		$result = wbDB::runQuery($query);
		
		$query = 'UPDATE '.$wbTables['all_search'].' SET `all_title` = REPLACE(`all_title`,"_"," ") ';
		$result = wbDB::runQuery($query);
	}

	///////////////////////////////////////////////////////
	//
	//		Get rid of the need to set globals in getConfig()
	//		redo $dbInfo..
	//
	function config(){
		global $wbTables,$dbInfo;
		
		$query = 'SELECT revision, data FROM '.$wbTables['config'].' ORDER BY revision DESC LIMIT 1'; 
		$result = @mysql_query($query); //use mysql_query here because I don't want to report any errors here
		$row = mysql_fetch_assoc($result);
		$temp = unserialize($row['data']);
		

		if( empty($temp['wbConfig']['createNew']) ){
			$temp['wbConfig']['createNew'] = array('page'=>1,'map'=>1,'template'=>1);
		}
		
		
		///////////////////////////////////////////////////////
		//
		//		Redo the dbInfo
		//
		
			$array['talk']['class'] = 'searchTalk';
			$array['special']['class'] = 'SPEC';
			$array['admin']['class'] = 'ADMIN';
			
			$array['page']['class'] = 'CLASSpage';
			$array['page']['dbTable'] = "`{$wbTablePrefix}pages`";
			$array['page']['uniqLink'] = ' CONCAT("/", `'.$wbTablePrefix.'pages`.owner, "/", `'.$wbTablePrefix.'pages`.title) ';
			$array['page']['dTitle'] = array(' `'.$wbTablePrefix.'pages`.title'=>0);
			$array['page']['searchTitle'] = array('title');
			$array['page']['searchContent'] = array('content');
			
			$array['comment']['class'] = 'CLASScomment';
			$array['comment']['dbTable'] = "`{$wbTablePrefix}comments`";
			$array['comment']['uniqLink'] = ' CONCAT("/Comment/", `'.$wbTablePrefix.'comments`.prefix, `'.$wbTablePrefix.'comments`.owner,"/", `'.$wbTablePrefix.'comments`.title,"/", `'.$wbTablePrefix.'comments`.subject) ';
			$array['comment']['keys'] = array('prefix'=>1,'owner'=>1,'title'=>1,'subject'=>1);
			$array['comment']['dTitle'] = array('`'.$wbTablePrefix.'comments`.prefix'=>0,'`'.$wbTablePrefix.'comments`.title'=>0,'" > "'=>0,'talk'=>1,'" >  "'=>0,'`'.$wbTablePrefix.'comments`.subject'=>0);
			$array['comment']['searchTitle'] = array('title','subject');
			$array['comment']['searchContent'] = array('content');
		
			$array['map']['class'] = 'CLASSmap';
			$array['map']['dbTable'] = "`{$wbTablePrefix}maps`";
			$array['map']['searchTitle'] = array('title');
			$array['map']['searchContent'] = array('content');
		
			$array['template']['class'] = 'CLASStemplate';
			$array['template']['dbTable'] = "`{$wbTablePrefix}templates`";
			$array['template']['xmlHTTP'] = 0;
			
			$array['help']['class'] = 'CLASShelp';
			$array['help']['dbTable'] = "`{$wbTablePrefix}help`";
			$array['help']['uniqLink'] = ' CONCAT("/Help/", `'.$wbTablePrefix.'help`.lang,"/",`'.$wbTablePrefix.'help`.title) ';
			$array['help']['keys'] = array('lang'=>1,'title'=>1);			
			$array['help']['searchTitle'] = array('title');
			$array['help']['searchContent'] = array('content');
		
			$newInfo =& $temp['dbInfo'];
			
			foreach($array as $space => $info){
				if( isset($newInfo[$space]) ){
					unset($newInfo[$space]);
				}
				$newInfo[$space] = $info;
			}
			
		///////////////////////////////////////////////////////
		//
		//		Save
		//
		
			$data = serialize($temp);
			$query = 'UPDATE '.$wbTables['config'].' SET `modified`=`modified` ';
			$query .= ' , `data`="'.wbDB::escape($data).'" ';
			$query .= ' WHERE `revision`="'.$row['revision'].'" ';
			wbDB::runQuery($query);
	}
	
	
}
	