<?php
/*

need to update the database first!

*/


class to15 extends fromSkeleton{
	var $MySQL41;

	function to15($updateObj=null,$versionNum=null){
		$this->updateObj = $updateObj;
		$this->versionNum = $versionNum;
	}
	
	function go($MySQL41){
		global $wbTablePrefix;
		$this->done = false;
		$this->MySQL41 = $MySQL41;
		
		
		$_GET += array('cmd'=>'');
		switch( $_GET['cmd']){
			
			case 'start':
				if( !$this->history() ){
					message('The first step was not successful');
					message('<a href="?cmd=start">Try Again</a>');
					return;
				}
				message('The first step has successful. <a href="?cmd=second">Continue</a>');
			break;
			
			case 'second':
				if( !$this->updateFlags() ){
					message('the second step was not successful');
					message('<a href="?cmd=second">Try Again</a>');
					return;
				}
				message('<a href="?cmd=end">Finish</a>');
			break;			
			
			case 'end':
				$this->done = true;
			break;
			
			default:
				message('<a href="?cmd=start">Start</a>');
			break;
		}
	}
	function history(){
		global $wbTables,$dbInfo;
		
		$query = 'SELECT IF('.$wbTables['all_files'].'.`modified` = '.$wbTables['all_history'].'.`modified`,1,0) as `updated`';
		$query .= ' FROM ';
		$query .= $wbTables['all_files'];
		$query .= ' INNER JOIN ';
		$query .= $wbTables['all_history'];
		$query .= ' USING(`file_id`) ';
		$query .= ' ORDER BY '.$wbTables['all_history'].'.`modified` DESC ';
		$query .= ' LIMIT 1';
		$result = wbDB::runQuery($query);
		$row = mysql_fetch_assoc($result);
		if( $row['updated'] === '1'){
			return true;
		}
					
		foreach($dbInfo as $space => $info){
			if( !isset($info['dbTable']) ){
				continue;
			}
			
			$query = 'INSERT INTO '.$wbTables['all_history'];
			$query .= ' (`file_id`,`modified`,`instructions`,`username`,`ip`,`summary`) ';
			$query .= ' SELECT '.$wbTables['all_files'].'.`file_id`, `modified`, "",`username`,`ip`, `summary` '; //missing summary
			$query .= ' FROM ';
			$query .= $info['dbTable'];
			$query .= ' INNER JOIN ';
			$query .= $wbTables['all_files'];
			$query .= ' USING(`file_id`) ';
			message($query);
			if( !wbDB::runQuery($query) ){
				return false;
			}
			
		}
		return true;
	}
	function updateFlags(){
		global $wbTables;
		$this->updateDB();
		
		$query = 'UPDATE '.$wbTables['all_files'];
		$query .= ' SET `modified` = `modified` ';
		$query .= ' , `flags` = REPLACE(REPLACE(REPLACE(`flags`,"unchecked","blogged"),"flag1","notchecked"),"flag2","relvisible") ';
		message($query);
		if( !wbDB::runQuery($query) ){
			return false;
		}
		
		$query = 'UPDATE '.$wbTables['all_files'].' SET `modified` = `modified`, `visible` = 0 ';
		$query .= 'WHERE ';
		$query .= 'FIND_IN_SET("hidden", `flags`) OR ';
		$query .= 'FIND_IN_SET("deleted", `flags`) OR ';
		$query .= 'FIND_IN_SET("relvisible", `flags`) ';
		message($query);
		if( !wbDB::runQuery($query) ){
			return false;
		}
		
		
		$query = 'UPDATE '.$wbTables['users'];
		$query .= ' SET `modified` = `modified` ';
		$query .= ' , `created` = `modified` ';
		message($query);
		if( !wbDB::runQuery($query) ){
			return false;
		}
		
		return true;
	}
}