<?php
/*

need to update the database first!

*/


class to16 extends fromSkeleton{
	var $MySQL41;

	function to16($updateObj=null,$versionNum=null){
		$this->updateObj = $updateObj;
		$this->versionNum = $versionNum;
	}
	
	function go($MySQL41){
		global $wbTablePrefix;
		$this->done = false;
		$this->MySQL41 = $MySQL41;
		
		
		$_GET += array('cmd'=>'');
		switch( $_GET['cmd']){
			
			case 'start':
				if( !$this->start() ){
					message('The first step was not successful');
					message('<a href="?cmd=start">Try Again</a>');
					return;
				}
				message('<a href="?cmd=end">Finish</a>');
			break;
			
			case 'end':
				$this->done = true;
			break;
			
			default:
				message('<a href="?cmd=start">Start</a>');
			break;
		}
	}
	
	function modConfig(){
		global $wbTables,$wbTablePrefix,$wbWritable;
		
		$query = 'SELECT `revision`, `maintained`, `data` FROM '.$wbTables['config'];
		$query .= ' ORDER BY revision DESC  LIMIT 1 OFFSET 0;';
		$result = wbDB::runQuery($query);
		if( !$result ){
			return false;
		}
		$row = mysql_fetch_assoc($result);

		$config = unserialize($row['data']);
		
		if( !isset($config['dbInfo']['help']) ){
			if( isset($config['dbInfo']['help']['dbPlugin']) ){
				//
			}elseif( isset($config['dbInfo']['help']['isPlugin']) ){
				//
			}else{
				unset($config['dbInfo']['help']);
			}
		}

		
		
		//API Key
		if( !empty($config['googleMapsKey']) ){
			$server = wbStrtolower($config['serverName3'].'/include');
			$config['googleMapKeys'][$server] = $config['googleMapsKey'];
		}
		unset($config['googleMapsKey']);
		
		//interHelp
		unset($config['wbConfig']['interHelp']);
		
		//disk usage
		$config['maxUserDiskUsage'] = '1000000000'; //approx 1 GB
		
		//attach data type
		if( !isset($wbWritable) || $wbWritable === true){
			$config['dbInfo']['attach']['class'] = 'CLASSattachment';
			$config['dbInfo']['attach']['dbTable'] = "`{$wbTablePrefix}attachments`";
			$config['dbInfo']['attach']['dTitle'] = array("`{$wbTablePrefix}attachments`.`title` "=>0); 
			//set keys to disable createNew even though it's the same as the default
			$config['dbInfo']['attach']['keys'] = array('owner'=>1,'title'=>1);
		}
		
		

		//remove help type
		$data = serialize($config);
		$query = 'UPDATE '.$wbTables['config'].' SET `modified`=`modified`, `data`="'.wbDB::escape($data).'" ';
		$query .= ' WHERE `revision` = "'.$row['revision'].' " ';
		wbDB::runQuery($query);
		return true;
	}
	
	
	function start(){
		global $wbTables,$dbInfo;
		
		if( !$this->modConfig() ){
			return false;
		}
		
		$this->updateDB();
		
		//populate config_links
		includeFile('admin/ConfigLinks.php',false);
		ConfigLinks::setDefaults();
		ConfigLinks::restore(); //for FileManager and ImageManger

		
		
		//get all adminLinks form ad_objects
		$query = 'SELECT * FROM '.$wbTables['ad_objects'];
		$query .= ' WHERE ';
		$query .= ' `selector` LIKE "adminLink:%" ';
		$query .= ' ORDER BY `modified` ';
		$result = wbDB::runQuery($query);
		$len = strlen('adminLink:');
		$linkArray = array();
		while($row = mysql_fetch_assoc($result) ){
			
			$link = substr($row['selector'],$len);
			$info = unserialize($row['data']);
			$info += array(	'img'=>''
						,'label'=>''
						,'script'=>''
						);
							
			if( isset($info['hide']) && $info['hide'] ){
				$newInfo['visible'] = 0;
			}
			$newInfo['userlevel'] = 5;
			$newInfo['plugin_space'] = $info['plugin'];
			$newInfo['plugin_dir'] = $info['pluginDir'];
			$newInfo['label'] = $info['label'];
			$newInfo['script'] = $info['script'];
			$newInfo['header'] = $info['header'];
			$newInfo['img'] = $info['img'];
			
			$linkArray[$link] = $newInfo;
		}
		ConfigLinks::addLinks($linkArray);
		
		//remove adminLinkS
		$query = 'DELETE FROM '.$wbTables['ad_objects'];
		$query .= ' WHERE ';
		$query .= ' `selector` LIKE "adminLink:%" ';
		wbDB::runQuery($query);
		
		
		//get all specLinks form ad_objects
		$query = 'SELECT * FROM '.$wbTables['ad_objects'];
		$query .= ' WHERE ';
		$query .= ' `selector` LIKE "specLink:%" ';
		$query .= ' ORDER BY `modified` ';
		$result = wbDB::runQuery($query);
		$len = strlen('specLink:');
		$linkArray = array();
		while($row = mysql_fetch_assoc($result) ){
			
			$link = substr($row['selector'],$len);
			$info = unserialize($row['data']);
			$info += array(	'img'=>''
						,'label'=>''
						,'script'=>''
						);
			
			if( isset($info['hide']) && $info['hide'] ){
				$newInfo['visible'] = 0;
			}
			if( isset($info['userlevel'])  ){
				$newInfo['userlevel'] = $info['userlevel'];
			}
			$newInfo['plugin_space'] = $info['plugin'];
			$newInfo['plugin_dir'] = $info['pluginDir'];
			$newInfo['label'] = $info['label'];
			$newInfo['script'] = $info['script'];
			$newInfo['header'] = $info['header'];
			$newInfo['img'] = $info['img'];
			
			$linkArray[$link] = $newInfo;
		}
		ConfigLinks::addLinks($linkArray);
		
		//remove specLinks
		$query = 'DELETE FROM '.$wbTables['ad_objects'];
		$query .= ' WHERE ';
		$query .= ' `selector` LIKE "specLink:%" ';
		wbDB::runQuery($query);
		
		// update workgroup
		$query = 'UPDATE '.$wbTables['workgroup'];
		$query .= ' SET `userlevel`=`userlevel`+1 WHERE ';
		$query .= ' `userlevel` = 4';
		return wbDB::runQuery($query);
		
	}
}