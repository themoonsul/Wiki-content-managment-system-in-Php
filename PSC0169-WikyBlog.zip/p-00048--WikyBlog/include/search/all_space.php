<?php
defined('WikyBlog') or die("Not an entry point...");

//
//	Query class extended for use with a single namespace
//

	includeFile('search/all.php');

	class query_space extends query{
	
		var $SpaceInfo = false;
		var $SpaceClass = false;
		var $SpaceOutput = false;
		
			
		//set space to use of class abbrevOutput
		function SetSpaceInfo($space){
			global $dbInfo;
			
			//dbInfo
			$this->SpaceInfo = $dbInfo[$space];
			$this->SpaceClass = wbData::getClass($space);
			if( $this->SpaceClass && is_callable(array($this->SpaceClass,'abbrevOutput')) ){
				$this->SpaceOutput = true;
			}				
		}
		function abbrevOutput($row,$i,$actualRowsFound){
			call_user_func(array($this->SpaceClass,'abbrevOutput'),$row,$i,$actualRowsFound);
		}
		function mysqlFetch(&$result){
			return mysql_fetch_object($result);
		}		
	}
