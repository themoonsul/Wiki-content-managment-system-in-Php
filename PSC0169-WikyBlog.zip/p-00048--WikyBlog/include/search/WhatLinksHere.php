<?php

defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$page;
$page->displayTitle = $langA['what_links_here'];
$page->regLink('?',$langA['what_links_here'].'?en=What_Links_Here');


includeFile('search/all.php');
	
class queryWhatLinks extends query{
	var $tempObject;
	
	function queryWhatLinks(){
		global $page,$dbInfo,$pageOwner;
		global $langA,$wbTables;
		$page->css2 =true;
		$this->rowLimit = 50;
		
		if( !isset($_GET['to']) ){
			message('Invalid Request');
			return;
		}
		$_GET['to'] = wbHtmlspecialchars($_GET['to']);
		
		$page->displayTitle = $langA['what_links_here']. ' > '. str_replace('_',' ',$_GET['to']);
		
		$this->searchUrl = '/Special/'.$pageOwner['username'].'/WhatLinksHere';
		
		$this->selectFrom = $wbTables['all_links'].' INNER JOIN '.$wbTables['all_files'].'  ON '.$wbTables['all_files'].'.`file_id` =  '.$wbTables['all_links'].'.`file_id` ';
		$this->selectFrom .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';
		
		$this->joinAllTo = $wbTables['all_links'];
		$this->allSelect = array();
		
		$owner = ' IF( '.$wbTables['all_files'].'.`owner_id` = "'.wbDB::escape($pageOwner['user_id']).'", 1, 0) ';
		$this->allSelect = array($owner=>'is_owner');
		
		$this->queryAllFiles();
		$this->query .= ' AND `to_link` = "'.wbDB::escape($_GET['to']).'" ';
		
		$this->browse($page->displayTitle);
	}
	
	function abbrevOutput(&$row){
		global $pageOwner;
		$this->queryAllResult($row);
		
		echo '<li>';
		if( $row['is_owner'] == '0'){
			echo wbLinks::user($row['owner']).' :: ';
		}
		echo wbLinks::local($row['uniqLink'],toDisplay($row['dTitle']),' title="'.toDisplay($row['dTitle']).'"');
		if( $row['is_owner'] == '0'){
			
		}
		
		echo '</li>';

	}
	function displayPre(){
		echo '<ol>';
	}
	function displayPost(&$prev,&$pages,&$next){
		echo '</ol>';
		parent::displayPost($prev,$pages,$next);
	}

}

new queryWhatLinks();

