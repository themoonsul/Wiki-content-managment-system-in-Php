<?php

defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$page;

$page->displayTitle = $langA['orphaned_files'];
$page->regLink('?', $langA['orphaned_files'].'?en=Orphaned_Files');

includeFile('search/all.php');
	
class orphanedFiles extends query{
	var $tempObject;
	
	function orphanedFiles(){
		global $page,$dbInfo,$pageOwner,$langA,$wbTables;
		$page->css2 =true;
		$this->rowLimit = 50;
		$this->searchUrl = '/Special/'.$pageOwner['username'].'/OrphanedFiles';
		
		//
		//	New
		//
		$this->allSelect = array();
		$this->joinAllTo = 'T1';
		
		$this->selectFrom = $wbTables['all_files'].' AS T1 LEFT JOIN '.$wbTables['all_links'];
		$this->selectFrom .= ' ON T1.`file_id` = '.$wbTables['all_links'].'.`to_id` ';
		//$this->selectFrom .= ' LEFT JOIN '.$wbTables['all_files'].' AS T2 ';
		//$this->selectFrom .= ' ON T2.`file_id` = '.$wbTables['all_links'].'.`to_id` ';
		
		$this->queryAllFiles();
		$this->query .= ' AND T1.`owner_id` = "'.wbDB::escape($pageOwner['user_id']).'" ';
		$this->query .= ' AND ('.$wbTables['all_links'].'.`to_id` IS NULL ';
		//$this->query .= ' OR T2.`visible` = 1 ';
		$this->query .= ' )';
		
		
		//message($this->query);
		$this->browse($langA['orphaned_files']);
	}
	
	function abbrevOutput(&$row){
		$this->queryAllResult($row);
		
		echo '<li>';
		echo wbLinks::local($row['uniqLink'],toDisplay($row['dTitle']));
		echo '</li>';
	}
	
	function displayPre(){
		echo '<ol>';
	}
	function displayPost($prev,$pages,$next){
		echo '</ol>';
		parent::displayPost($prev,$pages,$next);
	}	
	function displayEmpty(){
		parent::displayEmpty();
		return true;
	}
	
}

new orphanedFiles();

