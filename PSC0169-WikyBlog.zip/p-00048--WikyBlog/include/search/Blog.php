<?php
defined('WikyBlog') or die("Not an entry point...");


includeFile('tool/BlogContent.php');
includeFile('search/all.php');
	
class queryBlog extends query{
	var $tempObject;
	
	var $typeClass;
	
	function queryBlog(){
		global $page,$dbInfo,$pageOwner,$langA,$wbTables,$wbTablePrefix,$dbObject;
		
		$page->regLink($langA['blog'],'/Special/'.$pageOwner['username'].'/Blog');
		$page->regLink('?',$langA['blog'].'?en=Blog');
		$this->searchUrl = '/Special/'.$pageOwner['username'].'/Blog';
		$page->css2 =true;
		$this->rowLimit = $pageOwner['nBlog'];
		
		$this->query = BlogContent::blogQuery(true);

		$this->browse($langA['blog']);
	}
	function whileResult(&$result){
		BlogContent::whileResult($result);
	}
}

new queryBlog();

