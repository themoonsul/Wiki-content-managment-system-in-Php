<?php

defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$page;
$page->displayTitle = $langA['trash'];
$page->regLink($langA['trash'],'/Special/'.$pageOwner['username'].'/Trash');
$page->formAction = '/Special/'.$pageOwner['username'].'/Trash';


//	isOwner(warn,strct)
if(!isOwner(true,false)) return false;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//


	includeFile('search/all.php');
		
	class queryTrash extends query{
		var $classes;
		
		function queryTrash(){
			global $page,$dbInfo,$pageOwner,$jsNum,$langA,$wbTables,$wbNow;
			
			$page->css2 =true;
			$this->rowLimit = 25;
			$this->searchUrl = $page->formAction;
			
			//$this->fields[--shown to user--] = --database column--
			$this->fields[$langA['deleted']] = 'modified';
			$this->fields[$langA['file']] = 'uniqLink';
			
			$this->classes[] = ' class="tableRowEven" ';
			$this->classes[] = ' class="tableRowOdd" ';
			
			$page->scripts[] = '/include/js/rows.js?'.$jsNum;
			
			//select
			$this->allSelect = array('file_id','modified');
			$this->infoSelect = array('owner','uniqLink','dTitle');
			$this->queryAllFiles();
			
			//where
			$this->query .= ' AND '.$wbTables['all_files'].'.`owner_id` = "'.$pageOwner['user_id'].'" ';
			$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 0 ';
			$this->query .= ' AND FIND_IN_SET("deleted", '.$wbTables['all_files'].'.`flags`) ';
			$this->query .= ' AND (adddate('.$wbTables['all_files'].'.`modified`,INTERVAL 31 DAY) > "'.$wbNow.'") ';
			$this->orderBy();
			$this->browse($langA['trash']);
		}
		
	
		function displayPre(){
			global $langA;
			echo '<table cellpadding="2" cellspacing="0" border="0" width="100%">';
			echo '<tr class="tableRows"><th>'.$langA['file'].'</th>';
			echo '<th colspan="2">'.$langA['deleted'].'</th>';
			echo '<th colspan="2">'.$langA['options'].'</th></tr>';
		}
		function displayPost(&$prev,&$pages,&$next){
			global $langA;
			echo '<tr onclick="setCheckboxes(this)" style="cursor:pointer" >';
			echo '<td colspan="2" class="sm">'.$langA['DELETED_AFTER_30'].'</td>';
			echo '<td colspan="3" class="sm" style="text-align:right"><a href="javascript:void(0);return false;">'.$langA['check_uncheck'].'</a></td>';
			echo '</tr>';
			
			echo '<tr>';
				echo '<td colspan="5" class="sm" style="text-align:right">';
				echo '<input type="submit" name="cmd" value="'.$langA['delete'].'" title="'.$langA['delete'].'" />';
				echo '<p>';
				echo '<input type="submit" name="cmd" value="'.$langA['empty_trash'].'" title="'.$langA['empty_trash'].'" />';
				echo '</p>';
			echo '</td>';
			echo '</tr>';
			
			echo '</table>';
			parent::displayPost($prev,$pages,$nest);
		}	
		
		function abbrevOutput(&$row,$i){
			global $langA;
			
			$class = $this->classes[($i%2)];
			//echo '<tr '.$class.' ><td>';
			$this->queryAllResult($row);
	
			//echo '<tr '.$class.'onclick="selectCheckBox(event,\''.addslashes($row['uniqLink']).'\')" id="row_'.$row['uniqLink'].'" style="cursor:pointer">';
			echo '<tr '.$class.'onclick="selectCheckBox(event,\''.addslashes($row['file_id']).'\')" id="row_'.$row['file_id'].'" style="cursor:pointer">';
	
			
			echo '<td>';
			echo toDisplay($row['dTitle']);
			
			
			echo ' </td><td> ';
			$unix = dbFromDate($row['modified'],'unix');
			//$ago = (int)round((mktime()-$unix)/86400);
			$ago = (int)round((time()-$unix)/86400);
			
			if($ago === 0){
				echo $langA['today'];
			}elseif($ago === 1){
				echo $langA['yesterday'];
			}else{
				echo $ago.$langA['days_ago'];
			}
			
			echo '</td><td>';
			echo dbFromDate($row['modified'],1);
			
			echo '</td><td class="sm">';
			echo wbLinks::local($row['uniqLink'].'?cmd=restore',$langA['restore'],' title="'.toDisplay($row['dTitle']).'"');
			
			echo '</td><td>';
			
			echo ' <input type="checkbox" onclick="return true" id="checkbox_'.$row['file_id'].'" value="'.$row['file_id'].'" name="list[]" />';
			//echo ' <input type="checkbox" onClick="return true" id="checkbox_'.$row['uniqLink'].'" value="'.$row['space'].'='.$row['uniqLink'].'" name="list[]" />';
			//echo ' <input type="checkbox" onClick="return true" id="checkbox_'.$row['uniqLink'].'" value="'.$row['space'].'" name="list['.$row['uniqLink'].']" />';
			echo '</td></tr>';
			
			
		}
		
	}
	
	
//
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		DELETES FROM all_files, all_links
//
	class trash{
		function permanentDelete(){
			global $page,$dbInfo,$pageOwner,$wbTables;
	
			
			if( !isset($_POST['list']) || !is_array($_POST['list']) ){
				message('DELETE_FILES');
				return;
			}
			
			includeFile('tool/emptyTrash.php');
			$num = emptyTrash($_POST['list']);
			if( $num === 0){
				message('NOTHING_DELETED');
			}else{
				message('DELETED_FILES');
			}
		}
		
		function emptyAll(){
			global $page,$langA;
			ob_start();
			echo '<div style="text-align:center">';
			echo $langA['CONFIRM_EMPTY_TRASH'];
			
			echo '<p>';
			echo '<input type="submit" name="cmd" value="'.$langA['continue'].'" title="'.$langA['continue'].'" />';
			
			echo ' &nbsp; ';
			
			echo '<input type="submit" name="cmd" value="'.$langA['cancel'].'" title="'.$langA['cancel'].'" />';
			echo '</p>';
			
			echo '</div>';
			$page->contentA[$langA['trash']] = wb::get_clean();
		}
		
		function confirmEmpty(){
			global $page,$langA,$wbTables,$pageOwner;
			
			//Create a List of files
				$query = 'SELECT `file_id` FROM ';
				$query .= $wbTables['all_files'];
				$query .= ' WHERE FIND_IN_SET("deleted", flags) AND ';
				$query .= $wbTables['all_files'].'.`owner_id` = "'.wbDB::escape($pageOwner['user_id']) .'" ';
				$result = wbDB::runQuery($query);
				$list = array();
				while($row = mysql_fetch_assoc($result) ){
					$list[] = $row['file_id'];
				}
				
			//delete list of files
				includeFile('tool/emptyTrash.php');
				$num = emptyTrash($list);
				if( $num === 0){
					message('NOTHING_DELETED');
				}else{
					message('DELETED_FILES');
				}
		}
	}

//
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//

	switch($page->userCmd){
		case wbStrtolower($langA['delete']);
			trash::permanentDelete();
		break;
		case wbStrtolower($langA['empty_trash']);
			trash::emptyAll();
		return;
		case wbStrtolower($langA['continue']);
			trash::confirmEmpty();
		break;
	}
	
	new queryTrash();