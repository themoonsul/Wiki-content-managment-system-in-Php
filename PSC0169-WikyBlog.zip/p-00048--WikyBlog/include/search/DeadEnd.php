<?php

defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$page;

$page->displayTitle = $langA['dead_end'];
$page->regLink('?',$langA['dead_end'].'?en=Dead End');

includeFile('search/all.php');
	
class deadEndFiles extends query{
	var $tempObject;
	
	function deadEndFiles(){
		global $page,$dbInfo,$pageOwner,$langA,$wbTables;
		$page->css2 =true;
		$this->rowLimit = 50;
		$this->searchUrl = '/Special/'.$pageOwner['username'].'/DeadEnd';
		
		//
		//	New
		//
		$this->allSelect = array();
		$this->joinAllTo = $wbTables['all_files'];
		
		$this->selectFrom = $wbTables['all_files'].' LEFT JOIN '.$wbTables['all_links'].'  USING(`file_id`) ';
		
		$this->queryAllFiles();
		$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';

		$this->query .= ' AND `owner_id` = "'.wbDB::escape($pageOwner['user_id']).'" ';
		$this->query .= ' AND '.$wbTables['all_links'].'.`file_id` IS NULL ';
		
		//message($this->query);
		$this->browse($langA['dead_end']);
	}
	
	function abbrevOutput(&$row){
		$this->queryAllResult($row);
		
		echo '<li>';
		echo wbLinks::local($row['uniqLink'],toDisplay($row['dTitle']));
		echo '</li>';
	}
	
	function displayPre(){
		echo '<ol>';
	}
	function displayPost($prev,$pages,$next){
		echo '</ol>';
		parent::displayPost($prev,$pages,$next);
	}
	
	function displayEmpty(){
		parent::displayEmpty();
		return true;
	}
	
}

new deadEndFiles();

