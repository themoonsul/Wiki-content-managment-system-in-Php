<?php
/*


http://www.google.com/webmasters/add.html



<?xml version="1.0" encoding="UTF-8" ?> 
<Module>
   <ModulePrefs title="__MODULE_ID__ demonstration" height="140"/>
   <Content type="html">
      <![CDATA[
      <i>This gadget illustrates the proper use of &#95;&#95;MODULE_ID__</i>.<p>
      <script type="text/javascript">
      function doclick__MODULE_ID__() {
         var output = _gel("outputd" + __MODULE_ID__)
         var name = _gel("inputb" + __MODULE_ID__);
         output.innerHTML = "Hello, " +name.value+ ".";
      }
      </script>
      <input type=text value="Your name" id=inputb__MODULE_ID__>
      <input type=button value="Go" onclick="doclick__MODULE_ID__()">
      <p>
      <div id=outputd__MODULE_ID__></div>
   ]]>
   </Content>
</Module>

*/




defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$page;
$page->displayTitle = 'Google Gadget'; //!!$lang
$page->regLink('?','Google Gadget?en=Google_Gadget');


includeFile('search/all.php');
	



class googleGadget extends query{
	
	var $numTables = 0;
	var $numFields = 0;
	
	function googleGadget(){
		global $page,$dbInfo,$pageOwner,$langA,$wbTables;
		$this->rowLimit = 7;
		
		$this->queryAllFiles();
		$this->query .= ' AND '.$wbTables['all_files'].'.owner_id = "'.$pageOwner['user_id'].'" ';
		$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';
		$this->query .= ' ORDER BY '.$wbTables['all_files'].'.`modified` DESC '; //won't need to specify all_files once completely developed
		
		$this->searchUrl = '/Special/'.$pageOwner['username'].'/googleGadget';
		$this->browse('Google Gadget');	//!!$langA	
	}
	
	function displayNumbers(&$from,&$to,&$rowsFound,&$prev,&$next){}
	function displayEmpty(){}
	
	function displayPre(){
		global $langA,$serverName1,$pageOwner,$serverName4;
		
		//.tls {white-space:nowrap;overflow:hidden;}
		//.tld {white-space:nowrap;text-align:right;width:8ex;}
		//<tr title="%SUBJECT%">' +'<td class=tls>' +'<div class=tls>' +'<a target=igmail ' +'href="http://mail.google.com/mail?account_id=oyejorge%40gmail.com&message_id=%HEX_THREAD_ID%&view=conv&extsrc=ig">' +'%SENDERS%%MESSAGE_COUNT%' +'&nbsp;-&nbsp;%SUBJECT%&nbsp;-&nbsp;' +'<font color=#6f6f6f>%SNIPPET%</font>' +'</a>' +'</div>' +'</td>' +'<td class=tld>' +'<nobr>%DATE%</nobr>' +'</td>' +'</tr>',
		
		$this->serverPrefix =& $serverName4;
			
		//header('Content-type: text/plain; charset=UTF-8');
		header('Content-type: text/xml; charset=UTF-8');
		echo '<'.'?xml version="1.0" encoding="UTF-8" ?'.'>';
		echo '<Module>';
		echo '<ModulePrefs title="'.wbHtmlspecialchars($pageOwner['username']).' - '.wbHtmlspecialchars($serverName1).'" ';
			echo ' height="160" render_inline="optional" scrolling="true" category="communication" category2="tools" description="WikyBlog.com ChangeLog for '.wbHtmlspecialchars($pageOwner['username']).'." ';
			//echo ' title_url="'.wbHtmlspecialchars($this->serverPrefix.'/Special/'.$pageOwner['username'].'/ChangeLog').'?__UP_show__" ';
			echo ' title_url="'.wbHtmlspecialchars($this->serverPrefix.'/Special/'.$pageOwner['username'].'/ChangeLog').'"';
			echo ' >';
			echo '<Require feature="dynamic-height"/>';
			echo '</ModulePrefs>';
			
			// echo '<UserPref name="show" display_name="Show" default_value="5" datatype="enum" >';
			// echo '<EnumValue value="1" />';
			// echo '<EnumValue value="2" />';
			// echo '<EnumValue value="3" />';
			// echo '<EnumValue value="4" />';
			// echo '<EnumValue value="5" />';
			// echo '<EnumValue value="6" />';
			// echo '<EnumValue value="7" />';
			// echo '<EnumValue value="8" />';
			// echo '<EnumValue value="9" />';
			// echo '</UserPref>';
			
		echo '<Content type="html"><![CDATA[';
		echo '<style>a {font-size:83%;text-decoration:none;} th{font-weight:normal;font-size:75%;}';
		echo 'table{margin:0}';
		echo '.td1{text-align:left;white-space:nowrap;overflow:hidden;}';
		echo '.td2{text-align:right;white-space:nowrap;width:15ex;}';
		echo '.ip{font-size:75%}';
		echo '</style>';
		echo '<table cellpadding="2" cellspacing="0" border="0" style="width:100%">';
		echo '<tr><th class="td1">File</th><th class="td2">By</th></tr>';
// 		echo '<tr><td>';
// 		echo showArray($_GET);
// 		echo '</td></tr>';
	}
	function displayPost(&$prev,&$pages,&$next){
		echo '</table>';
		echo "]]>\n";
		echo '</Content></Module>';
		exit(); //must end it here
	}
		
	function abbrevOutput(&$row){
		global $langA;
		
		$this->queryAllResult($row);
		echo "\n<tr>";
		echo '<td class="td1"><div class="td1">';
		echo '<a href="'.$this->serverPrefix.$row['uniqLink'].'" target="_top" title="'.toDisplay($row['dTitle']).'">'.toDisplay($row['dTitle'],20);
		echo '</div></td><td class="td2"><div class="td2">';
		
		if( !empty($row['username']) ){
			echo '<a href="'.$this->serverPrefix.'/'.$row['username'].'/'.$GLOBALS['wbDefaultTitle'].'">'.$row['username'].'</a>';
		}else{
			echo '<span class="ip">'.$row['ip'].'</span>';
		}
		echo '</div></td></tr>';
			
	}
}

new googleGadget();


