<?php

defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$page;

$page->displayTitle = $langA['wanted_files'];
$page->regLink('?',$langA['wanted_files'].'?en=Wanted_Files');

includeFile('search/all.php');
	
class queryWanted extends query{
	var $tempObject;
	
	function queryWanted(){
		global $page,$dbInfo,$pageOwner,$langA,$wbTables;
		$page->css2 =true;
		$this->rowLimit = 50;
		
		
		$this->query = 'SELECT DISTINCT SQL_CALC_FOUND_ROWS ';
		$this->query .= ' `to_link`, COUNT(*) as `count` ';
		$this->query .= ' FROM '.$wbTables['all_links'];
		$this->query .= ' INNER JOIN '.$wbTables['all_files'].' USING(`file_id`) ';
		$this->query .= ' WHERE `to_owner` = "'.wbDB::escape($pageOwner['username']).'" ';
		$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';
		$this->query .= ' AND `to_id` IS NULL ';
		
		$this->query .= ' GROUP BY `to_link` ';
		//$this->query .= ' HAVING COUNT(*) > '.$count;

		$this->searchUrl = '/Special/'.$pageOwner['username'].'/WantedFiles';
		$this->browse($langA['wanted_files']);
	}
	
	function abbrevOutput(&$row){
		echo '<li>';
		echo wbLinks::local($row->to_link,str_replace('_',' ',$row->to_link));
		echo ' &nbsp; (';
		echo wbLinks::special('WhatLinksHere?to='.$row->to_link,$row->count.' links');
		echo ')';
		echo '</li>';
	}
	
	function mysqlFetch(&$result){
		return mysql_fetch_object($result);
	}
	function displayPre(){
		echo '<ol>';
	}
	
	function displayPost($prev,$pages,$next){
		echo '</ol>';
		parent::displayPost($prev,$pages,$next);
	}
	
	function displayEmpty(){
		parent::displayEmpty();
		return true;
	}
}

new queryWanted();

