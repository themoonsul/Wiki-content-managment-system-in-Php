<?php
defined('WikyBlog') or die("Not an entry point...");


includeFile('search/User.php');