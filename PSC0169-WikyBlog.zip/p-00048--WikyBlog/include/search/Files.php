<?php
defined('WikyBlog') or die("Not an entry point...");

includeFile('search/all_space.php');

class queryFiles extends query_space{
	var $classes;
	
	function queryFiles($space='page',$plural='pages'){
		global $dbInfo,$pageOwner,$page,$langA,$wbTables;
		
		//Space Info
		$this->SetSpaceInfo($space);
		
		
		$page->displayTitle = $langA['browse'].' > '.$langA[$this->SpaceClass];
		$label = $langA['browse'].' '.$langA[$this->SpaceClass];
		
		
		$this->searchUrl = '/Special/'.$pageOwner['username'].'/Browse'.wbUcwords($plural);
		
		$this->rowLimit = 5;

		
		//$this->fields[--shown to user--] = --database column--
		$this->fields[$langA['posted']] = 'posted';
		$this->fields[$langA['modified']] = 'modified';
		$this->fields[$langA['created']] = $this->SpaceInfo['dbTable'].'.`file_id`';//'created';
		
		
		$this->query .= 'SELECT SQL_CALC_FOUND_ROWS '.wbData::dbInfo($space,'querySelect');
		$this->query .= ' ,'.wbData::dbInfo($space,'uniqLink').' as uniqLink ';
		$this->query .= ' ,'.wbData::getDTitle($space);
		$this->query .= ' , `modified`, `posted`, `created`,`flags` ';
		$this->query .= ' FROM ';
		
		// $this->query .= $this->SpaceInfo['dbTable'];
		// $this->query .= ' LEFT JOIN '.$wbTables['all_files'];
		$this->query .= $wbTables['all_files'];
		$this->query .= ' INNER JOIN '.$this->SpaceInfo['dbTable'];
		
		$this->query .= ' ON '.$wbTables['all_files'].'.`file_id` = '.$this->SpaceInfo['dbTable'].'.`file_id` ';
		$this->query .= ' WHERE owner_id = "'.$pageOwner['user_id'].'" ';
		$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';//deleted, hidden, redirect and relvisible flags
		$this->query .= ' AND !FIND_IN_SET("redirect", '.$wbTables['all_files'].'.flags) ';
		
		$this->orderBy();
		//message($this->query.'<p>');
		$this->browse($label);
	}


}

//					QUERY CLASS
//
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//					CONTROL FLOW

global $dbInfo,$page,$pageOwner,$dbObject,$langA;
$page->regLink('?',$langA['browse'].'?en=Browse');

switch($dbObject->title){
	case 'browsecomments':
		$space = 'comment';
		$plural = 'comments';
	break;
	
	default:
	case 'browsepages';
		$space = 'page';
		$plural = 'pages';
	break;
}

new queryFiles($space,$plural);

