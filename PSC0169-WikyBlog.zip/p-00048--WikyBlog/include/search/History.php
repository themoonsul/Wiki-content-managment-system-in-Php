<?php

defined('WikyBlog') or die("Not an entry point...");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//					HISTORY LISTS
//
	
	includeFile('search/all.php');
	
	class queryHistory extends query{
		var $classes;
		
		var $month,$day = false;
		
		function queryHistory(){
			global $page,$dbInfo,$dbObject,$pageOwner,$maxHistory,$langA,$wbTables;
			
			if( !$dbObject->exists ){
				message('NON_EXISTANT');
				return;
			}
						
			if( isOwner() ){
				if( strpos($dbObject->flags,'notchecked') !== false){
					message('<img src="'.wbLinks::getDir('/imgs/icons/bullet_flag_yellow.gif').'" border="0" width="16" height="16" style="vertical-align:middle" alt="'.$langA['unchecked'].'"/> '.$langA['unchecked']);
				}
				
				if( strpos($dbObject->flags,'flag3') !== false){
					message('<img src="'.wbLinks::getDir('/imgs/icons/bullet_error.gif').'" border="0" width="16" height="16" style="vertical-align:middle" alt="'.$langA['syntax_warning'].'" /> '.$langA['syntax_warning']);
				}
			}
			
			
			$page->css2 = true;
			$page->formMethod = 'get';
			$page->formAction = $this->searchUrl = '/Edit'.$dbObject->uniqLink;
			$page->formAction .= '?hist';	//so that the form is different from 
		
			
			$maxHistory = (int)$maxHistory;
			$pageOwner['maxHistory'] = (int)$pageOwner['maxHistory'];
			if( ($maxHistory > 0) && ($maxHistory < $pageOwner['maxHistory']) ){
				$this->maxRows = $maxHistory;
			}elseif( $pageOwner['maxHistory'] > 0 ){
				$this->maxRows = $pageOwner['maxHistory'];
			}
			
			
			$this->classes[] = ' class="tableRowEven" ';
			$this->classes[] = ' class="tableRowOdd" ';
			$this->rowLimit = 25;
			
			$this->query = ' SELECT SQL_CALC_FOUND_ROWS * FROM '.$wbTables['all_history'];
			$this->query .= ' WHERE ';
			$this->query .= ' `file_id` = '.$dbObject->file_id;
			$this->query .= ' ORDER BY revision DESC';
			$this->browse($langA['history']);
		}
		
		function mysqlFetch(&$result){
			return mysql_fetch_object($result);
		}

		function displayEmpty(){
			return true;
		}
		
		function displayPre(){
			global $page,$dbObject,$langA;
			
			echo '<table cellpadding="2" cellspacing="0" border="0" width="100%">';
			echo  '<tr class="tableRows"><th>'.$langA['timeline'].'</th><th colspan="2">'.$langA['revision'].'</th><th>'.$langA['user'].'</th><th>'.$langA['summary'].'</th></tr>';
		}
		
		function abbrevOutput(&$row,$i){
			global $page,$pageOwner,$dbObject;
			global $langA;
			
			//	3)	Echo a row
			$class3 = $this->classes[($i%2)];
			
			echo '<tr>';
			$this->timelineTD($row->modified);

	
			echo '<td '.$class3.' style="white-space:nowrap">';
			$checked = '';
			if( $i == 1 ){
				$checked = ' checked="checked" ';
				echo $langA['current'];
			}else{
				echo $row->revision;
			}
			echo '</td><td '.$class3.' style="white-space:nowrap"> ';
			//echo '<input type="radio" name="revNum1" value="'.$row->revision.'" '.$checked.' onFocus="radioFocus(this)" />';
			//echo '<input type="submit" name="cmd['.$row->revision.']" value="'.$langA['compare'].'" title="'.$langA['COMPARE_REVISONS'].'" onMouseOver="histList(this)" />';
			
			echo '<input type="radio" name="revNum1" value="'.$row->revision.'" '.$checked.' /> ';
			echo '<input type="submit" name="cmd['.$row->revision.']" value="'.$langA['compare'].'" title="'.$langA['COMPARE_REVISONS'].'" />';
			
			if( $i == 1 ){
				//nothing for current
			}else{
				if( isset($dbObject->dbInfo['xmlHTTP']) && $dbObject->dbInfo['xmlHTTP'] == 0){
					echo wbLinks::local('/Edit'.$dbObject->uniqLink.'?cmd=editRevision&revNum='.$row->revision,$langA['edit_revision'],'name="noxml"');
				}else{
					echo wbLinks::local('/Edit'.$dbObject->uniqLink.'?cmd=show&revNum='.$row->revision,$langA['show']);
				}
			}
			
			echo '</td><td '.$class3.'>';
			
			
			if( !empty($row->username) ){
				echo wbLinks::user($row->username);
				//echo wbLinks::local('/'.$row->username.'/'.$GLOBALS['wbDefaultTitle'],$row->username);
				$guest = $row->username;
			}else{
				echo $row->ip;
				$guest = $row->ip;
			}

			
			if( !isset($this->users[$guest]) ){
				echo '<span class="sm">';
				echo '&nbsp; ';
				echo wbLinks::special('UserEdits?user='.$guest,'edits');
				if( !empty($_SESSION['username']) ){
					if($_SESSION['username'] != $guest){
						echo '&nbsp; ';
						echo wbLinks::special('Permissions?guest='.$guest,'+/-','title="'.$langA['SET_USER_PERMISSIONS'].$guest.'"',$_SESSION['username']);
					}
				}
				echo '</span>';
				$this->users[$guest] = true;
			}			
			
			
			
			
			
			echo '</td><td '.$class3.'><span class="sm">';
			echo $row->summary;
			echo '&nbsp;</span></td></tr>';
		}

		function displayPost(&$prev,&$pages,&$next){
			echo '</table>';
			parent::displayPost($prev,$pages,$next);
		}
	}//end class
	
	
	
new queryHistory();


