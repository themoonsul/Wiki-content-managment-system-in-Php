<?php

defined('WikyBlog') or die("Not an entry point...");

/*
things to remove
	edate

*/

includeFile('search/all.php');

class searchKeywordPage extends query{
	var $keyword;
	var $label;
	var $links = array(); //for $dbObject
	var $fileLinks; //for each row found
	var $dbInfo;
	var $useDbInfo;
	var $space;
	
	function searchKeywordPage($type){
		global $dbInfo,$page;
		$page->css2 = true;
		
		$this->space = $type;
		
		$info = $dbInfo[$this->space];
		if( isset($info['keySpace']) && ($info['keySpace'] !== true) ){ // 'keySpace' is used by spaces created by the software
			$this->useSpace = $info['keySpace'];
			
		}elseif( isset($info['useInfo']) ){ // 'useInfo' will be used by custom plugins
			$this->useSpace = $info['useInfo'];
			
		}else{
			die('INVALID_REQUEST');
		}
		
		
		if( !isset($dbInfo[$this->useSpace]) ){
			die('Not found in dbInfo: '.$this->useSpace);
			
		}
		$this->useDbInfo = $dbInfo[$this->useSpace];
		$this->displayClass = wbData::getClass($this->useSpace,true);
	}
	
	function getOwner(&$pathArray){
		return $GLOBALS['wbConfig']['pUser'];
	}
	function getStep1($pathArray){}
	
	function getStep2(){
		global $dbInfo,$page,$wbTables,$wbNow,$langA;
		$this->rowLimit = 10;
		
		
		if( isset($langA[$this->space]) ){
			$this->title = $langA[$this->space];
		}else{
			$this->title = toDisplay($this->space);
		}
		$this->searchUrl = '/'.$this->title;		


		$this->query = 'SELECT SQL_CALC_FOUND_ROWS '.wbData::dbInfo($this->useSpace,'querySelect');
		$this->query .= ', '.wbData::dbInfo($this->useSpace,'uniqLink').' as uniqLink ';
		$this->query .= ', '.wbData::getDTitle($this->useSpace);
		$this->query .= ', '.$wbTables['all_files'].'.* ';
		$this->query .= ' FROM '.wbData::dbInfo($this->useSpace,'queryFrom');
		$this->query .= ' LEFT JOIN '.$wbTables['all_files'];				//join to all_files needs to be last!
		$this->query .= ' ON '.$wbTables['all_files'].'.`file_id` = '.$this->useDbInfo['dbTable'].'.`file_id` ';
		$this->query .= ' WHERE';
		$this->query .= $wbTables['all_files'].'.`visible` = 1 ';
		
		if( !empty($this->config['where']) ){
			$this->query .= ' AND '.$this->config['where'];
		}

		
		//Similar to searchKeywords.php
		$pos= strpos($this->config['keyword'],':');
		if(($pos === false)||($pos+1) == strlen($this->config['keyword'])){
			$temp = $this->config['keyword'].':';
			
			$this->query .= ' AND (';
			$this->query .= ' (FIND_IN_SET("'.wbDB::escape(wbHtmlspecialchars($this->config['keyword'])).'", '.$wbTables['all_files'].'.`keywords` )>0) ';
			$this->query .= ' OR ('.$wbTables['all_files'].'.`keywords` LIKE "'.wbDB::like(wbHtmlspecialchars($temp)).'%") ';
			$this->query .= ' OR ('.$wbTables['all_files'].'.`keywords` LIKE "%,'.wbDB::like(wbHtmlspecialchars($temp)).'%") ';
			$this->query .= ')';
		}else{
			$this->query .= ' AND (FIND_IN_SET("'.wbDB::escape(wbHtmlspecialchars($this->config['keyword'])).'", '.$wbTables['all_files'].'.`keywords` )>0) ';	//FIND_IN_SET seems to be case insensitive?
		}
		
		if( isset($this->config['order']) ){
			$this->query .= ' ORDER BY '.$this->config['order'];
		}
		
		$this->browse($this->title);
	}
	
	function mysqlFetch(&$result){
		return mysql_fetch_object($result);
	}
	function abbrevOutput(&$row,&$i,&$actualRowsFound){
		call_user_func(array($this->displayClass,'abbrevOutput'),$row,$i,$actualRowsFound);
	}
}
