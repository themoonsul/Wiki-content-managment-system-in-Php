<?php

defined('WikyBlog') or die("Not an entry point...");

global $pageOwner,$dbObject,$langA,$page;

$page->displayTitle = $langA['flagged'];
$page->regLink('?',$langA['flagged'].'?en=Flagged');

includeFile('search/all.php');
	
class flagged extends query{
	var $tempObject;
	var $flags;
	function flagged(){
		global $dbInfo,$langA,$pageOwner,$page,$dbObject;
		$this->overWrite['flag'] = false;
		$contentUri = $page->regLink($langA['flagged'],$this->searchUrl = '/Special/'.$pageOwner['username'].'/Flagged');
		
		$this->flag =& $_GET['flag'];
		
		//				flag			langA
		$this->flags['template'] = 'content_template';
		$this->flags['redirect'] = 'redirect';
		if( isOwner(true,false) ){
			$this->flags['relvisible'] = 'editor_visible';
			$this->flags['hidden'] = 'hidden';
		}
		
		if( !isset($this->flags[$this->flag]) ){
			ob_start();
			$this->selectFlag();
			$page->contentB[$contentUri] = wb::get_clean();
			return;
		}
		
		$this->show();
	}
	function selectFlag(){
		global $langA;
		echo '<b>'.$langA['flagged'].':</b> ';
		foreach($this->flags as $flag => $langValue){
			if( $this->flag == $flag ){
				echo wbLang::text($langValue);
				echo ' &nbsp; ';
				continue;
			}
			echo wbLinks::special('Flagged?flag='.$flag,$langValue);
			echo ' &nbsp; ';
		}
	}
	
	function show(){
		global $page,$dbInfo,$pageOwner,$langA,$wbTables;
		$page->css2 =true;
		$this->rowLimit = 50;
		
		//
		//	New
		//
		$this->allSelect = array('modified');
		$this->queryAllFiles();
		$this->query .= ' AND (';
			$this->query .= ' FIND_IN_SET("'.wbDB::escape($this->flag).'", '.$wbTables['all_files'].'.`flags`) ';
		$this->query .= ')';
		
		
		switch($this->flag){
			case 'hidden':
				$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 0 ';
				$this->query .= ' AND !FIND_IN_SET("deleted", '.$wbTables['all_files'].'.`flags`) ';
				$this->query .= ' AND !FIND_IN_SET("relvisible", '.$wbTables['all_files'].'.`flags`) ';
			break;
			
			case 'relvisible':
				$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 0 ';
				$this->query .= ' AND !FIND_IN_SET("deleted", '.$wbTables['all_files'].'.`flags`) ';
				$this->query .= ' AND !FIND_IN_SET("hidden", '.$wbTables['all_files'].'.`flags`) ';
			break;
			
			default:
				$this->query .= ' AND '.$wbTables['all_files'].'.`visible` = 1 ';//deleted, hidden, redirect and relvisible flags
			break;
		}
		
		$this->query .= ' AND `owner_id` = "'.wbDB::escape($pageOwner['user_id']).'" ';
		
		$this->browse($langA['flagged']);
	}
	
	function displayNumbers(&$from,&$to,&$rowsFound,&$prev,&$next){
		$this->selectFlag();
		parent::displayNumbers($from,$to,$rowsFound,$prev,$next);
	}

	function displayPre(){
		echo '<ol>';
	}
	
	function displayPost($prev,$pages,$next){
		echo '</ol>';
		parent::displayPost($prev,$pages,$next);
	}
	
	function displayEmpty(){
		parent::displayEmpty();
		return true;
	}
}

new flagged();
