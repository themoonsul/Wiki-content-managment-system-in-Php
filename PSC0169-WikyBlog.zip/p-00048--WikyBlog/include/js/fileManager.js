
function wbUL(){}
wbUL.addFile=function(el){var tbl=WB.C(el,'TBODY');var row=WB.C(el,'TR');el.style.position='absolute';el.style.left='-1000px';t=el.value.replace('\\','/');pos=t.search('/');while(pos>=0){if(pos==-1){break;}
t=t.substr(pos+1);pos=t.search('/');}
var txt=dcc('span');txt.innerHTML=t;el.parentNode.appendChild(txt);var td=dcc('td');td.innerHTML='<a href="" onclick="wbUL.remove(this);return false;"/>'+lg[27]+'</a>';row.appendChild(td);wbUL.adjust(tbl);}
wbUL.remove=function(el){var tbl=WB.C(el,'TBODY');var row=WB.C(el,'TR');dcr(row);var fi=dcc('input');fi.type='file';fi.name='userfile[]';fi.onchange=function(){wbUL.addFile(this)}
var td=dcc('td');td.appendChild(fi);var tr=dcc('tr');tr.style.display='none';tr.appendChild(td);tbl.appendChild(tr);wbUL.adjust(tbl);return false;}
wbUL.adjust=function(tbl){var trs=tbl.childNodes;var a=false;for(i=0;i<trs.length;i++){if(trs[i].childNodes.length==1){if(!a){a=true;trs[i].style.display='';}else{trs[i].style.display='none';}}}}