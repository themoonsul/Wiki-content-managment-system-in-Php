
function wbUL(){}
wbUL.remove=function(el){var tbl=WB.C(el,'TBODY');if(tbl.childNodes.length==7){wbUL.addFileInput(tbl);}
var row=WB.C(el,'TR');dcr(row);return false;}
wbUL.addFile=function(el){var tbl=WB.C(el,'TBODY');var row=WB.C(el,'TR');el.style.position='absolute';el.style.left='-1000px';t=el.value;while(pos=t.search('\\\\')){if(pos==-1){break;}
t=t.substr(pos+1);}
row.firstChild.style.textAlign="left";row.lastChild.innerHTML='<input type="Submit" name="cmd" value="Remove" onclick="wbUL.remove(this)"/>';var txt=dcc('span');txt.innerHTML=t;el.parentNode.appendChild(txt);if(tbl.childNodes.length<7){wbUL.addFileInput(tbl);}}
wbUL.addFileInput=function(tbl){var new_row=dcc("tr");var last=tbl.lastChild;tbl.insertBefore(new_row,last);var new_td=dcc("td");new_td.style.textAlign="right";new_td.innerHTML='<input type="file" name="userfile[]" onchange="wbUL.addFile(this)" >';new_row.appendChild(new_td);var new_td=dcc("td");new_row.appendChild(new_td);}