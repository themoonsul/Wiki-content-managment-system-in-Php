
function showBacktrace(el){if(el.nextSibling.style.display=='none'){WB.DS(el.nextSibling);}else{WB.DS(el.nextSibling,'none');}}