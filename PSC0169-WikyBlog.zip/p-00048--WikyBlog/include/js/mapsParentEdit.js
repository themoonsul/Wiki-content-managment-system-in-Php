
olE=new Object();olE.miles=true;olE.geocoder=false;olE.picon=false;olE.init=function(fr){fr.mapObj.editing=true;fr.mapObj.tempO=false;fr.myCtrl=new wbCtrl();fr.myGmap.addControl(fr.myCtrl);wbMaps.reSize();if(fr.mapObj.count>(wbMaps.max-10)){if(fr.mapObj.count>wbMaps.max){alert(sprintf(lg[34],fr.mapObj.count,wbMaps.max));}else{alert(sprintf(lg[70],fr.mapObj.count,wbMaps.max));}}
var a;for(var i=0;i<fr.mapObj.overlays.length;i++){a=fr.mapObj.overlays[i];if(a.enableDragging){a.enableDragging();}}}
olE.up=function(){var a=dcg('WBmapFld'+WB.shn+mf.mapObj.current);if(!a)return;var b=a.previousSibling;if(!b)return;olE.trade(b,a);WBe.set(true);}
olE.down=function(){var a=dcg('WBmapFld'+WB.shn+mf.mapObj.current);if(!a)return;var b=a.nextSibling;if(!b)return;olE.trade(a,b);WBe.set(true);}
olE.trade=function(a,b){var ci=olE.divN(a);var c=mf.mapObj.overlays[ci];var di=olE.divN(b);var d=mf.mapObj.overlays[di];if(c.getIcon&&d.getIcon){var lt=mf.mapObj.letters[di];mf.mapObj.letters[di]=mf.mapObj.letters[ci];mf.mapObj.letters[ci]=lt;olE.newLet(c,ci);olE.newLet(d,di);}
a.parentNode.insertBefore(b,a);}
olE.newLet=function(a,i){var pt=a.getPoint();mf.myGmap.removeOverlay(a);wbMaps.nMarker(mf,pt,0,i,mf.mapObj.letters[i]);mf.myGmap.addOverlay(mf.mapObj.overlays[i]);olE.updMenu(i);}
olE.divN=function(a){var len=('WBmapFld'+WB.shn).length;return parseInt(a.id.substr(len));}
olE.remove=function(){try{if(!confirm(lg[52]))return;var i=mf.mapObj.current;if(!(i>=0)){return;}
WBe.set(true);mf.myGmap.closeInfoWindow();var ol=mf.mapObj.overlays[i];mf.myGmap.removeOverlay(ol);var prev=wbMaps.prevId();if(ol.setPoint){mf.mapObj.count--;}else{mf.mapObj.count-=ol.getVertexCount();}
if(i==(mf.mapObj.overlays.length-1)){mf.mapObj.overlays.splice(i,1);mf.mapObj.letters.pop();}else{delete mf.mapObj.overlays[i];}
wbMaps.removeMenu(i);delete mf.mapObj.current;wbMaps.Oselect(prev);return;}
catch(m){err(m,'remove');return;}}
olE.info=function(){var i=mf.mapObj.current;var ol=mf.mapObj.overlays[i];var tp;var m='';var cl='';var thPt;var pr=wbMaps.prevId();var n=wbMaps.nextId();var pPt;var txt;m+='<div class="WBboxInfo">&nbsp;</div>';m+='<div class="WBcontentArea2">';m+='<h1 class="WBpageTitle">'+lg[51]+'</h1>';m+='<table class="tableRows" width="100%">';if(ol.setPoint){thPt=ol.getPoint();tp='Marker';m+='<tr><th>'+lg[56]+'</th><th>'+lg[53]+'</th></tr>';txt=dcg('WBmapDesc'+WB.shn+i).value;m+='<tr><td>'+thPt+'</td><td>'+wbMaps.text(txt,35)+'</td></tr>';}else{tp='Route';thPt=ol.getVertex(0);var pts=wbMaps.toPoints(ol);var ppt;var nwDis=0;var dis=0;m+='<tr><th>'+lg[54]+'</th><th>'+lg[55]+'</th><th>'+lg[56]+'</th></tr>';for(var j=0;j<pts.length;j++){if(ppt){nwDis=wbMaps.dist(ppt,pts[j]);dis=dis+nwDis;}
cl=' class="tableRowOdd" ';if((j%2)==0){cl=' class="tableRowEven" ';}
m+='<tr'+cl+'><td> '+(j+1)+' </td><td> '+olE.rduce(nwDis)+olE.gUnits()+'</td><td> '+pts[j]+' </td></tr>';ppt=pts[j];}
m+='<tr><th>'+lg[57]+'</th><th>'+lg[58]+'</th><th>'+lg[59]+'</th></tr>';m+='<td>'+(pts.length-1)+'</td><td>'+olE.rduce(dis)+olE.gUnits()+'</td><td>'+olE.rduce(wbMaps.dist(ppt,pts[0]))+olE.gUnits()+'</td></tr>';}
if(pr!=i){if(mf.mapObj.overlays[pr].setPoint){pPt=mf.mapObj.overlays[pr].getPoint();}else{pPt=mf.mapObj.overlays[pr].getVertex(0);}
m+='<tr><th>'+lg[64]+'</th><th>'+lg[65]+'</th></tr>';txt=dcg('WBmapDesc'+WB.shn+pr).value;m+='<tr><td>'+olE.rduce(wbMaps.dist(thPt,pPt))+olE.gUnits()+'</td><td>'+wbMaps.text(txt,35)+'</td></tr>';}
if(n!=i){if(mf.mapObj.overlays[n].setPoint){pPt=mf.mapObj.overlays[n].getPoint();}else{pPt=mf.mapObj.overlays[n].getVertex(0);}
m+='<tr><th>'+lg[66]+'</th><th>'+lg[67]+'</th></tr>';txt=dcg('WBmapDesc'+WB.shn+n).value;m+='<tr><td>'+olE.rduce(wbMaps.dist(thPt,pPt))+olE.gUnits()+'</td><td>'+wbMaps.text(txt,35)+'</td></tr>';}
m+='</table>';m+='<br/><div class="sm">';m+=lg[69];m+='</div><br/>';m+='</div>';txt=dcg('WBmapDesc'+WB.shn+i).value;WB.at=false;var lbl=wbMaps.text(txt,16);var id=wbCA.add(lbl,m,false,false);WBt.go(id);}
olE.rduce=function(x,a){a=a||1;var b=Math.pow(10,a);return Math.round(x*b)/b;}
olE.infoTxt=function(a){var b=dcg('WBmapInfo'+WB.shn);if(b)b.innerHTML=a.replace(/ /g,'&nbsp;');}
olE.infoLine=function(pt){var u=olE.gUnits();var a=mf.mapObj.overlays[mf.mapObj.current];if(!a)return;var j=mf.mapObj.cl.length;txt=lg[39]+(j);txt+='    '+lg[60]+mf.mapObj.len+u;if(j>0){var pt1=a.getVertex(j-1);if(pt){txt+='    '+lg[61]+olE.rduce(wbMaps.dist(pt,pt1))+u;}}
olE.infoTxt(txt);}
olE.infoMark=function(){var i=mf.mapObj.current;var ol=mf.mapObj.overlays[i];if(!ol)return;var pt=ol.getPoint();var txt=lg[38]+olE.rduce(pt.lat(),4);txt+='     '+lg[37]+olE.rduce(pt.lng(),4);var dv=dcg('WBmapFld'+WB.shn+i);dv=dv.previousSibling;if(dv){var fld='WBmapFld'+WB.shn;var id=dv.id.substr(fld.length);ol=mf.mapObj.overlays[id];if(ol){var pt2=false;if(ol.getPoint){pt2=ol.getPoint();}else if(ol.getVertex){pt2=ol.getVertex(ol.getVertexCount()-1);}
if(pt2){txt+='     '+lg[68]+olE.rduce(wbMaps.dist(pt,pt2))+olE.gUnits();}}}
olE.infoTxt(txt);}
olE.cUnits=function(){var a=dcg('WBunits'+WB.shn);if(olE.miles){a.innerHTML=lg[63];olE.miles=false;}else{a.innerHTML=lg[62];olE.miles=true;}
wbMaps.Oselect(mf.mapObj.current);}
olE.gUnits=function(){if(olE.miles){return lg[62];}
return lg[63];}
olE.updMenu=function(i,a){if(!a){a=dcg('WBmapDesc'+WB.shn+i).value;}
var menu=dcg('WBmapFld'+WB.shn+i);if(menu){var str='';if(mf.mapObj.letters[i]){str='<b>'+mf.mapObj.letters[i]+'</b>'}
str+=wbMaps.text(a,20);menu.innerHTML=str;}}
olE.updDesc=function(el){i=mf.mapObj.current;if(!mf.mapObj.overlays[i]){return;}
WBe.set(true);var txt=el.form.d.value;if(txt.length>1000){alert(sprintf(lg[49],txt.length));}
var d=dcg('WBmapDesc'+WB.shn+i);d.value=txt;olE.updMenu(i,txt);wbMaps.Oselect(i);}
olE.editDesc=function(){var a=mf.mapObj;var c=dcg('WBmapDesc'+WB.shn+a.current);if(!c)return;txt='<form onsubmit="return false"><textarea rows="5" style="width:100%" name="d">';txt+=c.value;txt+='</textarea>';txt+='<input type="submit" value="Update" onclick="p.olE.updDesc(this)" />';txt+=' <input type="submit" value="Cancel" onclick="myGmap.closeInfoWindow()" />';txt+='</form>';var b=a.overlays[a.current];if(b.setPoint){b.openInfoWindowHtml(txt);}else if(a.cl.length>0){mf.myGmap.openInfoWindowHtml(a.cl[0],txt);}}
olE.showBoxes=function(a,i){i=i||1;var box=dcg('WBmapEdit'+a);var c=box.childNodes;for(var j=0;j<c.length;j++){if(c[j].style){WB.DS(c[j],'none');}}
box=dcg('WBmapEdit'+i+a);WB.DS(box);return;}
olE.gpx=function(a){if(!a&&typeof(import_gpx)=='undefined'){WBx.SA();WB.LF('script','/include/js/mapsParentGpx.js?'+WB.nJs,true);WB.TO('olE.gpx(true)',300);return;}
WBx.CA(true);var a=WBt.gTab('A',false,WB.shn);olE.showBoxes(a.rev,3);}
olE.save=function(url){if(!WB.compat){err('Not compatible.');return;}
if(mf.mapObj.count>wbMaps.max){alert(sprintf(lg[50],mf.mapObj.count,wbMaps.max));return;}
var a=dcg('WBinputs'+WB.shn);a.innerHTML='';var d=Array();var c=false;var txt;a.innerHTML+='<input type="hidden" name="zoom" value="'+mf.myGmap.getZoom()+'" />';var mType=-1;for(var ix=0;ix<mf.myGmap.getMapTypes().length;ix++){if(mf.myGmap.getMapTypes()[ix]==mf.myGmap.getCurrentMapType())
mType=ix;}
a.innerHTML+='<input type="hidden" name="mapType" value="'+mType+'" />';var olays=dcg('WBmarkers'+WB.shn).childNodes;if(!olays){return;}
var fld='WBmapFld'+WB.shn;var ol;for(i=0;i<olays.length;i++){if(!olays[i].id){continue;}
id=olays[i].id.substr(fld.length);ol=mf.mapObj.overlays[id];if(ol.getPoint){a.innerHTML+='<input type="hidden" name="npts['+id+'][]" value="'+ol.getPoint().lat()+'" />';a.innerHTML+='<input type="hidden" name="npts['+id+'][]" value="'+ol.getPoint().lng()+'" />';if(!c){c=ol.getPoint();}}else{var len=ol.getVertexCount();for(var j=0;j<len;j++){var pt=ol.getVertex(j);if(pt){a.innerHTML+='<input type="hidden" name="npts['+id+']['+j+'][]" value="'+pt.lat()+'" />';a.innerHTML+='<input type="hidden" name="npts['+id+']['+j+'][]" value="'+pt.lng()+'" />';}}
if(!c){c=ol.getVertex(0);}}}
if(!c){c=mf.myGmap.getCenter();}
a.innerHTML+='<input type="hidden" name="c2[]" value="'+c.lat()+'" />';a.innerHTML+='<input type="hidden" name="c2[]" value="'+c.lng()+'" />';WB.hist=1;var tmp=WB.f.action;WB.f.action=WBx.reqUrl(WB.f.action);WB.f.target='WBhistory';WB.TO(function(){WB.RSr(WB.f,tmp);},100);WB.f.submit();WBe.set(false);}
olE.find=function(){var a=prompt('Enter an Address');if(a==null)return;a=trim(a);if(a=='')return;if(a=='undefined')return;if(!olE.geocoder){olE.geocoder=new mf.GClientGeocoder();}
olE.geocoder.getLatLng(a,function(point){if(!point){alert(a+' was not found');}else{var i=wbMaps.nMarker(mf,point,2);wbMaps.addOL(mf,i,a);wbMaps.Oselect(i);olE.infoMark();}});}
olE.m_Select=function(i){var ol=mf.mapObj.overlays[i];if(!ol.draggable()){var pt=ol.getPoint();mf.myGmap.removeOverlay(ol);wbMaps.nMarker(mf,pt,0,i,mf.mapObj.letters[i]);mf.myGmap.addOverlay(mf.mapObj.overlays[i]);}
olE.infoMark();}
olE.m_New=function(){wbMaps.unSelect();olE.emptyList();mf.myCtrl.hide();var l=mf.GEvent.addListener(mf.myGmap,'click',function(ol,pt){i=wbMaps.nMarker(mf,pt,2);wbMaps.addOL(mf,i,lg[46]+i);wbMaps.Oselect(i);});mf.mapObj.listeners.push(l);olE.infoTxt(lg[45]);}
olE.p_Select=function(i){mf.mapObj.cl=wbMaps.toPoints(mf.mapObj.overlays[i]);olE.p_dist();olE.infoLine();}
olE.p_New=function(){wbMaps.unSelect();olE.emptyList();mf.myCtrl.hide();var l=mf.GEvent.addListener(mf.myGmap,'click',function(ol,pt){var i=mf.mapObj.overlays.length;mf.mapObj.cl=Array();mf.mapObj.cl.push(pt);olE.p_draw(i);wbMaps.menu(mf,i,lg[48]);wbMaps.incr(mf,2);olE.p_addPts(1);wbMaps.Oselect(i,true);});mf.mapObj.listeners.push(l);olE.infoTxt(lg[47]);}
olE.p_addPts=function(a){mf.myGmap.closeInfoWindow();if(a==1){var l=mf.mapObj.listeners.pop();mf.GEvent.removeListener(l);}
WB.TO(function(){var l=mf.GEvent.addListener(mf.myGmap,'click',olE.p_addPt);mf.mapObj.listeners.push(l);l=mf.GEvent.addListener(mf.myGmap,'mousemove',function(pt){olE.infoLine(pt);});mf.mapObj.listeners.push(l);},300);}
olE.p_addPt=function(ol,pt){mf.mapObj.cl.push(pt);olE.p_draw(mf.mapObj.current);wbMaps.incr(mf,2);olE.infoLine();WBe.set(true);if(!mf.mapObj.tempO)return;olE.p_edit(true);}
olE.p_shift=function(){var i=mf.mapObj.current;if(mf.mapObj.cl.length<1)return;mf.mapObj.cl.shift();olE.p_shorten(i);if(!mf.mapObj.tempO)return;var a=mf.mapObj.tempO.shift();mf.myGmap.removeOverlay(a);var a=mf.mapObj.tempO.shift();mf.myGmap.removeOverlay(a);}
olE.p_pop=function(){var i=mf.mapObj.current;if(mf.mapObj.cl.length<1)return;mf.mapObj.cl.pop();olE.p_shorten(i);if(!mf.mapObj.tempO)return;var a=mf.mapObj.tempO.pop();mf.myGmap.removeOverlay(a);var a=mf.mapObj.tempO.pop();mf.myGmap.removeOverlay(a);}
olE.p_shorten=function(i){mf.mapObj.count--;if(mf.mapObj.cl.length>0){olE.p_draw(i);}
olE.infoLine();}
olE.p_draw=function(i){if(mf.mapObj.overlays[i]){mf.myGmap.removeOverlay(mf.mapObj.overlays[i]);}
mf.mapObj.overlays[i]=new mf.GPolyline(mf.mapObj.cl,'#0000ff');mf.myGmap.addOverlay(mf.mapObj.overlays[i]);if(i==mf.mapObj.current){olE.p_dist();}}
olE.p_dist=function(){if(!mf.mapObj.cl)return;var ppt;var dis=0;var leg=0;for(var j=0;j<mf.mapObj.cl.length;j++){if(ppt){dis=dis+wbMaps.dist(ppt,mf.mapObj.cl[j]);;}
ppt=mf.mapObj.cl[j];}
mf.mapObj.len=olE.rduce(dis);}
olE.p_edit=function(cont){if(!cont){mf.myGmap.closeInfoWindow();olE.emptyList();mf.mapObj.tempO=Array();}
var i=mf.mapObj.current;a=mf.mapObj.overlays[i];var len=a.getVertexCount();var b=false;var c=false;for(var j=0;j<len;j++){b=a.getVertex(j);if(c){var lat=(c.lat()+b.lat())/2;var lng=(c.lng()+b.lng())/2;olE.p_pt(new mf.GLatLng(lat,lng),j,(j*2)-1,true);}
olE.p_pt(b,j,(j*2));c=b;}}
olE.p_icon=function(){this.picon=new mf.GIcon();this.picon.iconSize=new mf.GSize(14,14);this.picon.iconAnchor=new mf.GPoint(7,7);this.picon.image=WB.dPrefix+'/imgs/maps/pIcon.png';}
olE.p_pt=function(a,i,j,b){b=b||false;var c=mf.mapObj.tempO[j];if(c){var d=c.getPoint();if((d.lng()!=a.lng())||(d.lat()!=a.lat())){c.setPoint(a);}
return;}
if(!this.picon){this.p_icon();}
var c=new mf.GMarker(a,{draggable:true,icon:new mf.GIcon(this.picon),bouncy:false,clickable:false,dragCrossMove:true});mf.GEvent.addListener(c,'dragend',function(){olE.p_movePt(i,this.getPoint(),b);});mf.mapObj.tempO.push(c);mf.myGmap.addOverlay(c);}
olE.p_movePt=function(i,pt,b){var a=mf.mapObj.overlays[mf.mapObj.current];mf.mapObj.cl=Array();var len=a.getVertexCount();for(var j=0;j<len;j++){if(i==j){mf.mapObj.cl.push(pt);if(!b)continue;}
mf.mapObj.cl.push(a.getVertex(j));}
olE.p_draw(mf.mapObj.current);olE.infoLine();WB.TO('olE.p_edit(true)',400);}
olE.emptyList=function(){var ls=mf.mapObj.listeners;if(ls.length>0){for(var i=0;i<ls.length;i++){mf.GEvent.removeListener(ls[i]);}
mf.mapObj.listeners=Array();}
ls=mf.mapObj.tempO;if(ls&&ls.length>0){for(i=0;i<ls.length;i++){mf.myGmap.removeOverlay(ls[i]);}
mf.mapObj.tempO=false;}}
function wbCtrl(){}
wbCtrl.prototype=new mf.GControl();wbCtrl.prototype.initialize=function(map){var a=map.getContainer();do{a=a.parentNode;}while(a&&!a.createElement);var c=a.createElement('div');c.className='linkCont';WB.DS(c,'none');var b=a.createElement('a');b.className='linkHead';b.onclick=function(){mf.myCtrl.sh_()}
c.appendChild(b);this.head=b;b=a.createElement('div');b.className='linkBod';b.innerHTML='';c.appendChild(b);this.bod=b;map.getContainer().appendChild(c);return c;}
wbCtrl.prototype.sh_=function(){var a=this.bod.style;if(a.display=='none'){a.display='';}else{a.display='none';}}
wbCtrl.prototype.getDefaultPosition=function(){return new mf.GControlPosition(mf.G_ANCHOR_TOP_LEFT,new mf.GSize(70,7));}
wbCtrl.prototype.update=function(i){WB.DS(this.head.parentNode);a='';a+=this.eLnk('p.olE.editDesc()',1);a+='<div class="spacer"></div>';if(mf.mapObj.overlays[i].setPoint){}else{a+=this.eLnk('p.olE.p_addPts()',35);a+=this.eLnk('p.olE.p_shift()',76);a+=this.eLnk('p.olE.p_pop()',43);a+=this.eLnk('p.olE.p_edit(false)',36);a+='<div class="spacer"></div>';}
a+=this.eLnk('p.olE.up()',41);a+=this.eLnk('p.olE.down()',42);a+=this.eLnk('p.olE.info()',40);a+='<div class="spacer"></div>';a+=this.eLnk('p.olE.remove()',27);this.bod.innerHTML=a;var c=dcg('WBmapDesc'+WB.shn+i).value;c=wbMaps.text(c,15);this.head.innerHTML=c;}
wbCtrl.prototype.hide=function(){WB.DS(this.head.parentNode,'none');}
wbCtrl.prototype.eLnk=function(a,b){return' <a href="javascript:void(0)" onclick="'+a+';return false;">'+lg[b]+'</a>';}