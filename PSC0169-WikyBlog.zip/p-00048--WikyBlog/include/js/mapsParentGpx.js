
function clear_data(){WB.f.mapData.value='';}
function import_gpx(){WBx.SA();WB.TO('import_gpx2()',10);}
function import_gpx2(){if(!WB.f||!WB.f.id)return;if(WB.f.mapData.value==''){alert(lg[4]);return;}
var gpx=mf.GXml.parse(WB.f.mapData.value);var list;var j;var i;var n;var pt;var letter;var desc;list=dcn('rte',gpx);for(i=0;i<list.length;i++){desc=gpxGetDesc(list[i].childNodes);if(!desc)desc=lg[71];var pts=dcn('rtept',list[i]);n=wbMaps.nLine(mf,pts,'lon');wbMaps.addOL(mf,n,desc);}
list=dcn('trk',gpx);for(i=0;i<list.length;i++){desc=gpxGetDesc(list[i].childNodes);if(!desc)desc=lg[71];list2=dcn('trkseg',list[i]);for(j=0;j<list2.length;j++){desc2=gpxGetDesc(list2[j].childNodes);if(!desc2){desc2=desc;}
var pts=dcn('trkpt',list2[j]);n=wbMaps.nLine(mf,pts,'lon');wbMaps.addOL(mf,n,desc2);}}
list=dcn('wpt',gpx);for(i=0;i<list.length;i++){desc=gpxGetDesc(list[i].childNodes);if(!desc)desc=lg[71];pt=new mf.GLatLng(parseFloat(list[i].getAttribute("lat")),parseFloat(list[i].getAttribute("lon")));n=wbMaps.nMarker(mf,pt,1);wbMaps.addOL(mf,n,desc);}
WBx.CA(true);wbMaps.incr(mf,3);WBe.set(true);return;}
function gpxGetDesc(nl){if(!nl){return false;}
var str=Array();var j;var tmp;for(i=0;i<nl.length;i++){j=false;tmp='';switch(nl[i].nodeName){case'desc':j=0;tmp=getValue(nl[i].childNodes)+'<br/>';break;case'ele':j=1;tmp='<b>'+lg[72]+'</b> '+nl[i].firstChild.nodeValue+lg[73]+'<br/>';break;case'time':j=2;tmp='<b>'+lg[74]+'</b> '+nl[i].firstChild.nodeValue+'<br/>';break;case'sym':j=3;tmp='<b>'+lg[75]+'</b> '+nl[i].firstChild.nodeValue+'<br/>';break;default:continue;break;}
if(tmp){str[j]=tmp;}}
if(str.length==0){return false;}
return str.join("\n");}
function getValue(nl){var str='';for(var i=0;i<nl.length;i++){if(nl[i].nodeValue){str+=nl[i].nodeValue+' ';}}
return str;}
function descToGpx(i){return'<desc><![CDATA['+dcg('WBmapDesc'+WB.shn+i).value+']]></desc>';}
function pointToGpx(pType,point){var cl='>';if(pType=='rtept'){cl='/>';}
return'<'+pType+' lat="'+point.lat().toFixed(6)+'" lon="'+point.lng().toFixed(6)+'"'+cl;}
function export_gpx(){WBx.SA();WB.TO('export_gpx2()',10);}
function export_gpx2(){var txt=Array();txt.push("<?xml version='1.0' ?>");txt.push('<gpx version="1.1" creator="wikyblog.com" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd" xmlns="http://www.topografix.com/GPX/1/1">');txt.push('<metadata>');var metaName=dcn('title')[0].innerHTML;txt.push('<name><![CDATA[');txt.push(metaName);txt.push(']]></name>');txt.push('<desc><![CDATA[');try{txt.push(encodeURI(window.location.href));}catch(m){txt.push(escape(window.location.href));}
txt.push(']]></desc>');txt.push('</metadata>');for(var i=0;i<mf.mapObj.overlays.length;i++){if(!mf.mapObj.overlays[i]){continue;}
if(mf.mapObj.overlays[i].setPoint){txt.push(pointToGpx('wpt',mf.mapObj.overlays[i].getPoint()));txt.push(descToGpx(i));txt.push('</wpt>');}else{txt.push('<rte>');txt.push(descToGpx(i));var pts=wbMaps.toPoints(mf.mapObj.overlays[i]);for(var j=0;j<pts.length;j++){txt.push(pointToGpx('rtept',pts[j]));}
txt.push('</rte>');}}
txt.push('</gpx>');WB.f.mapData.value=txt.join("\n");WBx.CA(true);}