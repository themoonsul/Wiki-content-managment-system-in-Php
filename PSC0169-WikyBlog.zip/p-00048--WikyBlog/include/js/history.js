
var histRow;function radioFocus(el){histRow=WB.C(el,'TR');el.parentNode.style.cssText="border-style:solid;border-width: 0 0 0 1px;border-color:black";return true;}
function histList(el){var row=WB.C(el,'TR');alert(row);}