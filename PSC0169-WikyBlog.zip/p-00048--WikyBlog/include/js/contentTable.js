
WB.TOCi=0;WB.TOCN=function(el){var o='';var obj=WB.CI(el,'WBcontentArea2');var headers=WB.TN('h1,h2,h3,h4,h5',obj);if(headers.length<2){el.innerHTML=o;return false;}
headers.shift();var ml=5;for(var i=0;i<headers.length;i++){var cl=headers[i].nodeName.substr(1);if(ml>cl){ml=cl;}}
ml--;var cl=headers[0].nodeName.substr(1);o+=WB.TOCH(cl-ml);for(var i=0;i<headers.length;i++){var hT=TS.T(headers[i]);if(trim(hT)==''){continue;}
var nl=headers[i].nodeName.substr(1);if(cl!=nl){if(cl<nl){o+=WB.TOCH(nl-cl);}else if(nl<cl){o+=WB.TOCH(cl-nl,'/');}
cl=nl;}
var hId=headers[i].id||'WB_HEADER_LINK'+WB.TOCi;o+='<li><a href="#'+hId+'" rev="local">'+hT+'</a></li>';headers[i].id=hId;WB.TOCi++;}
o+=WB.TOCH(cl-ml,'/');el.rows[1].cells[0].innerHTML=o;el.onclick=function(){};}
WB.TOCH=function(n,c){var t='';c=c||'';for(var i=0;i<parseInt(n);i++){t+='<'+c+'ul>';}
return t;}
WB.TOCT=function(a){var b='';if(a.style.display==''){b='none';}
WB.DS(a,b);}
WB.TN=function(list,obj){if(!obj)var obj=document;var t=list.split(',');var a=new Array();for(var i=0;i<t.length;i++){var tags=obj.getElementsByTagName(t[i]);for(var j=0;j<tags.length;j++){a.push(tags[j]);}}
if(a.length==0)return[];if(a[0].sourceIndex){a.sort(function(b,c){return b.sourceIndex-c.sourceIndex;});}
else if(a[0].compareDocumentPosition){a.sort(function(b,c){return 3-(b.compareDocumentPosition(c)&6);});}
return a;}