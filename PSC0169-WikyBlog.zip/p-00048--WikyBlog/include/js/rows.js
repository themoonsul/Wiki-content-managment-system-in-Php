
var isChecked=false;function selectCheckBox(e,which){e=getE(e);var el=getEl(e);var checkbox=dcg("checkbox_"+which);if(checkbox.type!='checkbox'){return;}
if(el!=checkbox){if(checkbox.checked){checkbox.checked=false;}else{checkbox.checked=true;}}
if(checkbox.checked){setRowStyle(which,true);}else{setRowStyle(which,false);}}
function setRowStyle(id,a){var b=dcg('row_'+id);if(b){if(a){b.className='tableRowH '+b.className;}else{b.className=b.className.replace('tableRowH ','');}}}
function setCheckboxes(el){var frm=WB.C(el,'FORM');if(isChecked){setCheckboxes2(frm,false,0);isChecked=false;}else{setCheckboxes2(frm,true,0);isChecked=true;}}
function setCheckboxes2(frm,check,i){try{if(!frm){return;}
var elts=frm.elements['list[]'];if(!elts){return;}
if(elts.nodeName){setRowStyle(elts.id,check);elts.checked=check;return;}
if(!check){x=elts.length-1-i;}else{x=i;}
if(elts.length>0&&i<elts.length&&i>=0){if(elts[x].checked!=check){id=elts[x].id.replace(/^checkbox_/,'');setRowStyle(id,check);}
elts[x].checked=check;i++;WB.TO(function(){setCheckboxes2(frm,check,i)},15);}}
catch(m){err(m,"setCheckboxes2");}}