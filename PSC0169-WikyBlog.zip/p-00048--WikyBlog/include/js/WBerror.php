<?php
define('WikyBlog',true);
$autoStart = false;
require_once('../../wiki.php');
require_once($includeDir.'/tool/errorClass.php');

function recordError(){
	
	
	if( empty($_GET['err']) && empty($_GET['msg']) ){
		return;
	}
	$err = '<h3>'.$_GET['msg'].'</h3>';
	if( is_array($_GET['err']) ){
		$err .= '<table cellpadding="5"><tr><th>Key</th><th>Value</th></tr>';
		foreach($_GET['err'] as $key => $value){
			$err .= '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';
			
		}
		$err .= '</table>';
	}
	
	wbError::save($err,'JavaScript Error');
	
}
recordError();
