
var scrollTops=Array();var rid=0;function rsetScroll(){var i=0;var id='';var t;for(i in scrollTops){t=dcg(i);if(t){t.scrollTop=scrollTops[i];}else{delete scrollTops[i];}}
return;}
function setScroll(el){if(!el.id){rid++;el.id='WBrid'+rid;}
scrollTops[el.id]=el.scrollTop;}
WB.sf=false;WB.IS=function(a){var c=WB.f.wb_img_search;var u=WB.f.wb_img_url;if(!c||!u)return;a=a||'&s='+WB.en(c.value);var d=u.value+a+'&th='+WB.f.wb_img_thumb.value;WBx.goToScript(d);WB.sf=c.parentNode.lastChild;WB.sf.innerHTML='';}
WB.IR=function(a){if(!WB.sf)return;WB.sf.innerHTML=a;WB.sf=false;}
function insertWiki(area,WO,WC,txt){try{var ta=eval('WB.f.'+area);dcs=dc.selection;if(dcs&&dcs.createRange){var ts=dcs.createRange().text;if(!ts){ts=txt;}
ta.focus();if(ts.charAt(ts.length-1)==" "){ts=ts.substring(0,ts.length-1);dcs.createRange().text=WO+ts+WC+" ";}else{dcs.createRange().text=WO+ts+WC;}}else if(ta.selectionStart||ta.selectionStart=='0'){var startPos=ta.selectionStart;var endPos=ta.selectionEnd;var scrollTop=ta.scrollTop;var myText=(ta.value).substring(startPos,endPos);var subst;if(!myText){myText=txt;}
if(myText.charAt(myText.length-1)==" "){subst=WO+myText.substring(0,(myText.length-1))+WC+" ";}else{subst=WO+myText+WC;}
ta.value=ta.value.substring(0,startPos)+subst+
ta.value.substring(endPos,ta.value.length);ta.focus();var cPos=startPos+(WO.length+myText.length+WC.length);ta.selectionStart=cPos;ta.selectionEnd=cPos;ta.scrollTop=scrollTop;}
if(ta.createTextRange)ta.caretPos=dcs.createRange().duplicate();WBe.set(true);}
catch(m){p.err(m,'insertWiki');}}