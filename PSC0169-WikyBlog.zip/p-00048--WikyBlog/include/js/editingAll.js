
var editing=true;var WBe=new Object();WBe.edT='Unsaved changes will not be saved.';WBe.PS=function(a){WBt.go(a);if(!WB.f)return;b=WB.f;if(typeof(b)=='undefined')return;WBe.FS(b);var c=b.action;b.action=WBx.reqUrl(b.action,'cmd=save');b.target="WBhistory";WB.hist=1;WBx.SA();b.submit();WB.TO(function(){WB.RSr(b,c);},100);WBe.set(false,b);}
WBe.set=function(b,c){try{if(typeof(WB)=='undefined')return;c=c||WB.f;if(!c){return;}
if(b){c.setAttribute('wbEdited','true');}else{c.setAttribute('wbEdited','false');}}
catch(m){err(m,'WBe.set');}}
WBe.check=function(e){if(!WB.compat)return;e=getE(e);var frms=dcn('form');for(var i in frms){WBe.FS(frms[i]);}
for(var i in frms){if(WBe.f(frms[i])){e.returnValue=WBe.edT;return WBe.edT;}}}
WBe.check2=function(a){try{if(!WB.compat||!WB.f)return true;if(!WBe.f(WB.f))return true;var r=confirm('Are you sure you want to '+a+' this tab? \n\n'+WBe.edT+' \n\n Press OK to continue, or Cancel to keep the current tab.');if(r){WBe.set(false);}
return r;}
catch(m){err(m,'WBe.check2');return true;}}
WBe.f=function(f){if(f.nodeName!='FORM')return;if(f.getAttribute('wbEdited')=='true')return true;return false;}
window.onbeforeunload=WBe.check;WBe.tme=false;WBe.create=function(el,own){if(el.value==el.title){el.value='';}
WBe.elmt=el;var c=dcg('WBautoSelectKeys');if(!c){c=dcc('div');c.id='WBautoSelectKeys';dcg('WBextras').appendChild(c);c.style.cssText='padding:5px;font-size:90%;position:absolute;z-index:1000;border:1px #cccccc solid;background-color:#f1f1f1;';}
WB.DS(c);var txt=el.form.keyList.value;WBe.keys=txt.split(',');WBe.selectBox=c;WBe.show();}
WBe.blur=function(){WBe.tme=WB.TO('WBe.end()',200);}
WBe.end=function(){if(WBe.elmt.value==''){WBe.elmt.value=WBe.elmt.title;}
WBe.elmt=null;WBe.selectBox=null;var c=dcg('WBautoSelectKeys');WB.DS(c,'none');}
WBe.next=function(){WB.CT(WBe.tme);WBe.elmt.value=WBe.elmt.value+',';WBe.elmt.focus();WBe.show();}
WBe.add=function(a){WB.CT(WBe.tme);var txt=WBe.elmt.value;var res='';while(txt.search(',')!=-1){var pos=txt.search(',');res+=txt.substr(0,pos+1)+' ';txt=txt.substr(pos+1);}
if(a.search(':')==-1){res+=a;}else{res+=a+', ';}
WBe.elmt.value=res.replace(/\s+/g,' ');WBe.elmt.focus();WBe.show();}
WBe.getList=function(){var txt=WBe.elmt.value.toLowerCase();var arr=txt.split(',');if(arr.length==0){arr=Array('');}
txt=arr[(arr.length-1)];while(txt.substr(0,1)==' '){txt=txt.substr(1);}
if(txt.search(':')!=-1){WBe.simple=false;}
var len=txt.length;var prev;var curr;var lowKey;var lst=Array();for(var i=0;i<WBe.keys.length;i++){curr=WBe.keys[i];if((len>0)&&(curr.substr(0,len).toLowerCase()!=txt)){continue;}
if(WBe.simple){pos=curr.search(':');if(pos!=-1){curr=curr.substr(0,pos);}
if(curr==prev){continue;}}
lst.push(curr);prev=curr;}
if(WBe.simple&&lst.length<3){WBe.simple=false;return WBe.getList();}
return lst;}
WBe.show=function(){WBe.simple=true;var lst=WBe.getList();var res='';for(var i=0;i<lst.length;i++){if(lst[i]==''){continue;}
res+='<a href="javascript:void(0)" style="white-space:nowrap;font-size:90%;text-decoration:none;display:block" onclick="WBe.add(\''+lst[i]+'\');return false;">'+lst[i]+'</a>';}
if(res==''){WBe.selectBox.innerHTML='';WB.DS(WBe.selectBox,'none');return;}
if(!WBe.simple){res+='<a href="javascript:void(0)" style="white-space:nowrap;font-size:90%;text-decoration:none;display:block" onclick="WBe.next();return false;"> ... '+lg[32]+'</a>';}
WB.DS(WBe.selectBox);WBe.selectBox.innerHTML=res;var c=WB.FL(WBe.elmt);var y=(c.y-WBe.selectBox.clientHeight);if(y<0){y=(c.y+WBe.elmt.clientHeight+6);}
if(WB.sc=='On'){var sa=dcg('WB_SCROLLAREA');if(sa)y=y-sa.scrollTop;}
WBe.selectBox.style.top=(y-3)+'px';WBe.selectBox.style.left=c.x+'px';}
WBe.ES=function(a,el){try{if(!WB.f)return;var h=el.value,ta=eval('WB.f.'+a);WBe.FS(WB.f,el);if(h=='')return;var lines=ta.value.split("\n");n=lines.length;var before='',content=Array(),after='';var which=0;for(i=0;i<n;i++){ln=lines[i];if(ln.indexOf('=')===0){if(which==1){which=2;}
if((ln.replace(/[=<>'"]/g,'')==h)&&(which==0)){which=1;}}
switch(which){case 1:content.push(ln);break;case 2:after+="\n"+ln;break;default:before+=ln+"\n";break;}}
WBe.SV(before,after,a);ta.value=WBe.JN(content);}
catch(m){err(m,'WBe.FS');}}
WBe.JN=function(a){var r='';var nl='';for(var i=0;i<a.length;i++){r+=nl+a[i].replace("\r",'');nl="\n";}
return r;}
WBe.FS=function(f,el){try{if(f.nodeName!='FORM')return;var before=f.getAttribute('BeforeContent');var after=f.getAttribute('AfterContent');var area=f.getAttribute('ContentArea');if(!area){return;}
var ta=eval('WB.f.'+area);ta.value=before+ta.value+after;WBe.SV('','','');if(el){WBe.GS(area,el);}}
catch(m){err(m,'WBe.FS');}}
WBe.SV=function(bf,af,ar){try{WB.f.setAttribute('BeforeContent',bf);WB.f.setAttribute('AfterContent',af);WB.f.setAttribute('ContentArea',ar);}
catch(m){err(m,'WBe.SV');}}
WBe.GS=function(a,el){try{if(!WB.f)return;if(el.value!=''){return;}
var i,n,ln,opts,sections=Array(),ta=eval('WB.f.'+a);while(el.childNodes.length>2){el.removeChild(el.lastChild);}
var lines=ta.value.split("\n");n=lines.length;for(i=0;i<n;i++){ln=lines[i];if(ln.indexOf('=')===0){ln=ln.replace(/[=<>'"]/g,'');if(ln==''){continue;}
var s=dcc('option');el.appendChild(s);s.value=ln;s.innerHTML=ln.substr(0,20);}}}
catch(m){err(m,'WBe.GS');}}