
var olE=false;var mf=false;var wbMaps=new Object();wbMaps.e=false;wbMaps.icon=false;wbMaps.max=400;wbMaps.menu=function(fr,i,txt){var str='';if(fr.mapObj.letters[i]){str='<b>'+fr.mapObj.letters[i]+'</b>';}
z='<a href="javascript:void(0)" class="mapField" style="overflow:hidden;white-space:normal !important;" onclick="wbMaps.Oselect('+i+');return false;" id="WBmapFld'+fr.mapObj.ID+i+'">';z+=str+wbMaps.text(txt,20);z+='</a>';dcg('WBmarkers'+fr.mapObj.ID).innerHTML+=z;var x=dcc('input');x.type='hidden';x.id='WBmapDesc'+fr.mapObj.ID+i;x.value=txt;x.name='desc['+i+']';dcg('WBform'+fr.mapObj.ID).appendChild(x);}
wbMaps.removeMenu=function(i){dcrm('WBmapFld'+WB.shn+i);dcrm('WBmapDesc'+WB.shn+i);}
wbMaps.text=function(txt,len){if(!len){len=16;}
txt=txt.replace(/<.*?>/g,' ');txt=txt.replace(/[\n\r\t ]+/g,' ');if(txt.length>(len+5)){ix=txt.indexOf(' ',(len-3));if(ix>1){txt=txt.substr(0,(ix-1));}
if(txt.length>=(len+5)){txt=txt.substr(0,len);}
txt+=' ...';}
return txt.replace(/ /g,'&nbsp;');}
wbMaps.addOL=function(fr,i,desc){fr.myGmap.addOverlay(fr.mapObj.overlays[i]);this.menu(fr,i,desc);}
wbMaps.toPoints=function(pLine){var res=Array();var len=pLine.getVertexCount();for(var j=0;j<len;j++){var pt=pLine.getVertex(j);if(pt){res.push(pt);}}
return res;}
wbMaps.reSize=function(){if(!mf)return;var fr=dcg('WBmapFrame'+WB.shn);if(!fr)return;var o2=WB.WS().y-10;var o1=WB.FL(fr).y;var y=Math.min(o1,WB.XY().y);wbMaps.setSize(fr,o2-o1+y);}
wbMaps.setSize=function(fr,y){fr.style.height=y+'px';fr.style.width='100%';mf.mapDiv.style.height=fr.offsetHeight+'px';mf.mapDiv.style.width=fr.offsetWidth;}
wbMaps.evnts=function(){this.reSize();if(this.e)return;this.e=true;WB.AE(window,'resize',wbMaps.reSize);WB.AE(window,'scroll',wbMaps.reSize);}
wbMaps.prevId=function(){var pDiv;var i=mf.mapObj.current;if(!(i>=0)){pDiv=dcg('WBmarkers'+WB.shn).lastChild;}else{var cDiv=dcg('WBmapFld'+WB.shn+i);pDiv=cDiv.previousSibling;}
if(!pDiv){pDiv=cDiv.parentNode.lastChild;}
if(pDiv.id){var fld='WBmapFld'+WB.shn;i=pDiv.id.substr(fld.length);}
return parseInt(i);}
wbMaps.nextId=function(){var nDiv;var i=mf.mapObj.current;if(!(i>=0)){nDiv=dcg('WBmarkers'+WB.shn).firstChild;}else{var cDiv=dcg('WBmapFld'+WB.shn+i);nDiv=cDiv.nextSibling;}
if(!nDiv){nDiv=cDiv.parentNode.firstChild;}
if(nDiv.id){var fld='WBmapFld'+WB.shn;i=nDiv.id.substr(fld.length);}
return parseInt(i);}
wbMaps.prev=function(){var i=wbMaps.prevId();wbMaps.Oselect(i);}
wbMaps.next=function(){var i=wbMaps.nextId();wbMaps.Oselect(i);}
wbMaps.dist=function(a,b){var c=a.distanceFrom(b);if(olE.miles){return c/1609.344;}
return c/1000;}
wbMaps.incr=function(fr,x){switch(x){case 1:fr.mapObj.count++;return;case 2:fr.mapObj.count++;if(fr.mapObj.count==(wbMaps.max-10)){alert(sprintf(lg[70],fr.mapObj.count,wbMaps.max));}else if((fr.mapObj.count>=wbMaps.max)&&(fr.mapObj.count%5)==0){alert(sprintf(lg[34],fr.mapObj.count,wbMaps.max));}
return;case 3:if(fr.mapObj.count>=wbMaps.max){alert(sprintf(lg[34],fr.mapObj.count,wbMaps.max));}
break;}}
wbMaps.init=function(fr){if(WB.status<2){setTimeout(function(){wbMaps.init(fr)},500);return;}
fr.mapObj.ID=WB.shn;if(!WB.f||!wbMaps.CO(WB.f,fr.frameElement)){setTimeout(function(){wbMaps.init(fr)},2000);return;}
fr.mapDiv=fr.dcg('mapDiv');if(!fr.mapDiv){setTimeout(function(){wbMaps.init(fr)},200);return;}
if(!fr.GBrowserIsCompatible()){wbMaps.mess('1');return;}
if(!mf){mf=fr;WBt.fs.push('var fr = dcg("WBmapFrame"+shw);if(fr){mf=fr.contentWindow}else{mf=false;}');}
if(WB.f.json&&WB.f.json.value){eval('var obj = '+WB.f.json.value+';');wbMaps.JSON(fr,obj);return;}
if((typeof(xml)=='undefined')||!xml){xml=dcg('WBxml'+fr.mapObj.ID).value;}
xml=fr.GXml.parse(xml);wbMaps.xml(fr,xml);xml=false;delete xml;}
wbMaps.JSON=function(fr,a){wbMaps.reSize();fr.myGmap=new fr.GMap2(fr.mapDiv);var tps=fr.myGmap.getMapTypes();var e=a.mtype;if(e||!tps[e]){e=0;}
var c=new fr.GLatLng(a.center_lat,a.center_lng);var d=parseInt(a.level);fr.myGmap.setCenter(c,d,tps[e]);fr.myGmap.removeMapType(fr.G_HYBRID_MAP);fr.myGmap.addMapType(fr.G_PHYSICAL_MAP);fr.myGmap.addControl(new fr.GLargeMapControl());fr.myGmap.addControl(new fr.GMapTypeControl());this.icon=new fr.GIcon();this.icon.shadow=WB.dPrefix+'/imgs/maps/shadow50.png';this.icon.iconSize=new fr.GSize(20,34);this.icon.shadowSize=new fr.GSize(37,34);this.icon.iconAnchor=new fr.GPoint(9,34);this.icon.infoWindowAnchor=new fr.GPoint(9,2);this.icon.infoShadowAnchor=new fr.GPoint(18,25);elmts=a.olay;for(var i in elmts){if(elmts[i].ol=='mark'){var pt=new fr.GLatLng(parseFloat(elmts[i].pt[0]),parseFloat(elmts[i].pt[1]));wbMaps.nMarker(fr,pt,1,i);wbMaps.addOL(fr,i,this.JSON_desc(elmts[i].desc));}else{var pts=elmts[i].pts;wbMaps.JSON_poly(fr,pts,i);wbMaps.addOL(fr,i,this.JSON_desc(elmts[i].desc));}}
if(mf==fr)wbMaps.Oselect(0);wbMaps.incr(fr,3);wbMaps.evnts();}
wbMaps.JSON_desc=function(a){a=a.replace(/^[ \n\r]/,'').replace(/[ \n\r]$/,'');return a;}
wbMaps.JSON_poly=function(fr,pts,n){if(!n){var n=fr.mapObj.overlays.length;}
var ptsArr=Array();var pt;for(var i in pts){pt=new fr.GLatLng(pts[i][0],pts[i][1]);ptsArr.push(pt);wbMaps.incr(fr,1);}
overlay=new fr.GPolyline(ptsArr,'#2e8b57');fr.mapObj.overlays[n]=overlay;return n;}
wbMaps.CO=function(a,b){if(!a||!b)return false;if(typeof(a.contains)!='undefined'){return a.contains(b);}
do{if(b==a){return true;}
b=b.parentNode;}while(b);return false;}
wbMaps.xml=function(fr,xml){try{if(!xml){err('no xml');return;}
wbMaps.reSize();fr.myGmap=new fr.GMap2(fr.mapDiv);var ctrElem=dcn('center',xml);var tps=fr.myGmap.getMapTypes();var e=parseInt(ctrElem[0].getAttribute('maptype'));if(e||!tps[e]){e=0;}
var c=new fr.GLatLng(parseFloat(ctrElem[0].getAttribute('lat')),parseFloat(ctrElem[0].getAttribute('lng')));var d=parseInt(ctrElem[0].getAttribute('level'));if(!ctrElem[0].getAttribute('version')){var d=17-d;}
fr.myGmap.setCenter(c,d,tps[e]);wbMaps.parse2(fr,xml);}
catch(m){err(m,'initMap.xml');wbMaps.mess('0');}}
wbMaps.mess=function(m){WB.DS(mf.dcg('mapDebug'+m));}
wbMaps.parse2=function(fr,xmlDoc){var overlay;var i;var elmts;var n;var letter;var desc=Array();fr.myGmap.addControl(new fr.GLargeMapControl());fr.myGmap.addControl(new fr.GMapTypeControl());this.icon=new fr.GIcon();this.icon.shadow=WB.dPrefix+'/imgs/maps/shadow50.png';this.icon.iconSize=new fr.GSize(20,34);this.icon.shadowSize=new fr.GSize(37,34);this.icon.iconAnchor=new fr.GPoint(9,34);this.icon.infoWindowAnchor=new fr.GPoint(9,2);this.icon.infoShadowAnchor=new fr.GPoint(18,25);elmts=dcn('marker',xmlDoc);for(i=0;i<elmts.length;i++){n=elmts[i].getAttribute('index');var pt=new fr.GLatLng(parseFloat(elmts[i].getAttribute('lat')),parseFloat(elmts[i].getAttribute('lng')));wbMaps.nMarker(fr,pt,1,n);desc='';if(elmts[i].firstChild){desc=this.getDesc(elmts[i].firstChild);}
wbMaps.addOL(fr,n,desc);}
elmts=dcn('polyline',xmlDoc);for(i=0;i<elmts.length;i++){n=elmts[i].getAttribute('index');var pts=dcn('plypt',elmts[i]);wbMaps.nLine(fr,pts,'lng',n);desc='';if(elmts[i].firstChild){desc=this.getDesc(elmts[i].firstChild);}
wbMaps.addOL(fr,n,desc);}
if(mf==fr)wbMaps.Oselect(0);wbMaps.incr(fr,3);wbMaps.evnts();}
wbMaps.getDesc=function(el){var a='';if(el.nodeValue){a=el.nodeValue;}else if(el.innerText){a=el.innerText;}
a=a.replace(/^[ \n\r]/,'').replace(/[ \n\r]$/,'');a=a.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&amp;/g,'&');return a;}
wbMaps.nLine=function(fr,pts,b,n){if(!n){var n=fr.mapObj.overlays.length;}
var ptsArr=Array();var pt;for(var i=0;i<pts.length;i++){pt=new fr.GLatLng(parseFloat(pts[i].getAttribute('lat')),parseFloat(pts[i].getAttribute(b)));ptsArr.push(pt);wbMaps.incr(fr,1);}
overlay=new fr.GPolyline(ptsArr,'#2e8b57');fr.mapObj.overlays[n]=overlay;return n;}
wbMaps.nMarker=function(fr,point,x,n,lt){if(!(n>=0)){var n=fr.mapObj.overlays.length;}
lt=lt||this.nxtLet(fr);var ic=new fr.GIcon(wbMaps.icon);ic.image=WB.dPrefix+'/imgs/maps/marker'+lt+'.png';if(!fr.mapObj.editing){ol=new fr.GMarker(point,ic);}else{ol=new fr.GMarker(point,{draggable:true,icon:ic});}
fr.GEvent.addListener(ol,'click',function(){parent.wbMaps.Oselect(n);});fr.GEvent.addListener(ol,'dragstart',function(){fr.myGmap.closeInfoWindow();});fr.mapObj.letters[n]=lt;fr.mapObj.overlays[n]=ol;wbMaps.incr(fr,x);return n;}
wbMaps.nxtLet=function(fr){var i=fr.mapObj.letters.length;if(i==0){return'A';}
var z='Z'.charCodeAt(0);var lt=fr.mapObj.letters[i-1];if(!lt){return'A';}
if(lt=='-'){return'-';}
var j=lt.charCodeAt(0)+1;if(j>z){return'-';}
lt=String.fromCharCode(j);return lt;}
wbMaps.Oselect=function(i,noWin){fr=mf;var ol=fr.mapObj.overlays[i];if(!ol)return;var a;var b;var dBox=dcg('WBmapDesc'+WB.shn+i);if(!dBox)return;if(i!=fr.mapObj.current){wbMaps.unSelect();}
if(fr.mapObj.cl)delete this.cl;if(fr.mapObj.editing){olE.emptyList();}
if(fr.myCtrl){fr.myCtrl.update(i);}
var txt=false;if(!noWin){txt=dBox.value;}
if(ol.setPoint){b=1;if(txt){ol.openInfoWindowHtml('<div>'+txt+'</div>');}}else{b=2;a=wbMaps.toPoints(ol);fr.myGmap.removeOverlay(ol);ol=new fr.GPolyline(a,'#0000ff');fr.mapObj.overlays[i]=ol;fr.myGmap.addOverlay(ol);if(txt&&a.length>0){fr.myGmap.openInfoWindowHtml(a[0],'<div>'+txt+'</div>');}}
wbMaps.sBox(i);if(olE){if(b==1){olE.m_Select(i);}else{olE.p_Select(i);}}}
wbMaps.sBox=function(i){mf.mapObj.current=i;dcg('WBmapFld'+WB.shn+i).className='mapField2';}
wbMaps.unSelect=function(){var fr=mf;fr.myGmap.closeInfoWindow();var c=fr.mapObj.current;if(c>=0){fr.mapObj.current=-1;dcg('WBmapFld'+WB.shn+c).className='mapField';var a=fr.mapObj.overlays[c];if(!a){return;}
if(a.getVertex){fr.myGmap.removeOverlay(a);var b=wbMaps.toPoints(a);a=new fr.GPolyline(b,'#2e8b57');fr.mapObj.overlays[c]=a;fr.myGmap.addOverlay(a);}}}
wbMaps.load=function(){if(!WB.compat){alert('It appears your browser is not fully compatible, you may reload this page to try again.');return;}
var a=WBt.gTab('A',false,WB.shn);if(!mf.mapObj.editing){var url=a.href;WBx.goToFrame(url,'cmd=customedit');wbMaps.edit(a.rev,mf);}else{olE.showBoxes(a.rev);}}
wbMaps.edit=function(rev,fr){var a=dcg('WBmapEdit2'+rev);if(a&&olE){olE.init(fr);}else{WB.TO(function(){wbMaps.edit(rev,fr);},100);}}