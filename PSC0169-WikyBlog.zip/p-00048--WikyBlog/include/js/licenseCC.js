
function getLicense(url){msgWindow=window.open(url,"displayWindow","menubar=no,scrollbars=yes");}