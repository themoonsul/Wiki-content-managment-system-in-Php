
var wn=window;var dc=wn.document;WB.status=1;WB.compat=false;WB.ky=false;WB.fls=Array();WB.at=false;WB.hist=0;var editing;var site='';var ckt=false;var xml;function dcg(t){return dc.getElementById(t);}
function dcc(t){return dc.createElement(t);}
function dca(a,b){a.appendChild(b);}
function dcm(a){return dc.getElementsByName(a);}
function dcn(a,b){b=b||dc;return b.getElementsByTagName(a);}
function dcr(a){if(!a)return false;a.parentNode.removeChild(a);return true;}
function dcrm(a){return dcr(dcg(a));}
function getE(e){return(e)?e:((wn.event)?wn.event:null);}
function getEl(e){return(e.target)?e.target:((e.srcElement)?e.srcElement:null);}
function trim(s){return s.replace(/^\s+|\s+$/g,'');}
function sprintf(a){var i,n=arguments.length;for(i=1;i<n;i++){a=a.replace('%s',arguments[i]);}
return a;}
WB.TO=function(a,b){return wn.setTimeout(a,b);}
WB.DS=function(a,b){if(!a)return;b=b||'';if((b==='')&&(typeof(a.className)!='undefined')){a.className=a.className.replace('loadHide','').replace('scriptHide','');}
a.style.display=b;}
WB.CT=function(a){if(a)clearTimeout(a);}
WB.RS=function(e){try{if(!WB.compat)return true
if(WB.ky=='x')return true
var f;e=getE(e);f=getEl(e);if(typeof(f.form)!='undefined'){f=f.form;}
if(editing){WBe.FS(f);}
var l=f.getAttribute('revtype');if(l=='inter'){f.target='_blank';return true;}
WBx.SA();var tmp=f.action;f.target='WBhistory';if(f.method=='post'){WB.hist=1;f.action=WBx.reqUrl(f.action);}else{var b=dcc('div');b.id='WBformGetData';WB.DS(b,'none');dca(f,b);WB.RSh(b,'wb[o]',WB.own);WB.RSh(b,'wb[v]',WB.nJs);WB.RSh(b,'wb[u]',WB.shn);}
WB.TO(function(){WB.RSr(f,tmp);},100);return true}
catch(m){err(m,'WB.RS');return false}}
WB.RSr=function(a,b){a.action=b;dcrm('WBformGetData');}
WB.RSh=function(a,b,c){var d=dcc('input');d.type='hidden';d.name=b;d.value=c;if(a)dca(a,d);return d;}
function isLink(e,el){try{if(e.ctrlKey||e.shiftKey)return false;if(!(WB.compat&&el.href))return false;if((el.name=='noxml')||!el.rev)return false;if(el.rev=='always')return true;if(WB.ajax=='Off')return false;if(WB.ajax=='Partial'){if(el.parentNode.className=='WBboxInfo'){return true;}
return false;}
return true;}
catch(m){err(m,'isLink');return false;}}
function isLoaded(t){if(t==''){return false}
if(dcg('WBbox'+t)){return t;}
return false}
WB.LF=function(tpe,url,b){try{if(!WB.LFS(url))return;if(b)url=WB.dPrefix+url;var e=dcc(tpe);if(tpe=='script'){e.src=url;e.type='text/javascript';}else if(tpe=='link'){e.type='text/css';e.rel='stylesheet';e.href=url;}
dca(dcn('head')[0],e);}
catch(m){err(m,'loadFile');}}
WB.LFS=function(a){if(!a)return;var b=a.indexOf('?');if(b>0)a=a.substr(0,b);if(WB.fls[a])return false;WB.fls[a]=true;return true;}
WB.C=function(a,b){if(!a)return false;do{if(a.nodeName==b){return a;}
a=a.parentNode;}while(a);return false;}
WB.CI=function(a,b){if(!a)return false;do{if(a.className&&(a.className==b)){return a;}
a=a.parentNode;}while(a);return false;}
WB.IC=function(b,a){do{if(b==a){return true;}
b=b.parentNode;}while(b);return false;}
WB.FL=function(obj){var O=new Object();O.y=0;O.x=0;if(obj&&obj.offsetParent){while(obj.offsetParent){O.y+=obj.offsetTop;O.x+=obj.offsetLeft;obj=obj.offsetParent;}}else if(obj&&obj.y){O.y+=obj.y;O.x+=obj.x;}
return O;}
WB.XY=function(){var t=new Object;t.x=0;t.y=0;var dcd=dc.documentElement;if(dcd&&(dcd.scrollTop>=0)){t.y=dcd.scrollTop;t.x=dcd.scrollLeft;}else if(dc.body&&(dc.body.scrollTop>=0)){t.y=dc.body.scrollTop;t.x=dc.body.scrollLeft;}else if(wn.pageYOffset>=0){t.y=wn.pageYOffset;t.x=wn.pageXOffset;}else if(wn.scrollY>=0){t.y=wn.scrollY;t.x=wn.scrollX;}
return t;}
WB.WS=function(){var o=new Object();if(self&&self.innerWidth){o.x=self.innerWidth;o.y=self.innerHeight;}else if(dc.documentElement&&dc.documentElement.clientHeight){o.x=dc.documentElement.clientWidth;o.y=dc.documentElement.clientHeight;}else{o.x=dc.body.clientWidth;o.y=dc.body.clientHeight;}
return o;}
WB.dblc=0;function allClicks(e){try{var el,t;e=getE(e);if(e.which&&(e.which!=1))return true
el=getEl(e);if(!el)return true;el=WB.C(el,'A');if(!el)return true;if(typeof(el.onclick)=='function'){return WB.CR(e,false);}
if(el.href.indexOf('javascript:')===0){t=el.href.substr(11);eval(unescape(t));return WB.CR(e);}
if((WB.ky=='x')&&(el.name!='none')){return true}
t=isLoaded(el.rev);if(t&&(t==WB.shn)){var t=new Date().getTime();if((t-WB.dblc)<1000){wbCA.reload(e);t=0;}
WB.dblc=t;return WB.CR(e);}
if(t){var h=el.href;WBt.go(t,h);var p=h.indexOf('#');if(p!==-1){window.location.hash=h.substr(p);;}
e.returnValue=false;return WB.CR(e);;}
if(isLink(e,el)){WBx.goTo(el.href);return WB.CR(e,false);}
if((WB.win=='On')&&!el.rev){el.target='_blank';}
return true;}
catch(m){err(m,'allClicks');return false;}}
WB.CR=function(e,r){r=r||false;WB.ky=false;e.returnValue=r;return r;}
var WBt=new Object();WBt.areas=Array('WBbox','WBnavbar');WBt.fs=Array();WBt.go=function(shw,url){try{if(!dcg('WBtab'+shw)&&url){WBx.goTo(url);return;}
var i=0,n;WBt.hide(WB.shn,true);n=WBt.fs.length;while(i<n){if(typeof(WBt.fs[i])=='string'){eval(WBt.fs[i]);}
i++;}
WBt.show(shw);WB.shn=shw;var el=WBt.gTab('A',false,shw);if(el){dc.forms['WBFormHistory'].a.value=WB.shn;dc.forms['WBFormHistory'].b.value=el.href;}}
catch(m){err(m,'WBt.go: '+shw);}}
WBt.show=function(a){try{if(WB.f){WB.DS(WB.f,'none');}
var s,t=dcg('WBtab'+a),box;if(t){t.className='WBcontentTabShow';dc.title=t.title;s=t.getAttribute('sc');}
WBt.doAreas(a,'');box=dcg('WBbox'+a);WB.f=WB.C(box,'FORM');WB.DS(WB.f);if(typeof(rsetScroll)=='function')rsetScroll();WBt.sc(s);}
catch(m){err(m,'show: '+a);}}
WBt.hide=function(a,b){try{var s,sa,t=dcg('WBtab'+a);if(t)t.className='WBcontentTabHide';if(b){if(WB.sc=='On'){sa=dcg('WB_SCROLLAREA');if(sa)s=sa.scrollTop;}
if(t&&typeof(s)!=='undefined')t.setAttribute('sc',s);}
WBt.doAreas(a,'none');}
catch(m){err(m,'hide '+a);}}
WBt.sc=function(a){a=a||0;if(WB.sc=='On'){var sa=dcg('WB_SCROLLAREA');if(sa){sa.scrollTop=parseInt(a,10);return;}}
wn.scrollTo(0,parseInt(a,10));}
WBt.doAreas=function(id,how){var b,i=0,n=WBt.areas.length;while(i<n){b=dcg(WBt.areas[i]+id);if(b){WB.DS(b,how);}
i++;}}
WBt.hist=function(){if(WB.status<2)return;if(!WB.compat)return;var t=wn.frames['WBhistory'].location.hash;t=WB.de(t).substr(1);if(!dcg('WBbox'+t)){WBx.goTo(t);}else if(t!=''&&t!=WB.shn){WBt.go(t);}}
WBt.gTab=function(w,a,b){if(!a){a=dcg('WBtab'+b);if(!a)return false}
while(a){if(a.nodeName==w)return a;a=a.firstChild;}
return false}
function err(m,msg){var vals='',nv=navigator,t,i;if(!msg)msg='';t=typeof m;if(t=='object'){for(i in m){vals+='&err['+escape(i)+']= '+escape(m[i]);}}else if(t=='string'){vals+='&err[msg]= '+escape(m);}
vals+='&err[platform]= '+escape(nv.platform);vals+='&err[userAgent]= '+escape(nv.userAgent);vals+='&err[appVersion]= '+escape(nv.appVersion);vals+='&err[location]= '+escape(wn.location.href);i=new Image();i.src='/include/js/WBerror.php?msg='+escape(msg)+vals;if(WB.ul==5){alert(lg[5]);}}
function setArray(){if(typeof(Array.push)=='undefined'){Array.prototype.push=function(a){this[this.length]=a;}}}
function getLst(a,b){try{var d=dcg(a),c=new Array(),i=0,len;var ei=0;if(!d)return c;ei++;d=d.childNodes;ei++;len=b.length;ei++;while(i<d.length){if(d[i].id){c.push(d[i].id.substr(len));}
i++;}
ei++;return c;}
catch(m){err(m,'getLst['+ei+']');return false;}}
function doKeywords2(a){WB.CT(ckt);do{a=a.nextSibling;if(a&&a.className.substr(0,14)=='WBkeywordLink2'){WB.DS(a);}else{a=false;}}while(a);}
function collapseKeywords(){WB.CT(ckt);ckt=WB.TO('collapseKeywords2()',400);}
function collapseKeywords2(){var c,b=dcg('WBkeywords2');if(!b)return;c=b.firstChild;do{if(c&&c.className.substr(0,14)=='WBkeywordLink2'){WB.DS(c,'none');}
c=c.nextSibling;}while(c);}
WB.LC=function(a){if(a.substr(0,1)=='/'){return true;}
a=WB.de(a);a=a.substr(0,site.length).toLowerCase();if(a==site){return true;}
return false;}
WB.init=function(){try{if(typeof(dc.getElementById)=='undefined')return;if(!dcg('WBloaded')){WB.TO('WB.init()',50);return;}
setArray();var bod=dcn('body')[0];bod.scroll='auto';var i=0,lst=getLst('WBactions','WBtab'),n=lst.length;while(i<n){if(!dcg('WBbox'+lst[i])){i++;continue;}
if(!WB.shn){WB.shn=lst[i];}else if(WB.shn!=lst[i]){WBt.hide(lst[i],false);}
i++;}
WB.isC1();var b=dcg('WBbox'+WB.shn);WB.f=WB.C(b,'FORM');dc.onclick=allClicks;site=wn.location.href;var p=site.search(/[^\/]\/[^\/]/);if(p!=-1){site=site.substr(0,p+1);}
site=site.replace(/\/$/,'');site+=WB.dPrefix;site=site.toLowerCase();WB.status=2;TS.I(dc);}
catch(m){err(m,'WB.init');}}
WB.en=function(a){try{return encodeURIComponent(a);}catch(m){}
return a;}
WB.de=function(a){try{return decodeURIComponent(a);}catch(m){}
return a;}
WB.isC1=function(a){try{if(typeof(encodeURIComponent)=='undefined'){return;}
var s=dcc('script');s.type='text/javascript';s.text='WB.isC2(0)';dca(dcn('head')[0],s);}
catch(m){err(m,'WB.isC1');}}
WB.isC2=function(a){if(a>=20)return;var fr=wn.frames['WBhistory'];var xt=dcg('WBextrasBox');if(!fr||!fr.fullyLoaded||!xt){a++;WB.TO('WB.isC2('+a+')',100);return;}
var s='.noscript, .scriptOnly{display:block !important;} .loadHide{display:none;}';a=dcc('style');a.setAttribute('type','text/css');if(a.styleSheet){a.styleSheet.cssText=s;}else{a.innerHTML=s;}
dca(dcn('head')[0],a);WB.compat=true;var frm=dc.forms['WBFormHistory'];var b=frm.b.value;if((frm.a.value!=WB.shn)&&(b!='')){WB.back(b);}
if((typeof(style2)!='undefined')&&style2){WB.LF('link',style2,true);}
var t='<span id="WBNewLoading" style="display:none"></span>';t+='<a href="" onclick="wbCA.prev();return false;" title="'+sprintf(lg[15],WB.sk)+'">&lt;&lt;</a>';t+='<a href="" onclick="wbCA.reload(event);return false;" title="'+sprintf(lg[30],WB.sk)+'">'+lg[31]+'</a>';t+='<a href="" onclick="wbCA.pLink(event);return false;" title="'+sprintf(lg[28],WB.sk)+'">'+lg[29]+'</a>';t+='<a href="" onclick="wbCA.close();return false;" title="'+sprintf(lg[16],WB.sk)+'">X</a>';t+='<a href="" onclick="wbCA.next();return false;" title="'+sprintf(lg[17],WB.sk)+'">&gt;&gt;</a>';xt.innerHTML=t;dc.onmouseover=WBx.testLink;dc.onmouseout=WBx.CA;dc.onkeydown=keydown;dc.onkeyup=keyup;if(WB.sc=='On')WBx.iDS();WB.TO('WB.SF()',500);}
WB.SF=function(){WB.fls=Array();var url,tags,i,n;tags=dcn('script');n=tags.length;for(i=0;i<n;i++){WB.LFS(tags[i].src)}
tags=dcn('link');n=tags.length;for(i=0;i<n;i++){WB.LFS(tags[i].href);}}
WB.back=function(a,i){i=i||0;if(i>20){return;}
if(!WB.compat){WB.TO('WB.back("'+a+'")',400);return;}
WBx.goTo(a);}
WB.AE=function(a,b,c){if(a.addEventListener){a.addEventListener(b,c,false);}else if(a.attachEvent){a.attachEvent('on'+b,c);}}
WB.DE=function(a,b,c){if(a.removeEventListener){a.removeEventListener(b,c,false);}else if(a.detachEvent){a.detachEvent('on'+b,c);}}
var TS=new Object();TS.d=WB.dPrefix+'/imgs/';TS.j=null;TS.i=0;TS.I=function(a){var t,i;if(!a.getElementsByTagName)return;var tbls=dcn('table',a);for(i=0;i<tbls.length;i++){TS.i++;t=tbls[i];var c=' '+t.className+' ';if(c.indexOf('sortable')!==-1){TS.M(t,TS.i);}
if(c.indexOf('collapsible')!==-1){TS.IC(t,TS.i);}
if(c.indexOf('toc_table')!==-1){t.onclick=function(){WB.TOCN(this)};}}}
TS.M=function(t,j){var i,cl,txt,n,fr;if(!t.id){t.setAttribute('id','sortable_table_id_'+j);j++}
fr=TS.FR(t);if(!fr)return;n=fr.cells.length;for(i=0;i<n;i++){cl=fr.cells[i];txt=TS.T(cl);if((' '+cl.className+' ').indexOf(' unsortable ')==-1){cl.innerHTML=txt+'<a href="#" class="sortheader" onclick="TS.R(this,'+i+');return false" style="text-decoration:none;margin:0 .3em 0 .3em"><img src="'+TS.d+'arrow-none.gif" /></a>';}}
TS.A(t);}
TS.FR=function(t){if(t.rows&&t.rows.length>0){if(t.tHead&&t.tHead.rows.length>0){return t.tHead.rows[t.tHead.rows.length-1];}else{return t.rows[0];}}
return false;}
TS.T=function(el){if(typeof(el)=='string')return el;if(typeof(el)=='undefined')return'';if(el.abbr)return el.abbr;if(el.innerText)return el.innerText;var str='',i,cs=el.childNodes,n=cs.length;for(i=0;i<n;i++){switch(cs[i].nodeType){case 1:str+=TS.T(cs[i]);break;case 3:str+=cs[i].nodeValue;break;}}
return str;}
TS.R=function(lnk,clid){var i=0,row,a,n;row=WB.C(lnk,'TR');n=row.childNodes.length;for(i=0;i<n;i++){a=row.childNodes[i].lastChild;if(a&&a.className=='sortheader'){a.innerHTML='<img src="'+TS.d+'arrow-none.gif"/>';}}
var td=lnk.parentNode;TS.j=clid||td.cellIndex;var t=WB.C(td,'TABLE');if(t.rows.length<=1)return;var start=(t.tHead&&t.tHead.rows.length>0?0:1);var itm='';for(i=start;i<t.rows.length;i++){if(t.rows[i].cells.length>TS.j){itm=TS.T(t.rows[i].cells[TS.j]);itm=itm.replace(/^[\s\xa0]+/,'').replace(/[\s\xa0]+$/,'');if(itm!='')break;}}
if(itm=='')return;var sortfn=TS.NC;if(itm.match(/^-?[�$�ۢ�]\d/))sortfn=TS.N;if(itm.match(/^-?(\d+[,\.]?)+(E[-+][\d]+)?%?$/))sortfn=TS.N;var k,newRows=new Array(),noSort=new Array();for(k=0;k<t.tBodies.length;k++){for(i=0;i<t.tBodies[k].rows.length;i++){row=t.tBodies[k].rows[i];if(row.innerHTML.indexOf('<th')!=-1){noSort[i]=row;}else if(row.className&&(row.className.indexOf('sortbottom')!=-1)){noSort[i]=row;}else{newRows.push(row);}}}
newRows.sort(sortfn);if(lnk.getAttribute('sort')=='dn'){lnk.innerHTML='<img src="'+TS.d+'arrow-down.gif" />';lnk.setAttribute('sort','up');newRows.reverse();}else{lnk.innerHTML='<img src="'+TS.d+'arrow-up.gif" />';lnk.setAttribute('sort','dn');}
for(i=0;i<newRows.length;i++){dca(t.tBodies[0],newRows[i]);}
for(i=0;i<noSort.length;i++){if(noSort[i]&&noSort[i].className){dca(t.tBodies[0],noSort[i]);}}
for(i=0;i<t.tBodies[0].rows.length;i++){if(noSort[i]&&noSort[i].className){t.tBodies[0].insertBefore(noSort[i],t.tBodies[0].rows[i]);}}
TS.A(t);}
TS.N=function(a,b){a=TS.G(a);b=TS.G(b);return a-b;}
TS.G=function(a){a=TS.T(a.cells[TS.j]);a=a.replace(/[^-?0-9.]/g,'');a=parseFloat(a);return(isNaN(a)?0:a);}
TS.NC=function(a,b){a=TS.T(a.cells[TS.j]).toLowerCase();b=TS.T(b.cells[TS.j]).toLowerCase();if(a==b){return 0;}
if(a<b){return-1;}
return 1;}
TS.A=function(t){var bods,i,n,rows,j,m;bods=dcn('tbody',t);n=bods.length;for(i=0;i<n;i++){rows=dcn('tr',bods[i]);m=rows.length;for(j=0;j<m;j++){if((j%2)==0){if(!(rows[j].className.indexOf('Odd')==-1)){rows[j].className=rows[j].className.replace('Odd','Even');}else{if(rows[j].className.indexOf('Even')==-1){rows[j].className+=' Even';}}}else{if(!(rows[j].className.indexOf('Even')==-1)){rows[j].className=rows[j].className.replace('Even','Odd');}else{if(rows[j].className.indexOf('Odd')==-1){rows[j].className+=' Odd';}}}}}}
TS.IC=function(t,i){var fr,n,rc,txt;fr=TS.FR(t);n=fr.cells.length;if(n<1)return;rc=fr.cells[n-1];rc.innerHTML='<a href="" class="collapsible_button" onclick="TS.CT(this,'+i+');return false"></a>'+rc.innerHTML;var tb=dcc('tbody');tb.className='collapse_tbody';t.appendChild(tb);n=t.rows.length;for(j=1;j<n;j++){tb.appendChild(t.rows[j]);}}
TS.CT=function(a,i){t=WB.C(a,'TABLE');if(t.className.indexOf('collapsed')==-1){t.className+=' collapsed';}else{t.className=t.className.replace('collapsed','');}}
WB.SIO=function(a,d){var b=a.lastChild;b.style.cssText='width:auto;border:1px solid #ccc;background-color:white;margin-left:1em;position:absolute;z-index:10000;padding:0 5px 0 5px;';WB.SI(a,d);}
WB.si=false;WB.SI=function(a,d){d=d||'';WB.DS(a.lastChild,d);if(WB.si&&(a!=WB.si)){WB.HH(WB.si);}
WB.si=a;WB.CT(ckt);}
WB.HI=function(a,t){t=t||400;WB.CT(ckt);ckt=WB.TO(function(){WB.HH(a)},t);}
WB.HH=function(a){if(a.getAttribute('wbhide')=='no')return;WB.DS(a.lastChild,'none');}
function keydown(e){try{e=getE(e);WB.ky=String.fromCharCode(e.keyCode).toLowerCase();if(WB.KS(e)){switch(WB.ky){case'x':wbCA.close(e);break;case'r':wbCA.reload(e);break;case'l':wbCA.pLink(e);break;case'0':wbCA.next();break;case'9':wbCA.prev();break;default:return true}
WB.ky=false;return false}
return true}
catch(m){err(m,'keydown');return true;}}
WB.KS=function(e){switch(WB.sk){case'alt':if(e.altKey)return true;break;case'alt-shift':if(e.altKey&&e.shiftKey)return true;break;case'alt-ctrl':if(e.altKey&&e.ctrlKey)return true;break;}
return false;}
function keyup(e){WB.ky=false;}
function wbCA(){}
wbCA.reload=function(e){try{if(!WB.shn)return;if(WB.shn=='_CL')return;var tab=dcg('WBtab'+WB.shn);if(!tab)return;var el=WBt.gTab('A',tab);if(!el||el.name=='none')return;if(editing&&!WBe.check2('reload')){return;}
WBx.goTo(el.href);var prev=tab.previousSibling;if(prev&&prev.id){WBx.prev=prev.id.substr(5);}else{WBx.prev='_CL';}
wbCA.close(e);return;}
catch(m){err(m,'wbCA.reload');}}
wbCA.close=function(){try{WBx.CA();if(!WB.shn)return;if(WB.shn=='_CL'){wbCA.prev();return;}
var ids=Array();if(WB.f&&WB.f.childNodes){var i=0,id,tab,tabA,lbls=Array(),cAll=false;var chln=WB.f.childNodes;while(i<chln.length){if(chln[i].id){id=chln[i].id.substr(5);tab=dcg('WBtab'+id);if(tab){ids.push(id);tabA=WBt.gTab('A',tab);if(tabA){lbls.push(tab.title);if(tabA.href.search('#')!=-1){cAll=true;}}}}
i++;}
if(ids.length>1){if(!cAll){cAll=confirm(lg[11]+lbls.join("\n- ")+lg[12]);}
if(!cAll){delete ids;ids=Array(WB.shn);}}
if(editing&&!WBe.check2('close')){WB.ky=false;return;}}else{ids[0]=WB.shn;}
wbCA.close2(ids);return;}
catch(m){err(m,'wbCA.close '+id);return;}}
wbCA.close2=function(ids){try{var b=dcg('WBbox'+ids[0]);if(b)WB.f=WB.C(b,'FORM');if(editing&&WB.f){WBe.set(false);}
if(WB.f&&WB.f.childNodes){if(WB.f.childNodes.length==ids.length){dcr(WB.f);WB.f=false;}}
var i=0,j=0,b=false,nId,n=ids.length;while(i<n){j=0;while(j<WBt.areas.length){b=dcg(WBt.areas[j]+ids[i]);dcr(b);j++;}
b=dcg('WBtab'+ids[i]);if(b){nId=wbCA.nextTab(b,1);WBt.CL(Array(b));}
i++;}
nId=nId||'_CL';WBt.go(nId);WB.TO('WBx.DS()',100);}
catch(m){err(m,'wbCA.close2 ');}}
wbCA.nextTab=function(tab,dir){if(typeof(tab)=='string'){tab=dcg('WBtab'+tab);}
var next=tab,id,b,i=0,limit=tab.parentNode.childNodes.length;while(i<limit){if(dir&&dir==1){next=next.previousSibling;if(!next)next=tab.parentNode.lastChild;}else{next=next.nextSibling;if(!next)next=tab.parentNode.firstChild;}
if(next.id){id=next.id.substr(5);b=dcg('WBbox'+id);if(b)return id;}
i++;}
return false}
wbCA.add=function(lbl,text,tab,rev,pr,lb2){try{lb2=lb2||lbl;pr=pr||false;var rel='';if(!tab){tab='/#WBnone'+lbl;rev=WB.en(tab);}
var t=dcg('WBtab'+rev);if(!t){t=wbCA.NT(lbl,tab,rev,lb2);var nx=false;if(pr)nx=dcg('WBtab'+pr);if(nx&&(nx=nx.nextSibling)){nx.parentNode.insertBefore(t,nx);}else{dca(dcg('WBactions'),t);}}
dcrm('WBrec'+rev);WBt.CLE();var box=dcg('WBbox'+rev);if(box){box.innerHTML=text;}else{box=wbCA.nb(rev,text);if(WB.at){dca(WB.at,box);}else{dca(dcg('WBcontentAreas'),box);}
WBt.hide(rev,false);}
TS.I(box);return rev;}
catch(m){err(m,'wbCA.add '+rev);}
return true}
wbCA.nb=function(a,b){var d=dcc('div');d.id='WBbox'+a;d.className='WBcontentArea';d.innerHTML=b;return d;}
wbCA.NT=function(a,b,c,a2){try{var d=' href="'+b+'" rev="'+c+'" ';if(b.search('#WBnone')!=-1){d+=' name="none"';}
var t=tabHtml.replace('%2$s',d);t=t.replace('%1$s',' id="WBtab'+c+'"').replace('%3$s',a).replace('%4$s',a2);var temp=dcc('div');temp.innerHTML=t;var r=temp.firstChild;r.className='WBcontentTabHide';return r;}
catch(m){err(m,'wbCA.NT');return false;}}
wbCA.CL=function(ig){try{var tabs=dcg('WBactions').childNodes;var cl=Array();var len=tabs.length;var a=Array();wbCA.LP(tabs,a,false);a.reverse();wbCA.LP(tabs,a,true);var i;for(n in a){i=a[n];if(len<=WB.tabs){break;}
if(ig[i]){continue;}
var t=dcg('WBbox'+i);if(t){if(editing&&WBe.f(t.parentNode)){continue;}
dcr(t);}
t=dcg('WBtab'+i);if(t)cl.push(t);len--;}
WBt.CL(cl);}
catch(m){err(m,'wbCA.CL');return;}}
wbCA.LP=function(l,a,b){var i,id,c,n;n=l.length;for(i=0;i<n;i++){if(!l[i].id)continue;if(l[i].id=='WBtab_CL')continue;id=l[i].id.substr(5);c=dcg('WBbox'+id);if(c&&!b){continue;}else if(!c&&b){continue;}
a.push(id);}}
wbCA.pLink=function(e){var a=WBt.gTab('A',false,WB.shn);if(!a)return;wn.location.href=a.href;}
wbCA.prev=function(){tab=wbCA.nextTab(WB.shn,1);WBt.go(tab);}
wbCA.next=function(){tab=wbCA.nextTab(WB.shn);WBt.go(tab);}
wbCA.app=function(a,b){a=dcg(a);if(a)a.innerHTML+=b;}
wbCA.rep=function(a,b){var c=wbCA.TTN(b);if(a&&c)a.parentNode.replaceChild(c,a);}
wbCA.TTN=function(a){var c=dcc('div');c.innerHTML=a;return c.firstChild;}
wbCA.adC=function(a,b,c){try{var nb;if(a&&b){nb=dcg(a+b);if(nb){var par=nb.parentNode;dcr(nb);par.innerHTML+=c;return;}}
nb=dcg(a);if(nb){if(a&&b){nb.innerHTML+=c;}else{nb.innerHTML=c;}
return;}}
catch(m){err(m,'wbCA.adC '+a+' :: '+b);}}
WBt.CL=function(a){try{if(a.length<1)return;var c='',i;for(i=(a.length-1);i>=0;i--){var el=WBt.gTab('A',a[i]);c+='<li id="WBrec'+el.rev+'"><a href="'+el.href+'" rev="'+el.rev+'">'+a[i].title+'</a>';c+='</li>';dcr(a[i]);}
var b=dcg('WB_CL');if(!b){WBt.CLS(c);}else{b.innerHTML=c+b.innerHTML;var c=b.childNodes;while(c.length>20){dcr(b.lastChild);}}
WBt.CLE();}
catch(m){err(m,'WBt.CL');return;}}
WBt.CLt=function(a){a='00'+a;return a.substr(-2);}
WBt.CLS=function(t){try{WB.tabs++;var b=wbCA.NT('&gt;','#','_CL','Recent Tabs');var c=dcg('WBactions');c.insertBefore(b,c.firstChild);WB.at=false;t='<div class="WBboxInfo">&nbsp;</div><div class="WBcontentArea2"><h1 class="WBcontentTitle">'+lg[8]+'</h1><ol id="WB_CL">'+t+'</ol><div id="WB_CLE" style="display:none">'+lg[4]+'</div></div>';wbCA.add('&gt;',t,'_CL','_CL');}
catch(m){err(m,'WBt.CLS');return;}}
WBt.CLE=function(){try{var a=dcg('WB_CL');if(!a)return;var b=dcg('WB_CLE');if(a.childNodes.length==0){WB.DS(b);}else{WB.DS(b,'none');}}
catch(m){err(m,'WBt.CLE');return;}}
function WBx(){}
WBx.reqUrl=function(a,b,c){var i=a.indexOf('?');if(i==-1){a=a.replace(/\+/g,'%2B');a+='?';}else{a=a.substr(0,i).replace(/\+/g,'%2B')+a.substr(i);a+='&';}
if(b)a+=b+'&';a+='wb[o]='+WB.own;if(c)a+='&wb[s]=1';a+='&wb[v]='+WB.nJs;a+='&wb[u]='+WB.en(WB.shn);return a;}
WBx.goTo=function(a,b){var p=a.indexOf('#');if(p!==-1){WBx.hash=a.substr(p);a=a.substr(0,p);}
WBx.SA();if(!WB.LC(a)){WB.hist=2;WBx.goToScript(a,b);return;}
WBx.goToFrame(a,b);}
WBx.goToFrame=function(a,b){wn.frames['WBhistory'].location.href=WBx.reqUrl(a,b);}
WBx.goToScript=function(a,b){dcrm('WBscript');var e=dcc('script');e.type='text/javascript';e.id='WBscript';e.src=WBx.reqUrl(a,b,1);dca(dcn('head')[0],e);}
WBx.goBackTo=function(fr){if(typeof(fr.isBlank)=='undefined'){err('BackTo error: '+fr.location.href);return;}
t=fr.location.search;t=WB.de(t);2
t=t.substr(1);if(!dcg('WBbox'+t)){if(WB.compat){WBx.goTo(t);}else{err('No Request type for iframeload: '+t);}
return;}
if(t!=''&&t!=WB.shn){WBt.go(t);}}
WBx.prev=false;WBx.revtype='local';WBx.hash=false;WBx.act=function(JSON,CHECK){try{var fr,first=false,sFiles=Array(),flds,mess=false,obj,imgs=Array(),lst=Array(),n,i,evals=Array();fr=wn.frames['WBhistory'];if(!JSON){WBx.goBackTo(fr);WBx.CA(true);return false}
WB.at=false;n=JSON.length;for(i=0;i<n;i++){obj=JSON[i];switch(obj.aa){case'xml':xml=obj.cc;break;case'form':WBx.setForm(obj.bb,obj.cc,obj.dd);break;case'script':sFiles.push(obj.bb);break;case'link':WB.LF('link',obj.bb,true);break;case'addcontent':wbCA.adC(obj.bb,obj.cc,obj.dd);break;case'append':wbCA.app(obj.bb,obj.cc);break;case'replace':wbCA.rep(dcg(obj.bb),obj.cc);break;case'message':WBx.MS(obj.bb,obj.cc);break;case'eval':evals.push(obj.bb);break;case'prev':WBx.prev=obj.bb;break;case'':WBx.prev=wbCA.add(obj.bb,obj.cc,obj.dd,obj.ee,WBx.prev,obj.ff);if(!first){first=WBx.prev;}
if(obj.ee){lst[obj.ee]=true;}
break;}}
WBx.prev=false;WBx.revtype='local';wbCA.CL(lst);if(first){WBt.go(first);WBt.sc(0);}
if(WBx.hash){window.location.hash=WBx.hash;WBx.hash=false;}
switch(WB.hist){case 1:fr.location.replace(WB.dPrefix+'/include/js/WBblank2.html#'+WB.en(first));break;case 2:fr.location.href=WB.dPrefix+'/include/js/WBblank.html#'+WB.en(first);break;}
WB.hist=0;WB.TO(function(){var i,n;WBx.DS();n=sFiles.length;for(i=0;i<n;i++){WB.LF('script',sFiles[i],true);}
n=evals.length;for(i=0;i<n;i++){eval(evals[i]);}},10);WBx.CA(true);if(typeof(pngFix)=='function'){pngFix();}
return true;}
catch(m){err(m,'WBx.act ');return true}}
WBx.MS=function(a,b){b=dcg('WBbox'+b);var c=b.firstChild.nextSibling.firstChild.nextSibling;if(c.className=='WBmessages'){wbCA.rep(c,a);}else{a=wbCA.TTN(a);c.parentNode.insertBefore(a,c);}
WBt.sc(0);}
WBx.testLink=function(e){try{e=getE(e);var el=getEl(e);if(!el)return;if(el.nodeName&&el.nodeName=='INPUT'&&el.type=='submit'){WBx.SA(6);return;}
el=WB.C(el,'A');if(!el||!el.href){return;}
if(!WBx.REV(el))return;var t=isLoaded(el.rev);if(t){WBx.SA(7);return;}
t=isLink(e,el);if(t){WBx.SA(6);}}
catch(m){err(m,'WBx.testLink '+el);}}
WBx.setForm=function(meth,act,act2){var a=dcg('WBform'+act2);if(a){WB.at=a;return;}
a=dcc('form');a.id='WBform'+act2;a.method=meth;a.action=act;if(typeof(a.encoding)!='undefined'){a.encoding='multipart/form-data';}else{a.enctype='multipart/form-data';}
a.setAttribute('revtype',WBx.revtype);a.onsubmit=WB.RS;dca(dcg('WBcontentAreas'),a);WB.at=a;}
WBx.iDS=function(){try{var dv=dcg('WB_SCROLLAREA');if(!dv)return;var bod=dcn('body')[0];bod.scroll='no';bod.style.overflow='hidden';dv.style.position='relative';dv.style.overflow='scroll';WB.TO('WBx.iDSt()',100);}
catch(m){err(m,'iDS');}}
WBx.iDSt=function(){WBx.DS();WB.AE(wn,'resize',WBx.DS);WB.AE(wn,'scroll',WBx.DS);}
WBx.wdth=false;WBx.DS=function(){var dv=dcg('WB_SCROLLAREA');if(!dv)return;if(dv.style.overflow!='scroll')return;var o1=WB.WS();var o2=WB.FL(dv);dv.style.height=(o1.y-o2.y)+'px';dv.style.width=(o1.x-o2.x-o2.x)+'px';}
WBx.uDS=function(){try{var dv=dcg('WB_SCROLLAREA');if(!dv)return;dc.body.scroll='auto';dc.body.style.overflow='';dv.style.overflow='';dv.style.height='100%';dv.style.width='100%';}
catch(m){err(m,'uDS');}}
WBx.REV=function(a){var b,c;try{b=decodeURIComponent(a.href);}catch(e){a.rev='';return false;}
if(a.rev=='interwiki'){a.rev='aHR0cDovL3d3dy53aWt5YmxvZy5jb20'+WBx.cRev(b.substr(23));}else if(a.rev=='always'){}else if(a.rev=='local'){b='/'+b.replace(/.*:\/\/[^\/]*\//,'');a.href=b;c=WB.lPrefix.length;if(c>0)b=b.substr(c);a.rev=WBx.cRev(b);}
return true;}
WBx.cRev=function(a){var c;c=a.indexOf('?');if(c>0){a=a.substr(0,c).toLowerCase()+a.substr(c).replace(/&/g,'&amp;');}else{a=a.toLowerCase();}
if(a.indexOf('/edit')==0){a=a.substr(5);}
a=unescape(encodeURIComponent(a));a=base64_encode(a);return a.replace(/[\/]/g,'.').replace(/[=]/g,'_')}
function base64_encode(a){if(typeof(btoa)=='function'){return btoa(a);}
var n=a.length,enc="",i=0,c1,c2,c3,e1,e2,e3,e4,b64="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";while(i<n){c1=a.charCodeAt(i++);c2=a.charCodeAt(i++);c3=a.charCodeAt(i++);e1=c1>>2;e2=((c1&3)<<4)|(c2>>4);e3=((c2&15)<<2)|(c3>>6);e4=c3&63;bits=c1<<16|c2<<8|c3;h1=bits>>18&0x3f;h2=bits>>12&0x3f;h3=bits>>6&0x3f;h4=bits&0x3f;if(isNaN(c2)){e3=e4=64;}else if(isNaN(c3)){e4=64;}
enc+=b64.charAt(e1)+b64.charAt(e2)+b64.charAt(e3)+b64.charAt(e4);}
return enc;}
WBx.LD=false;WBx.SA=function(a){var b=dcg('WBNewLoading');if(!b)return;if(!a){WBx.LD=true;a=13;}else if(WBx.LD){return;}
b.innerHTML=lg[a];WB.DS(b);}
WBx.CA=function(e){var b=dcg('WBNewLoading');if(!b)return;if(WBx.LD){if(e!==true){return;}else{WBx.LD=false;}}
WB.DS(b,'none');}
function showProps(obj){var a='';for(var i in obj){a+='<br/>'+i+" = "+obj[i]+"\n";}
wbCA.add('javascript',a,'#javascript','#javascript');WBt.go('#javascript','#javascript');}
WB.init();