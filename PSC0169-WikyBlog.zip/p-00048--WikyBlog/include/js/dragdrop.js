
var WBd=new Object();WBd.INIT=function(a,c){var b,n,i,d,e;a.onmouseover=null;WBd.VARS();c=c||'DIV';d=a.childNodes;n=d.length;for(i=0;i<n;i++){e=d[i];if(e.className&&!(e.className.indexOf('draggable')==-1)){e.setAttribute('drag','yes');e.onmousedown=WBd.dMDn;}}
WBd.DB();}
WBd.VARS=function(){WBd.startX=WBd.startY=WBd.offsetX=WBd.offsetY=WBd.dragEl=WBd.loc=WBd.elIndex=WBd.moved=false;WBd.dist=0;}
WBd.dMDn=function(e){try{var a,b,l;e=getE(e);a=WBd.dragEl=this;el=getEl(e);if(WB.C(el,'A'))return true;if(el.nodeName=='INPUT')return true;if(el.nodeName=='LABEL')return true;WBd.offsetX=-(a.offsetWidth/2);WBd.offsetY=-(a.offsetHeight/2);b=WBd.DB();b.style.height=a.offsetHeight+'px';b.style.width=a.offsetWidth+'px';b.style.display='block';WBd.DMB(e);WB.AE(document,'mouseup',WBd.DMU);WB.AE(document,'mousemove',WBd.DMM);WBd.SL();return false;}
catch(m){err(m,"WBd.dMDn");return true;}}
WBd.SL=function(){var a,c,n,i,d,e;WBd.loc=new Array();c=WBd.dragEl.parentNode.childNodes;n=c.length;for(i=0;i<n;i++){d=c[i];if(d.getAttribute&&(d.getAttribute('drag')=='yes')){e=WB.FL(d);WBd.loc[i]=new Array((e.x+(d.offsetWidth/2)),(e.y+(d.offsetHeight/2)));}
if(d==WBd.dragEl){WBd.elIndex=i;}}}
WBd.DB=function(a){a=dcg('WB_DRAG_BOX');if(a)return a;a=dcc('div');a.style.cssText='position:absolute;border:2px dashed #bbb;z-index:10000;';a.id='WB_DRAG_BOX';a.style.display='none';dcg('WBextras').appendChild(a);return a;}
WBd.DMU=function(e){dcg('WB_DRAG_BOX').style.display='none';WBd.VARS();WB.DE(document,'mouseup',WBd.DMU);WB.DE(document,'mousemove',WBd.DMM);}
WBd.DMB=function(e){var a,b;b=WB.XY();a=dcg('WB_DRAG_BOX');a.style.left=(e.clientX+WBd.offsetX+b.x)+'px';a.style.top=(e.clientY+WBd.offsetY+b.y)+'px';}
WBd.DMM=function(e){var a,i,n,b,c,min,target;e=getE(e);WBd.DMB(e);a=WB.XY();if(WBd.dist<10){WBd.dist++;return false;}
WBd.dist=0;n=WBd.loc.length;for(i=0;i<n;i++){b=WBd.loc[i];if(!b)continue;c=Math.abs(e.clientX+a.x-b[0])+Math.abs(e.clientY+a.y-b[1]);if(!min||(c<min)){min=c;target=i;}}
WBd.DP(target);WBd.SL();return false;}
WBd.DP=function(i){if(i==WBd.elIndex)return;var a,b,c,n,j;a=WBd.dragEl;b=a.parentNode;c=b.childNodes;if(!WBd.moved&&WB.f.moved){WB.f.moved.value='true';}
if(WBd.elIndex>i){b.insertBefore(a,c[i]);}else if(i==(c.length-1)){b.appendChild(a);}else{b.insertBefore(a,c[i+1]);}}
WBd.RO=function(b){var c,n,i,d,e;c=b.childNodes;n=c.length;for(i=(n-1);i>=0;i--){d=c[i];if(d.getAttribute&&(d.getAttribute('drag')=='yes')){b.appendChild(d);}}
WB.f.moved.value='true';}