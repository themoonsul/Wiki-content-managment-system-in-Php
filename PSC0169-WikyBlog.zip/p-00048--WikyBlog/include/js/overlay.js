
var wbg=new Object();wbg.to=false;wbg.olSz=function(){try{var ws=WB.WS();var sc=WB.XY();var dv=dcg('WBGalleryDivShade');dv.style.width=Math.max(ws.x,dc.body.offsetWidth)+'px';dv.style.height=Math.max(ws.y,dc.body.offsetHeight)+'px';var isMSIE55=(window.showModalDialog&&window.clipboardData&&window.createPopup);if(!isMSIE55||(typeof(document.body.filters)=="object")){dv.style.backgroundColor='#000000';wbg.opac(dv.style,50);}
var dv=dcg('WBGalleryDiv');dv.style.width=(ws.x-160)+'px';dv.style.height=(ws.y-80)+'px';dv.style.top=(sc.y+40)+'px';dv=dcg('WBGalleryLinks');var ht=dv.offsetHeight;dv=dcg('WBGalleryIframe');dv.style.width=(ws.x-160)+'px';dv.style.height=(ws.y-80-ht)+'px';}
catch(m){err(m,'wbg.olSz ');return false;}}
wbg.opac=function(a,b){a.opacity=(b/100);a.MozOpacity=(b/100);a.KhtmlOpacity=(b/100);a.filter="alpha(opacity="+b+")";}
wbg.close=function(){var a=dcg('WBGalleryContainer');a.parentNode.removeChild(a);WB.DE(window,'resize',wbg.olSz);WB.DE(window,'scroll',wbg.olSz);}
wbg.init=function(){try{wbg.olSz();WB.AE(window,'resize',wbg.olSz);WB.AE(window,'scroll',wbg.olSz);}
catch(m){err(m,'wbg.init');return false;}}
wbg.init();