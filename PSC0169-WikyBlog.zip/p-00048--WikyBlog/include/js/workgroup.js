
function changeUser(nm,pm){WB.f.guest.value=nm;WB.f.level.value=pm;window.scrollTo(0,0);}