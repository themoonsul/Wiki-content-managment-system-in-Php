
function collapseKeywords(){}
function doKeywords(){}
function addMap(){}
function insertWiki(){}
function showImgs(){}
function showImage(){}
function showSelect(){}
function setScroll(){}
function tagFocus(){}
function tagChange(){}
function tagBlur(){}
function showSBOptions(){}
WBe=new Object();WBe.set=function(){}
WBe.blur=function(){}
WBe.show=function(){}
WBe.create=function(){}
WB.RS=function(){}
function wbCreateNew(){}
function setCheckboxes(){}
function selectCheckbox(){}
function wbUL(){}
wbUL.addFile=function(){}