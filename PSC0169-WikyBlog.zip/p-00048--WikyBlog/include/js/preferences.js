
function showSBOptions(el){var a=dcg('WBPrefUpdateServices');var b=dcg('WBPrefBlogType');if(el.value=='Off'){WB.DS(a,'none');WB.DS(b);}else{WB.DS(a);WB.DS(b,'none');}}