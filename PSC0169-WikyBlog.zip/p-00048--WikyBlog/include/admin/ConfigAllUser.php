<?php
defined('WikyBlog') or die("Not an entry point...");



class configurationInstance extends configurationGeneric{
	var $history = false;
	
	function configurationInstance(){
		includeFile('tool/Variables.php');
	}
	
	
	function getPossible(){
		global $langA;
		
		$array['defaultUser:homeTitle'] = '';
		$array['defaultUser:textareaY'] = '';
		$array['defaultUser:isBlog'] = array('On'=>$langA['on'],'Off'=>$langA['off']);
		$array['defaultUser:timezone'] = '';
		$array['defaultUser:ajax'] = array('On'=>$langA['on'],'Off'=>$langA['off']);
		//$array['defaultUser:ajax'] = array('On'=>$langA['on'],'Partial'=>$langA['partial'],'Off'=>$langA['off']);
		$array['defaultUser:maxHistory'] = '';
		
		includeFile('themes/data.php');
		$themes = returnThemeData();
		$array['defaultUser:pTemplate'] = array();
		
		foreach($themes as $theme => $colors){
			$group = $theme;
			foreach($colors as $color => $temp){
				if( $color == 'html'){
					continue;
				}
				$full = $theme.'/'.$color;
				$array['defaultUser:pTemplate'][$full] = $full;
			}
		}
		return $array;
	}
	
	function getValues(){
		$values = wbVariables::getArray('defaultUser:');
		$values += $this->defaultVals;
		return $values;
	}

	function saveConfig(){
		$this->saveToConfigVars('defaultUser:');
	}	
	
}
		
	
