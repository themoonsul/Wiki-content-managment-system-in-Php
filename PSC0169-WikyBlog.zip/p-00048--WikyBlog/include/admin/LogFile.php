<?php

//!! php 5 only

defined('WikyBlog') or die("Not an entry point...");

class logFile{
	
	function logFile(){
		global $rootDir,$page,$pageOwner,$dbObject;
		$page->regLink('Log File','/Admin/'.$pageOwner['username'].'/LogFile');
		$page->autoForm = true;

		
		ob_start();
		$_POST += array('find'=>'','location'=>$rootDir);
		
		echo '<table><tr><td>';
		echo 'Location: ';
		echo '</td><td>';
		echo '<input type="text" name="location" value="'.$_POST['location'].'" size="100" />';
		echo '</td></tr>';
		echo '<tr><td>';
		echo 'Find: ';
		echo '</td><td>';
		echo '<input type="text" name="find" value="'.$_POST['find'].'" size="100" />';
		echo '</td></tr>';
		echo '<tr><td>';
		echo '</td><td>';
		echo '<input type="submit" name="cmd" value="Go" />';
		echo '</td></tr>';
		echo '</table>';
		
// 		switch($page->userCmd){
// 			
// 			case 'go':
// 				$this->find();
// 			break;
// 		}
		if( !empty($_POST['find']) ){
			$this->find();
		}
		
		
		$page->contentA['Log File'] = wb::get_clean();
	}
	function find(){
		
		if( !is_file($_POST['location']) ){
			message('Could not find log file.');
			return;
		}
		if( empty($_POST['find'])){
			message('`Find` was empty.');
			return;
		}
		
		$array = array();
		$fp = fopen($_POST['location'],'r');
		$i = 0;
		if( isset($_POST['offset']) ){
			$offset = $_POST['offset'];
		}else{
			$offset = 0;
		}
		//message(showArray($_POST));
		while($line = fgets($fp)){
			//$lowerline = strtolower($line);
			//!! php5 only
			if( $offset < $i ){
				if( stripos($line,$_POST['find']) !== false){
					$array[] = $line;
				}
				if( count($array) > 20 ){
					break;
				}
			}
			$i++;
		}
		message('read '.$i.' lines. <input type="submit" name="offset" value="'.$i.'" /> ');

		
		message('Found: '.showArray($array));
		
	}
}
	
new logFile();

