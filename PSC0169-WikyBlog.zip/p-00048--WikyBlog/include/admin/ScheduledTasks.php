<?php
defined('WikyBlog') or die("Not an entry point...");


class runTasks{
	function runTasks(){
		global $page,$pageOwner,$dbObject,$langA;
		
		$contentUri = $page->regLink('Scheduled Tasks','/Admin/'.$pageOwner['username'].'/ScheduledTasks');
		$page->autoForm = true;
		
		if( $page->userCmd === false){
			$page->contentA[$page->displayTitle] = '&nbsp;';
			return;
		}
		
		$continue = '';
		$GLOBALS['wbMaintain'] = array(true);
		includeFile('maintenance/scheduledTasks.php');
		$tasks = new taskManager();
		if( $tasks->all() ){
			message('Scheduled Tasks Complete');
			$continue = '<input type="submit" name="" value="Start Over" />';
		}else{
			$continue = '<input type="submit" name="" value="Continue" />';
			message('Continue to run more scheduled tasks.');
		}
		
		
		$GLOBALS['wbMaintain'] = false; //we don't want to do it twice in the same request
		$page->contentB[$contentUri] = '<ul>'.$tasks->buffer.'</ul>' . $continue;
		
		//message('SUCCESS');
	}
	
}
new runTasks();