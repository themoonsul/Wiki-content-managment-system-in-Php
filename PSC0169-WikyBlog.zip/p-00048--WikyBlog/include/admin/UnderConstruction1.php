<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML><HEAD><TITLE></TITLE></HEAD>
<body>
<p style="font-size:80%">(Can't connect to the MySQL server.)</p>

<div style="padding-top:10em;text-align:center">
Sorry, this website is experiencing technical difficulties.

<p>Please
<?php
echo '<a href="'.$_SERVER['REQUEST_URI'];
echo '">try again</a>';
?> 
shortly.
</p>


<div style="padding-top:10em">
Powered by <a href="http://www.wikyblog.com">WikyBlog</a>
</div>


</div>
<?php

die();

?>
</body>
</html>
