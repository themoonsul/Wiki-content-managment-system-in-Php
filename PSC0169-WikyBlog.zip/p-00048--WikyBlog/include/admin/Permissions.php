<?php
defined('WikyBlog') or die("Not an entry point...");

includeFile('search/all.php');
wbLang::getFile('SPEC');

class adminPermissions extends query{
	
	
	function adminPermissions(){
		global $page, $pageOwner,$langA,$wbTables;
		$page->css2 = true;
		
		$_POST += array('user'=>'');
		
		switch($page->userCmd){
			case 'delete':
				$this->rmUser();
			break;
			case wbStrtolower($langA['update']):
				$this->addUser();
			break;
		}
		
			
		$this->classes[] = 'class="tableRowOdd" ';
		$this->classes[] = 'class="tableRowEven" ';
		$this->searchUrl = '/Admin/'.$pageOwner['username'].'/Administrators';
			
		//so that we don't get multiple tabs
		$this->overWrite['user'] = false;
		$this->overWrite['cmd'] = false;
		$page->autoForm = true;
		
		$this->query = 'SELECT SQL_CALC_FOUND_ROWS ';
		$this->query .= ' `username` ';
		$this->query .= 'FROM '.$wbTables['users'];
		$this->query .= ' WHERE FIND_IN_SET("admin",`flags`) ';
		$this->query .= ' ORDER BY `username` ';
		//$this->browse($langA['permissions']);
		$this->browse('Administrators');

	}
	
	
	function addUser(){
		global $wbTables;
		
		$newName =& $_POST['user'];
		if( empty($newName) ){
			return;
		}
		
		$query = ' UPDATE '.$wbTables['users'];
		$query .= ' SET ';
		$query .= ' `flags` = '. wbDB::add_to_set('admin','`flags`');
		$query .= ' WHERE `username` = "'.wbDB::escape($newName).'" ';
		$query .= ' LIMIT 1 ';
		$num = wbDB::runQuery($query,true);
		if( $num > 0 ){
			message('updated');
		}else{
			message('OOPS');
		}
	}
	
	function rmUser(){
		global $wbTables;
		
		
		
		if( empty($_GET['user']) ){
			message('INVALID_REQUEST');
			return;
		}
		
		$newName = $_POST['user'] = $_GET['user'];
		
		
		if( strcasecmp(toStorage($newName),toStorage($GLOBALS['wbAdminUser']) ) === 0 ){
			message('INVALID_REQUEST');
			return;
		}
		
		
		if( strcasecmp(toStorage($_SESSION['username']),toStorage($newName) ) === 0 ){
			message('Cannot remove self.');
			return;
		}
		
		
		$query = ' UPDATE '.$wbTables['users'];
		$query .= ' SET ';
		$query .= ' `flags` = '. wbDB::remove_from_set('admin','`flags`');
		$query .= ' WHERE `username` = "'.wbDB::escape($newName).'" ';
		$query .= ' LIMIT 1 ';
		$num = wbDB::runQuery($query,true);
		if( $num > 0 ){
			message('updated');
		}else{
			message('OOPS');
		}		
		
	}
	
		
	function mysqlFetch(&$result){
		return mysql_fetch_assoc($result);
	}
	
	function displayPre(){
		global $langA,$pageOwner;
		

		echo '<table id="update" border="0" style="margin-left:auto;margin-right:auto">';
		
		echo '<tr><td><b>';
		echo $langA['username'];
		echo '</b>';
		echo '</td>';
		echo '</tr>';

		echo '<tr><td>';
		echo '<input type="text" name="user" size="30" value="'. wbHtmlspecialchars($_POST['user']) .'" />';
		echo '</td><td>';
		echo ' <input type="submit" name="cmd" value="'.$langA['update'].'" />';
		echo '</td></tr>';
		echo '</table>';
			 
		echo '<table cellspacing="0" width="100%" class="tableRows"><tr>';
		echo '<th>'.$langA['user'].'</th>';
		echo '<th colspan="3">'.$langA['view_users'].'</th>';
		echo '<th>'.$langA['options'].'</th>';
		echo '</tr>';
	}
	function displayEmpty(){
		return true;
	}
	function displayPost(&$prev,&$pages,&$next){
		echo '</table>';
		parent::displayPost($prev,$pages,$next);
	}
	
	function abbrevOutput($row,$i){
		global $langA;
		
		echo '<tr '.$this->classes[($i%2)].'>';
		echo '<td>'.toDisplay($row['username']).'</td>';
		
		$temp = wbStr_replace('.','',$row['username']);
		if( !is_numeric($temp) ){
			echo '<td class="sm">'.wbLinks::user($row['username'],$langA['homepage']).'</td>';
			echo '<td class="sm">'.wbLinks::special('ControlPanel','control_panel','',$row['username']).'</td>';
			echo '<td class="sm">'.wbLinks::special('UserEdits','edits','',$row['username']).'</td>';
		}else{
			echo '<td> </td><td> </td>';
		}
		
		echo '<td class="sm">';
		
		echo ' &nbsp; ';
		
		
		$removable = true;
		if( strcasecmp(toStorage($row['username']),toStorage($GLOBALS['wbAdminUser']) ) === 0 ){
			$removable = false;
			
		}elseif( strcasecmp(toStorage($_SESSION['username']),toStorage($row['username']) ) === 0 ){
			$removable = false;
			
		}		
		
		if( $removable ){
			$label = '<img src="'.wbLinks::getDir('/imgs/icons/delete.gif').'" height="16" width="16" alt="'.$langA['delete'].'" title="'.$langA['delete'].'" />';
			echo wbLinks::admin('Administrators?cmd=delete&user='.urlencode($row['username']),$label);
		}

		
		echo '</td>';
		echo '</tr>';
	}	
}
new adminPermissions();
