<?php
defined('WikyBlog') or die("Not an entry point...");


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		PLUGIN CREATOR (pre-alpha)
/*

		For a complete plugin we need
			1)	A way to create the sql, dbinfo, and the class
			2)	The class needs a number of elements
				- display
				- editing
				

		Column Types
		--------------------------------------------------------------------
			Must have
				`title`			text
				`keywords`		list

			Can Have Types
				text
					0-56k
					url's
					emails
				dates/times
				enum/sets
				integer			..need unsigned/signed? .. length decimals for double/float..
				
				
		!!! NEED TO COME BACK TO
		--------------------------------------------------
			-	$dbInfo['searchTitle'] ..
			-	need types like email, editors list
*/
//

global $page,$dbInfo,$pageOwner,$dbObject;
$page->regLink('Custom Data Types','/Admin/'.$pageOwner['username'].'/CreatePlugin');
$page->regLink('Data Types','/Admin/'.$pageOwner['username'].'/ManageTypes');
$page->regLink('?','Custom Data Types?en=Custom_Data_Types');
$page->displayTitle = 'Custom Data Types';

if( !isAdmin() ){
	$page->contentA[$page->displayTitle] = 'You must be an administrator to access this page.';
	return;
}

includeFile('admin/PluginCreateTool.php');

class createPlugin extends createPluginTool{
	var $types = array();
	
	//used for checking
	var $existingVars = array();
	var $usedCols = array();
	
	//resulting files
	var $sqlFile, $infoFile, $classFile;
	
	
	function createPlugin(){
		global $page;
		
		$this->createPluginTool();
		
			switch($page->userCmd){
				case 'check':
					if( $this->checkAll() ){
						message('Your plugin is ready for creation.');
					}
					$this->createForm($_POST);
				break;
				
				case 'show code':
					$this->showCode();
					if( !isset($_GET['wb']) ){
						$this->createForm($_POST);
					}
				break;
					
				case 'add plugin':
					$this->add();
					if( !isset($_GET['wb']) ){
						$this->createForm($_POST);
					}							
				break;
				
				default:
					$this->createForm($_POST);
				break;
			}
		
		
	}
	
	///////////////////////////////////////////////////////////////
	//
	//		The interface for creating a plugin
	//
	
	function createForm($args){
		global $page,$dbObject,$dbInfo;
		$page->autoForm = true;

		ob_start();
		
		$this->form($args);
		
		$page->contentA['Custom Data Types'] = wb::get_clean();
	}
	function formSubmit(){
		echo '<div style="text-align:right">';
		echo ' <input type="submit" name="cmd" value="Check" />';
		echo ' &nbsp; ';
		echo '<input type="submit" name="cmd" value="Add Plugin" />';
		echo ' &nbsp; ';
		echo '<input type="submit" name="cmd" value="Show Code" />';
		echo '</div>';
	}
	
	///////////////////////////////////////////////////////////////
	//
	//		extending functions
	//
	function add(){
		
		if( !$this->checkAll() ){
			return;
		}
		$nameSpace = toStorage($_POST['plugin']);

		$this->className = $this->getClassName($nameSpace);
		$this->createScripts($nameSpace);
		$this->addToDB($nameSpace);
	}
	
	function showCode(){
		if( !$this->checkAll(false) ){
			return;
		}
		$nameSpace = toStorage($_POST['plugin']);
		$this->className = $this->getClassName($nameSpace);
		$this->createScripts($nameSpace);
		$this->modify($nameSpace);
	}
	
}

new createPlugin();

