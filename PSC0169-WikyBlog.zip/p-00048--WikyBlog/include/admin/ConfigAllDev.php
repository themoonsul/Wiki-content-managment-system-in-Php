<?php
defined('WikyBlog') or die("Not an entry point...");



class configurationInstance extends configurationGeneric{
	
	
	function configurationInstance(){}
	
	
	function getPossible(){
		global $langA,$includeDir;
		
		$array['maxErrorFileSize'] = '';
		$array['errorEmail'] = '';

		return $array;
	}
	
	
	function getValues(){
		return $this->getConfig();
	}
	
	
	function saveConfig(){
		$newValues = $this->getFromPost();
		parent::saveToConfig($newValues);
	}
	
}
		
	