<?php
defined('WikyBlog') or die("Not an entry point...");



class configurationInstance extends configurationGeneric{
	
	
	
	function configurationInstance(){
		$this->beta['thumbs'] = true;
		$this->beta['negotiation'] = true; //Content Negotiation
	}
	
	
	function getPossible(){
		global $langA;
		
		$array['pUser'] = '';
		$array['online'] = array('On'=>$langA['on'],'Off'=>$langA['off']);
		$array['floodInterval'] = '';
		$array['ajax'] = array('On'=>$langA['on'],'Off'=>$langA['off']);
		//$array['ajax'] = array('On'=>$langA['on'],'Partial'=>$langA['partial'],'Off'=>$langA['off']);
		
		if( function_exists('tidy_parse_string')){
			$array['tidy'] = array('On'=>$langA['on'],'Off'=>$langA['off']);
		}else{
			$array['tidy'] = false;
		}

		$array['allUsers'] = array('On'=>$langA['on'],'Off'=>$langA['off']);
		$array['sesslevel'] = array('1'=>'123.123.123','2'=>'123.123','3'=>'123');
		
		
		// imagetypes() was added in 4.0.2
		// imagecreatetruecolor() was added in 4.0.6
		// imagecopyresampled() was added in 4.0.6
		//!! imagecreatetruecolor() : With PHP 4.0.6 through 4.1.x this function always exists if the GD module is loaded, but calling it without GD2 being installed PHP will issue a fatal error and exit
		//		-> before creating thumbnails, we check the type against supported imagetypes ( see imagetypes() function) .. if not supported, the thumbnail won't be created
		if( function_exists('imagecreatetruecolor') ){
			$array['thumbs'] = array('On'=>$langA['on'],'Off'=>$langA['off']);
		}else{
			$array['thumbs'] = false;
		}
		
		//$array['negotiation'] = array('On'=>$langA['on'],'Off'=>$langA['off']);

		return $array;
	}
	
	function showForm(){
		global $langA;
		parent::showForm($langA['wbConfig']);
	}
	
	function getValues(){
		$array = $this->getConfig();
		if( empty($array['wbConfig']['thumbs']) ){
			$array['wbConfig']['thumbs'] = 'Off';
		}
		return $array['wbConfig'];
	}
	
	
	function saveConfig(){
		$newValues = $this->getFromPost();
		
		if( empty($newValues['allUsers']) ){
			$newValues['allUsers'] = 'On';
		}
		if( !isset($newValues['sesslevel']) ){
			$newValues['sesslevel'] = '2';
		}		
		
		$array['wbConfig'] = $newValues;
		parent::saveToConfig($array);
	}
	
	
}
		
	
