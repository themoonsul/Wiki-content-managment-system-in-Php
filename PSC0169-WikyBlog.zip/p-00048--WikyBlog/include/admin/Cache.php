<?php

defined('WikyBlog') or die("Not an entry point...");


class wbCache{
	
	function wbCache(){
		global $page, $pageOwner;
		
		$contentUri = $page->regLink('Cache Management','/Admin/'.$pageOwner['username'].'/Cache');
		ob_start();
		
		switch($page->userCmd){
			
			case 'purgeblog':
				$this->purgeBlog();
			break;
			
			case 'purgetype':
				$this->purgeType();
			break;
			
		}
		$this->options();
		$page->contentB[$contentUri] = wb::get_clean();
	}
	
	
	function options(){
		global $dbInfo;
		
		echo '<table class="WBeditArea1" style="margin:1em auto 1em auto">';
		echo '<tr>';
		echo '<th>';
		echo 'Purge Blog Cache by Data Type';
		echo '</th>';
		echo '</tr>';
		echo '<tr>';
		echo '<td style="text-align:center">';
		
		echo '<p>';
		foreach($dbInfo as $space => $info){
			if( !isset($info['dbTable']) ){
				continue;
			}
			$list[] = wbLinks::admin('Cache?cmd=purgetype&space='.$space,$space);
		}
		echo implode(' - ',$list);
		
		echo '</p>';
		
// 		echo '<p>';
// 		echo wbLinks::admin('Cache?cmd=purgeblog','Purge Entire Cache');
// 		echo '</p>';
		
		echo '</td>';
		echo '</tr>';
		echo '</table>';
	}
	
	function purgeType(){
		global $wbTables, $dbInfo;
		
		$space = $_GET['space'];
		if( !isset($dbInfo[$space]) || !isset($dbInfo[$space]['dbTable']) ){
			message('INVALID_REQUEST');
			return;
		}
		$table = $dbInfo[$space]['dbTable'];
		
		
		//$query = 'SELECT count(*) FROM ';
		$query = 'DELETE ';
		$query .= $wbTables['all_blog'];
		$query .= ' FROM ';
		$query .= $wbTables['all_blog'];
		$query .= ' JOIN '.$table;
		$query .= ' USING( `file_id` ) ';
		$num = wbDB::runQuery($query,true);
		message('Purged '.$num.' entries');
		
	}
	
	function purgeBlog(){
		global $wbTables;
		
		$query = 'TRUNCATE TABLE '.$wbTables['all_blog'];
		wbDB::runQuery($query);
		message($wbTables['all_blog'].' was truncated');
	}
	
	
}
new wbCache();