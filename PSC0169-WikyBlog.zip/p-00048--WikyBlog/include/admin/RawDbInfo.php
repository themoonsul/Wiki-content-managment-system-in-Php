<?php
defined('WikyBlog') or die("Not an entry point...");

global $page,$pageOwner,$dbObject,$langA;
$page->regLink('Raw dbInfo','/Admin/'.$pageOwner['username'].'/Raw dbInfo');
$page->displayTitle = 'Raw dbInfo';
$page->autoForm = true;

class rawDbInfo{
	var $newInfo = false;
	function rawDbInfo(){
		global $page;
		
		if( $page->userCmd === false){
			$page->contentA[$page->displayTitle] = '&nbsp;';
			return;
		}
		
		ob_start();
		switch( $page->userCmd ){
			case 'save':
				$this->save();
			break;
		}
		
		$this->show();
		$page->contentA['Raw dbInfo'] = wb::get_clean();
	}
	function show(){
		global $dbInfo;
		if( empty($_POST)){
			message('<strong>Note:</strong> You should only modify these values if you are very familiar with PHP and WikyBlog.');
		}
		
		echo '<textarea style="width:100%" rows="30" name="dbinfo">';
		$temp = var_export($dbInfo,true);
		echo wbHtmlspecialchars($temp);
		echo '</textarea>';
		echo '<input type="submit" name="cmd" value="Save" />';
	}
	function save(){
		global $dbObject, $page, $wbDisableFeatures;
		
		if( isset($wbDisableFeatures) && $wbDisableFeatures ){
			message('<b>Sorry, this feature was disabled.');
			return false;
		}
		
		if( !$this->check() ){
			message('Could not save the supplied values.');
			return;
		}
		$data = $dbObject->getConfiguration();
		$data['dbInfo'] = $this->newInfo;
		
		if( $dbObject->updateConfig($data) ){
			$page->session = true; //send a new userMenu
			message('Your configuration has been updated (1).');
		}
	}
	function check(){
		$newInfo = false;
		if( empty($_POST['dbinfo']) ){
			return false;
		}
		$temp = '$newInfo = '.$_POST['dbinfo'].';';
		eval($temp);
		
		if( !is_array($newInfo) ){
			message('Not a valid array.');
			return false;
		}
		if( !isset($newInfo['page']) ){
			message('"page" is a required data type.');
			return false;
		}
		$this->newInfo =& $newInfo;
		return true;
	}
	
}
new rawDbInfo();