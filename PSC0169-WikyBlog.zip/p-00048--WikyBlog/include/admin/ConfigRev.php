<?php
//$langA checked

defined('WikyBlog') or die("Not an entry point...");


if( !isAdmin() ){
	global $page;
	$page->contentA['Admin Only'] = 'You must be an administrator to access this page.';
	return;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//					HISTORY LISTS
//

includeFile('search/all.php');

	class queryConfig extends query{
		var $classes;
		var $month,$day = false;
		
		function queryConfig(){
			global $page,$dbInfo,$dbObject,$pageOwner,$langA,$wbTables;
			
			$page->css2 = true;
			$page->displayTitle = $langA['confighistory'];
			
			$page->regLink($langA['configuration'],'/Admin/'.$pageOwner['username'].'/configuration');
			$dbObject->uniqLink = $page->formAction = $this->searchUrl = '/Admin/'.$pageOwner['username'].'/ConfigHistory';
			$page->regLink('?',$langA['configuration'].'?en=Configuration');


						
			// I don't like this because there may be configuration values that were changed by the software that could be undone by completely reverting
			// switch($page->userCmd){
			// 	case 'deletecurrent':
			// 		message('Are you sure you want to '.wbLinks::admin('ConfigHistory?cmd=confirmdelete','revert to the previous configuration').'.');
			// 	break;
			// 	case 'confirmdelete':
			// 		message('here');
			// 	break;
			// }
			
			switch($page->userCmd){
				case 'revert':
					message('Are you sure you want to '.wbLinks::admin('ConfigHistory?cmd=confirmrevert&revision='.$_GET['revision'],'revert to revision '.$_GET['revision']).'.');
				break;
				case 'confirmrevert':
					$this->revertConfig();
				break;
			}			
			

			$this->classes[] = ' class="tableRowEven" ';
			$this->classes[] = ' class="tableRowOdd" ';
			$this->rowLimit = 25;
			$this->overWrite['cmd'] = false;
			$this->overWrite['revision'] = false;
			
			$this->query = ' SELECT SQL_CALC_FOUND_ROWS * FROM '.$wbTables['config'].' ';
			$this->query .= ' ORDER BY revision DESC';
			$this->browse($langA['confighistory']);
		}
		
		function revertConfig(){
			global $wbTables;
			includeFile('admin/Config.php',false);
			
			if( !is_numeric($_GET['revision']) ){
				message('INVALID_REQUEST');
				return;;
			}
			
			$query = 'SELECT data FROM '.$wbTables['config'].' WHERE `revision` = "'.$_GET['revision'].'" LIMIT 1';
			$result = wbDB::runQuery($query);
			$row = mysql_fetch_assoc($result);
			$oldConfig = unserialize($row['data']);
			
			$_POST['summary'] = 'Reverted to '.$_GET['revision'];
			configurationGeneric::saveToConfig($oldConfig);
		}
		

		
		
		function mysqlFetch(&$result){
			return mysql_fetch_object($result);
		}

		function displayEmpty(){
			return true;
		}
		
		function displayPre(){
			global $dbObject,$langA;
			echo '<table cellpadding="2" cellspacing="0" border="0" width="100%">';
			echo  '<tr class="tableRows"><th>'.$langA['timeline'].'</th><th colspan="2">'.$langA['revision'].'</th><th>'.$langA['user'].'</th><th>'.$langA['summary'].'</th></tr>';
		}
		
		function abbrevOutput(&$row,$i){
			global $page,$pageOwner,$dbObject;
			global $langA;
	
	
			//	3)	Echo a row
			if( $i == $langA['current'] && isset($_GET['offset']) ){
				$class3 = $this->classes[($_GET['offset']%2)];
			}else{
				$class3 = $this->classes[($i%2)];
			}
			
			echo '<tr>';
			
			$this->timelineTD($row->modified);
	
			echo '<td '.$class3.' style="white-space:nowrap">';
			
			if( $i === 1){
				echo $langA['current'];
			}else{	
				echo $row->revision;
			}
			
			
			echo '</td><td '.$class3.' style="white-space:nowrap">';
			
			if( ($i === 1) && ($row->revision > 1) ){
				echo wbLinks::admin('configuration',$langA['edit_revision']);
				//echo wbLinks::admin('ConfigHistory?cmd=deletecurrent',$langA['delete']);
			}else{
				//echo wbLinks::admin('configuration?cmd=revert&revision='.$row->revision,$langA['edit_revision']);
				echo wbLinks::admin('ConfigHistory?cmd=revert&revision='.$row->revision,'revert');
			}
			
			echo '</td><td '.$class3.'>';
	
			
			if( !empty($row->username) ){
				echo wbLinks::user($row->username);
			}else{
				echo 'unknown';
			}
			
			if( isset($_SESSION['username']) ){
				if($_SESSION['username'] != $row->username){
					$guest = $row->username;
					
					if( !empty($row->username) ){
						echo ' <span class="sm">';
						echo wbLinks::special('Permissions?guest='.$guest,'+/-','title="'.$langA['SET_USER_PERMISSIONS'].$row->username.'"',$_SESSION['username']);
						echo '</span>';
					}
				}
			}
			
			
			echo '</td><td '.$class3.'><span class="sm">';
			echo $row->summary;
			echo '&nbsp;</span></td></tr>';
		}

		function displayPost(&$prev,&$pages,&$next){
			echo '</table> <p> <br/> </p>';
			echo $prev.$pages.$next;
		}
	}//end class
	
	
	
	new queryConfig();



//
//					HISTORY LISTS
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
