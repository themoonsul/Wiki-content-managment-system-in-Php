<?php
defined('WikyBlog') or die("Not an entry point...");



class configurationInstance extends configurationGeneric{
	var $history = false;
	
	function configurationInstance(){
		global $langA, $serverName1;
		wbLang::getFile('register');
		includeFile('tool/Variables.php');
		
		$this->defaultVals['register:reqemail'] = 'Off';
		$this->defaultVals['register:register'] = $langA['register'];
		$this->defaultVals['register:registered'] = $langA['welcome_to'].$serverName1;
		$this->defaultVals['register:captcha'] = 'Off';
		
	}
	
	
	function getPossible(){
		global $includeDir,$langA;
		$array['register:reqemail'] = array('On'=>$langA['on'], 'Off'=>$langA['off']);
		$array['register:register'] = '';
		$array['register:registered'] = '';
		
		if( function_exists('imagecreate') ){
			$array['register:captcha'] = array('On'=>$langA['on'], 'Off'=>$langA['off']);
		}else{
			$array['register:captcha'] = false;
		}

		
		return $array;
	}
	
	function getValues(){
		$values = wbVariables::getArray('register:');
		$values += $this->defaultVals;
		return $values;
	}

	function saveConfig(){
		$this->saveToConfigVars('register:');
	}
}
		
	