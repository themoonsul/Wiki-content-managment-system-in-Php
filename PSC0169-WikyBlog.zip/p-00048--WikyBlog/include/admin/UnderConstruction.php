<?php

global $page,$wbDirPrefix;


ob_start();
	echo '<div style="padding:10em 1em 10em 1em;text-align:center">';
	echo 'This website is currently undergoing maintenance, please check back shortly.';
	
	echo '<div style="padding-top:1em">';
	echo '<a href="'.$wbDirPrefix.'/include/maintenance/index.php">Administrators</a>';
	echo '</div>';
	echo '</div>';

$content = wb::get_clean();


if( $page->ajaxRequest ){
	message($content);
	$page->send();
	die();
	
}else{
	echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">';
	echo '<HTML><HEAD><TITLE>Under Construction</TITLE></HEAD>';
	echo '<body>';
	echo $content;
	echo '<div style="padding-top:10em;text-align:center">';
	echo 'Powered by <a href="http://www.wikyblog.com">WikyBlog</a>';
	echo '</div>';
	echo '</body>';
	echo '</html>';
	die();
}

