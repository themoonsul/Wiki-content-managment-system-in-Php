
<?php defined('WikyBlog') or die('Not an entry point...') ?> 

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo toDisplay($pageOwner["username"]); ?> - <?php echo $page->displayTitle2; ?></title>

<link href="<?php echo $GLOBALS["wbLinkPrefix"]; ?>/Special/<?php echo toDisplay($pageOwner["username"]); ?>/atom?field=blog" rel="alternate" title="Blog Feed for <?php echo toDisplay($pageOwner["username"]); ?>" type="application/rss+xml" />
<link href="<?php echo $GLOBALS["wbLinkPrefix"]; ?>/Special/<?php echo toDisplay($pageOwner["username"]); ?>/atom" rel="alternate" title="Recently Modified Feed for <?php echo toDisplay($pageOwner["username"]); ?>" type="application/rss+xml" />
<link href="<?php echo $GLOBALS["wbLinkPrefix"]; ?>/Special/<?php echo toDisplay($pageOwner["username"]); ?>/atom?field=1" rel="alternate" title="Recently Posted Feed for <?php echo toDisplay($pageOwner["username"]); ?>" type="application/rss+xml" />

<?php $page->htmlHead(); ?>
</head>
<body>

<div id="globalWrapper">
<h1 class="header">
<a href="<?php echo $GLOBALS["wbLinkPrefix"]; ?>/<?php echo toDisplay($pageOwner["username"]); ?>"><?php echo toDisplay($pageOwner["username"]); ?></a></h1>
<span class="header2"><?php echo toDisplay($pageOwner["username"]); ?></span> 
<span class="header3"><?php echo toDisplay($pageOwner["username"]); ?></span> 
<span class="header4"><?php echo toDisplay($pageOwner["username"]); ?></span> 
<span class="header5"><?php echo toDisplay($pageOwner["username"]); ?></span> 

<table cellpadding="0" cellspacing="0" border="0">
<tr>
	<td class="sideMenu"><div class="sideMenuDiv">
		&nbsp;
	</div></td>
	<td>
		<!-- &ToolMenu& Start -->
<?php echo $page->displayActions(); ?>

<!-- &ToolMenu& End -->
	</td>

</tr>
</table>

<div id="WB_SCROLLAREA">
<table cellpadding="0" cellspacing="0" border="0" id="contentTable">
<tr>

	<td class="sideMenu"><div class="sideMenuDiv">
	<div id="sideMenuPad">
	
	<!-- &NavBarNew& Start -->
	<?php $page->getNavBar(); ?>
	<!-- &NavBarNew& End -->
	
	<div class="sideMenuArea">
	 <b><?php echo toDisplay($pageOwner["username"]); ?></b>
	<ul><li><?php echo wbLinks::local('',''); ?></li><li><?php echo wbLinks::special('Blog','blog'); ?></li><li><?php echo wbLinks::special('BrowseComments','talk'); ?></li><li><?php echo wbLinks::special('ChangeLog','change_log'); ?></li></ul>
	</div>

	 <!-- &UserMenuNew& Start -->
	<?php $page->userMenu(); ?>
	<!-- &UserMenuNew& End -->

	 <!-- &KeywordsNew& Start -->
	<?php $page->getKeywords(); ?>
	<!-- &KeywordsNew& End -->

	 <!-- &links& Start -->
	<?php echo $page->getLinks(); ?>
	<!-- &links& End -->

	<div class="sideMenuArea">
	 <b>Search</b>
	 <!-- &WBSearch& Start -->
	<?php echo $page->search(); ?>
	<!-- &WBSearch& End -->
	</div>


	</div></div></td>

	<td class="contentTD">
		<!-- &Content& Start -->
<?php echo $page->displayPage() ?>

<!-- &Content& End -->
	</td>

</tr></table>

<div id="footer"><!-- &PageFooter& Start -->
<?php echo $page->getFooter(); ?>

<!-- &PageFooter& End --></div>

</div><!-- WB_SCROLLAREA End -->

<!-- &WBExtras& Start -->
<?php echo $page->extras; ?>

<!-- &WBExtras& End -->



</div>
</body></html>
