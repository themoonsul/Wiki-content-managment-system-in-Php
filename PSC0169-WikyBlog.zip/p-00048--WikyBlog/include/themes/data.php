<?php
/*

screenShot.png	height=140 width=250

*/

function returnThemeData(){
		global $includeDir;

	//
	//	Framed Three
	//
		// if( wbDebug ){
		// 	$temp['Framed_Three']['html'] = '<div style="border:1px solid #CCC;padding: 4px ;"><div style="background-color:#%s;padding:9px 0 0 0;"><div style="background-color:#%s;padding:0px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div></div>';
		// 	$temp['Framed_Three']['blue'][] = '334466';
		// 	$temp['Framed_Three']['blue'][] = 'FFF';
		// 	$temp['Framed_Three']['blue'][] = '792b1e';
		// }
		
	//
	//	graphic
	//
		$temp['graphic']['html'] = '<div style="border:1px solid #CCC;padding: 4px ;"><div style="background-color:#%s;padding:9px 0 0 0;"><div style="background-color:#%s;padding:0px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div></div>';
		$temp['graphic']['blue'][] = '334466';
		$temp['graphic']['blue'][] = 'FFF';
		$temp['graphic']['blue'][] = '792b1e';
		
		$temp['graphic']['brown'][] = '81654f';
		$temp['graphic']['brown'][] = 'FFF';
		$temp['graphic']['brown'][] = '1c73bf';
		
		$temp['graphic']['gray'][] = 'B7BBBC';
		$temp['graphic']['gray'][] = 'FFF';
		$temp['graphic']['gray'][] = '436976';
		
		$temp['graphic']['light_blue'][] = 'DEE7EC';
		$temp['graphic']['light_blue'][] = 'FFF';
		$temp['graphic']['light_blue'][] = '436976';
		
		$temp['graphic']['orange'][] = 'EFA52A';
		$temp['graphic']['orange'][] = 'FFF';
		$temp['graphic']['orange'][] = '446677';
		
		$temp['graphic']['red'][] = 'B52121';
		$temp['graphic']['red'][] = 'FFF';
		$temp['graphic']['red'][] = 'B52121';
		
		
	//
	//	Floating
	//
		$temp['floating']['html'] = '<div style="border:1px solid #CCC;background-color:#%s;padding:10px 0 0 0;"><div style="background-color:#%s;padding:4px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div>';
	
		$temp['floating']['black'][] = '1D1D1D';
		$temp['floating']['black'][] = 'FFF';
		$temp['floating']['black'][] = '1188BB';
		
		$temp['floating']['blue'][] = '445577';
		$temp['floating']['blue'][] = 'FFF';
		$temp['floating']['blue'][] = '1188BB';
		
		// $temp['floating']['new blue'][] = '445577';
		// $temp['floating']['new blue'][] = 'FFF';
		// $temp['floating']['new blue'][] = '1188BB';
	
	//
	//	Three Column
	//
		$temp['three_columns']['html'] = '<div style="border:1px solid #CCC;background-color:#%s;padding:10px 0 4px 0;"><div style="background-color:#%s;padding:4px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div>';
		$temp['three_columns']['light_blue'][] = 'DEE7EC';
		$temp['three_columns']['light_blue'][] = 'FFF';
		$temp['three_columns']['light_blue'][] = '436976';
		
		$temp['three_columns']['brown'][] = 'dab082'; //'81654f';
		$temp['three_columns']['brown'][] = 'FFF';
		$temp['three_columns']['brown'][] = '436976'; //'1c73bf';
		
		$temp['three_columns']['gray'][] = 'B7BBBC';
		$temp['three_columns']['gray'][] = 'FFF';
		$temp['three_columns']['gray'][] = '436976';		
		
		$temp['three_columns']['blue'][] = '334466';
		$temp['three_columns']['blue'][] = 'FFF';
		$temp['three_columns']['blue'][] = '792b1e';
		
	//
	//	Framed
	//
		$temp['Framed']['html'] = '<div style="border:2px solid #223;background-color:#ddd;padding:2px ;"><div style="background-color:white;padding:3px;"><div style="background-color:#%s;padding:9px 0 0 0;"><div style="background-color:#%s;padding:0px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div></div></div>';
		
		$temp['Framed']['green'][] = '00cc00';
		$temp['Framed']['green'][] = 'FFF';
		$temp['Framed']['green'][] = '136caf';
		
		$temp['Framed']['blue'][] = '157bc3';
		$temp['Framed']['blue'][] = 'FFF';
		$temp['Framed']['blue'][] = '136caf';
		
		$temp['Framed']['red'][] = 'dd0000';
		$temp['Framed']['red'][] = 'FFF';
		$temp['Framed']['red'][] = 'aa0000';
			
		$temp['Framed']['orange'][] = 'ff9934';
		$temp['Framed']['orange'][] = 'FFF';
		$temp['Framed']['orange'][] = '136caf';
		
	//
	//	Framed Organic
	//
		$temp['Framed_Organic']['html'] = '<div style="border:2px solid #a09a81;background-color:#dfe0c5;padding:2px ;"><div style="background-color:white;padding:3px;"><div style="background-color:#%s;padding:9px 0 0 0;"><div style="background-color:#%s;padding:0px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div></div></div>';
				
		$temp['Framed_Organic']['brown'][] = '624740';
		$temp['Framed_Organic']['brown'][] = 'FFF';
		$temp['Framed_Organic']['brown'][] = '136caf';
		
		$temp['Framed_Organic']['green'][] = '36663e';
		$temp['Framed_Organic']['green'][] = 'FFF';
		$temp['Framed_Organic']['green'][] = '136caf';
				
		$temp['Framed_Organic']['blue-green'][] = '457d83';
		$temp['Framed_Organic']['blue-green'][] = 'FFF';
		$temp['Framed_Organic']['blue-green'][] = '136caf';
		
		$temp['Framed_Organic']['light_blue'][] = '8ebcc0';
		$temp['Framed_Organic']['light_blue'][] = 'FFF';
		$temp['Framed_Organic']['light_blue'][] = '136caf';

		
		$temp['Framed_Organic']['red'][] = '91080c';
		$temp['Framed_Organic']['red'][] = 'FFF';
		$temp['Framed_Organic']['red'][] = '136caf';		
	//
	//	Simple
	//
	
		$temp['simple']['html'] = '<div style="border:1px solid #CCC;background-color:#%s;padding:10px 4px 4px 20px;"><div style="background-color:#%s;padding:4px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div>';
		
		$temp['simple']['tan'][] = 'EDEDCB';
		$temp['simple']['tan'][] = 'FFF';
		$temp['simple']['tan'][] = '06F';
		
		$temp['simple']['light_blue'][] = 'DEE7EC';
		$temp['simple']['light_blue'][] = 'FFF';
		$temp['simple']['light_blue'][] = '436976';
		
		$temp['simple']['green'][] = 'A0AA6D';
		$temp['simple']['green'][] = 'E9ECCF';
		$temp['simple']['green'][] = '4D87CE';

		
		
	//
	//	Default
	//
		$temp['default']['html'] = '<div style="border:1px solid #CCC;background-color:#%s;padding:10px 0 4px 0;"><div style="background-color:#%s;padding:4px;">Page Text<br/><span style="color:#%s;">Link Text</span></div></div>';
		
		$temp['default']['blue'][] = '334466';
		$temp['default']['blue'][] = 'FFF';
		$temp['default']['blue'][] = '792b1e';
		
		$temp['default']['green'][] = '748E42';
		$temp['default']['green'][] = 'FFF';
		$temp['default']['green'][] = '4D87CE';
		
		$temp['default']['red'][] = 'AA2200';
		$temp['default']['red'][] = 'FFF';
		$temp['default']['red'][] = '5588CC';
		
		$temp['default']['light_blue'][] = 'DFF1FF';
		$temp['default']['light_blue'][] = 'FBFBFB';
		$temp['default']['light_blue'][] = '792b1e';
				
		foreach($temp as $themeGroup => $colors){
			$path = $includeDir .'/themes/'.$themeGroup.'/template.php';
			if( !is_file($path) ){
				unset($temp[$themeGroup]);
			}
		}
		
		
	return $temp;
}
