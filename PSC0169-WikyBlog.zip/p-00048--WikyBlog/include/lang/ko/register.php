<?php
$langA['ILLEGAL_USERNAME'] = 'The Username cannot include the following characters: %s';
$langA['LONG_USERNAME'] = '사용자명이 너무 깁니다';	
$langA['SHORT_USERNAME'] = '사용자명이 너무 짧습니다.';
$langA['USER_TAKEN'] = '다른 사용자명을 선택해 주세요. <tt>%s</tt> 이 선택되었습니다. ';
$langA['USERNAME_ALL_DIGITS'] = '사용자명 전체가 숫자가 될 수는 없습니다.';
$langA['PASSWORDS_DIFFERENT'] = '암호가 일치하지 않습니다.';
$langA['SHORT_PASSWORD'] = '암호가 너무 짧습니다.';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = '등록';
$langA['welcome_to'] = '에 오신걸 환영합니다. ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = '최소 5개 문자';
$langA['confirm_password'] = '암호 확인';
$langA['REG_CONFIRM_PASS'] = '위와 같이';
$langA['REG_EMAIL'] = '선택사항이나 암호를 잊었을 때 유용함';
$langA['REQUIRED_FIELD'] = '필요 항목 표시';

$langA['REGISTRATION_TEXT'] = '무료로 등록 가능하며 빠르고 여러 이점이 있음';
$langA['REG_A_USER_PAGE'] = '/UserName/Your_Pages';
$langA['REG_A_MAP_PAGE'] = '/Map/Username/Your_Maps';

//login
$langA['LOGGED_IN'] = '<tt>%s</tt>로 로그인 됐습니다.';
$langA['WRONG_USERNAME'] = '사용자명이 존재하지 않습니다. 등록하시겠습니까?';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Activate your account now.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Your account has been activated.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
