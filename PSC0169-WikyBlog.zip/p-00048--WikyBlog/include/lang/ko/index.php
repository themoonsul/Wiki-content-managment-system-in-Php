<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = '파일';
$langA['edit'] = '수정';
$langA['edits'] = 'Edits';
$langA['view_source'] = '소스보기';
$langA['talk'] = '댓글';
//$langA['reply'] = 'Reply';
$langA['history'] = '기록';
$langA['diff'] = '비교';
$langA['watch'] = '눈여겨보기';
$langA['unwatch'] = '해제';
$langA['options'] = '옵션';


$langA['messages'] = '메시지';
$langA['current'] = '현재';
$langA['blog'] = '블로그';
$langA['possible'] = '가능한';

$langA['DEFAULT_CONTENT'] = '이것은 새로운 파일입니다.[[%s?cmd=edit|새롭게 만듭니까]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = '이것은 새로운 파일입니다.이 파일을 만들려면 권한이 있는 계정으로 로그인해야 합니다.';

$langA['NOT_OWNER'] = '이 기능을 위한 권한이 없습니다.';
$langA['LONG_PATH'] = '이 파일의 제목은 너무 길기 때문에 생략 되었습니다.';
$langA['EMPTY_CONTENT'] = '내용이 필요합니다';
$langA['INCOMPLETE_PATH'] = '경로가 불완전합니다.';
$langA['ADMIN_DISABLED_ALL_USERS'] = '관리자가 이용자의 블로그를 정지했습니다.여기와 같은 기능의 WikiBlog를 만들려면<a href="http://www.wikyblog.com">WikyBlog.com</a>를 봐 주세요.';
$langA['TITLE_EXISTS'] = '이 제목은 이미 존재합니다. 다른 것을 선택하시고 다시 저장하시기 바랍니다.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = '이 파일은 숨겨져 있습니다. ';
$langA['DELETED_FILE'] = '이 파일은 현재 쓰레기통에 들어가 있습니다. 당신이 이 계정의 소유자라면 제어판으로부터 파일을 복원할 수 있습니다.';
$langA['PROTECTED_FILE'] = '이 파일은 보호되고 있습니다. 이 파일에 대한 변경은 보존되지 않습니다.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = '링트 텍스트';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = '%s 로부터 이동되었습니다.';
$langA['REDIRECT_TO'] = '이 페이지는 %s에 리디렉트.';

//	Data Types
$langA['all'] = '모두';
$langA['page'] = '페이지';
$langA['comment'] = '코맨트';
$langA['map'] = '지도';
$langA['template'] = '템플릿';
$langA['help'] = '도움말';
$langA['skeleton'] = '스켈레톤';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = '코멘트';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = '페이지';
$langA['CLASScomment'] = '코멘트';
$langA['CLASSmap'] = '지도';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = '도움말';
$langA['IS_CONTENT_TEMPLATE'] = '이 파일은 컨텐츠 템플릿으로 블로그에는 표시되지 않습니다.';


$langA['seconds'] = ' 초';
$langA['queries'] = ' 쿼리';

$langA['QUERY_TIME'] = ' 쿼리 실행 동안';
$langA['INVALID_PATH'] = '올바르지 않은 파일 경로입니다: <tt>%s</tt>';							//replaced with path
$langA['INVALID_REQUEST'] = '유효하지 않은 요청';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = '소프트웨어의 통합 부분으로 중앙서버에 파일이 저장되도록 돕습니다.<br/> %s이%s 내용을 편집할 수 있으며 다른 것들은 %s의 파일을 돕습니다.';

$langA['NEW_HELP'] = '새로운 도움말 파일을 만든다';



//	Special Files that need to be in with main lang file
$langA['browse'] = '탐색';
$langA['change_log'] = '변경 사항';
$langA['control_panel'] = '제어판';
$langA['administration'] = '관리';
$langA['preferences'] = '설정';
$langA['watchlist'] = '주의 항목';
$langA['wanted_files'] = '요청 파일';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = '검색';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = '파일에 최대로 연결된';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = '외부 링크';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = '최근에 등록된 글.';
$langA['NEED_INTERNET'] = '이 기능은 인터넷에 접속된 시스템만으로 이용할 수 있습니다.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>경고：</b> 계속하려면  쿠키가 필요합니다. 만약 쿠키를 활성화시켰다면 이 페이지를 새로고침 해주세요.';
$langA['LOGIN_REQUIRED'] = '이 기능을 사용하려면 가입해 주세요.';

$langA['ENTER_USERNAME'] = '사용자명 넣어 주세요.';
$langA['ENTER_PASSWORD'] = '패스워드를 넣어 주세요.';
$langA['LOGGED_OUT'] = '로그아웃 했습니다.';
$langA['AUTO_LOGOUT'] = '세션 유지 시간을 초과했습니다.';

$langA['LOGIN_FAILED'] = '로그인 실패: 패스워드가 올바르지는 않습니다.<ul><li> Caps Lock 키가 켜져 있지 않습니까?<li>%s 패스워드를 잊었습니까%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = '로그인의 시도의 최대치%s를 넘었습니다. 지금부터 %s분동안 로그인할 수 없습니다.';
						
$langA['create_new'] = '새로 만들기 ';
$langA['remember_me'] = '입력값 기억';
$langA['log_out'] = '로그아웃';
$langA['log_in'] = '로그인';

//	SAVING 
$langA['syntax_error'] = '문법 오류';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>문법 에러：</b> 최신의 변경을 보존하거나 표시하거나 할 수 없습니다.';
$langA['SYNTAX_FIXED'] = '문법 오류가 수정되었습니다.';


$langA['NO_CHANGES'] = '이 파일에는 변경사항이 없습니다.(%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = '이 파일을 저장할 수 없습니다. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = '이 파일의 변경 내용이 저장되었습니다.';
$langA['HIDDEN_FILE3'] = '<b>주의：</b> 이것은 숨겨진 파일입니다.이 파일의 태그는 사용자의 메뉴에는 표시되지 않습니다.';

$langA['VERSION_CONFLICT'] = '경고：버전의 충돌이 있었으므로 변경사항을 저장할 수 없습니다.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = '<b>%s</b>를 <b>%s</b>로 복사합니다. <br/>"저장"을 클릭하여 복사를 최종 승인합니다.'; //replaced with paths

$langA['FLOOD_WARN'] = '편집은 한개 파일에 %s초로 제한되고 있습니다. %s초 후에 다시 시도해 주세요.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = '옵션 저장';
$langA['blog_this'] = '블로그 표시';



//	toolHistory2.php
$langA['differences'] = '차이';
$langA['line_num'] = '줄번호 #';


//	toolHistory1.php
$langA['revision'] = '버전 ';
$langA['revision_as_of'] = '버전번호 ';
$langA['revision_num_as_of'] = '버전번호 %s : %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = '해당 버전 편집';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = '버전 # 로 되돌리기';
$langA['SET_USER_PERMISSIONS'] = '이 사용자에게 허가한다: '; 
$langA['compare_with_prev'] = '← 이전의 버전과 비교';
$langA['current_revision'] = '현재의 버전';
$langA['compare_with_next'] = '다음의 버전과 비교 →';
$langA['lines'] = '줄번호';
$langA['text'] = '텍스트';
$langA['vs'] = ' vs ';
$langA['content'] = '내용';
$langA['your_text'] = '당신의 텍스트';
$langA['show_prev_revision'] = '← %s 버전'; //%s replaced with a revision number
$langA['show_next_revision'] = '%s 버전 →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>경고：</b>이 페이지의 최신버전을 편집하고 있지 않습니다.<br />저장을 실행하는 곳의 낡은 버전으로 최신판을 덧쓰기합니다.';
$langA['SELECT_TWO_VERSIONS'] = '비교하는 2개의 버전을 선택해 주세요.';
$langA['NO_UNIQUE_REVISION'] = '요청된 버전이 발견되지 않았습니다.';
$langA['INVALID_REVISION'] = '<b>에러：</b>버전의 번호가 올바르지 않습니다.';
$langA['NO_DIFFERENCES'] = '비교된 2개의 버전은 동일합니다.';
$langA['NO_REVISIONS'] = '비교하기 전에 2개가 다른 버전이 필요합니다.';
$langA['NON_EXISTANT'] = '이 파일은 더 이상 존재하지 않습니다.';

//	toolEditPage.php
$langA['bold_text'] = '두껍게';
$langA['italic_text'] = '기울임꼴';
$langA['headline_text'] = '표제를 삽입';
$langA['title'] = '타이틀';
$langA['unordered_list'] = '정렬 안된 리스트';
$langA['ordered_list'] = '정렬된 리스트';


$langA['internal_link'] = '내부 링크';
$langA['link'] = '링크';
$langA['external_link'] = '외부링크';
$langA['embed_image'] = '포함된 그림';
$langA['find_images'] = 'Find Images';
$langA['image'] = '그림';
$langA['nowiki'] = '위키의 처리없는글 삽입';
$langA['NOWIKI_TEXT'] = '포멧없는 글 삽입';
$langA['signature'] = '서명';
$langA['SIGNATURE_TEXT'] = '서명을 입력하세요';
$langA['preview'] = '미리보기';
$langA['PREVIEW_TEXT'] = '변경을 미리보기 [%s-p]';
$langA['PREVIEW_WARN'] = '이것은 미리보기입니다. 변경사항은 아직 저장되지 않았습니다.';
$langA['SAVE_TEXT'] = '변경된 내용을 저장[%s-s]';
$langA['reset'] = '내용 지우기';
$langA['RESET_TEXT'] = '이 폼을 원래 상태에 되돌리기[%s-c]';
$langA['changes'] = '변경';
$langA['CHANGES_TEXT'] = '이 파일에 추가된 변경사항을 보여준다.[%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = '위 글에 대한 키워드를 콤마(,)로 구분'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = '태그';
$langA['edit_summary'] = '편집내용 요점';
$langA['syntax_warning'] = '문법 경고';
$langA['NO_IMAGES'] = '그림을 찾을 수 없습니다.';
$langA['insert_emoticons'] = '이모티콘 추가';
$langA['upload'] = '업로드';



//searchHistory
$langA['show'] = '보기';
$langA['hide'] = 'Hide';
$langA['compare'] = '비교';
$langA['timeline'] = '타임라인';
$langA['summary'] = '요점';
$langA['COMPARE_REVISONS'] = '선택한 버전과 비교.';
$langA['unchecked'] = '체크되지 않음';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = '올바르지 않은 파일 형식입니다.';


//	SEARCH
$langA['next'] = '다음';
$langA['previous'] = '이전';
$langA['order_by'] = '정렬 방법 :';
$langA['ascending'] = '오름차순';
$langA['descending'] = '내림차순';
$langA['search_from'] = '(으)로부터 검색 : ';
$langA['all_users'] = '모든사용자';
$langA['user'] = '사용자';
$langA['from_file_type'] = '파일 타입으로부터 검색: ';
$langA['read_more'] = '더 읽기';
$langA['words'] = ' 단어';

$langA['RESULTS'] = '%s 중 %s 로부터 %s 까지의 결과'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = '이 검색에서는 아무것도 발견되지 않았습니다.';

//searchTalk
$langA['add_comment'] = '새로운 Topic을 추가';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = '경고：중복 한 엔트리에 대한 잘못된 포맷의 데이터는 포함할 수 없습니다.';
$langA['duplicate_entry'] = '엔트리 복제';
$langA['DUPLICATE_ENTRY'] = '이것은 %s 로 발견된 페이지에 대한 중복 엔트리입니다.<br/>여기에 있는 중복 하고 있지 않는 정보는 이 페이지가 삭제되기 전에 오리지날 페이지에 이동됩니다.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = '찾을 수 없음 : '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>에러：</b><br />이 스크립트를 실행중에 에러가 일어났습니다.<br /> 요청을 확인해 주세요. 에러 로그 %s 를 보고 스크립트를 디버그 하려고 합니다.'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = '초기 설정의 템플릿은 삭제할 수 없습니다.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = '특정된 테마는 올바르지는 않습니다.';

//
//	CLASSmap
//
$langA['new_marker']='새로운 Marker';
$langA['new_route']='새로운 Route';
$langA['SAVE_HEADER']='저장하기 전에 기억';
$langA['save_map']='지도 저장';
$langA['continue_editing']='계속 편집';
$langA['miles/km'] = 'miles/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>이것은 새로운 지도입니다</b><br/>　이 지도를 새롭게 만들거나 편집하려면 위의 "편집"을 클릭해 주세요.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = '죄송하지만, 이 지도를 편집할 수 있는 권한이 없습니다.';
$langA['play'] = '실행';
$langA['stop'] = '정지';
$langA['import'] = '가져오기';
$langA['export'] = '내보내기';
$langA['gpx_data'] = 'GPX 데이타';
$langA['gpx_exchange_format'] = 'GPX 변환 포멧';
$langA['CLICK_EDIT'] = '지도를 편집하려면 위의 "편집"을 클릭해 주세요';


//	smileys
$langA['smiles'][':D'] = '매우기쁨';
$langA['smiles'][':)'] = '스마일';
$langA['smiles'][':('] = '슬픔';
$langA['smiles'][':o'] = '놀람';
$langA['smiles'][':shock:'] = '충격';
$langA['smiles'][':?'] = '혼란';
$langA['smiles']['8)'] = '멋진';
$langA['smiles'][':lol:'] = '웃음';
$langA['smiles'][':x'] = 'Mad';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = '부끄럽다';
$langA['smiles'][':cry:'] = '울음';
$langA['smiles'][':evil:'] = 'Evil or Very Mad';
$langA['smiles'][':twisted:'] = 'Twisted Evil';
$langA['smiles'][':roll:'] = '멀뚱멀뚱';
$langA['smiles'][':wink:'] = '윙크';
$langA['smiles'][':!:'] = '깜짝';
$langA['smiles'][':?:'] = '질문';
$langA['smiles'][':idea:'] = '아이디어';
$langA['smiles'][':arrow:'] = '화살표';
$langA['smiles'][':|'] = '중립';
$langA['smiles'][':mrgreen:'] = 'Mr. Green';

//
//	General Language
//
$langA['or'] = '또는';
$langA['username'] = '사용자명';
$langA['password'] = '암호';
$langA['email'] = 'E-Mail';
$langA['register'] = '등록';
$langA['cancel'] = '취소';
$langA['language'] = '언어';
$langA['use'] = '사용';
$langA['copy'] = '복사';
$langA['rename'] = '이름 변경';

$langA['on'] = '켜기';
$langA['partial'] = '일부의';
$langA['off'] = '끄기';
$langA['save'] = '저장';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = '정의되지 않은';
$langA['homepage'] = '홈페이지';
$langA['home'] = '홈';
$langA['go'] = '가기';
$langA['user_menu'] = '사용자 메뉴';

$langA['last_modified'] = '최종변경';
$langA['LAST_MODIFIED'] = '최종변경 %s : %s에 의해';//%s replaced with date and username
$langA['accessed_times'] = '접근횟수 : %s회';// %s replaced with a number
$langA['modified'] = '변경됨';
$langA['posted'] = '등록됨';
$langA['created'] = '생성됨';
$langA['hidden'] = '숨김';
$langA['what_links_here'] = '이와 관련된 링크들';
$langA['share'] = '공유';
$langA['INVALID_LINK'] = '요청하신 페이지 제목은 유효하지 않습니다. 제목에서 사용되지 않은 문자를 하나 이상 포함하고 있습니다.';
$langA['FILE_MUST_EXIST'] = '이 작업을 하기 전에 파일을 저장하지 않으면 안됩니다';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = '크기 ';
$langA['bytes'] = '바이트';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = '업데이트';
$langA['editing'] = '수정';
$langA['workgroup'] = 'Workgroup';
$langA['BROWSE_HIDDEN'] = '숨김파일 찾기';

$langA['delete'] = '삭제';
$langA['confirm_delete'] = '삭제 확인';
$langA['continue'] = '계속';
$langA['back'] = '뒤로';
$langA['close'] = 'Close';
$langA['view'] = '보기';
$langA['empty'] = '- 비어있음 -';
$langA['none'] = '알 수 없음';
$langA['total'] = '전체 ';
$langA['files'] = '파일';
$langA['other'] = '다른';
$langA['trash'] = '휴지통';
$langA['flagged'] = '표시';

$langA['today'] = '오늘';
$langA['yesterday'] = '어제';
$langA['days_ago'] = ' 일 전';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = '더';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = '일요일';
$langA['date_l'][1] = '월요일';
$langA['date_l'][2] = '화요일';
$langA['date_l'][3] = '수요일';
$langA['date_l'][4] = '목요일';
$langA['date_l'][5] = '금요일';
$langA['date_l'][6] = '토요일';

$langA['date_D'][0] = '일요일';
$langA['date_D'][1] = '월요일';
$langA['date_D'][2] = '화요일';
$langA['date_D'][3] = '수요일';
$langA['date_D'][4] = '목요일';
$langA['date_D'][5] = '금요일';
$langA['date_D'][6] = '토요일';


$langA['date_F'][1] = '1월';
$langA['date_F'][2] = '2월';
$langA['date_F'][3] = '3월';
$langA['date_F'][4] = '4월';
$langA['date_F'][5] = '5월';
$langA['date_F'][6] = '6월';
$langA['date_F'][7] = '7월';
$langA['date_F'][8] = '8월';
$langA['date_F'][9] = '9월';
$langA['date_F'][10] = '10월';
$langA['date_F'][11] = '11월';
$langA['date_F'][12] = '12월';

$langA['date_M'][1] = '1월';
$langA['date_M'][2] = '2월';
$langA['date_M'][3] = '3월';
$langA['date_M'][4] = '4월';
$langA['date_M'][5] = '5월';
$langA['date_M'][6] = '6월';
$langA['date_M'][7] = '7월';
$langA['date_M'][8] = '8월';
$langA['date_M'][9] = '구월';
$langA['date_M'][10] = '10월';
$langA['date_M'][11] = '11월';
$langA['date_M'][12] = '12월';

$langA['date_a']['am'] = '오전';
$langA['date_a']['pm'] = '오후';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabic (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = '독일어 (de)';
$langA['lang']['el'] = '그리스어 (el)';
$langA['lang']['en'] = '영어 (en)';
$langA['lang']['es'] = '스페인어 (es)';
$langA['lang']['fr'] = '프랑스어 (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italian (it)';
$langA['lang']['ja'] = '일본어 (ja)';
$langA['lang']['ko'] = '한국어 (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = '독일어 (nl)';
$langA['lang']['pl'] = '폴란드어 (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = '러시아어';
$langA['lang']['tr'] = '터키어 (tr)';
$langA['lang']['vi'] = '베트남어 (vi)';
$langA['lang']['zh'] = '중국어 (zh)';
$langA['lang']['zh-cn'] = '중국어 간자 (zh-cn)';



