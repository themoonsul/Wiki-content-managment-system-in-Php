<?php

//	toolOptions.php
$langA['properties'] = '속성';
$langA['file_name'] = '파일명';
$langA['update_from'] = '갱신 :';
$langA['COPY_SYSTEM_FILES'] = '%s로부터 최신의 시스템 도움말 파일을 카피한다.';

$langA['EDITING_OPTIONS'] = '이 파일을 편집할 수 있는 사람을 제한한다';
$langA['registered_users'] = '등록된 이용자';
$langA['restricted_to'] = '에 제한 ';
$langA['admin_only'] = '관리자만';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Owner Only';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = '볼 수 있는가';
$langA['VISIBILITY_OPTIONS'] = '아직 모두에게 보이게 할 준비가 되어있지 않으면, 이 파일을 숨긴다.';
$langA['visible'] = '볼 수 있음';

$langA['COMMENT_OPTIONS'] = '이 파일에의 코멘트를 붙이지 않을 수 없게 한다.';
$langA['enabled'] = '사용가능';
$langA['disabled'] = '사용불가';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = '다른';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = '블로그에서 제거';
$langA['repost'] = '다시 올림';
$langA['copy_to'] = '다음으로 복사...';
$langA['send_to_trash'] = '휴지통에 보내기';
$langA['default_options'] = '기본 설정';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = '이 파일 타입에 %s를 설정한다'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = '이 파일은 재등록 되었습니다';
$langA['NOT_REPOSTED'] = '<b>에러：</b> 이 파일은 재등록할 수 없습니다';
$langA['OPTIONS_NOT_CHANGED'] = '파일 옵션이 변경되지 않았습니다.';
$langA['OPTIONS_UPDATED'] = '파일 옵션이 성공적으로 업데이트 되었습니다.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>주의:</b> 파일 옵션이 업데이트되지 않았습니다.';

$langA['redirect'] = '전송';
$langA['REMOVE_REDIRECT'] = '더 이상 이 파일을 전송 하고 싶지 않으면, 삭제하거나 편집해 주세요. ';


$langA['UNCHECKED_REMOVED'] = '이 파일에서 표시되지 않은 플래그가 제거되었습니다.';

$langA['NO_KEYWORDS'] = '이 파일에 관한 키워드들이 없습니다. 먼저 <a %s>키워드를 추가하시겠습니까?</a> <a %s>아니면 지금 블로그를 시작하시겠습니까</a>?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = '<a %s>관심 항목</a>이 업데이트되었습니다.';


$langA['user_permissions'] = '사용자&nbsp;권한';
