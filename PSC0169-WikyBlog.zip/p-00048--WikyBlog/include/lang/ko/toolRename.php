<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = '파일명이 변경되지 않았습니다.';
$langA['NOT_RENAMED'] = '파일명을 <tt>%s</tt>로 변경할 수 없습니다. 파일이 이미 존재하지 않는지 확인하세요.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = '파일명을 변경할 수 없습니다.';
$langA['redirected_to'] = '다음 페이지로 자동이동합니다. : ';
$langA['RENAMED'] = '파일명이 성공적으로 변경되었습니다.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b>가 복원되었습니다. ';
$langA['ERROR_RESTORING'] = '<b>Error:</b> <tt>%s</tt>로부터 파일을 복구할 수 없습니다.';
$langA['ALREADY_RESTORED'] = '이 파일은 이미 복원되었습니다.';
$langA['WAS_DELETED'] = '<b>%s</b> 는 삭제되었습니다.이 파일은 %s 에 30일간 보존되고 있습니다.';
$langA['ERROR_DELETING'] = '<b>에러：</b><tt>%s</tt> 파일을 삭제할 수 없습니다.';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt>는 삭제되었습니다.';
