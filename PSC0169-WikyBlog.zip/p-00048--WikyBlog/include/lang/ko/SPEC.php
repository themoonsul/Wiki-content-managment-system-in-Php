<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = '권한';
$langA['UNDEFINED_SPECIAL_PAGE'] = '이 특별 페이지는 아직 정의되고 있지 않습니다: <tt>%s</tt>';

//	control panel
$langA['general'] = '일반';
$langA['attachments'] = '첨부';
$langA['account_info'] = '계정 정보';
$langA['error_log'] = '오류 기록';
$langA['advanced_search'] = '고급 검색';
$langA['configuration'] = '설정';
$langA['search_options'] = '검색 옵션';
$langA['data_types'] = '데이타 타입';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = '탭';
$langA['account_display'] = '계정 표시';
$langA['links'] = '링크들';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = '사용자 통계';
$langA['database_info'] = '데이터베이스 정보';
$langA['user_preferences'] = '사용자 설정';
$langA['content_license'] = '컨텐츠 라이센스';
$langA['user_permissions'] = '사용자 권한';
$langA['default_page_options'] = '기본 페이지 옵션';
$langA['account_details'] = '계정 상세정보';
$langA['manage_images'] = '그림 관리';
$langA['manage_files'] = '파일관리&nbsp;';
$langA['upload_files'] = '파일 업로드';
$langA['public_templates'] = '공개 템플릿';
$langA['feeds'] = 'Syndication / Feeds';
$langA['recently_modified'] = '최근 변경';
$langA['recently_posted'] = '최근 등록';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = '<tt>%s</tt> 제어판';
$langA['CONTROL_PANEL_2'] = '%s를 보시겠습니까?';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = '패키지 템플릿 디렉토리를 사용할 수 없습니다.';
$langA['themes']['default'] = '기본';
$langA['themes']['simple'] = '단순';
$langA['themes']['three_columns'] = '세개 칼럼';
$langA['themes']['floating'] = '유동';
$langA['themes']['graphic'] = '그래픽';

$langA['colors']['colors'] = '색';
$langA['colors']['black'] = '검은색';
$langA['colors']['blue'] = '파랑';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = '초록';
$langA['colors']['light_blue'] = '밝은 파랑';
$langA['colors']['green'] = '초록';
$langA['colors']['tan'] = '황갈색';
$langA['colors']['red'] = '빨강';
$langA['colors']['orange'] = '오렌지';
$langA['colors']['gray'] = '회색';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = '숨김 보기';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = '권한 업데이트';
$langA['username_or_ip'] = '사용자명 또는 IP';
$langA['status'] = '상태';
$langA['workgroup'] = 'Workgroup';
$langA['admin'] = '관리자';
$langA['full_owner'] = 'Full/소유자';
$langA['ban'] = '추방';
$langA['banned'] = '추방됨';

//	friends.php
$langA['friends'] = '친구들';
$langA['my_status'] = '내 상태';


$langA['EX_USERNAMES'] = '예: <a>BillyJoe</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = '권한 조건을 지정하지 않았습니다.';
$langA['view_users'] = '이 사용자 보기...';
$langA['change'] = '변경';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = '사용자 <tt>%s</tt>는 이 워크그룹에서 탈퇴 되었습니다.';
$langA['USER_NOT_REMOVED'] = '사용자 <tt>%s</tt>는 이 워크그룹에서 탈퇴되지 않았습니다. ';
$langA['ADDED_PERMISSIONS'] = '<tt>%s</tt>에 추가된 권한.';
$langA['UPDATED_PERMISSIONS'] = '<tt>%s</tt>에 변경된 권한.';
$langA['NOT_A_USER'] = '사용자이름 <tt>%s</tt>를 찾을 수 없습니다.';
$langA['IP_NOT_ADDED'] = '<tt>%s</tt>에 대한 권한의 추가/업데이트를 할 수 없습니다.';
$langA['ALREADY_OWNER'] = '<b>경고：</b>사용자 <tt>%s</tt>는 이미 이 계정의 소유자입니다.';
$langA['IP_WRONG_LEVEL'] = '<b>경고：</b>IP주소에는 "워크그룹" 이상의 권한은 주어지지 않습니다.';
$langA['SET_PERMISSIONS'] = '"%s"에 대한 권한을 설정하려면, 희망하는 조건을 선택해 "권한 업데이트"를 클릭해 주세요.';


//	specLostPass
$langA['lost_password'] = '패스워드 잃어버림';



//	specFileManager
$langA['file_manager'] = '파일 관리자';
$langA['image_manager'] = '그림관리';
$langA['CONFIRM_FILE_DELETE'] = '<b>%s</b>를 삭제해도 괜찮습니까?';
$langA['IMAGE_MANAGER_INTRO'] = '그림을 붙이려면 wiki 문법 또는 html를 사용할 수 있습니다. 템플릿이나 지도등의 파일 타입에는 html를 사용하는 것을 추천 합니다.';
$langA['FILE_MANAGER_INTRO'] = '이 파일들을 포함시키기 위해 wiki 구문이나 html을 이용할 수 있습니다. 특정 파일 타입의 경우(템플릿, 맵스 등)html 구문 사용을 추천합니다.';
$langA['file_name'] = '파일명';
$langA['available_space'] = '사용 가능한 용량';
$langA['UPLOAD_INTRO'] = '페이지 삽입을 위해 첨부 파일이나 이미지를 업로드 할 수 있습니다.';
$langA['file_upload'] = '파일 업로드';
$langA['file_info'] = '파일 정보';
$langA['width'] = '너비';
$langA['height'] = '높이';
$langA['file_location'] = '파일 경로';
$langA['wiki_syntax'] = '위키 문법';
$langA['html_syntax'] = 'HTMl 문법';
$langA['append_to'] = '에 추가';
$langA['count'] = 'Count';
$langA['total_size'] = '전체 크기';
$langA['images'] = '이미지들';
$langA['overwrite_existing'] = '덮어쓰기가 존재함';
$langA['compression'] = 'Compression';

$langA['NOT_AN_IMAGE'] = '이미지로 존재하지 않는 파일입니다. 파일을 확인해 보시고 다시 시도해 보세요. (%s). ';
$langA['IMAGE_NOT_DELETED'] = '<tt>%s</tt>는 삭제할 수 없습니다.';
$langA['UPLOADED'] = '<tt>%s</tt>는 업로드되었습니다';
$langA['UPLOADED_RENAMED'] = '<tt>%s</tt> 파일이 <tt>%s</tt>로 업로드 됐습니다. <a %s>이름을 %s</a>로 변경할 수 있습니다.';
$langA['RENAMED'] = '파일명이 성공적으로 변경되었습니다.';
$langA['UPLOAD_FAILED'] = '파일 복사에 실패: <tt>%s</tt>';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = '<tt>%s</tt> 파일을 업로드 할 수 없습니다. <br/>파일은 <tt>%s</tt>바이트를 초과할 수 없습니다.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = '파일 타입을 선택:';
$langA['default_options'] = '기본 설정';
$langA['UNKNOWN_FILE_TYPE'] = '알 수 없는 페이지 형식: <tt>%s</tt>';

//	specAccountDetails
$langA['account'] = '계정';
$langA['entries'] = '엔트리';
$langA['average'] = '평균';
$langA['uploaded_files'] = '업로드된 파일';


//	searchTrash
$langA['deleted'] = '삭제됨';
$langA['restore'] = '복원';
$langA['empty_trash'] = '빈 휴지통';
$langA['CONFIRM_EMPTY_TRASH'] = '휴지통을 비우시겠습니까?';

$langA['DELETED_AFTER_30'] = '파일은 30일 후에 자동적으로 삭제됩니다.';
$langA['check_uncheck'] = '모두 체크/모두 체크해제';
$langA['DELETED_FILES'] = '선택된 파일이 성공적으로 삭제되었습니다.';
$langA['NOTHING_DELETED'] = '아무것도 삭제되지 않았습니다.';
$langA['DELETE_FILES'] = '삭제할 파일을 선택해주세요.';
$langA['MAP_INVALID_PT'] = '지도 데이터가 올바르지 않습니다：포인트의 포맷이 올바르지 않습니다';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = '이 사이트의 검색 기능이 사용 가능하지 않은 것 같습니다. 사이트 관리자가 제어판의 검색 옵션에서 사용가능하게 할 수 있습니다.';
$langA['search:'] = '검색: ';
$langA['search_for'] = '검색대상: ';
$langA['registered'] = '등록됨';
$langA['restricted'] = '제한됨';
$langA['locked'] = '잠김';
$langA['disabled'] = '사용불가';
$langA['editing_option'] = '수정 옵션';
$langA['comments_option'] = '댓글 옵션';
$langA['visibility_option'] = '보이는 방법 옵션';
$langA['normal'] = '일반';
$langA['advanced'] = '고급';
$langA['relevance'] = '관련';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'For all of the words';
$langA['SEARCH_EXACT'] = 'For the exact phrase';
$langA['SEARCH_WITHOUT'] = 'Without the words';
$langA['SEARCH_BEGIN'] = '다음으로 시작되는 단어에 대하여';


//	searchKeywords
$langA['keyword_search'] = '키워드 검색';
$langA['non_tagged_files'] = '테그없는 파일';

//	searchChangeLog
$langA['new'] = 								'새로운';
$langA['DIFF_TITLE'] = 							'최신버전과 차이를 비교';
$langA['indicates_syntax_error'] = 				'구문 에러를 가리킴';
$langA['indicates_unchecked'] = 				'표시되지 않은 파일 표시';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = '라이센스를 선택';
$langA['SELECT_LICENSE_DESC'] = 'Creative Commons의 웹 페이지를 새 창으로 엽니다.';
$langA['DELETE_LICENSE_DESC'] = '현재의 컨텐츠 라이센스를 제거합니다.';
$langA['LICENSE_UPDATED'] = '컨텐츠 라이센스가 업데이트 되었습니다.';
$langA['LICENSE_DELETED'] = '라이센스 삭제됨';
$langA['LICENSE_DELETED2'] = '라이센스가 이미 삭제되었습니다.';
$langA['customize_license'] = '당신의 라이센스를 조정';

$langA['text_before'] = '링크 앞에 텍스트';
$langA['text_after'] = '링크 뒤에 텍스트';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = '특히 주기가 없는 한 이 저작물은 이하의 라이센스의 원으로 작성되고 있습니다. ';
$langA['LICENSE_TEXT_LINK'] = 'Creative Commons License';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = '인식하다';
$langA['from'] = '보낸이';
$langA['to'] = '받는이';
$langA['KEYWORDS_UPDATED'] = '키워드가 업데이트되었습니다.';
$langA['KEYWORDS_EMPTY'] = '키워드를 활용하여 어떤 파일도 만들지 않았습니다.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = '<a %s>관심 항목</a>이 업데이트되었습니다.';

//links
$langA['uri'] = 'URI';
$langA['label'] = '레이블';
$langA['description'] = '설명';
$langA['add_link'] = '링크 추가';
$langA['link_groups'] = '링크 그룹들';
$langA['group'] = '그룹';
$langA['name'] = '이름';
$langA['add_group'] = '그룹 추가';
$langA['add_page'] = 'Add Page';

$langA['limit'] = '한계';
$langA['random'] = '임의로';
$langA['order'] = '순서';
$langA['LEAVE_EMPTY'] = '한계가 없을 경우 채우지 마시오';
$langA['unlimited'] = '무제한';
$langA['type'] = '타입';
$langA['auto_detect'] = '자동 검색';
$langA['bookmarklet'] = '북마크';
$langA['move_up'] = '위로 이동';
$langA['move_down'] = '아래로 이동';
$langA['redirect'] = '전송';
$langA['content_template'] = 'Content Template';

