<?php

$langA['lost_page'] = '없어진 페이지';
$langA['PAGE_NOT_FOUND'] = '요청하신 페이지 <tt>%s</tt>를 찾을 수 없습니다.';
$langA['REGISER_AS_USER'] = '사용자 계정 <tt>%s</tt>이 생성되지 않았습니다. %s를 사용자명으로 이용하시겠습니까?';
$langA['LINK_TYPO'] = ' 참조 페이지의 링크 타이포를 확인하세요. ';
$langA['REGISTER_TO_CREATE'] = '먼저 사용자명 <tt>%s</tt>을 이용하여 등록하신 후에 페이지를 생성할 수 있습니다.';