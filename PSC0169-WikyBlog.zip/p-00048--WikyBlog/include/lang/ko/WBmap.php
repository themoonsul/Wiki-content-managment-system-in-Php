<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'Loading Map...';
$langA['MAP_DEBUG_O'] = '요청하신 페이지와 맵을 로딩중에 에러가 발생했습니다. <p></p> 에러 로그가 생성되어 사이트 관리자가 곧 문제를 해결할 예정입니다.';
$langA['MAP_DEBUG_1'] = 'The Google Maps API does not appear to be compatible with your browser.<p>If you know your browser is compatible, make sure the correct map key is being used and that you are connected to the internet.</p><p>You can <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">get more information</a> about browser support from google.com.</p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>주의:</b> 지도들이 작동하기 위해서는 자바스크립트를 필요로 합니다.</p><p> 브라우저에 자바스크립트가 설치되지 않은 것으로 보입니다. 브라우저에 자바스크립트를 활성화한 후 페이지를 리로드하시기 바랍니다.</p>';