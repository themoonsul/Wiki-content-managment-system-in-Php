<?php

$langA['end_of_document'] = ' ---문서의 끝-- ';
$langA['syntax_warning'] = ' 구문 주의: ';

$langA['XML_ERROR_INVALID_TOKEN'] = '%s 라인의 %s에 에러가 발견되었으나 이전 라인에 의해 제기된 에러입니다.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>random &lt;text</tt> instead of <tt>random &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> instead of <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> instead of <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = '다음의 문서를 완성하기 위해서는 HTML tag를 닫아야 합니다 : "<em>%s</em>"';

$langA['unnecessary_closing_tag'] = '불필요한 closing tag.';
$langA['should_be'] = ' 단순히 ';

$langA['CLOSING_AN_UNOPENED_TAG'] = '열려있지 않는 tag을 닫습니다.<br />클로징 tag을 위한 오프닝 tag이 없습니다<tt>&lt;/%s&gt;</tt>.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>&lt;/tag&gt;</tt> without <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> instead of <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Missing closing tag. <br /> The <tt>&lt;%s&gt;</tt> tag must be closed using <tt>%s</tt> ';
$langA['MISSING_CLOSING_TAG2'] = ' closing tag 앞 <tt>&lt;/%s&gt;</tt>.';

$langA['AUTOMATED_SYNTAX_ERROR'] = '자동화된 구문 에러:';
$langA['AUTOMATED_SYNTAX_ERROR2'] = ' (%s)%s 라인의 (%s 라인의) %s에    ';
$langA['last_open_tag'] = '<br />마지막 open tag ';
