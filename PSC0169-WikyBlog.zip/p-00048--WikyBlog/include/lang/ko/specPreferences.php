<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = '기존의 설정에서 변경된 내용이 없습니다.';
$langA['INVALID_PREFS'] = '<b>경고：</b>입력하신 값을 설정에 저장할 수 없습니다.';

$langA['EMAIL_PREFS'] = '패스워드를 잊었을 때에 유용함.';

$langA['LANG_PREFS'] = '언어 선택.';

$langA['javascript_preferences'] = 'JavaScript Preferences';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'JavaScript 향상기능을 ON/OFF 합니다. JavaScript기능을 끄면 일부 기능이 정상적으로 동작하지 않을 수 있습니다.';

$langA['time_zone'] = '표준시간대';
$langA['TIME_ZONE_PREFS'] = '현지시간과 서버시간의 차이: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = '서버 시간은 %s 입니다. <br/>수정된 시간은 %s 입니다.';

$langA['sig'] = '서명';
$langA['SIGNATURE'] = '위키 구문을 이용해 서명을 개인화하세요';


$langA['home_title'] = '홈 타이틀';
$langA['HOME_TITLE_PREFS'] = '홈 페이지에 표시되는 타이틀.';

$langA['blog_styled_frontpage'] = '블로그 스타일 시작페이지';
$langA['BLOG_PREFS'] = '홈 페이지를 블로그로 표시.';

$langA['blogT'] = '블로그 타입';
$langA['BLOG_TYPE'] = '블로그에 적합한 데이타 타입을 정하세요';

$langA['selective_blogging'] = '선택적 블로깅';
$langA['SELECTIVE_BLOGGING'] = '선택적 블로깅으로 첫 페이지에 표시하고 싶은 페이지를 표시할 수 있습니다.';

$langA['blog_count'] = 'Blog Count';
$langA['BLOG_COUNT'] = 'The number of entries to show on your blog.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = '각 파일의 하단에 "공유" 링크를 표시합니다.';

$langA['ihelp'] = 'Help Links';
$langA['IHELP'] = 'Show help links.';

$langA['uServices'] = '서비스 업데이트';
$langA['UPDATE_SERVICES'] = '새로운 포스트를 등록하실때마다 다음의 추가된 서비스가 자동으로 공지됩니다. 라인 브레이크와 분리된 복수 서비스 URI';
$langA['BAD_UPDATE_SERVICES'] = '업데이트 서비스를 위해 올바르지 않는 URI(s)가 주어졌습니다.';


$langA['VIEW_THEME'] = '<a %s>Edit or copy</a> this theme.';

$langA['quick_comment'] = '코멘트';
$langA['QUICK_COMMENT'] = '보다 빠른 코멘트를 위해서 양식이 talk page 상단에 표시됨';

$langA['textarea rows'] = '편집영역 줄 수';
$langA['TEXTAREA_ROWS_PREFS'] = '편집영역의 초기설정 높이.';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = '서버에 저장되는 열의 수를 제한한다';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Maximum %s.';

$langA['tab_limit'] = '탭 제한';
$langA['TAB_LIMIT'] = '이 제한 값만큼 탭이 열리면 자동으로 탭이 닫힙니다.(JavaScript이용) 기본값은 7인데, JavaScript에서 이를 제어하지 않도록 하려면 1000 이상의 값으로 세팅하세요.';

$langA['EXTERNAL_LINKS'] = '"On" 상태에서 외부 링크는 새 창에 열립니다.';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = '키보드 단축키';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = '설정 저장';

$langA['CONFIRM_CHANGE'] = '사용자 설정을 변경하시겠습니까?';
$langA['preference'] = '선호';
$langA['old_value'] = '기존 값';
$langA['new_value'] = '새로운 값';

$langA['changes'] = '변경';
$langA['PREFS_CHANGED'] = '설정이 업데이트 되었습니다. <br/> 변경된 값들은 아래와 같습니다.';


//check edit
$langA['anonymous'] = '무명';
$langA['fEdits'] = '플래크 편집';
$langA['FLAG_EDITS'] = '다음 상태의 사용자에 의해서 편집된 내용은 계정 소유자의 리뷰가 있을 때까지 "확인안됨"으로 표시됩니다. ';

//save all edits
$langA['saveAll'] = 'Log All Edits';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
