 <?php

$langA['CHANGE_PASS_INTRO'] = '패스워드를 변경하기 위해서, "Permission Key"를 당신에게 전송하면 이를 이용해 제한적으로 사용 가능합니다. 키를 받게 되면, 이 페이지로 돌아와서 해당 정보를 아래에 입력하세요. 당신의 "Permission Key"는 당신의 사용자명을 위해서만 사용됩니다.';

$langA['next_step'] = '다음 단계';

$langA['PASS_EMAIL_SUBJECT'] = '%s를 위한 허가 키';
$langA['PASS_EMAIL_TEXT'] ='%s를 위한 허가 키는 %s';

$langA['get_your_key'] = '허가 키를 얻으세요';
$langA['GET_YOUR_KEY'] = '등록시에 입력하신 이메일 계정으로 키값이 전송됩니다.';

$langA['send_key'] = '허가 키를 보냅니다.';

$langA['change_password'] = '비밀번호를 바꾸시오';
$langA['permission_key'] = '허가 키';
$langA['new_password'] = '새로운 비밀번호';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = '비밀번호 변경에 실패했습니다: 부정황한 허가 키 또는 사용자명';
$langA['PASSWORD_CHANGED'] = '<tt>%s</tt>를 위해 비밀번호가 성공적으로 업데이트되었습니다.';
$langA['PROVIDE_PASSWORD'] = '비밀번호를 입력하세요';
$langA['PROVIDE_PERMISSION_KEY'] = '비밀번호 변경을 위해 허가 키를 입력하세요';
$langA['PERMISSION_KEY_SENT'] = '허가 키가 성공적으로 전송되었습니다. 이메일 계정에서 키값을 확인하시고 아래의 양식을 이용, 비밀번호를 변경하시기 바랍니다.';
$langA['PERMISSION_KEY_NOT_SENT'] = '이메일 계정으로 허가 키를 보내지 못했습니다. 사이트 관리자에게 문의하세요.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = '이메일 계정으로 등록된 것이 없습니다. 사이트 관리자에게 문의하세요.';

