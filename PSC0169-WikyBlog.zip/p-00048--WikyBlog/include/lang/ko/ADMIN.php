<?php

	$langA['googleMapKeys'] =						'Google Maps API 키값';


	$langA['ADMIN_ONLY'] =							'관리자만 이 페이지에 접근할 수 있습니다.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'이 관리 페이지는 아직 정의되지 않았습니다: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'다시 한번 암호를 확인해 주세요.';
	$langA['confirm_password'] =						'암호 확인';
	$langA['confirmation_failed'] =					'암호 정보가 일치하지 않습니다. 다시 시도해주세요.';
	
	$langA['run_scheduled_tasks'] =					'계획된 작업을 실행합니다.';
	$langA['FAILED'] = 								'죄송합니다, 실행 요청이 실패하였습니다. 다시 시도해주세요.';
	$langA['SUCCESS'] = 								'실행 요청이 성공하였습니다.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'검색 옵션';
	$langA['search_status'] =						'검색 상태';
	$langA['search_enabled'] =						'검색 기능';
	$langA['SEARCH_ENABLED'] =						'기능을 끄게되면 `all_search` 데이터 테이블은 비게 됩니다. 나중에 검색기능을 다시 켜고싶으면, `all_search` 테이블은 다시 활성화 될 것입니다.\'';
	$langA['disable'] =								'사용안함';
	
	$langA['search_disabled'] =						'검색 사용안함';
	$langA['SEARCH_DISABLED'] =						'검색은 할 수 없게 되어 있습니다. 검색을 사용하려면 검색 데이타베이스에 모든 파일의 엔트리를 넣는 작업이 필요합니다.이 작업은 큰 데이타베이스의 경우, 꽤 시간이 걸립니다.';
	$langA['SEARCH_IS_DISABLED'] =					'비활성화되었거나 truncated된 테이블 검색';
	$langA['enable'] =								'사용함';
	
	$langA['FINISHED_ENTRIES'] =						'%s 완료, %s 진행중.';
	$langA['SEARCH_IS_ENABLED'] =					'검색기능을 사용할 수 있습니다.';


//
// adminConfig.php
//
	$langA['configuration'] =						'설정';
	$langA['confighistory'] =						'설정 이력';
	$langA['CONFIG_SAVING'] =						'새로운 설정이 덧쓰기되지 않고 보존되었습니다. 원한다면 되돌리는 것이 가능합니다.';
	$langA['CONFIG_STAT'] =							'지금까지 %s 번의 설정 변경이 이루어졌습니다.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'수정번호 %s 의 내용으로 되돌립니다. 계속하려면 <tt> 저장</tt> 버튼을 클릭해 주세요.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'다음과 같이 사용할 수 있습니다: "Welcome to serverName1"';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'업로드 할 수 있는 파일의 최대크기.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'콤마로 분리된 사용자명을 이용하여 등록할 수 없습니다.';
	
	$langA['maxErrorFileSize']['desc'] = 			'에러 로그 파일의 최대치.초기설정치는 10,000바이트.';
	$langA['errorEmail']['desc'] = 					'전자메일 주소를 입력하세요 ';
	
	
	$langA['include']['desc'] = 						'매 요청시 자동적으로 소프트웨거가 php 파일을 포함하도록 합니다. 파일명은 콤마로 구분되며 루트 디렉토리에에 상대적인 것으로 제공됩니다.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'일반 설정';
	$langA['performance'] = 							'성능';
	
	$langA['serverName1']['alias'] = 				'Pretty 서버명';
	$langA['serverName2']['alias'] = 				'서버명';
	$langA['serverName3']['alias'] = 				'서버의 URL(전체 주소)';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'최대업로드크기';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'언어';
	$langA['reservedWords']['alias'] = 				'예약된 말';
	
	$langA['developer_aids'] = 						'개발자 지원';
	$langA['maxErrorFileSize']['alias'] = 			'에러 로그 크기';
	$langA['errorEmail']['alias'] = 					'에러 메일';
	$langA['include']['alias'] = 					'PHP파일 포함';

//
//	default user
//
	$langA['default_user_vars'] = 				'기본 사용자 설정';
	
	$langA['defaultUser:homeTitle']['alias'] =		'홈 타이틀';
	$langA['defaultUser:homeTitle']['desc'] =		'홈 페이지의 타이틀로서 표시됩니다.';
	
	$langA['defaultUser:template']['alias'] =		'이용자 템플릿';
	$langA['defaultUser:template']['desc'] =		'Main/Home이 wikyblog 템플릿의 초기 설정값입니다.';
	
	$langA['defaultUser:textareaY']['alias'] =		'편집영역 높이';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'블로그 홈 페이지';
	$langA['defaultUser:isBlog']['desc'] =			'블로그 스타일의 홈 페이지 사용 on / off.';
	
	$langA['defaultUser:timezone']['alias'] =		'표준시간대';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'최대 기록 줄수';
	$langA['defaultUser:maxHistory']['desc'] =		'기록 줄의 최대치 초기값.';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = '그룹 추가';
	$langA['unlimited'] = '무제한';
	$langA['group'] = '그룹';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'사용자 통계';
	$langA['user_stats'] =							'사용자 통계';
	$langA['user_account'] =							'사용자 계정';
	$langA['entries'] =								'엔트리';
	$langA['history Rows'] =							'기록 줄수';
	$langA['last_visit'] = 							'최종 방문';
	
	$langA['users_found'] =							'사용자가 발견되었습니다.';
	$langA['showing_of_found'] =						'%s를 통해 %s를 보인다';
	$langA['cpanel'] =								'컨트롤 패널';
	$langA['details'] =								'상세';
	
	$langA['within_the_hour'] =						' < 1시간전';
	$langA['hours'] =								'시간';
	$langA['days'] =									'일';
	$langA['months'] =								'월';
	$langA['years'] = 								'년';
	$langA['ago'] = 									'전';
	
	$langA['TIMEOUT'] = 								'<b>타임 아웃 에러:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>경고</b> "Main"계정은 삭제할 수 없습니다.';
	$langA['CONFIRM_DELETE_USER'] = 					'<b>%s</b>를 삭제해도 괜찮습니까?';
	$langA['CONFIRM_DELETE_USER2'] = 				'삭제는 계정에 포함된 모든 파일을<i>완전히 삭제</i>합니다: ';
	$langA['userfiles_directory'] = 					'사용자 디렉토리: ';
	$langA['template_directory'] = 					'템플릿 디렉토리: ';
	$langA['database_entries'] = 					'모든 데이타베이스 엔트리: 페이지, 페이지기록, 댓글 등.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'삭제된 데이타베이스 엔트리.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>경고:</b>데이타베이스 엔트리를 삭제할 수 없습니다.';
	
	$langA['DELETED_USERFILES'] = 					'삭제된 사용자 파일 디렉토리.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>경고:</b>사용자 파일 디렉토리를 삭제할 수 없습니다.';
	
	$langA['DELETED_TEMPLATES'] = 					'삭제된 템플릿 디렉토리.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>경고:</b>템플릿 디렉토리를 삭제할 수 없습니다.';
	
	$langA['USER_DELETED'] = 						'%s 는 완전히 삭제되었습니다: ';
	$langA['USER_NOT_DELETED'] = 					'%s 는 완전히 삭제되지 않았습니다: ';
	$langA['DELETE_ACCOUNT'] = 						'이 계정을 완전히 삭제합니다.';
	$langA['DISABLE_ACCOUNT'] = 					'파일 수정 불가.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activate';
	$langA['lost_page'] = 							'없어진 페이지';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'사용불가';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'에러 로그를 삭제할 수 없습니다.';
	$langA['ERROR_LOG_DELETED'] = 					'에러 로그가 삭제되었습니다.';
	$langA['ERROR_LOG_MAXED'] = 						'에러로그 파일이 최대 사이즈에 이르렀습니다. 에러 로그를 한층 더 쓰려면  파일의 내용을 비워주세요. %s';


	$langA['select'] = 								'선택';
	$langA['description'] = 						'설명';


//	adminPlugins
	$langA['data_types'] = 							'데이타 타입'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'존재하는 타입';
	$langA['available_plugins'] = 					'사용가능한 플러그인';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'모두 체크/모두 체크해제';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'온라인';
	$langA['wbConfig']['online']['desc'] = 			'이 작업의 실행은 인터넷에 접속되고 있습니까?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Flood 간격';
	$langA['wbConfig']['floodInterval']['desc'] = 	'허가가 없는 이용자가 편집할 때에 다음의 편집까지 기다려야 하는 시간(초)';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'흔히 있는 이용자의 입력 미스를 수정하려면  HTML Tidy를 사용해 주세요.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'전체 기능.';
	$langA['wbConfig']['allUsers']['desc'] = 		'모든 등록 이용자에게 자신의 블로그를 개설하는 것을 허가한다.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'방문자가 아니라면 표시될 사용자 계정을 선택하세요';
	$langA['wbConfig']['pUser']['alias'] = 			'기본 사용자';

	$langA['wbConfig']['sesslevel']['desc'] = 		'세션을 확인할 때 얼마나 많은 사용자 IP가 체크될지 결정합니다.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'세션 수준';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

