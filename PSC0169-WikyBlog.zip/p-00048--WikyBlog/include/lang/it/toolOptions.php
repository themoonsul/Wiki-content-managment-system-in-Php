<?php

//	toolOptions.php
$langA['properties'] = 'Proprietà';
$langA['file_name'] = 'Nome File';
$langA['update_from'] = 'Aggiornato da';
$langA['COPY_SYSTEM_FILES'] = 'Copia i file di aiuto di sistema più recenti da %s.';

$langA['EDITING_OPTIONS'] = 'Controlla a chi è permesso modificare questo file.';
$langA['registered_users'] = 'Utenti registrati';
$langA['restricted_to'] = 'Ristretto a ';
$langA['admin_only'] = 'Solo Amministratore';
$langA['editor_visible'] = 'Visibile per gli editori';
$langA['owner_only'] = 'Solo il proprietario';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = 'Visibilità';
$langA['VISIBILITY_OPTIONS'] = 'Nascondi questo file se non sei pronto a mostrarlo al mondo';
$langA['visible'] = 'Visibile';

$langA['COMMENT_OPTIONS'] = 'Disabilita i commenti per questo file.';
$langA['enabled'] = 'Attivo';
$langA['disabled'] = 'Disattivo';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = 'Altri';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Elimina da Blog';
$langA['repost'] = 'ReInvia';
$langA['copy_to'] = 'Copia in...';
$langA['send_to_trash'] = 'Invia al Cestino';
$langA['default_options'] = 'Opzioni di Default';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = 'Imposta %s per questo tipo di file.'; //replaced with link
$langA['add_to_tabs'] = 'Aggiungi a ettichette';
$langA['add_to_links'] = 'Aggiungi ai link';

$langA['REPOSTED'] = 'Il file è stato reinviato.';
$langA['NOT_REPOSTED'] = '<b>Errore:</b>Impossibile reinviare il file.';
$langA['OPTIONS_NOT_CHANGED'] = 'Le opzioni dei file non sono state cambiate.';
$langA['OPTIONS_UPDATED'] = 'Le opzioni dei file sono state aggiornate correttamente.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not updated.';

$langA['redirect'] = 'Ridireziona';
$langA['REMOVE_REDIRECT'] = 'Se non vuoi più che questo file ridirezioni, puoi modificarlo o eliminarlo. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'Permessi&nbsp;Utenti';
