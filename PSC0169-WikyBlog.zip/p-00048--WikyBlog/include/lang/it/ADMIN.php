<?php

	$langA['googleMapKeys'] =						'Chiave API di Google Maps';


	$langA['ADMIN_ONLY'] =							'Devi essere un amministratore per poter accedere a questa pagina.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Questa pagina di amministrazione non è ancora stata definita: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Per favore conferma la password per continuare';
	$langA['confirm_password'] =						'Conferma password';
	$langA['confirmation_failed'] =					'Password non valida. Riprova ancora per favore.';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Opzioni di ricerca';
	$langA['search_status'] =						'Stato della ricerca';
	$langA['search_enabled'] =						'Ricerca Abilitata';
	$langA['SEARCH_ENABLED'] =						'Disabilitando la funzione ricerca cancellerai il contenuto della tabella `all_search` del database. Se vorrai riattivare la funzione ricerca dovrai nuovamente riempire la tabella `all_search`.';
	$langA['disable'] =								'Disabilita';
	
	$langA['search_disabled'] =						'Ricerca Disabilitata';
	$langA['SEARCH_DISABLED'] =						'La funzione di ricerca e disabilitata. Per attivare la funzione di ricerca è necessario riempire la tabella `all_search` del database con tutti i file. Questo processo potrebbe richiedere del tempo su database grandi.';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'Attiva';
	
	$langA['FINISHED_ENTRIES'] =						'%s entrate fatte, %s ancora da eseguire.';
	$langA['SEARCH_IS_ENABLED'] =					'La funzione di ricerca è attiva adesso.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Configurazione';
	$langA['confighistory'] =						'Cronologia Configurazione';
	$langA['CONFIG_SAVING'] =						'Le nuove configurazione sono salvate senza sovrascrivere i valori attuali, permettendo di annullare le modifiche se ce ne fosse bisogno...';
	$langA['CONFIG_STAT'] =							'Sono state fatte %s revisioni alla configurazione';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Sei sicuro che vuoi tornare al numero di revisione %s. Clicca <tt>Salva</tt> per continuare.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Qualcosa che può essere usato con frase tipo: "Benvenuto al serverName1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'Dimensione massima di un file uplodato.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Dimensione massima permessa del file di log degli errori. Il valore di default è 10,000 byte.';
	$langA['errorEmail']['desc'] = 					'Fornisci un\'indirizzo email. ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Impostazioni Generali';
	$langA['performance'] = 							'Performanza';
	
	$langA['serverName1']['alias'] = 				'Nome Carino del Server';
	$langA['serverName2']['alias'] = 				'Nome del Server';
	$langA['serverName3']['alias'] = 				'Url Completa del Server';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Upload Massimo';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Lingua';
	$langA['reservedWords']['alias'] = 				'Parole Riservate';
	
	$langA['developer_aids'] = 						'Aiutatni dello sviluppatore';
	$langA['maxErrorFileSize']['alias'] = 			'Dimensione del file di log degli errori';
	$langA['errorEmail']['alias'] = 					'Email per gli errori';
	$langA['include']['alias'] = 					'Include PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Impostazioni Utente di Default';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Titolo della Home';
	$langA['defaultUser:homeTitle']['desc'] =		'Visualizzato come il titolo della home page.';
	
	$langA['defaultUser:template']['alias'] =		'Template Utente';
	$langA['defaultUser:template']['desc'] =		'Main/Home è il template di default di wikyblog.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Altezza della textarea';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Home Page del Blog';
	$langA['defaultUser:isBlog']['desc'] =			'Attiva e disattiva la homepage in stile blog.';
	
	$langA['defaultUser:timezone']['alias'] =		'Fuso Orario';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Numero massimo di righe cronologia';
	$langA['defaultUser:maxHistory']['desc'] =		'Massimo numero di default per le righe cronologia.';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Aggiungi gruppo';
	$langA['unlimited'] = 'Illimitato';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registrazione';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Statistiche Utenti';
	$langA['user_stats'] =							'Statistiche Utente';
	$langA['user_account'] =							'Account Utente';
	$langA['entries'] =								'Entrate';
	$langA['history Rows'] =							'Righe Cronologia';
	$langA['last_visit'] = 							'Ultima Visita';
	
	$langA['users_found'] =							'Utenti Trovati';
	$langA['showing_of_found'] =						'Sto mostrando %s attraverso %s';
	$langA['cpanel'] =								'CPanel';
	$langA['details'] =								'Dettagli';
	
	$langA['within_the_hour'] =						' < 1 ora fà';
	$langA['hours'] =								'ore';
	$langA['days'] =									'giorni';
	$langA['months'] =								'mesi';
	$langA['years'] = 								'anni';
	$langA['ago'] = 									'fà';
	
	$langA['TIMEOUT'] = 								'<b>Errore di Timeout</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'Sei sicuro di voler cancellare <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Cancellando <i>eliminerai completamente</i> tutti i file dell\'account inclusi:';
	$langA['userfiles_directory'] = 					'Percorse dei file utenti: ';
	$langA['template_directory'] = 					'Percorso dei template ';
	$langA['database_entries'] = 					'E tutte le entrare del database: pagine, cronologia pagine, commenti ecc...';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Entrare del Database Cancellate.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Attenzione:</b> Impossibile cancellare le entrare del database.';
	
	$langA['DELETED_USERFILES'] = 					'Directory dei file utente cancellati.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Warning:</b> Impossibile cancellare la directory dei file utenti.';
	
	$langA['DELETED_TEMPLATES'] = 					'Percorso dei file template cancellati.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Attenzione: </b> Impossibile cancellare il percorso dei template.';
	
	$langA['USER_DELETED'] = 						'%s è stato completamente cancellato: ';
	$langA['USER_NOT_DELETED'] = 					'%s non è stato cancellato completamente: ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Caricato';
	$langA['suspend'] = 							'Suspenda';
	$langA['activate'] = 							'Attiva';
	$langA['lost_page'] = 							'Pagina Persa';
	$langA['suspended'] =							'Suspendato';
	$langA['disabled'] =							'Disattivo';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Impossibile cancellare il file di log degli errori.';
	$langA['ERROR_LOG_DELETED'] = 					'Il file di log degli errori è stato cancellato.';
	$langA['ERROR_LOG_MAXED'] = 						'Il file di log degli errori ha raggiunto le dimesioni massime, per favore svuotalo in modo che lo script possa continuare a registrare gli errori. %s';


	$langA['select'] = 								'Seleziona';
	$langA['description'] = 						'Descrizione';


//	adminPlugins
	$langA['data_types'] = 							'Tipi di Dato'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Tipi Esistenti';
	$langA['available_plugins'] = 					'Plugin Disponibili';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Seleziona tutti/Deseleziona tutto';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Connesso';
	$langA['wbConfig']['online']['desc'] = 			'Questa implementazione è connessa a internet?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Intervallo Flood';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Il numero di secondi che un utente senza permessi deve attendere tra una modifica e l\'altra.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HMTL Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Utilizza HMTL Tidy per correggere possibili errori di input da parte degli utenti.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Pienamente Caratterizzato';
	$langA['wbConfig']['allUsers']['desc'] = 		'Permetti a tutti gli utenti registrati di avere il proprio blog.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

