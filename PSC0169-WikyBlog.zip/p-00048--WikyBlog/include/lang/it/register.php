<?php
$langA['ILLEGAL_USERNAME'] = 'Il nome utente non può contenere i seguenti caratteri: %s';
$langA['LONG_USERNAME'] = 'Nome Utente troppo lungo.';	
$langA['SHORT_USERNAME'] = 'Nome utente troppo corto.';
$langA['USER_TAKEN'] = 'Scegli un diverso Nome Utente. <tt>%s</tt> è già esistente. ';
$langA['USERNAME_ALL_DIGITS'] = 'Il Nome Utente non può contenere solo lettere.';
$langA['PASSWORDS_DIFFERENT'] = 'Password errata.';
$langA['SHORT_PASSWORD'] = 'La password è troppo corta.';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = 'Registrati';
$langA['welcome_to'] = 'Benvenuto in ';
$langA['REG_USERNAME'] = 'Un ID unico con 3-20 caratteri';
$langA['REG_PASSWORD'] = 'Deve essere di minimo 5 caratteri.';
$langA['confirm_password'] = 'Conferma password';
$langA['REG_CONFIRM_PASS'] = 'Le stesso di sopra.';
$langA['REG_EMAIL'] = 'Opzionale ma utile se dimentichi la password.';
$langA['REQUIRED_FIELD'] = 'Indica un campo obbligatorio.';

$langA['REGISTRATION_TEXT'] = 'La registrazione è rapida, gratuita e da molti vantaggi...';
$langA['REG_A_USER_PAGE'] = '/NomeUtente/Tue_Pagine';
$langA['REG_A_MAP_PAGE'] = '/Mappa/NomeUtente/Tue_Mappe';

//login
$langA['LOGGED_IN'] = 'Sei collegato come <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'Nome Utente inesistente. Vuoi registrarti come %s?';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Attiva il tuo conto adesso.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Il tuo conto è stato attivato.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
