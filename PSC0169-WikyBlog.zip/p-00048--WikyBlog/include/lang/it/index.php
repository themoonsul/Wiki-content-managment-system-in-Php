<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'File';
$langA['edit'] = 'Modifica';
$langA['edits'] = 'Edits';
$langA['view_source'] = 'Visualizza Sorgente';
$langA['talk'] = 'Parla';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Cronologia';
$langA['diff'] = 'diff';
$langA['watch'] = 'Guarda';
$langA['unwatch'] = 'Non guardare';
$langA['options'] = 'Opzioni';


$langA['messages'] = 'Messaggi';
$langA['current'] = 'Attuale';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Possible';

$langA['DEFAULT_CONTENT'] = 'Questo è un nuovo file, vuoi [[%s?cmd=edit|create it]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Questo è un nuovo file. Per crearlo devi effettuare l\'accesso con i privilegi corretti.';

$langA['NOT_OWNER'] = 'Non possiedi i privilegi corretti per questa opzione.';
$langA['LONG_PATH'] = 'Il titolo di questo file era troppo lungo e quindi è stato tagliato.';
$langA['EMPTY_CONTENT'] = 'Content è un campo richiesto';
$langA['INCOMPLETE_PATH'] = 'Il percorso fornito è incompleto.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Spiacente, l\'amministratore del sito ha disabilitato i blog utenti. Per creare un bliki con le stesse caratteristiche trovate qui, visita <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = 'Il file è nascosto. ';
$langA['DELETED_FILE'] = 'Il file è attualmente nel cestino. Se sei il proprietario di questo account, puoi ripristinarlo dal tuo pannello di controllo.';
$langA['PROTECTED_FILE'] = 'Questo file è protetto. Qualsiasi modifica fatta non verrà salvata.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Testo Link';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'Questa pagina redirige a %s.';

//	Data Types
$langA['all'] = 'Tutto';
$langA['page'] = 'Pagina';
$langA['comment'] = 'Commento';
$langA['map'] = 'Mappa';
$langA['template'] = 'Template';
$langA['help'] = 'Aiuto';
$langA['skeleton'] = 'Scheletro';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Commenti';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Pagine';
$langA['CLASScomment'] = 'Commenti';
$langA['CLASSmap'] = 'Mappe';
$langA['CLASStemplate'] = 'Temi';
$langA['CLASShelp'] = 'Aiuto';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' secs';
$langA['queries'] = ' queries';

$langA['QUERY_TIME'] = ' per le queries';
$langA['INVALID_PATH'] = 'Percorso file invalido: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Richiesta non valida.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'La tua tema';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = 'Crea un nuovo file di aiuto';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Naviga';
$langA['change_log'] = 'Cambia i Log';
$langA['control_panel'] = 'Pannello di Controllo';
$langA['administration'] = 'Amministrazione';
$langA['preferences'] = 'Preferenze';
$langA['watchlist'] = 'Guarda la liste';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'Cerca';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'Legame esterno';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'Post più recenti';
$langA['NEED_INTERNET'] = 'Questa opzione è utilizzabile solo da sistemi connessi a internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Warning:</b> I Cookie devono essere abilitati per continuare. Ricarica la pagina se hai già i cookie attivati.';
$langA['LOGIN_REQUIRED'] = 'Devi aver effettuato l\'accesso per utilizzare questa opzione.';

$langA['ENTER_USERNAME'] = 'Perfavore inserisci il tuo username.';
$langA['ENTER_PASSWORD'] = 'Perfavore inserisci la tua password.';
$langA['LOGGED_OUT'] = 'Hai effettuato il logout correttamente.';
$langA['AUTO_LOGOUT'] = 'La tua sessione è scaduta.';

$langA['LOGIN_FAILED'] = 'Accesso fallita: Password non corretta. <ul><li>E\' attivo il blocco maiuscole?<li> Tu %s ti sei dimenticato la password%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'Il numero massimo %s di tentativi di accesso è stato superato. Non ti sarà permesso effettuare il login per i prossimi %s minuti.';
						
$langA['create_new'] = 'Crea&nbsp;Nuovo ';
$langA['remember_me'] = 'Ricordami';
$langA['log_out'] = 'Esci';
$langA['log_in'] = 'Entra';

//	SAVING 
$langA['syntax_error'] = 'errore di sintassi';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Errore di Sintassi:</b>Impossibile Salvare/Mostrare i cambiamenti recenti di questo file a causa di una sintassi incompatibile.';
$langA['SYNTAX_FIXED'] = 'L\'errore di sintassi è stato corretto.';


$langA['NO_CHANGES'] = 'Non sono state fatte modifiche a questo file. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Impossibile salvare questo file. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Le modifiche a questo file sono state salvate.';
$langA['HIDDEN_FILE3'] = '<b>Note:</b> Questo file è nascosto, quindi i tag per questo file non verranno inclusi nel menu utente.';

$langA['VERSION_CONFLICT'] = 'Attenzione: Non possiamo salvare i tuoi cambiamenti perchè è stato trovato un conflitto di versioni.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'La modifica è stata limitata a una ogni %s secondi. Perfavore prova nuomente tra %s secondi.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Salva Opzioni';
$langA['blog_this'] = 'Blogga questo';



//	toolHistory2.php
$langA['differences'] = 'differenza(e)';
$langA['line_num'] = 'Linea #';


//	toolHistory1.php
$langA['revision'] = 'Revisione ';
$langA['revision_as_of'] = 'Revisione a partire da ';
$langA['revision_num_as_of'] = 'Revisione %s a partire da %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Modifica Revisione';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Ritornato alla revisione #';
$langA['SET_USER_PERMISSIONS'] = 'Imposta i tuoi permessi per questo utente: '; 
$langA['compare_with_prev'] = '← Confronta con la precedente revisione';
$langA['current_revision'] = 'Revisione Attuale';
$langA['compare_with_next'] = 'Confronta con la prossima revisione →';
$langA['lines'] = 'Linee';
$langA['text'] = 'Testo';
$langA['vs'] = ' vs ';
$langA['content'] = 'Contenuto';
$langA['your_text'] = 'Tuo Testo';
$langA['show_prev_revision'] = '← Revisione %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revisione %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Attenzione:</b> Non stai modificando la versione più recente di questa pagina. <br /> Salvando sovrascriverai la versione più recente con questa versione non aggiornata.';
$langA['SELECT_TWO_VERSIONS'] = 'Perfavore seleziona due versioni distinte da confrontare.';
$langA['NO_UNIQUE_REVISION'] = 'Impossibile trovare un\'unica revisione per questa richiesta.';
$langA['INVALID_REVISION'] = '<b> Errore:</b>Numero di revisione non valido';
$langA['NO_DIFFERENCES'] = 'Le due revisioni sono identiche.';
$langA['NO_REVISIONS'] = 'Ci devono essere due revisioni distinte prima che possa essere fatto un confronto.';
$langA['NON_EXISTANT'] = 'Il file non esiste.';

//	toolEditPage.php
$langA['bold_text'] = 'Grassetto';
$langA['italic_text'] = 'Corsivo';
$langA['headline_text'] = 'Inserisci Intestazione';
$langA['title'] = 'Titolo';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = 'Collegamento Interno';
$langA['link'] = 'Collegamento';
$langA['external_link'] = 'Collegamento Esterno';
$langA['embed_image'] = 'Immagine Inclusa';
$langA['find_images'] = 'Cerca immagini';
$langA['image'] = 'Immagine';
$langA['nowiki'] = 'No Wiki';
$langA['NOWIKI_TEXT'] = 'Inserisci il testo non formattato qui';
$langA['signature'] = 'Firma';
$langA['SIGNATURE_TEXT'] = 'Introdurre la firma';
$langA['preview'] = 'Anteprima';
$langA['PREVIEW_TEXT'] = 'Visualizza Anteprima delle tue modifiche[%s-p]';
$langA['PREVIEW_WARN'] = 'Questa è solo un\'anteprima. Le tue modifiche non sono ancora state salvate!';
$langA['SAVE_TEXT'] = 'Salva le tue modifiche[%s-s]';
$langA['reset'] = 'Reset';
$langA['RESET_TEXT'] = 'Resetta questo form al suo stao original[%s-c]';
$langA['changes'] = 'Modifiche';
$langA['CHANGES_TEXT'] = 'Visualizza le modifiche che hai fatto a questo file. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organizza i tuoi post con parole chiave separate da virgole'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Tags';
$langA['edit_summary'] = 'Modifica il sommario';
$langA['syntax_warning'] = 'Warning si sintassi';
$langA['NO_IMAGES'] = 'Nessuna immagine trovata';
$langA['insert_emoticons'] = 'Inserisci emoticons';
$langA['upload'] = 'Carica';



//searchHistory
$langA['show'] = 'Visualizza';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Confronta';
$langA['timeline'] = 'Linea Temporale';
$langA['summary'] = 'Sommario';
$langA['COMPARE_REVISONS'] = 'Confronta con la versione selezionata.';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'E\' stato fornito un formato di file non supportato.';


//	SEARCH
$langA['next'] = 'Prossimo';
$langA['previous'] = 'Precedente';
$langA['order_by'] = 'Ordina per:';
$langA['ascending'] = 'Ascendente';
$langA['descending'] = 'Discendente';
$langA['search_from'] = 'Cerca da: ';
$langA['all_users'] = 'Tutti gli utenti';
$langA['user'] = 'Utente';
$langA['from_file_type'] = 'Cerca Per Tipo di File ';
$langA['read_more'] = 'Leggi tutto';
$langA['words'] = ' parole';

$langA['RESULTS'] = 'Risultato %s a %s di %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Nessun risultato è stato trovato per il il criterio di ricerca.';

//searchTalk
$langA['add_comment'] = 'Aggiungi Nuovo Argomento';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Errore. I dati sono duplicati.';
$langA['duplicate_entry'] = 'Entrate duplicata';
$langA['DUPLICATE_ENTRY'] = 'Questo è un duplicato rispetto a %s. <br/>Trasferisci nell\'originale ogni informazione aggiuntiva prima che questa pagina venga eliminata.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Non trovato: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Errore:</b><br />Si è verificato un errore mentre veniva eseguito lo script.<br />Per favore controlla la tua richiesta e noi provvederemo al debug della tua richiesta con il tuo file di log degli errori. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Impossibile cancellare il template di default.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'Il tema specificato non era valido.';

//
//	CLASSmap
//
$langA['new_marker']='Nuovo indicatore';
$langA['new_route']='Nuovi Itenerario';
$langA['SAVE_HEADER']='Prima di salvare ricordati';
$langA['save_map']='Salva Mappa';
$langA['continue_editing']='Continua la modifica';
$langA['miles/km'] = 'miglia/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>Questa è una nuova mappa.</b><br/> Per creare/modificare questa mappa, clicca su "Modifica" qua sopra.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Spiacente, non hai i privilegi necessari per modificare questa mappa.';
$langA['play'] = 'Play';
$langA['stop'] = 'Stop';
$langA['import'] = 'Importa';
$langA['export'] = 'Esporta';
$langA['gpx_data'] = 'Dati GPX';
$langA['gpx_exchange_format'] = 'Formato di scambio GPX';
$langA['CLICK_EDIT'] = 'Per modificare la mappa, clicca su "Modifica" qua sopra';


//	smileys
$langA['smiles'][':D'] = 'Molto Felice';
$langA['smiles'][':)'] = 'Sorriso';
$langA['smiles'][':('] = 'Triste';
$langA['smiles'][':o'] = 'Sorpreso';
$langA['smiles'][':shock:'] = 'shockato';
$langA['smiles'][':?'] = 'Confuso';
$langA['smiles']['8)'] = 'Forte';
$langA['smiles'][':lol:'] = 'Sorridendo';
$langA['smiles'][':x'] = 'Matto';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Imbarazzato';
$langA['smiles'][':cry:'] = 'Piangendo dalla tristezza';
$langA['smiles'][':evil:'] = 'Cattivo o veramente matto';
$langA['smiles'][':twisted:'] = 'Cattivo Contorto';
$langA['smiles'][':roll:'] = 'Occhi Ruotanti';
$langA['smiles'][':wink:'] = 'Wink';
$langA['smiles'][':!:'] = 'Esclamazione';
$langA['smiles'][':?:'] = 'Domanda';
$langA['smiles'][':idea:'] = 'Idea';
$langA['smiles'][':arrow:'] = 'Freccia';
$langA['smiles'][':|'] = 'Neutrale';
$langA['smiles'][':mrgreen:'] = 'Signor Green';

//
//	General Language
//
$langA['or'] = 'o';
$langA['username'] = 'nome utente';
$langA['password'] = 'password';
$langA['email'] = 'E-mail';
$langA['register'] = 'Registrati';
$langA['cancel'] = 'Annulla';
$langA['language'] = 'Lingua';
$langA['use'] = 'Use';
$langA['copy'] = 'Copy';
$langA['rename'] = 'Rename';

$langA['on'] = 'Acceso';
$langA['partial'] = 'Parziale';
$langA['off'] = 'Spento';
$langA['save'] = 'Salva';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Indefinito';
$langA['homepage'] = 'Homepage';
$langA['home'] = 'Home';
$langA['go'] = 'Vai';
$langA['user_menu'] = 'Il menu del utente';

$langA['last_modified'] = 'Ultima modifica';
$langA['LAST_MODIFIED'] = 'Ultima modifica %s di %s.';//%s replaced with date and username
$langA['accessed_times'] = 'Entrato %s volte';// %s replaced with a number
$langA['modified'] = 'Modificato';
$langA['posted'] = 'Inviato';
$langA['created'] = 'Creato';
$langA['hidden'] = 'Nascosto';
$langA['what_links_here'] = 'Pagine che linkano questa';
$langA['share'] = 'Share';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'Il file deve essere salvato prima che tu possa compiere questa operazione.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Dimensione ';
$langA['bytes'] = 'byte';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Aggiorna';
$langA['editing'] = 'Modificando';
$langA['workgroup'] = 'Gruppo di Lavoro';
$langA['BROWSE_HIDDEN'] = 'Trova file nascosti';

$langA['delete'] = 'Elimina';
$langA['confirm_delete'] = 'Conferma la Cancellazione';
$langA['continue'] = 'Continua';
$langA['back'] = 'Indietro';
$langA['close'] = 'Close';
$langA['view'] = 'Visualizza';
$langA['empty'] = '-vuoto-';
$langA['none'] = 'Nessuno';
$langA['total'] = 'Totale ';
$langA['files'] = 'File';
$langA['other'] = 'Altri';
$langA['trash'] = 'Spazzatura';
$langA['flagged'] = 'Flagged';

$langA['today'] = 'Oggi';
$langA['yesterday'] = 'Ieri';
$langA['days_ago'] = ' gioni fà';
$langA['page_contents'] = 'Contenuti della pagina';
$langA['more'] = 'Più';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'Domenica';
$langA['date_l'][1] = 'Lunedì';
$langA['date_l'][2] = 'Martedì';
$langA['date_l'][3] = 'Mercoledì';
$langA['date_l'][4] = 'Giovedì';
$langA['date_l'][5] = 'Venerdì';
$langA['date_l'][6] = 'Sabato';

$langA['date_D'][0] = 'Dom';
$langA['date_D'][1] = 'Lun';
$langA['date_D'][2] = 'Mar';
$langA['date_D'][3] = 'Mer';
$langA['date_D'][4] = 'Gio';
$langA['date_D'][5] = 'Ven';
$langA['date_D'][6] = 'Sab';


$langA['date_F'][1] = 'Gennaio';
$langA['date_F'][2] = 'Febbraio';
$langA['date_F'][3] = 'Marzo';
$langA['date_F'][4] = 'Aprile';
$langA['date_F'][5] = 'Mag';
$langA['date_F'][6] = 'Giugno';
$langA['date_F'][7] = 'Luglio';
$langA['date_F'][8] = 'Agosto';
$langA['date_F'][9] = 'Settembre';
$langA['date_F'][10] = 'Ottobre';
$langA['date_F'][11] = 'Novembre';
$langA['date_F'][12] = 'Dicembre';

$langA['date_M'][1] = 'Gen';
$langA['date_M'][2] = 'Feb';
$langA['date_M'][3] = 'Mar';
$langA['date_M'][4] = 'Apr';
$langA['date_M'][5] = 'Mag';
$langA['date_M'][6] = 'Giu';
$langA['date_M'][7] = 'Lug';
$langA['date_M'][8] = 'Ago';
$langA['date_M'][9] = 'Sett';
$langA['date_M'][10] = 'Ott';
$langA['date_M'][11] = 'Nov';
$langA['date_M'][12] = 'Dic';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabo (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'Tedesco (de)';
$langA['lang']['el'] = 'Greco (el)';
$langA['lang']['en'] = 'Inglese (en)';
$langA['lang']['es'] = 'Spaniolo (es)';
$langA['lang']['fr'] = 'Francese (fr)';
$langA['lang']['hu'] = 'Ungaro (hu)';
$langA['lang']['it'] = 'Italiano (it)';
$langA['lang']['ja'] = 'Giapponese (ja)';
$langA['lang']['ko'] = 'Coreano (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Norvegese (nl)';
$langA['lang']['pl'] = 'Polacco (pl)';
$langA['lang']['ro'] = 'Rumeno (ro)';
$langA['lang']['ru'] = 'Russo (ru)';
$langA['lang']['tr'] = 'Turco (tr)';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'Cinese (zh)';
$langA['lang']['zh-cn'] = 'Cinese simplificato (zh-cn)';



