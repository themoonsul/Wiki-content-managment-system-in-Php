<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'Le tue preferenze non sono cambiate dai valori attualmente salvati.';
$langA['INVALID_PREFS'] = '<b>Attenzione:</b> Impossibile salvare le tue preferenza con i valori forniti.';

$langA['EMAIL_PREFS'] = 'Utile se perdi la password.';

$langA['LANG_PREFS'] = 'Seleziona la lingua.';

$langA['javascript_preferences'] = 'Preferenze JavaScript';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Turn on/off JavaScript enhancements. Some features will not work properly when JavaScript is disabled.';

$langA['time_zone'] = 'Zona Oraria';
$langA['TIME_ZONE_PREFS'] = 'Differenza oraria tra la tua ora locale e l\'ora del server: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'Server time is now %s. <br/>Your adjusted time is %s.';

$langA['sig'] = 'Firma';
$langA['SIGNATURE'] = 'Customize your signature with wiki syntax.';


$langA['home_title'] = 'Titolo della Home';
$langA['HOME_TITLE_PREFS'] = 'Titolo da mostrare nella tua home page.';

$langA['blog_styled_frontpage'] = 'Blog Stile Front Page';
$langA['BLOG_PREFS'] = 'Imposta la home page come blog.';

$langA['blogT'] = 'Il tipo di Blog';
$langA['BLOG_TYPE'] = 'Select among available data types to blog.';

$langA['selective_blogging'] = 'Selective Blogging';
$langA['SELECTIVE_BLOGGING'] = 'Selective Blogging allows you to blog only those pages you want displayed on the front page.';

$langA['blog_count'] = 'Blog Count';
$langA['BLOG_COUNT'] = 'Il numero di entrate da far vedere dentro al tuo blog.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'Display the "Share" link at the bottom of each file.';

$langA['ihelp'] = 'I link d\'aiuto';
$langA['IHELP'] = 'Mostra i link d\'aiuto';

$langA['uServices'] = 'Update Services';
$langA['UPDATE_SERVICES'] = 'When you publish a new post, the following update services will automatically be notified. Separate multiple service URIs with line breaks.';
$langA['BAD_UPDATE_SERVICES'] = 'Invalid URI(s) given for Update Services';


$langA['VIEW_THEME'] = '<a %s>Edit or copy</a> this theme.';

$langA['quick_comment'] = 'Commento Rapido';
$langA['QUICK_COMMENT'] = 'Quando attivo, un form viene mostrato in primo piano per velocizzare l\'inserimento di commenti.';

$langA['textarea rows'] = 'Righe textarea';
$langA['TEXTAREA_ROWS_PREFS'] = 'Imposta l\'altezza della editing area.';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'Limita il numero di righe da salvare come log nel server per ogni file.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Massimo %s';

$langA['tab_limit'] = 'Limite Tab';
$langA['TAB_LIMIT'] = 'JavaScript will automatically close tabs once the number of opened tabs has reached this limit. Defaults to 7. Set to 1000 or more if you don\'t want JavaScript to manage your tabs.';

$langA['EXTERNAL_LINKS'] = 'External links will be opened in a new window when "On".';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'Scorciatoie da tastiera';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = 'Salva Impostazioni';

$langA['CONFIRM_CHANGE'] = 'Sei sicuro di voler modificare le tue impostazioni?';
$langA['preference'] = 'Impostazioni';
$langA['old_value'] = 'Valore Precedente';
$langA['new_value'] = 'Nuovo Valore';

$langA['changes'] = 'Modifiche';
$langA['PREFS_CHANGED'] = 'Your preferences have been updated.<br/> Below is a summary of the values that have changed.';


//check edit
$langA['anonymous'] = 'Anonimo';
$langA['fEdits'] = 'Flag Edits';
$langA['FLAG_EDITS'] = 'Edits made by users with status at or below the selected status will be flagged as "Unchecked" until it is reviewed by the account owner.';

//save all edits
$langA['saveAll'] = 'Registra tutte le modifiche';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
