<?php

$langA['lost_page'] = 'Pagina Persa';
$langA['PAGE_NOT_FOUND'] = 'La pagine richiesta <tt>%s</tt> non è stata trovata';
$langA['REGISER_AS_USER'] = 'Sembra che l\'account utente <tt>%s</tt> non sia stato creato. Vuoi crearla con lo username %s?';
$langA['LINK_TYPO'] = ' Controlla il tipo di link per la pagina di riferimento. ';
$langA['REGISTER_TO_CREATE'] = 'Prima pagina creata con lo username <tt>%s</tt>.';