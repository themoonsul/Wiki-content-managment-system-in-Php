<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'Il nome del file non è stato modificato.';
$langA['NOT_RENAMED'] = 'Questo file non può essere rinominato in <tt>%s</tt>. Assicurarsi che il file non sia già presente.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'Non puoi rinominare questo file.';
$langA['redirected_to'] = 'Redirected to';
$langA['RENAMED'] = 'Il file è stato rinominato con successo.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b> è stato ripristinato. ';
$langA['ERROR_RESTORING'] = '<b>Error:</b> Could not restore the file at <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = 'Il file è stato già ripristinato.';
$langA['WAS_DELETED'] = '<b>%s</b> è stato cancellato. Questo file verrà mantenuto nel %s per 30 giorni.';
$langA['ERROR_DELETING'] = '<b>Errore:</b> Impossibile cancellare il file in <tt>%s</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> e\' stato cancellato.';
