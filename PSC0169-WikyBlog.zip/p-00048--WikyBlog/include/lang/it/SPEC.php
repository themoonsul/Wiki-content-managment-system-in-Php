<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Permessi';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'La pagina speciale non è ancora stata definita: <tt>%s></tt>';

//	control panel
$langA['general'] = 'Generale';
$langA['attachments'] = 'Attachments';
$langA['account_info'] = 'Account Info';
$langA['error_log'] = 'Log Errori';
$langA['advanced_search'] = 'Ricerca$nbsp;Avanzata';
$langA['configuration'] = 'Configurazione';
$langA['search_options'] = 'Opzioni di ricerca';
$langA['data_types'] = 'Tipi di Dato';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Contenuto dinamico';

$langA['tabs'] = 'Schede';
$langA['account_display'] = 'Account Display';
$langA['links'] = 'Link alle immagini';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = 'Statistiche Utenti';
$langA['database_info'] = 'Informazioni&nbsp;Database';
$langA['user_preferences'] = 'Preferenza Utente';
$langA['content_license'] = 'Licensa&nbsp;Contenuto';
$langA['user_permissions'] = 'Permessi Utenti';
$langA['default_page_options'] = 'Opzioni&nbsp;Pagina&nbsp;di Default';
$langA['account_details'] = 'Dettagli&nbsp;Account';
$langA['manage_images'] = 'Gestisci&nbsp;Immagini';
$langA['manage_files'] = 'Gestisci&nbsp;Files';
$langA['upload_files'] = 'Importa Files';
$langA['public_templates'] = 'Pubblica&nbsp;Template';
$langA['feeds'] = 'Syndication / Feeds';
$langA['recently_modified'] = 'Modificati di Recente';
$langA['recently_posted'] = 'Inviati di Recente';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = 'This is the Control Panel for <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Would you like to see your %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Tema a caso';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'Il percorso del pacchetto di template non è disponibile.';
$langA['themes']['default'] = 'Predefinito';
$langA['themes']['simple'] = 'Semplice';
$langA['themes']['three_columns'] = 'Tree Colonne';
$langA['themes']['floating'] = 'Floating';
$langA['themes']['graphic'] = 'Grafico';

$langA['colors']['colors'] = 'Colors';
$langA['colors']['black'] = 'Nero';
$langA['colors']['blue'] = 'Blu';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Verde';
$langA['colors']['light_blue'] = 'Azzurro';
$langA['colors']['green'] = 'Verde';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Rosso';
$langA['colors']['orange'] = 'Orange';
$langA['colors']['gray'] = 'Griggio';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = 'Naviga Nascosto';
$langA['editor_visible'] = 'Visibile per gli editori';


//	WorkGroup.php
$langA['update_permissions'] = 'Aggiorna Permessi';
$langA['username_or_ip'] = 'Nome Utente o IP';
$langA['status'] = 'Stato';
$langA['workgroup'] = 'Gruppo di Lavoro';
$langA['admin'] = 'Admin';
$langA['full_owner'] = 'Completo / Proprietario';
$langA['ban'] = 'Ban';
$langA['banned'] = 'Bannato';

//	friends.php
$langA['friends'] = 'Amici';
$langA['my_status'] = 'Il mio statuto';


$langA['EX_USERNAMES'] = 'es: <a>BillyJoe</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'You have not specefied any permissions.';
$langA['view_users'] = 'Visualizza di questo utente...';
$langA['change'] = 'Cambia';
$langA['users'] = 'Utenti';

$langA['USER_REMOVED'] = 'L\'utente <tt>%s</tt> è stato rimosso da questo gruppo di lavoro.';
$langA['USER_NOT_REMOVED'] = 'L\'utente <tt>%s</tt> non è stato rimosso correttamente da questo gruppo di lavoro. ';
$langA['ADDED_PERMISSIONS'] = 'Aggiunti i permessi per <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Permessi aggiornati per <tt>%s</tt>';
$langA['NOT_A_USER'] = 'L\'utente <tt>%s</tt>';
$langA['IP_NOT_ADDED'] = 'Impossibile aggiungere/aggiornare i permessi per <tt>%s</tt>';
$langA['ALREADY_OWNER'] = '<b>Attenzione: </b> L\'utente <tt>%s</tt> e\' gia\' il proprietario di questo account.';
$langA['IP_WRONG_LEVEL'] = '<b>Attenzione:</b> agli indirizzi IP non possono essere dati privilegi maggiori di "gruppo di lavoro".';
$langA['SET_PERMISSIONS'] = 'Per impostare i permessi per %s, seleziona lo stato desiderato e clicca su "Aggiorna Permessi".';


//	specLostPass
$langA['lost_password'] = 'Password Persa';



//	specFileManager
$langA['file_manager'] = 'Gestore di File';
$langA['image_manager'] = 'Gestione Immagini';
$langA['CONFIRM_FILE_DELETE'] = 'Sei sicuro di voler cancellare <b>%s</b>?';
$langA['IMAGE_MANAGER_INTRO'] = 'Puoi usare la sintassi wiki o html per includere questi file immagine nelle tue pagine. Per alcuni tipi di file(template, mappe...) e\' consigliata la sintassi html.';
$langA['FILE_MANAGER_INTRO'] = 'Per inserire questi file nelle tue pagine, puoi usare la sintassi wiki o html. Si raccomanda l\'uso della sintassi html per inserire file tipo templates o mappe.';
$langA['file_name'] = 'Nome File';
$langA['available_space'] = 'Spazio Disponibile';
$langA['UPLOAD_INTRO'] = 'Importa attachments e immagini da includere nelle tue pagine.';
$langA['file_upload'] = 'Carica File';
$langA['file_info'] = 'Informazioni File';
$langA['width'] = 'Larghezza';
$langA['height'] = 'Altezza';
$langA['file_location'] = 'Posizione File';
$langA['wiki_syntax'] = 'Sintassi Wiki';
$langA['html_syntax'] = 'Sintassi HTML';
$langA['append_to'] = 'Aggiungi a';
$langA['count'] = 'Totale';
$langA['total_size'] = 'Dimensione Totale';
$langA['images'] = 'Immagini';
$langA['overwrite_existing'] = 'Sovrascrivo l\'esistente';
$langA['compression'] = 'Compression';

$langA['NOT_AN_IMAGE'] = 'Immagine non riconosciuta. Verifica il file e riprova. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'Impossibile cancellare il file <tt>%s</i>.';
$langA['UPLOADED'] = 'Il file <tt>%s</tt> e\' stato caricato con successo.';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = 'Il file è stato rinominato con successo.';
$langA['UPLOAD_FAILED'] = 'Impossibile copiare il file: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Seleziona un tipo di file:';
$langA['default_options'] = 'Opzioni di Default';
$langA['UNKNOWN_FILE_TYPE'] = 'Tipo di pagina sconosciuta: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Account';
$langA['entries'] = 'Entrate';
$langA['average'] = 'Media';
$langA['uploaded_files'] = 'File Caricati';


//	searchTrash
$langA['deleted'] = 'Cancellato';
$langA['restore'] = 'Ripristina';
$langA['empty_trash'] = 'Empty Trash';
$langA['CONFIRM_EMPTY_TRASH'] = 'Are you sure you want to empty your trash?';

$langA['DELETED_AFTER_30'] = 'I file verranno cancellati automaticamente dopo 30 giorni.';
$langA['check_uncheck'] = 'Seleziona tutti/Deseleziona tutto';
$langA['DELETED_FILES'] = 'I file selezionati sono stati cancellati correttamente.';
$langA['NOTHING_DELETED'] = 'Non e\' stato cancellato nulla.';
$langA['DELETE_FILES'] = 'Perfavore seleziona i file da cancellare.';
$langA['MAP_INVALID_PT'] = 'Mappa Dati non Valida: Formato Punti non valido.';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'La funzione ricerca non sembra essere attivata per questo sito. L\'amministratore del sito puo\' attivare questa opzione dalle opzioni ricerca nel pannello di controllo.';
$langA['search:'] = 'Cerca: ';
$langA['search_for'] = 'Cerca Per: ';
$langA['registered'] = 'Registrato';
$langA['restricted'] = 'Ristretto';
$langA['locked'] = 'Bloccato';
$langA['disabled'] = 'Disattivo';
$langA['editing_option'] = 'Opzioni di Modifica';
$langA['comments_option'] = 'Opzioni Commenti';
$langA['visibility_option'] = 'Opzioni Visibilita\'';
$langA['normal'] = 'Normale';
$langA['advanced'] = 'Avanzato';
$langA['relevance'] = 'Rilevanza';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'Per tutte le parole';
$langA['SEARCH_EXACT'] = 'Per la frase esatta';
$langA['SEARCH_WITHOUT'] = 'Senza parole';
$langA['SEARCH_BEGIN'] = 'Per le paroche che cominciano con';


//	searchKeywords
$langA['keyword_search'] = 'Ricerca parole chiave';
$langA['non_tagged_files'] = 'File senza Tag';

//	searchChangeLog
$langA['new'] = 								'Nuovo';
$langA['DIFF_TITLE'] = 							'Confronta differenze con la versione piu\' recente';
$langA['indicates_syntax_error'] = 				'Indicates a syntax error.';
$langA['indicates_unchecked'] = 				'Indicates an unchecked file.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Seleziona una licensa';
$langA['SELECT_LICENSE_DESC'] = 'Apri un pagina web Creative Commons in una finestra popup.';
$langA['DELETE_LICENSE_DESC'] = 'Questo rimuovera; la tua attuale licensa del contenuto.';
$langA['LICENSE_UPDATED'] = 'La tua licenza del contenuto e\' stata aggiornata correttamente.';
$langA['LICENSE_DELETED'] = 'La licenza e\' stata cancellata.';
$langA['LICENSE_DELETED2'] = 'La licenza e\' gia\' stata cancellata.';
$langA['customize_license'] = 'Personalizza la tua licenza.';

$langA['text_before'] = 'Testo prima del link';
$langA['text_after'] = 'Testo dopo il Link';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'A parte quando specificato esplicitamente, questo lavoro e\' distribuito sotto licenza ';
$langA['LICENSE_TEXT_LINK'] = 'Licenza Creative Commons';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganizza';
$langA['from'] = 'Da';
$langA['to'] = 'A';
$langA['KEYWORDS_UPDATED'] = 'Your keywords have been updated.';
$langA['KEYWORDS_EMPTY'] = 'You have not created any files with keywords yet.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = 'Descrizione';
$langA['add_link'] = 'Add Link';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Group';
$langA['name'] = 'Nome';
$langA['add_group'] = 'Aggiungi gruppo';
$langA['add_page'] = 'Aggiungi pagina';

$langA['limit'] = 'Limit';
$langA['random'] = 'A caso';
$langA['order'] = 'Ordine';
$langA['LEAVE_EMPTY'] = 'Lascia vuoto per nelimitato';
$langA['unlimited'] = 'Illimitato';
$langA['type'] = 'Tipo';
$langA['auto_detect'] = 'Auto Detect';
$langA['bookmarklet'] = 'Segnalibro';
$langA['move_up'] = 'Move Up';
$langA['move_down'] = 'Move Down';
$langA['redirect'] = 'Ridireziona';
$langA['content_template'] = 'Content Template';

