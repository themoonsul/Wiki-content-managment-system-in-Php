<?php

//	toolOptions.php
$langA['properties'] = 'Özellikler';
$langA['file_name'] = 'Dosya Adı';
$langA['update_from'] = 'Şuradan güncelle:';
$langA['COPY_SYSTEM_FILES'] = '%s den en yeni yardım dosyalarını kopyala.';

$langA['EDITING_OPTIONS'] = 'Kime bu sayfayı düzenleme hakkı verildiðini ayarla.';
$langA['registered_users'] = 'Kayıtlı Kullanıcılar';
$langA['restricted_to'] = 'Şuna Özel: ';
$langA['admin_only'] = 'Sadece Yönetici';
$langA['editor_visible'] = 'Editörlere Görünür';
$langA['owner_only'] = 'Sadece Sahibi';
$langA['use_captcha'] = 'Captcha Kullan';
		

$langA['visibility'] = 'Görünürlük';
$langA['VISIBILITY_OPTIONS'] = 'Eğer bu dosyayı dünyaya göstermeye hazır değilseniz saklayabilirsiniz.';
$langA['visible'] = 'Görünür';

$langA['COMMENT_OPTIONS'] = 'Bu dosya için yorumları devre dışı bırak.';
$langA['enabled'] = 'Açık';
$langA['disabled'] = 'Devre Dışı';
$langA['RECENT_COMMENTS'] = 'Son yorumları göster.';

$langA['anti_spam'] = 'İstenmeyen Posta Engelleme';
$langA['nofollow'] = 'Takipyok';

$langA['other'] = 'Diğer';
$langA['related_links'] = 'İlgili Bağlantılar';
$langA['unblog'] = 'Blogdan sil';
$langA['repost'] = 'Tekrar Gönder';
$langA['copy_to'] = 'Şuraya Kopyala...';
$langA['send_to_trash'] = 'Çöpe At';
$langA['default_options'] = 'Varsayılan Seçenekler';
$langA['restore_defaults'] = 'Varsayılanları Geri Yükle';
$langA['SET_DEFAULT_OPTIONS'] = 'Bu dosya tipi için %s ayarla.'; //replaced with link
$langA['add_to_tabs'] = 'Sekmelere Ekle';
$langA['add_to_links'] = 'Bağlantılara Ekle';

$langA['REPOSTED'] = 'Bu dosya tekrar gönderildi.';
$langA['NOT_REPOSTED'] = '<b>Hata:</b> Bu dosya tekrar gönderilemedi.';
$langA['OPTIONS_NOT_CHANGED'] = 'Dosya seçenekleri değiştirilmedi.';
$langA['OPTIONS_UPDATED'] = 'Dosya seçenekleri başarıyla güncellendi.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Dikkat:</b>Dosya ayarları güncellenmedi.';

$langA['redirect'] = 'Yönlendir';
$langA['REMOVE_REDIRECT'] = 'Artık bu dosyanın yönlendirilmesini istemiyorsanız, dosyayı silebilir ya da düzenleyebilirsiniz. ';


$langA['UNCHECKED_REMOVED'] = 'Bu dosyadan "Kontrol Edilmedi" işareti kaldırıldı.';

$langA['NO_KEYWORDS'] = 'Bu dosya için anahtar kelimeler ayarlanmadı. <a %s> e ilk anahtar kelimeleri eklemek</a> yada <a %s>şimdi blog yapmak ister misiniz </a>?';

$langA['file_id'] = 'Dosya No';

//watch
$langA['WATCH_UPDATED'] = '<a %s>İzleme listeniz</a> güncellendi.';


$langA['user_permissions'] = 'Kullanıcı&nbsp;İzinleri';
