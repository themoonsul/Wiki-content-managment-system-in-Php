<?php
$langA['ILLEGAL_USERNAME'] = 'Kullanıcı Adı, bu karekterleri içeremez: %s';
$langA['LONG_USERNAME'] = 'Kullanıcı Adı çok uzun.';	
$langA['SHORT_USERNAME'] = 'Kullanıcı Adı çok kısa.';
$langA['USER_TAKEN'] = 'Lütfen farklı bir Kullanıcı Adı seçin. <tt>%s</tt> alınmış. ';
$langA['USERNAME_ALL_DIGITS'] = 'Kullanıcı Adı tamamen rakamlardan oluşamaz.';
$langA['PASSWORDS_DIFFERENT'] = 'Parolalar uyuşmadı.';
$langA['SHORT_PASSWORD'] = 'Parola çok kısa.';
$langA['EMAIL_REQUIRED'] = 'Lütfen geçerli bir e-posta adresi yazın.';


$langA['register'] = 'Kayıt';
$langA['welcome_to'] = 'Buraya Hoşgeldin: ';
$langA['REG_USERNAME'] = '3-20 karekter arasında özgün bir kimlk no (ID).';
$langA['REG_PASSWORD'] = 'En az 5 karakter uzunluğunda olmalı.';
$langA['confirm_password'] = 'Şifreyi Onayla';
$langA['REG_CONFIRM_PASS'] = 'Üsttekiyle aynı olmalı.';
$langA['REG_EMAIL'] = 'Opsiyonel. Parolanızı unutursanız işinize yarayacaktır.';
$langA['REQUIRED_FIELD'] = 'Gerekli bir alan olduğunu belirtir.';

$langA['REGISTRATION_TEXT'] = 'Kayıt hızlı ve ücretsizdir, ayrıca birçok avantaj sağlar...';
$langA['REG_A_USER_PAGE'] = '/KullanıcıAdı/Sayfalarınız';
$langA['REG_A_MAP_PAGE'] = '/Map/KullanıcıAdı/Haritalarınız';

//login
$langA['LOGGED_IN'] = '<tt>%s</tt> olarak giriş yaptınız.';
$langA['WRONG_USERNAME'] = 'Sağlanan kullanıcı adı mevcut değil: <tt>%s</tt>';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Başarılı! Hesabınızı etkinleştirmek için, %s adresine gönderilen aktivasyon bağlantısına tıklayınız.';
$langA['ACTIVATE_ACCOUNT'] = 'Hesabınızı şimdi etkinleştirin.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Hesabınız etkinleştirildi.';
$langA['INVALID_CODE'] = 'Verilen onay kodu artık geçerli değil.';
