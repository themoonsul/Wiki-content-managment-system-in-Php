<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'Dosya adı değişmedi.';
$langA['NOT_RENAMED'] = 'Bu dosyanın adı <tt>%s</tt> olarak değiştirilemedi. Lütfen böyle bir dosyanın zaten varolmadığından emin olun.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'Bu dosya yeniden adlandırılamıyor.';
$langA['redirected_to'] = 'Şuraya yönlendirildi:';
$langA['RENAMED'] = 'Bu dosya başarıyla yeniden adlandırıldı.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b> geri yüklendi. ';
$langA['ERROR_RESTORING'] = '<b>Hata:</b> <tt>%s</tt>\'deki dosya geri yüklenemedi.';
$langA['ALREADY_RESTORED'] = 'Bu dosya zaten geri yüklenmiş.';
$langA['WAS_DELETED'] = '<b>%s</b> silindi. Bu dosya %s adresinde 30 gün saklanacak.';
$langA['ERROR_DELETING'] = '<b>Hata:</b> <tt>%s</tt> daki dosya silinemedi.';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> silindi.';
