<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'İzinler';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'Bu özel sayfa henüz tanımlanmamış: <tt>%s</tt>';

//	control panel
$langA['general'] = 'Genel';
$langA['attachments'] = 'Eklentiler';
$langA['account_info'] = 'Hesap Bilgisi';
$langA['error_log'] = 'Hata Günlüğü';
$langA['advanced_search'] = 'Gelişmiş&nbsp;Arama';
$langA['configuration'] = 'Site Ayarları';
$langA['search_options'] = 'Arama Seçenekleri';
$langA['data_types'] = 'Veri Türleri';
$langA['plugins'] = 'Eklentiler';
$langA['dynamic_content'] = 'Dinamik İçerik';

$langA['tabs'] = 'Sekmeler';
$langA['account_display'] = 'Hesap Görünümü';
$langA['links'] = 'Bağlar';
$langA['go_to'] = '%s\'e git.';


$langA['user_statistics'] = 'Kullanıcı İstatistikleri';
$langA['database_info'] = 'Veri Tabanı&nbsp;Bilgisi';
$langA['user_preferences'] = 'Kullanıcı Tercihleri';
$langA['content_license'] = 'İçerik&nbsp;Lisansı';
$langA['user_permissions'] = 'Kullanıcı İzinleri';
$langA['default_page_options'] = 'Varsayılan&nbsp;Sayfa&nbsp;Seçenekleri';
$langA['account_details'] = 'Hesap&nbsp;Detayları';
$langA['manage_images'] = 'Yönet&nbsp;Resimler';
$langA['manage_files'] = 'Dosyaları&nbsp;Yönet';
$langA['upload_files'] = 'Dosya Yükle';
$langA['public_templates'] = 'Genel&nbsp;Şablonlar';
$langA['feeds'] = 'Sendikasyon/Beslemeler';
$langA['recently_modified'] = 'Yeni Değiştirildi';
$langA['recently_posted'] = 'Yeni Gönderildi';
$langA['user_edits'] = 'Kullanıcı Değişiklikleri';

$langA['CONTROL_PANEL_1'] = '<tt>%s</tt> için Kontrol Paneli.';
$langA['CONTROL_PANEL_2'] = '%s ni görmek ister misin?';

//specTemplates
$langA['pTemplate'] = 'Paket Temalar';
$langA['custom_theme'] = 'Özel Tema';
$langA['current_theme'] = 'Geçerli Tema';
$langA['TEMPLATES_UNAVAILABLE'] = 'Paket Şablonları dizini kullanılabilir değil.';
$langA['themes']['default'] = 'orijinal';
$langA['themes']['simple'] = 'Basit';
$langA['themes']['three_columns'] = 'Üç Sütun';
$langA['themes']['floating'] = 'Değişken';
$langA['themes']['graphic'] = 'Grafik';

$langA['colors']['colors'] = 'Renkler';
$langA['colors']['black'] = 'Siyah';
$langA['colors']['blue'] = 'Mavi';
$langA['colors']['blue-green'] = 'Çamurcun';
$langA['colors']['brown'] = 'Kahverengi';
$langA['colors']['green'] = 'Yeşil';
$langA['colors']['light_blue'] = 'Açık Mavi';
$langA['colors']['green'] = 'Yeşil';
$langA['colors']['tan'] = 'Bronz';
$langA['colors']['red'] = 'Kırmızı';
$langA['colors']['orange'] = 'Portakal';
$langA['colors']['gray'] = 'Gri';


$langA['customize_this_theme'] = 'Bu Temayı Özelleştir';



//searchHidden.php
$langA['browse_hidden'] = 'Gizli Gezin';
$langA['editor_visible'] = 'Editörlere Görünür';


//	WorkGroup.php
$langA['update_permissions'] = 'İzinleri Güncelle';
$langA['username_or_ip'] = 'Kullanıcı Adı yada IP';
$langA['status'] = 'Durum';
$langA['workgroup'] = 'Çalışma Grubu';
$langA['admin'] = 'Yönetici';
$langA['full_owner'] = 'Tam / Sahip';
$langA['ban'] = 'Yasakla';
$langA['banned'] = 'Banlandı';

//	friends.php
$langA['friends'] = 'Arkadaşlar';
$langA['my_status'] = 'Durumum';


$langA['EX_USERNAMES'] = 'örn: <a>MuhammetKara</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'Herhangi bir özel yetkiyi sahip değilsin.';
$langA['view_users'] = 'Göster: Kullanıcı\'nın...';
$langA['change'] = 'Değiştir';
$langA['users'] = 'Kullanıcılar';

$langA['USER_REMOVED'] = '<tt>%s</tt> kullanıcısı bu çalışma grubundan çıkarıldı.';
$langA['USER_NOT_REMOVED'] = '<tt>%s</tt> kullanıcısı bu çalışma grubundan başarıyla çıkarılamadı. ';
$langA['ADDED_PERMISSIONS'] = '<tt>%s</tt> için izinler eklendi.';
$langA['UPDATED_PERMISSIONS'] = '<tt>%s</tt> için izinler güncellendi.';
$langA['NOT_A_USER'] = '<tt>%s</tt> kullanıcı adı bulunamadı.';
$langA['IP_NOT_ADDED'] = '<tt>%s</tt> için izinler eklenemedi/güncellenemedi.';
$langA['ALREADY_OWNER'] = '<b>Uyarı:</b> <tt>%s</tt> kullanıcısı zaten bu hesabın sahibi.';
$langA['IP_WRONG_LEVEL'] = '<b>Uyarı:</b> IP adreslerine "çalışma grubu"ndan daha yüksek haklar verilemez.';
$langA['SET_PERMISSIONS'] = '%s" için izinleri ayarlamak için, arzu edilen durumu seçin ve "İzinleri Güncelle"ye tıklayın.';


//	specLostPass
$langA['lost_password'] = 'Kayıp Parola';



//	specFileManager
$langA['file_manager'] = 'Dosya Yöneticisi';
$langA['image_manager'] = 'Resim Yöneticisi';
$langA['CONFIRM_FILE_DELETE'] = '<b>%s</b>i silmek istediğinize emin misiniz?';
$langA['IMAGE_MANAGER_INTRO'] = 'Bu resimleri sayfalarınıza eklemek için wiki sözdizimi ya da html kullanabilirsiniz. Bazı dosya türleri için (şablonlar, haritalar...) html sözdizimini kullanmanızı tavsiye ederiz.';
$langA['FILE_MANAGER_INTRO'] = 'Bu resimleri sayfalarınıza yerleştirmek için wiki söz dizimi yada html kullanabilirsiniz. Belli dosya tipleri için (şablonlar, mapler..) html söz dizimi kullanmanızı öneririz.';
$langA['file_name'] = 'Dosya Adı';
$langA['available_space'] = 'Kullanılabilir Alan';
$langA['UPLOAD_INTRO'] = 'Sayfalarda yer alması için resimler yükleyin.';
$langA['file_upload'] = 'Dosya Yükle';
$langA['file_info'] = 'Dosya Bilgisi';
$langA['width'] = 'Genişlik';
$langA['height'] = 'Yükseklik';
$langA['file_location'] = 'Dosya Konumu';
$langA['wiki_syntax'] = 'Wiki Sözdizimi';
$langA['html_syntax'] = 'HTML Sözdizimi';
$langA['append_to'] = 'şuna ekle:';
$langA['count'] = 'Adet';
$langA['total_size'] = 'Toplam Boyut';
$langA['images'] = 'Resimler';
$langA['overwrite_existing'] = 'Varolanın Üstüne Yaz';
$langA['compression'] = 'Sıkıştırma';

$langA['NOT_AN_IMAGE'] = 'Dosya bir resimmiş gibi görünmüyor. Lütfen dosyayı kontrol ettikten sonra tekrar deneyin. (%s): ';
$langA['IMAGE_NOT_DELETED'] = '<tt>%s</i> dosyası silinemedi.';
$langA['UPLOADED'] = '<tt>%s</tt> dosyası başarıyla yüklendi.';
$langA['UPLOADED_RENAMED'] = '<tt>%s</tt> dosyası <tt>%s</tt> olarak eklendi. <a %s>Adını %s olarak değiştirebilirsiniz</a>.';
$langA['RENAMED'] = 'Bu dosya başarıyla yeniden adlandırıldı.';
$langA['UPLOAD_FAILED'] = 'Dosya kopyalanamadı: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = '<tt>%s</tt> dosyası sunucuya yüklenemiyor. <br/>Dosyalar <tt>%s</tt> byte\'tan daha küçük olmalıdır.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> sadece kısmi olarak yüklenmiş. Lütfen tekrar deneyin.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Bir Dosya Tipi Seçin:';
$langA['default_options'] = 'Varsayılan Seçenekler';
$langA['UNKNOWN_FILE_TYPE'] = 'Bilinmeyen Dosya Tipi: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Hesap';
$langA['entries'] = 'Girdiler';
$langA['average'] = 'Ortalama';
$langA['uploaded_files'] = 'Dosya Yükle';


//	searchTrash
$langA['deleted'] = 'Silindi';
$langA['restore'] = 'Geri Yükle';
$langA['empty_trash'] = 'Çöp kutusunu boşalt';
$langA['CONFIRM_EMPTY_TRASH'] = 'Çöp kutusunu boşaltmak istediğinizden emin misiniz?';

$langA['DELETED_AFTER_30'] = 'Dosyalar 30 gün sonra otomatik olarak silinecektir.';
$langA['check_uncheck'] = 'Tümünü İşaretle / Tümünün İşaretini Kaldır';
$langA['DELETED_FILES'] = 'Seçilen dosyalar başarıyla silindi.';
$langA['NOTHING_DELETED'] = 'Hiçbirşey silinmedi.';
$langA['DELETE_FILES'] = 'Lütfen silinecek dosyaları seçin.';
$langA['MAP_INVALID_PT'] = 'Geçersiz Map Verisi: Geçersiz Nokta Biçimi';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'Bu site için arama özelliği açılmış gibi görünmüyor. Site yöneticileri bu özelliği Kontrol Panelindeki Arama Seçenekleri üzerinden açabilirler.';
$langA['search:'] = 'Ara: ';
$langA['search_for'] = 'Şunu Ara: ';
$langA['registered'] = 'Kayıtlı';
$langA['restricted'] = 'Kısıtlı';
$langA['locked'] = 'Kilitli';
$langA['disabled'] = 'Devre Dışı';
$langA['editing_option'] = 'Düzenleme Seçeneği';
$langA['comments_option'] = 'Yorum Seçeneği';
$langA['visibility_option'] = 'Görünürlük Seçeneği';
$langA['normal'] = 'Normal';
$langA['advanced'] = 'Gelişmiş';
$langA['relevance'] = 'İlişki';
$langA['SEARCH_ONE'] = 'Kelimelerden en az biri için';
$langA['SEARCH_ALL'] = 'Tüm kelimeler için';
$langA['SEARCH_EXACT'] = 'Tam ifade için';
$langA['SEARCH_WITHOUT'] = 'Kelimeleri olmaksızın';
$langA['SEARCH_BEGIN'] = 'Şununla başlayan kelimeler:';


//	searchKeywords
$langA['keyword_search'] = 'Anahtar Kelime Araması';
$langA['non_tagged_files'] = 'Taglanmamış Dosyalar';

//	searchChangeLog
$langA['new'] = 								'Yeni';
$langA['DIFF_TITLE'] = 							'En son revizyonla farkları karşılaştır';
$langA['indicates_syntax_error'] = 				'Bir sözdizimi hatası gösteriliyor.';
$langA['indicates_unchecked'] = 				'Kontrol edilemeyen bir dosya gösteriliyor.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Bir Lisans Seçin';
$langA['SELECT_LICENSE_DESC'] = 'Bir açılır pencerede Creative Commons web sayfasını açar.';
$langA['DELETE_LICENSE_DESC'] = 'Bu, mevcut içerik lisansınızı silecektir.';
$langA['LICENSE_UPDATED'] = 'İçerik lisansınız başarıyla güncellendi.';
$langA['LICENSE_DELETED'] = 'Lisans silindi';
$langA['LICENSE_DELETED2'] = 'Lisans zaten silinmiş.';
$langA['customize_license'] = 'Lisansınızı Özelleştirin';

$langA['text_before'] = 'Bağdan Önceki Metin';
$langA['text_after'] = 'Bağdan Sonraki Metin';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Aksinin belirtildiği yerler dışında, bu çalışma için geçerli lisans: ';
$langA['LICENSE_TEXT_LINK'] = 'Creative Commons License';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'Değişikliklerim';

//reorganize
$langA['reorganize'] = 'Yeniden Düzenle';
$langA['from'] = 'Kimden';
$langA['to'] = 'Kime';
$langA['KEYWORDS_UPDATED'] = 'Anahtar Kelimeler güncellendi.';
$langA['KEYWORDS_EMPTY'] = 'Anahtar Kelimelerle henüz hiç bir dosya oluşturmadınız.';
$langA['REORGANIZE'] = 'Burada, kullanmış olduğunuz anahtar kelimeleri yeniden adlandırarak dosyalarınızı yeniden yapılandırabilirsiniz.';

//watch
$langA['WATCH_UPDATED'] = '<a %s>İzleme listeniz</a> güncellendi.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Etiket';
$langA['description'] = 'Tanım';
$langA['add_link'] = 'Bağ Ekle';
$langA['link_groups'] = 'Bağ Grupları';
$langA['group'] = 'Grup';
$langA['name'] = 'Ad';
$langA['add_group'] = 'Grup Ekle';
$langA['add_page'] = 'Sayfa Ekle';

$langA['limit'] = 'Limit';
$langA['random'] = 'Rasgele';
$langA['order'] = 'Sıralama';
$langA['LEAVE_EMPTY'] = 'Limitsiz olması için boş bırakın';
$langA['unlimited'] = 'Sınırsız';
$langA['type'] = 'Tür';
$langA['auto_detect'] = 'Otomatik Algıla';
$langA['bookmarklet'] = 'Yerimi';
$langA['move_up'] = 'Yukarı Taşı';
$langA['move_down'] = 'Aşağı Taşı';
$langA['redirect'] = 'Yönlendir';
$langA['content_template'] = 'İçerik Şablonu';

