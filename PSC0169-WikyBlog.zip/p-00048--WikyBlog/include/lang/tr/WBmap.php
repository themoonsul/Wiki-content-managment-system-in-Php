<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'Map Yükleniyor...';
$langA['MAP_DEBUG_O'] = 'Bu sayfa yüklenirken bir hata oluştu ve istediğiniz map gösterilemedi.<p> </p>Hatanın bir günlüğü oluşturuldu ve web site yöneticileri bu sorunu kısa sürede çözecektir.';
$langA['MAP_DEBUG_1'] = 'Google Maps API, tarayıcınızla uyumluymuş gibi görünmüyor.<p>Eğer tarayıcınızın uyumlu olduğundan biliyorsanız, doğru harita anahtarının kulanıldığından ve internete bağlı olduğunuzdan emin olun.</p><p>Tarayıcı desteğiyle ilgili <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">daha fazla bilgiye google.com\'dan ulaşabilirsiniz.</a></p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>Dikkat:</b> Haritalar JavaScript e ihtiyaç duyar.</p><p>Web Tarayıcında JavaScript aktif görünmüyor. Bu haritayı görebilmek için lütfen, bu sayfayı yeniledikten sonra JavaScripti aktif yapınız.</p>';