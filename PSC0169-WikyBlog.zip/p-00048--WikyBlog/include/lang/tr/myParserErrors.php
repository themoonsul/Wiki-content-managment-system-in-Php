<?php

$langA['end_of_document'] = ' --- Belgenin Sonu -- ';
$langA['syntax_warning'] = ' Sözdizimi Uyarısı: ';

$langA['XML_ERROR_INVALID_TOKEN'] = '%s satırındaki %s pozisyonunda hata oluştu fakat daha önceki satırlardan kaynaklanıyor olabilir.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>random &lt;text</tt> instead of <tt>random &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> instead of <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> instead of <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = 'Bu belgenin tamamlanması için kapatıcı HTML imlerine ihtiyaç duyuluyor:"<em>%s</em>".';

$langA['unnecessary_closing_tag'] = 'Gereksiz tag kapamak.';
$langA['should_be'] = ' basitçe şöyle olmalı: ';

$langA['CLOSING_AN_UNOPENED_TAG'] = 'Açılmamaış bir tagı kapatmak.<br /> Bu kapanış tagı için bir açılış tagı yok: <tt>&lt;/%s&gt;</tt>.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>&lt;/tag&gt;</tt> without <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> instead of <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Kapatma tagı eksik. <br /> <tt>&lt;%s&gt;</tt> tagı <tt>%s</tt> kullanılarak kapatılmalıdır. ';
$langA['MISSING_CLOSING_TAG2'] = ' şu kapanış tagından önce: <tt>&lt;/%s&gt;</tt>.';

$langA['AUTOMATED_SYNTAX_ERROR'] = 'Otomatik Sözdizim Hatası:';
$langA['AUTOMATED_SYNTAX_ERROR2'] = '(%s) %s satırında (%s satırdan) %s pozisyonunda ';
$langA['last_open_tag'] = '<br />Son Açık Tag ';
