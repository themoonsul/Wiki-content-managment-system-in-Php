<?php

$langA['lost_page'] = 'Kayıp Sayfa';
$langA['PAGE_NOT_FOUND'] = 'İstenen sayfa <tt>%s</tt> bulunamadı.';
$langA['REGISER_AS_USER'] = '<tt>%s</tt> adında bir kullanıcı hesabı oluşturulmamış gibi görünüyor. Bu kullanıcı adıyla %s mak ister misiniz?';
$langA['LINK_TYPO'] = ' Geldiğiniz sayfada bir bağ hatası olup olmadığını kontrol edin: ';
$langA['REGISTER_TO_CREATE'] = 'Bu sayfayı önce <tt>%s</tt> kullanıcı adıyla kaydolarak oluştur.';