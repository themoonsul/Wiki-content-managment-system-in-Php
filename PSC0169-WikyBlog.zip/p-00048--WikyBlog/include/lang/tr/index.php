<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Dosya';
$langA['edit'] = 'Düzenle';
$langA['edits'] = 'Değişiklikler';
$langA['view_source'] = 'Kaynağı Göster';
$langA['talk'] = 'Konuş';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Geçmiş';
$langA['diff'] = 'Fark';
$langA['watch'] = 'İzle';
$langA['unwatch'] = 'İzleme';
$langA['options'] = 'Seçenekler';


$langA['messages'] = 'Mesajlar';
$langA['current'] = 'Güncel';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Mümkün';

$langA['DEFAULT_CONTENT'] = 'Bu yeni bir dosya, would you like to [[%s?cmd=edit|create it]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Bu yeni bir dosya. Bu dosyayı oluþturmak için, uygun haklarla giriş yapmış olmalısınız.';

$langA['NOT_OWNER'] = 'Bu özellik için uygun haklara sahip değilsiniz.';
$langA['LONG_PATH'] = 'Bu dosyanın başlığı çok uzun olduğu için kısaltıldı.';
$langA['EMPTY_CONTENT'] = 'İçerik, gerekli bir alan';
$langA['INCOMPLETE_PATH'] = 'Sağlanan yol eksik.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Üzgünüm, web site yöneticisi kullanıcı günlüklemesini kapatmış. Burada bulunan özelliklere sahip bir bliki oluşturmak için <a href="http://www.wikyblog.com">WikyBlog.com</a>\'u ziyaret edin.';
$langA['TITLE_EXISTS'] = 'Böyle bir başlık zaten var, lütfen farklı bir tane seçin ve sonra tekrar kaydedin.';

$langA['HIDDEN_FILE'] = 'Bu dosyaya erişim sahibi tarafından kısıtlanmıştır. Bu dosyayı görüntülemek için uygun haklarınız olmalıdır.';
$langA['HIDDEN_FILE2'] = 'Bu dosya "gizli". ';
$langA['DELETED_FILE'] = 'Bu dosya şuanda "çöp"te. Eğer bu hesabın sahibiyseniz, bu dosyayı kontrol panelini kullanarak geri yükleyebilirsiniz.';
$langA['PROTECTED_FILE'] = 'Bu dosya korunuyor. Bu dosyaya yapılan değişikliklerin hiçbiri kaydedilmedi.';
$langA['INVALID_THEME'] = 'Tercihlerde belirtilen tema adı geçersiz. Varsayılan tema kullanılıyor.';
$langA['link_text'] = 'Bağ Metni';
$langA['SURPASSED_MAX'] = '<b>Dikkat:</b> Disk kullanımı izin verilen miktarı aştı. Bu dosyada yapılan değişiklikler kaydedilemedi.';


$langA['REDIRECTED'] = '%s\'den yeniden yönlendirildi.';
$langA['REDIRECT_TO'] = 'Sayfa %s\'e yönlendirilmiş.';

//	Data Types
$langA['all'] = 'Tümü';
$langA['page'] = 'Sayfa';
$langA['comment'] = 'Yorum';
$langA['map'] = 'Harita';
$langA['template'] = 'Şablon';
$langA['help'] = 'Yardım';
$langA['skeleton'] = 'İskelet';
$langA['attach'] = 'Ekli Dosya';

$langA['theme'] = 'Tema';

$langA['comments'] = 'Yorumlar';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Sayfalar';
$langA['CLASScomment'] = 'Yorumlar';
$langA['CLASSmap'] = 'Haritalar';
$langA['CLASStemplate'] = 'Temalar';
$langA['CLASShelp'] = 'Yardım';
$langA['IS_CONTENT_TEMPLATE'] = 'Bu dosya içerik şablonudur ve blogunuzda gösterilmez.';


$langA['seconds'] = ' saniye';
$langA['queries'] = ' sorgu';

$langA['QUERY_TIME'] = ' sorgular için';
$langA['INVALID_PATH'] = 'Sağlanan dosya yolu geçersiz: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Geçersiz İstek.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'Bu yeni bir tema. Bu temayıi yukardaki "Düzenle" bağlantısına tıklayarak düzenleyin.<br/>Temaları oluştururken gerekli tüm içerik değişkenlerinin bulunmasına dikkat edin.';
$langA['your_theme'] = 'Sizin Temanız';
$langA['CURRENT_THEME'] = 'Şu anda <b>%s</b> temasını kullanıyorsunuz.'; //replaced with template name

$langA['use_this_theme'] = 'Yerine bu temayı kullan';
$langA['using_this_theme'] = 'Şu anda bu temayı kullanıyorsunuz';
$langA['MAKE_THEME'] = 'Bunun bir kopyasını başlangıç olarak kullanarak, kişiselleştirilmiş bir tema yapın.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Düzenleme</h2> Temaları düzenlerken, yaptığınız değişiklikler hemen görünmez.<br />Kaydettikten sonra değişiklikleri görmek için tarayıcınızın "tazele" düğmesini kullanmanız gerekebilir.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'Yazılımın bütünleşmiş kısmı gibi bu dosya merkezi sunucunda saklanmıştır.<br/> %sthis%s nin ve %s de ki yardım dosyalarının içeriğini düzenleyebilirsin.';

$langA['NEW_HELP'] = 'Yeni bir yardım dosyası oluştur.';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Gözat';
$langA['change_log'] = 'Değişiklik Günlüğü';
$langA['control_panel'] = 'Denetim Paneli';
$langA['administration'] = 'Yönetim';
$langA['preferences'] = 'Tercihler';
$langA['watchlist'] = 'İzleme Listesi';
$langA['wanted_files'] = 'Istenen Dosyalar';
$langA['dead_end'] = 'Kırık Dosyalar';
$langA['search'] = 'Ara';
$langA['orphaned_files'] = 'Sahipsiz Dosyalar';
$langA['most_linked'] = 'Dosyalara çoklu bağlantı';
$langA['scrl'] = 'Gelişmiş Kaydırma';
$langA['nWin'] = 'Harici Bağlantılar';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'Daha Yeni Gönderiler.';
$langA['NEED_INTERNET'] = 'Bu özellik sadece internete bağlı sistemler için kullanılabilir durumda.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Uyarı:</b> Devam edebilmek için çerezler gerekli. Eğer çerezleri açtıysanız bu sayfayı tazeleyin.';
$langA['LOGIN_REQUIRED'] = 'Bu özelliği kullanabilmek için giriş yapmalısınız.';

$langA['ENTER_USERNAME'] = 'Lütfen Kullanıcı Adınızı girin.';
$langA['ENTER_PASSWORD'] = 'Lütfen Parolanızı girin.';
$langA['LOGGED_OUT'] = 'Başarıyla çıkış yaptınız.';
$langA['AUTO_LOGOUT'] = 'Oturumunuzun süresi doldu.';

$langA['LOGIN_FAILED'] = 'Giriş başarısız: Yanlış Kullanıcı Adı veya Parola.<ul><li>Caps Lock açık mı?<li> %sParolanızı mı unuttunuz%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'En yüksek giriş denemesi sayısı olan %s aşıldı. Sonraki %s dakika boyunca girişinize izin verilmeyecek.';
						
$langA['create_new'] = 'Yeni&nbsp;Oluştur ';
$langA['remember_me'] = 'Beni Hatırla';
$langA['log_out'] = 'Çıkış';
$langA['log_in'] = 'Giriş';

//	SAVING 
$langA['syntax_error'] = 'sözdizim hatası';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'Bu dosyada istenmeyen bir biçimlemeye yol açabilecek bir <a %s>sözdizim hatası</a> tespit edildi.';

$langA['OTHER_ACCOUNT'] = '%s için dosyalar oluşturmak ister misiniz? (%s yerine)';
$langA['MAKE_ADMIN'] = 'Söz dizimi sınamasını atlamak için <a %s>dosya seçenekleri</a>ni "<tt>Sadece Yönetici</tt>" olarak ayarlayın.';


$langA['THEME_SYNTAX_WARN'] = '<b>Sözdizim Uyarısı:</b> Bu belgede yapılan son değişiklikler uyumsuz sözdizimi sebebiyle Kaydedilemiyor/Gösterilemiyor.';
$langA['SYNTAX_FIXED'] = 'Sözdizim hatası düzeltildi.';


$langA['NO_CHANGES'] = 'Bu dosyada hiçbir değişiklik yapılmadı. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Bu dosya kaydedilemiyor. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Bu dosyada yapılan değişiklikler kaydedildi.';
$langA['HIDDEN_FILE3'] = '<b>Not:</b> Bu gizli bir dosya, yani bu dosyanın tagları kullanıcı menüsü toplamında yer almayacak.';

$langA['VERSION_CONFLICT'] = 'Uyarı: Bir versiyon uyuşmazlığı tespit ettiğimiz için yaptığınız değişiklikleri kaydedemedik.';
$langA['VERSION_CONFLICT_2'] = 	'Uyarı: Bir sürüm uyuşmazlığına rastladığımız için değişikliklerinizi kaydedemedik. Aşağıdaki olaylar bu uyumsuzluğa neden olmuş olabilir. <ul><li>Var olan bir dosyanın üzerine yazmaya çalışıyor olabilirsiniz.</li> <li>Oturumunuz zaman aşımına uğramış olabilir.</li> <li>Bir başkası bu dosyada değişiklik yapmış olabilir.</li></ul>';

$langA['COPY_TO'] = '<b>%s</b>\'i &nbsp; <b>%s</b>\'e &nbsp; kopyalayın.<br/>Kopyalamayı sonlandırmak için "Kaydet"e tıklayın.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Düzenleme, %s saniyede bir taneyle sınırlandırılmış. Lütfen %s saniye içinde tekrar deneyin.';
$langA['INCORRECT_CAPTCHA'] = 'Güvenlik kodu uyuşmuyor. Lütfen tekrar deneyin';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Kayıt Seçenekleri';
$langA['blog_this'] = 'Blog Bu';



//	toolHistory2.php
$langA['differences'] = 'farklılık(lar)';
$langA['line_num'] = 'Satır numarası';


//	toolHistory1.php
$langA['revision'] = 'Sürüm ';
$langA['revision_as_of'] = 'Sürüm: ';
$langA['revision_num_as_of'] = 'Sürüm %s : %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Sürümü Düzenle';
$langA['revert_to_revision'] = 'Bu Revizyona Geri Dön';
$langA['reverted_to_rev'] = '# sürüme geri dönüldü';
$langA['SET_USER_PERMISSIONS'] = 'Bu kullanıcı için izinlerinizi ayarlayın: '; 
$langA['compare_with_prev'] = '← Önceki Revizyonla Karşılaştır';
$langA['current_revision'] = 'Güncel Sürüm';
$langA['compare_with_next'] = 'Sonraki Revizyonla Karşılaştır →';
$langA['lines'] = 'Satırlar';
$langA['text'] = 'Metin';
$langA['vs'] = ' \'e karşı ';
$langA['content'] = 'İçerik';
$langA['your_text'] = 'Metniniz';
$langA['show_prev_revision'] = '← Revizyon %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revizyon %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Uyarı:</b> Bu sayfanın en yeni sürümünü düzenlemiyorsunuz.<br /> Kaydetmek, en yeni sürümü bu tarihi-geçmiı sürümle değiştirecek.';
$langA['SELECT_TWO_VERSIONS'] = 'Karşılaştırmak için lütfen iki ayrı sürüm seçin.';
$langA['NO_UNIQUE_REVISION'] = 'Bu sorgu için özgün bir revizyon bulunamadı.';
$langA['INVALID_REVISION'] = '<b>Hata:</b> Geçersiz Revizyon Tarihi';
$langA['NO_DIFFERENCES'] = 'Karşılaştırılan iki revizyon birbirinin aynı.';
$langA['NO_REVISIONS'] = 'Bir karşılaştırmanın yapılabilmesi için öncelikle iki farklı revizyon olması gerekir.';
$langA['NON_EXISTANT'] = 'Henüz böyle bir dosya yok.';

//	toolEditPage.php
$langA['bold_text'] = 'Kalın yazı';
$langA['italic_text'] = 'İtalik yazı';
$langA['headline_text'] = 'Başlık Ekle';
$langA['title'] = 'Başlık';
$langA['unordered_list'] = 'Düzensiz Liste';
$langA['ordered_list'] = 'Düzenli Liste';


$langA['internal_link'] = 'İç Bağ';
$langA['link'] = 'Bağ';
$langA['external_link'] = 'Dış Bağ';
$langA['embed_image'] = 'Resim Göm';
$langA['find_images'] = 'Görüntü Bul';
$langA['image'] = 'Resim';
$langA['nowiki'] = 'wiki yok';
$langA['NOWIKI_TEXT'] = 'Buraya biçimlenmemiş metin girin';
$langA['signature'] = 'İmza';
$langA['SIGNATURE_TEXT'] = 'İmzanızı girin';
$langA['preview'] = 'Önizleme';
$langA['PREVIEW_TEXT'] = 'Değişikliklerinizi önizleyin [%s-p]';
$langA['PREVIEW_WARN'] = 'Bu sadece bir önizlemedir. Yaptığınız değişiklikler henüz kaydedilmedi!';
$langA['SAVE_TEXT'] = 'Değişikliklerinizi kaydedin [%s-s]';
$langA['reset'] = 'Sıfırla';
$langA['RESET_TEXT'] = 'Bu formu orijinal haline döndür [%s-c]';
$langA['changes'] = 'Değişiklikler';
$langA['CHANGES_TEXT'] = 'Bu dosyaya yapmış olduğunuz değişiklikleri gösterin. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Gönderilerinizi virgülle ayrılmış anahtar kelimelerle organize edin'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'İmler';
$langA['edit_summary'] = 'Düzenleme Özeti';
$langA['syntax_warning'] = 'Sözdizim Uyarısı';
$langA['NO_IMAGES'] = 'Hiç Resim Bulunamadı';
$langA['insert_emoticons'] = 'Gülümseme Ekle';
$langA['upload'] = 'Yükle';



//searchHistory
$langA['show'] = 'Göster';
$langA['hide'] = 'Gizle';
$langA['compare'] = 'Karşılaştır';
$langA['timeline'] = 'Zaman çizelgesi';
$langA['summary'] = 'Özet';
$langA['COMPARE_REVISONS'] = 'Seçilen sürümle karşılaştır.';
$langA['unchecked'] = 'İşaretsiz';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Sağlanan Dosya Tipi Geçersiz.';


//	SEARCH
$langA['next'] = 'İleri';
$langA['previous'] = 'Önceki';
$langA['order_by'] = 'Sıralama ölçütü:';
$langA['ascending'] = 'Artan';
$langA['descending'] = 'Azalan';
$langA['search_from'] = 'Şurdan Ara: ';
$langA['all_users'] = 'Tüm Kullanıcılar';
$langA['user'] = 'Kullanıcı';
$langA['from_file_type'] = 'Dosya Tipinden Ara: ';
$langA['read_more'] = 'Devamını Oku';
$langA['words'] = ' kelimeler';

$langA['RESULTS'] = '%s den %s e sonuçlar. Toplam: %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Arama kriteri için hiçbir girdi bulunamadı.';

//searchTalk
$langA['add_comment'] = 'Yorum Ekle';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Uyarı dahil edilemedi. Çifte girdi için yetersiz biçimlenmiş veri.';
$langA['duplicate_entry'] = 'Çift Girdi';
$langA['DUPLICATE_ENTRY'] = 'Bu, %s adresinde bulunan sayfa için bir çifte girdidir. <br/>Burada bulunan ve gereksiz olmayan tüm bilgiler bu sayfa silinmeden önce orijinaline aktarılmalıdır.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Bulunamadı: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Hata:</b><br /> Bu script çalıştırılırken bir hata oluştu.<br /> Lütfen sorgunuzu kontrol edin. Hata günlüğünü kullanarak scriptin hatalarını ayıklamaya çalışacağız. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Varsayılan şablon silinemez.';
$langA['THEME_MISSING_VARS'] = 'Gerekli değişken(ler) eksik: <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'Belirtilen tema geçersiz.';

//
//	CLASSmap
//
$langA['new_marker']='Yeni İm';
$langA['new_route']='Yeni Yol';
$langA['SAVE_HEADER']='Kaydetmeden Önce Hatırla';
$langA['save_map']='Haritayı Kaydet';
$langA['continue_editing']='Düzenlemeye Devam Et';
$langA['miles/km'] = 'mil/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>Bu yeni bir map.</b><br/> Bu mapi oluşturmak/düzenlemek için, yukarıdaki "Düzenle"ye tıklayın.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Üzgünüm, bu mapi düzenlemek için yeterli haklara sahip değilsiniz.';
$langA['play'] = 'Yürüt';
$langA['stop'] = 'Durdur';
$langA['import'] = 'İçe Aktar';
$langA['export'] = 'Dışa Aktar';
$langA['gpx_data'] = 'GPX Verisi';
$langA['gpx_exchange_format'] = 'GPX Takas Biçimi';
$langA['CLICK_EDIT'] = 'Haritayı düzenlemek için lütfen yukarıdaki "düzenle"ye tıklayın.';


//	smileys
$langA['smiles'][':D'] = 'Çok Mutlu';
$langA['smiles'][':)'] = 'Gülümse';
$langA['smiles'][':('] = 'Üzgün';
$langA['smiles'][':o'] = 'Şaşırmış';
$langA['smiles'][':shock:'] = 'Şoke Olmuş';
$langA['smiles'][':?'] = 'Kafası Karışık';
$langA['smiles']['8)'] = 'Havalı';
$langA['smiles'][':lol:'] = 'Kahkaha Atıyor';
$langA['smiles'][':x'] = 'Çılgın';
$langA['smiles'][':P'] = 'Dil Çıkart';
$langA['smiles'][':oops:'] = 'Utanmış';
$langA['smiles'][':cry:'] = 'Ağlıyor veya Çok Üzgün';
$langA['smiles'][':evil:'] = 'Kötü veya Çok Çılgın';
$langA['smiles'][':twisted:'] = 'Kaçık Şeytan';
$langA['smiles'][':roll:'] = 'Gözü Dönmüş';
$langA['smiles'][':wink:'] = 'Göz Kırp';
$langA['smiles'][':!:'] = 'Ünlem';
$langA['smiles'][':?:'] = 'Soru';
$langA['smiles'][':idea:'] = 'Fikir';
$langA['smiles'][':arrow:'] = 'Ok';
$langA['smiles'][':|'] = 'Tarafsız';
$langA['smiles'][':mrgreen:'] = 'Bay Yeşil';

//
//	General Language
//
$langA['or'] = 'yada';
$langA['username'] = 'Kullanıcı Adı';
$langA['password'] = 'Parola';
$langA['email'] = 'E-posta';
$langA['register'] = 'Kayıt';
$langA['cancel'] = 'Vazgeç';
$langA['language'] = 'Dil';
$langA['use'] = 'Kullan';
$langA['copy'] = 'Kopyala';
$langA['rename'] = 'Yeniden Adlandır';

$langA['on'] = 'Açık';
$langA['partial'] = 'Kısmen';
$langA['off'] = 'Kapalı';
$langA['save'] = 'Kaydet';
$langA['save_now'] = 'Şimdi Kaydet';
$langA['undefined'] = 'Tanımsız';
$langA['homepage'] = 'Anasayfa';
$langA['home'] = 'Ev';
$langA['go'] = 'Getir';
$langA['user_menu'] = 'Kullanıcı Menüsü';

$langA['last_modified'] = 'En Son Değiştirildi';
$langA['LAST_MODIFIED'] = 'En son %s tarihinde %s tarafından değiştirildi.';//%s replaced with date and username
$langA['accessed_times'] = '%s kez erişildi';// %s replaced with a number
$langA['modified'] = 'Değiştirildi';
$langA['posted'] = 'Gönderildi';
$langA['created'] = 'Oluşturuldu';
$langA['hidden'] = 'Gizli';
$langA['what_links_here'] = 'Sayfaya bağlantılar';
$langA['share'] = 'Paylaş';
$langA['INVALID_LINK'] = 'Talep edilen sayfa başlığı geçersiz. Bir ya da daha fazla uygunsuz karekter içeriyor olabilir.';
$langA['FILE_MUST_EXIST'] = 'Bu işlemi yapabilmek için dosyayı kaydetmelisiniz.';

$langA['OOPS'] = 'Oops, isteğiniz yerine getirilemedi. Lütfen tekrar deneyin.';


$langA['size'] = 'Boyut ';
$langA['bytes'] = 'byte';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Güncelle';
$langA['editing'] = 'Düzenleme';
$langA['workgroup'] = 'Çalışma Grubu';
$langA['BROWSE_HIDDEN'] = 'Gizli dosyaları bul';

$langA['delete'] = 'Sil';
$langA['confirm_delete'] = 'Silmeyi Onayla';
$langA['continue'] = 'Devam';
$langA['back'] = 'Geri';
$langA['close'] = 'Kapat';
$langA['view'] = 'Göster';
$langA['empty'] = '-boş-';
$langA['none'] = 'Hiç biri';
$langA['total'] = 'Toplam ';
$langA['files'] = 'Dosyalar';
$langA['other'] = 'Diğer';
$langA['trash'] = 'Çöp';
$langA['flagged'] = 'İşaretlendi';

$langA['today'] = 'Bugün';
$langA['yesterday'] = 'Dün';
$langA['days_ago'] = ' gün önce';
$langA['page_contents'] = 'Sayfa İçeriği';
$langA['more'] = 'daha';
$langA['download'] = 'İndir';


//Date
$langA['date_l'][0] = 'Pazar';
$langA['date_l'][1] = 'Pazartesi';
$langA['date_l'][2] = 'Salı';
$langA['date_l'][3] = 'Çarşamba';
$langA['date_l'][4] = 'Perşembe';
$langA['date_l'][5] = 'Cuma';
$langA['date_l'][6] = 'Cumartesi';

$langA['date_D'][0] = 'Paz';
$langA['date_D'][1] = 'Pzts';
$langA['date_D'][2] = 'Salı';
$langA['date_D'][3] = 'Çar';
$langA['date_D'][4] = 'Per';
$langA['date_D'][5] = 'Cuma';
$langA['date_D'][6] = 'Cmts';


$langA['date_F'][1] = 'Ocak';
$langA['date_F'][2] = 'Şubat';
$langA['date_F'][3] = 'Mart';
$langA['date_F'][4] = 'Nisan';
$langA['date_F'][5] = 'Mayıs';
$langA['date_F'][6] = 'Haziran';
$langA['date_F'][7] = 'Temmuz';
$langA['date_F'][8] = 'Ağustos';
$langA['date_F'][9] = 'Eylül';
$langA['date_F'][10] = 'Ekim';
$langA['date_F'][11] = 'Kasım';
$langA['date_F'][12] = 'Aralık';

$langA['date_M'][1] = 'Ocak';
$langA['date_M'][2] = 'Şubat';
$langA['date_M'][3] = 'Mart';
$langA['date_M'][4] = 'Nisan';
$langA['date_M'][5] = 'Mayıs';
$langA['date_M'][6] = 'Haziran';
$langA['date_M'][7] = 'Temmuz';
$langA['date_M'][8] = 'Ağustos';
$langA['date_M'][9] = 'Eylül';
$langA['date_M'][10] = 'Ekim';
$langA['date_M'][11] = 'Kasım';
$langA['date_M'][12] = 'Aralık';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'ÖÖ';
$langA['date_A']['pm'] = 'ÖS';

$langA['lang']['ar'] = 'Arapça (ar)';
$langA['lang']['bn'] = 'Bengal (tr)';
$langA['lang']['de'] = 'Almanca (de)';
$langA['lang']['el'] = 'yunan(el)';
$langA['lang']['en'] = 'İngilizce (en)';
$langA['lang']['es'] = 'Ispanyolca(es)';
$langA['lang']['fr'] = 'Fransızca (fr)';
$langA['lang']['hu'] = 'Macarca';
$langA['lang']['it'] = 'İtalyanca (it)';
$langA['lang']['ja'] = 'Japonca (ja)';
$langA['lang']['ko'] = 'Korece(ko)';
$langA['lang']['ml'] = 'Malayca';
$langA['lang']['nl'] = 'Hollanda(nl)';
$langA['lang']['pl'] = 'Polonya';
$langA['lang']['ro'] = 'Rumence (ro)';
$langA['lang']['ru'] = 'Rusça (ru)';
$langA['lang']['tr'] = 'Türkçe (tr)';
$langA['lang']['vi'] = 'Vietnam';
$langA['lang']['zh'] = 'Çince';
$langA['lang']['zh-cn'] = 'Basit Çince';



