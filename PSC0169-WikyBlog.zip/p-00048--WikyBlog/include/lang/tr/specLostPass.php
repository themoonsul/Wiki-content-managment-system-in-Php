 <?php

$langA['CHANGE_PASS_INTRO'] = 'Parolanızı değiştirmek için öncelikle size bir "İzin Anahtarı" göndermemiz gerekiyor; böylece bu kısıtlı özelliğe erişebilirsiniz. Bir kez anahtarı aldığınızda, bu sayfaya geri dönün ve aşağıdaki bilgileri girin. Lütfen unutmayın, "İzin Anahtarınız" yalnızca kendi kullanıcı adınızla çalışacaktır.';

$langA['next_step'] = 'Sonraki Adım';

$langA['PASS_EMAIL_SUBJECT'] = '%s için İzin Anahtarı.';
$langA['PASS_EMAIL_TEXT'] ='%s için izin anahtarınız: %s.';

$langA['get_your_key'] = 'İzin Anahtarınızı Alın';
$langA['GET_YOUR_KEY'] = 'Anahtarınız, kayıt sırasında sağladığınız e-posta adresine gönderilecek.';

$langA['send_key'] = 'İzin Anahtarı Gönder';

$langA['change_password'] = 'Parolanızı Değiştirin';
$langA['permission_key'] = 'İzin Anahtarı';
$langA['new_password'] = 'Yeni Parola';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = 'Parola Değiştirme başarısız: Yanlış İzin Anahtarı veya Kullanıcı Adı';
$langA['PASSWORD_CHANGED'] = 'Parolası başarıyla güncellenen: <tt>%s</tt>.';
$langA['PROVIDE_PASSWORD'] = 'Yeni bir parola sağlamalısınız.';
$langA['PROVIDE_PERMISSION_KEY'] = 'Parolanızı değiştirebilmek için bir İzin Anahtarı sağlamalısınız';
$langA['PERMISSION_KEY_SENT'] = 'İzin Anahtarı başarıyla gönderildi. E-postanızdan anahtara ulaşın ve aşağıdaki formu kullanarak parolanızı değiştirmek için kullanın.';
$langA['PERMISSION_KEY_NOT_SENT'] = 'Saðlanan e-posta adresine İzin Anahtarı gönderilemedi, daha fazla yardım için lütfen web site yöneticisine başvurun.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = 'Bu hesap için bir e-posta adresi sağlanmadı. Daha fazla yardım için lütfen web site yöneticisine başvurun.';

