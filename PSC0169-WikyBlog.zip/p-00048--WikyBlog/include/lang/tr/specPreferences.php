<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'Zaten kayıtlı olan tercihlerinizde değişiklik yapılmadı.';
$langA['INVALID_PREFS'] = '<b>Uyarı:</b> Tercihleriniz sağladığınız değerlerle kaydedilemedi.';

$langA['EMAIL_PREFS'] = 'Parolanızı kaybederseniz işinize yarayacaktır.';

$langA['LANG_PREFS'] = 'Bir dil seçin.';

$langA['javascript_preferences'] = 'JavaScript Tercihleri';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'JavaScript iyileştirmelerini aç/kapat. JavaScript devre dışı bırakıldığında bazı özellikler çalışmayacaktır.';

$langA['time_zone'] = 'Zaman Dilimi';
$langA['TIME_ZONE_PREFS'] = 'Yerel saatinizle sunucu saati arasındaki zaman farkı: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'Sunucu saati şu anda %s. <br/>Ayarlanmış saatiniz %s.';

$langA['sig'] = 'İmza';
$langA['SIGNATURE'] = 'İmzanı wiki sözdizimi ile düzenle.';


$langA['home_title'] = 'Anasayfa Başlığı';
$langA['HOME_TITLE_PREFS'] = 'Ana sayfanızda gösterilecek başlık.';

$langA['blog_styled_frontpage'] = 'Blog Stili Önsayfa';
$langA['BLOG_PREFS'] = 'Ana sayfayı blog olarak göster.';

$langA['blogT'] = 'Blog Türü';
$langA['BLOG_TYPE'] = 'Bloga kullanılabilir veri tipleri arasından seç.';

$langA['selective_blogging'] = 'Seçmeli Blog';
$langA['SELECTIVE_BLOGGING'] = 'Seçmeli blogging sadece ilk ön sayfada göstermek istediklerini kabul eder.';

$langA['blog_count'] = 'Blog Sayısı';
$langA['BLOG_COUNT'] = 'Günlüğünüz (Blog\'unuz) üzerinde gösterilecek girdi sayısı.';

$langA['blen'] = 'İçerik Uzunluğu';
$langA['BLEN'] = 'Her blog mesajından görüntülenecek yaklaşık içerik miktarını belirtir.';

$langA['SHARE'] = 'Her dosyanın altında "Paylaş" bağlantısını göster.';

$langA['ihelp'] = 'Yardım Bağlantıları';
$langA['IHELP'] = 'Yardım bağlantılarını göster.';

$langA['uServices'] = 'Güncelleme Servisleri';
$langA['UPDATE_SERVICES'] = 'Yeni bir mesaj yayınlayacağın zaman, takip eden güncelleme servisleri otomatik olarak bildirecek. Çoklu servis URIs hatlarla ayrılacak.';
$langA['BAD_UPDATE_SERVICES'] = 'Güncelleme Servisleri için geçersiz URI(ler)';


$langA['VIEW_THEME'] = 'Bu temayı <a %s>düzenleyin ya da kopyalayın.</a>';

$langA['quick_comment'] = 'Hızlı Yorum';
$langA['QUICK_COMMENT'] = 'Açık olduğu zaman, konuşma sayfalarının tepesinde daha hızlı yorumlama için bir form görüntilenecektir.';

$langA['textarea rows'] = 'Metin alanı Satırları';
$langA['TEXTAREA_ROWS_PREFS'] = 'Düzenleme alanlarının yüksekliğini belirler.';

$langA['history_rows'] = 'En Fazla Geçmiş Satırları';
$langA['HISTORY_ROWS_PREFS'] = 'Her dosya için sunucuda saklanan geçmiş satırlarının sayısını sınırlandırır.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'En Fazla %s.';

$langA['tab_limit'] = 'Sekme Limiti';
$langA['TAB_LIMIT'] = 'Açılan sekmelerin sayısı bu limite ulaştığında JavaScript sekmeleri otomatik olarak kapatacaktır. Öntanımlı 7\'dir. Eğer JavaScript\'in sekmelerinizi yönetmesini istemiyorsanız 1000 ya da daha fazlasına ayarlayın.';

$langA['EXTERNAL_LINKS'] = '"Açık" olduğunda harici bağlantılar yeni sayfada açılacak.';

$langA['SCROLL_CONTENT'] = 'Sayfanın tamamı yerine sadece içerik alanını kaydır. <br/><span class="sm">(Özel temalar için WB_SCROLLAREA div gerekecektir.)</span>';

$langA['shortK'] = 'Klavye Kısayolları';
$langA['SHORTK_CONTENT'] = 'Klavye kısayolu çıkış sırasını özelleştir. (Sayfayı yenilemeyi gerektirir)';


$langA['save_preferences'] = 'Tercihleri Kaydet';

$langA['CONFIRM_CHANGE'] = 'Tercihlerinizi deðiþtirmek istediðinize emin misiniz?';
$langA['preference'] = 'Tercih';
$langA['old_value'] = 'Eski Değer';
$langA['new_value'] = 'Yeni Değer';

$langA['changes'] = 'Değişiklikler';
$langA['PREFS_CHANGED'] = 'Tercihleriniz güncellendi.<br/> Değişen değerlerin bir özeti aşağıdadır.';


//check edit
$langA['anonymous'] = 'Anonim';
$langA['fEdits'] = 'İşaret Düzenle';
$langA['FLAG_EDITS'] = 'Hesap sahibi görene kadar aşağıdaki seçilmiş durum "Kontrol Edilmemiş" olarak işaretlenecek.';

//save all edits
$langA['saveAll'] = 'Tüm Değişikliklerin Günlüğünü Tut';
$langA['SAVEALL'] = '"Açık" seçeneği, revizyon geçmişindeki tüm değişiklikleri kaydeder.<br/> "Kapalı" seçeneği, revizyonları düzenleme oturumlarına göre kaydeder.';
