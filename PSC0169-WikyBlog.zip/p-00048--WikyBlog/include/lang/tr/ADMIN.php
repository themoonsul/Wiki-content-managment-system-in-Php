<?php

	$langA['googleMapKeys'] =						'Google Maps API Anahtarı';


	$langA['ADMIN_ONLY'] =							'Bu sayfaya erişebilmek için bir yönetici olmalısınız.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Bu yönetici sayfası henüz belirlenmemiş: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Devam etmek için lütfen parolanızı onaylayın.';
	$langA['confirm_password'] =						'Şifreyi Onayla';
	$langA['confirmation_failed'] =					'Şifre onaylaması başarısız oldu. Lütfen tekrar deneyin.';
	
	$langA['run_scheduled_tasks'] =					'Zamanlanmış Görevleri Çalıştır';
	$langA['FAILED'] = 								'Üzgünüm. İstenen işlem gerçekleştirilemedi. Lütfen tekrar deneyin.';
	$langA['SUCCESS'] = 								'İstenen işlem başarıyla gerçekleşti.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Arama Seçenekleri';
	$langA['search_status'] =						'Arama Durumu';
	$langA['search_enabled'] =						'Arama Açık';
	$langA['SEARCH_ENABLED'] =						'Arama özelliğini kapatmak, \'all_search\' veritabanı tablosunu boşaltacaktır. Aramayı daha sonra tekrar açmak isterseniz \'all_search\' tablosunun tekrar doldurulması gerekecek.';
	$langA['disable'] =								'Kapat';
	
	$langA['search_disabled'] =						'Arama Kapalı';
	$langA['SEARCH_DISABLED'] =						'Arama özelliği şu anda kapalı. Arama özelliğini açmak, \'all_search\' veritabanı tablosunun veritabanındaki tüm dosya girdileriyle doldurulması işlemini gerektirir.';
	$langA['SEARCH_IS_DISABLED'] =					'Arama özelliği kapatıldı ve arama tablosu kısaltıldı.';
	$langA['enable'] =								'Etkinleştir';
	
	$langA['FINISHED_ENTRIES'] =						'%s girdi tamam, %s tane daha var.';
	$langA['SEARCH_IS_ENABLED'] =					'Arama özelliği şimdi açık.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Site Ayarları';
	$langA['confighistory'] =						'Ayarlar Geçmişi';
	$langA['CONFIG_SAVING'] =						'Yeni ayarlar, şu anki değerlerin üstüne yazılmaksızın kaydedildi.Eğer gerekirse değişiklikleri geri alabilirsiniz...';
	$langA['CONFIG_STAT'] =							'Ayarlara %s değişiklik yapıldı.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'%s numaralı değişikliğe geri dönmek istediğinize emin misiniz? Devam etmek için <tt>Kaydet</tt>e tıklayın.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Kullanılamaz';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Şöyle bir cümleyle kullanılabilecek birşey: "sunucuAdı1\'e Hoşgeldiniz".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://sunucuAdı2';

//default user

	$langA['max_upload']['desc'] = 					'Yüklenen bir dosya için en yüksek boyut.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Kullanıcılar kayıtta  kullanıcı isimlerinin virgülle ayırmayacak.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Hata Günlüğü için izin verilen en yüksek dosya boyutu. Varsayılan değer: 10,000 byte.';
	$langA['errorEmail']['desc'] = 					'Bir e-posta adresi sağlayın ';
	
	
	$langA['include']['desc'] = 						'Her istekte bir php dosyası programa otomatik olarak dahil edilecek. Dosya isimleri virgül ile ayrılabilir ve RootDir (yönetim dizini) ile ilgili olabilir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Genel Ayarlar';
	$langA['performance'] = 							'Performans';
	
	$langA['serverName1']['alias'] = 				'Güzel Sunucu Adı';
	$langA['serverName2']['alias'] = 				'Sunucu Adı';
	$langA['serverName3']['alias'] = 				'Tam Sunucu Url\'si';
	
	
	$langA['total_usage'] = 						'Toplam Kullanım';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'En fazla Belge Yükleme';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Dil';
	$langA['reservedWords']['alias'] = 				'Ayrılmış Kelimeler';
	
	$langA['developer_aids'] = 						'Developer Araçları';
	$langA['maxErrorFileSize']['alias'] = 			'Hata Günlüğü Boyutu';
	$langA['errorEmail']['alias'] = 					'Hata E-postası';
	$langA['include']['alias'] = 					'PHP İçer';

//
//	default user
//
	$langA['default_user_vars'] = 				'Varsayılan Kullanıcı Ayarları';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Anasayfa Başlığı';
	$langA['defaultUser:homeTitle']['desc'] =		'Anasayfanın başlığı olarak gösterilir.';
	
	$langA['defaultUser:template']['alias'] =		'Kullanıcı Şablonu';
	$langA['defaultUser:template']['desc'] =		'Main/Home, varsayılan wikyblog şablonudur.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Metin alanı Yüksekliği';
	$langA['defaultUser:textareaY']['desc'] =		'Öntanımlı metin alanı yüksekliği.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Blog Ana Sayfası';
	$langA['defaultUser:isBlog']['desc'] =			'Blog stilinde anasayfayı açar ve kapatır.';
	
	$langA['defaultUser:timezone']['alias'] =		'Zaman dilimi';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'En fazla Geçmiş Satırı';
	$langA['defaultUser:maxHistory']['desc'] =		'Geçmiş satırları için varsayılan en yüksek değer.';

	$langA['defaultUser:pTemplate']['alias'] =		'Varsayılan Tema';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'Kullanıcı Grubu';
	$langA['add_group'] = 'Grup Ekle';
	$langA['unlimited'] = 'Sınırsız';
	$langA['group'] = 'Grup';
	$langA['related_links'] = 'İlgili Bağlantılar';
	
//
//	registration
//	
	$langA['registration'] = 						'Kayıt';
	$langA['register:reqemail']['alias'] = 				'E-posta Adresi Gerekli';
	$langA['register:register']['alias'] =				'Görüntü Başlığını Kaydet';
	$langA['register:registered']['alias'] =				'Kayıtlı Görüntü Başlığı';
	$langA['register:captcha']['alias'] =				'Captcha Kullan';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Kullanıcı İstatistikleri';
	$langA['user_stats'] =							'Kullanıcı İstatistikleri';
	$langA['user_account'] =							'Kullanıcı Hesabı';
	$langA['entries'] =								'Girdiler';
	$langA['history Rows'] =							'Geçmiş Satırları';
	$langA['last_visit'] = 							'Son Ziyaret';
	
	$langA['users_found'] =							'Bulunan Kullanıcılar';
	$langA['showing_of_found'] =						'Gösterilen: %s Toplam: %s';
	$langA['cpanel'] =								'CPanel';
	$langA['details'] =								'Ayrıntılar';
	
	$langA['within_the_hour'] =						' < 1 saat önce';
	$langA['hours'] =								'saat';
	$langA['days'] =									'gün';
	$langA['months'] =								'ay';
	$langA['years'] = 								'yıl';
	$langA['ago'] = 									'önce';
	
	$langA['TIMEOUT'] = 								'<b>Zaman aşımı hatası:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Uyarı</b> "Ana" hesap silinemez';
	$langA['CONFIRM_DELETE_USER'] = 					'<b>%s</b>i silmek istediğinize emin misiniz?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Silmek, hesaptaki dosyaların hepsini <i>tamamen ortadan kaldıracaktır</i>:';
	$langA['userfiles_directory'] = 					'Kullanıcı dosyaları dizini: ';
	$langA['template_directory'] = 					'Şablon dizini: ';
	$langA['database_entries'] = 					'Ve tüm veri tabanı girdileri: sayfalar, sayfa geçmişi, yorumlar v.b.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'%s deki silinen veri tabanı girdileri.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Uyarı:</b> %s deki veritabanı girdileri silinemedi.';
	
	$langA['DELETED_USERFILES'] = 					'Kullanıcı dosyaları Dizini Silindi.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Uyarı:</b> Kullanıcı dosyaları dizini silinemedi.';
	
	$langA['DELETED_TEMPLATES'] = 					'Şablon Dizini Silindi.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Uyarı:</b> Şablon Dizini silinemedi.';
	
	$langA['USER_DELETED'] = 						'%s tamamen silindi: ';
	$langA['USER_NOT_DELETED'] = 					'%s tamamen SİLİNMEDİ: ';
	$langA['DELETE_ACCOUNT'] = 						'Bu hesabı tamamen sil.';
	$langA['DISABLE_ACCOUNT'] = 					'Dosya düzenlemeyi engelle.';
	$langA['SUSPEND_ACCOUNT'] = 					'Tüm Kullanımı Askıya Al'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Harici bağların tümüne "takipyok" ekle.';
	$langA['updated'] = 							'Güncellendi';
	$langA['suspend'] = 							'Askıya Al';
	$langA['activate'] = 							'Aktifleştir';
	$langA['lost_page'] = 							'Kayıp Sayfa';
	$langA['suspended'] =							'Askıda';
	$langA['disabled'] =							'Devre Dışı';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Hata günlüğü silinemedi.';
	$langA['ERROR_LOG_DELETED'] = 					'Hata günlüğü silindi.';
	$langA['ERROR_LOG_MAXED'] = 						'Hata Günlüğü dosyası boyutu en yüksek değere ulaştı, betiğin hata günlüğü tutmaya devam edebilmesi için lütfen dosyayı boşaltın. %s';


	$langA['select'] = 								'Seç';
	$langA['description'] = 						'Tanım';


//	adminPlugins
	$langA['data_types'] = 							'Veri Türleri'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Varolan Türler';
	$langA['available_plugins'] = 					'Kullanılabilir Eklentiler';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Tümünü İşaretle / Tümünün İşaretini Kaldır';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Çevrimiçi';
	$langA['wbConfig']['online']['desc'] = 			'Bu uyarlama internete bağlı mı?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Ardışık Gelgit Aralığı';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Gerekli izinleri olmayan bir kullanıcının iki düzenleme arasında beklemesi gereken süre (saniye cinsinden).';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Anonim kullanıcılar için JavaScript iyileştirmesi düzeyini belirler.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Olası kullanıcı girdi hatalarını düzeltmek için HTML Tidy kullan.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Tüm Özelliklerle.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Kayıtlı tüm kullanıcıların kendi günlüğü olmasına izin ver.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Ziayretçi tarafından verilmediyse, gösterilecek kullanıcı hesabını seçiniz.';
	$langA['wbConfig']['pUser']['alias'] = 			'Varsayılan Kullanıcı';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Oturumlar onaylandığında kaç kullanıcı IP adresinin kontrol edileceğini belirleyin.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Oturum Seviyesi';

	$langA['wbConfig']['thumbs']['desc'] = 		'Yüklenen görüntüler için küçük resimler oluştur.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Küçük Resimler';

