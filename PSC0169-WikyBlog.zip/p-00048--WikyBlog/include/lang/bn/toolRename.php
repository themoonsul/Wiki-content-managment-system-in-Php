<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'ফাইল নামের পরিবর্তন হয়নি |';
$langA['NOT_RENAMED'] = 'এই ফাইলটির <tt>%s</tt> রূপে পুনরায় নামকরণ করা যায়নি | সুনিশ্চিত করুন যে ফাইলটি ইতিমধ্য়েই বর্তমান নহে |';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'এই ফাইলটির পুনঃনামকরণ করা যায়নি |';
$langA['redirected_to'] = 'পুনরায় দিকনির্দিষ্ট করে এখানে পাঠানো :';
$langA['RENAMED'] = 'এই ফাইলটির সফলভাবে পুনঃনামকরণ করা হয়েছে |';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b> পুনঃস্থাপিত হয়েছে ';
$langA['ERROR_RESTORING'] = '<b>ত্রুটি :</b> <tt>%s.</tt>-তে পুনঃস্থাপিত করা যায়নি |';
$langA['ALREADY_RESTORED'] = 'এই ফাইলটি ইতিমধ্য়ে পুনস্থাপিত হয়ে গেছে |';
$langA['WAS_DELETED'] = '<b>%s</b> মুছে ফেলা হয়েছে | এই ফাইলটি %s-এ ৩০ দিন রাখা থাকবে |';
$langA['ERROR_DELETING'] = '<b>ত্রুটি :</b> <tt>%s.</tt>-তে ফাইলটি মুছে ফেলা যায়নি |';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> মুছে ফেলা হয়েছে';
