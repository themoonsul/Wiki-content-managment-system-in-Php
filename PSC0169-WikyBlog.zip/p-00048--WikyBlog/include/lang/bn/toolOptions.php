<?php

//	toolOptions.php
$langA['properties'] = 'বৈশিষ্ট্য়';
$langA['file_name'] = 'ফাইল নাম';
$langA['update_from'] = 'অদ্য়তন এই থেকে';
$langA['COPY_SYSTEM_FILES'] = 'সবথেকে সাম্প্রতিক তন্ত্র সাহায্য় ফাইল নকল করুন %s থেকে |';

$langA['EDITING_OPTIONS'] = 'কে এটির সম্পাদনা করিতে পারেন নিয়ন্ত্রণ করুন |';
$langA['registered_users'] = 'পঞ্জীকৃত ব্য়বহারকারী';
$langA['restricted_to'] = 'কী পর্য্য়ন্ত সীমবদ্ধ ';
$langA['admin_only'] = 'কেবলমাত্র প্রবন্ধক';
$langA['editor_visible'] = 'সম্পাদকদের জন্য় দৃশ্য়';
$langA['owner_only'] = 'কেবলমাত্র অধিকারী';
$langA['use_captcha'] = 'Captcha ব্য়বহার করুন';
		

$langA['visibility'] = 'দৃশ্য়তা';
$langA['VISIBILITY_OPTIONS'] = 'যদি আপনি এই ফাইলটি সমস্ত জগতকে দেখাতে তৈরি নন এটিকে লুকিয়ে দিন |';
$langA['visible'] = 'দৃশ্য়';

$langA['COMMENT_OPTIONS'] = 'এই ফাইলের জন্য় টিপ্পণী নিষ্ক্রিয় করে দিন |';
$langA['enabled'] = 'সক্রিয়';
$langA['disabled'] = 'নিষ্ক্রিয়';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Spam বিরোধি';
$langA['nofollow'] = 'পশ্চাত্ধাবন নয়';

$langA['other'] = 'অন্য়';
$langA['related_links'] = 'সম্বদ্ধ যোগসুত্র';
$langA['unblog'] = 'ব্লগ থেকে সরিয়ে দিন |';
$langA['repost'] = 'পুনঃপ্রবিষ্টি';
$langA['copy_to'] = 'নকল করুন এতে ...';
$langA['send_to_trash'] = 'কুড়োখানাতে পাঠান';
$langA['default_options'] = 'পূর্বনির্ধারিত বিকল্প';
$langA['restore_defaults'] = 'পূর্বনির্ধারিত পুনঃস্থাপন করুন';
$langA['SET_DEFAULT_OPTIONS'] = 'এই ফাইল প্রকারের জন্য় %s নির্দিষ্ট করুন |'; //replaced with link
$langA['add_to_tabs'] = 'ট্য়াবে সংযুক্ত করুন';
$langA['add_to_links'] = 'যোগসুত্রে সংযোগ করুন';

$langA['REPOSTED'] = 'এই ফাইলটি পুনঃপ্রবিষ্ট করা |';
$langA['NOT_REPOSTED'] = '<b>ত্রুটি :</b> ফাইলটি পুনঃপ্রবিষ্ট করা যায়নি |';
$langA['OPTIONS_NOT_CHANGED'] = 'ফাইল বিকল্পে পরিবর্তন হয়নি |';
$langA['OPTIONS_UPDATED'] = 'ফাইল বিকল্পগুলি সফলভাবে অদ্য়তন করা হয়েছে |';
$langA['OPTIONS_NOT_UPDATED'] = '<b>চেতাবনী :</b> ফাইল বিকল্প অদ্য়তন করা হয়নি |';

$langA['redirect'] = 'পুনঃপ্রেষিত করুন';
$langA['REMOVE_REDIRECT'] = 'যদি আপনি চান না এই ফাইলটি পুনঃপ্রেষিত হ‍উক, এটিকে মুছে ফেলুন অথবা সম্পাদিত করুন | ';


$langA['UNCHECKED_REMOVED'] = 'এই ফাইল থেকে "অপরিক্ষীত" পতাকা সরিয়ে দেওয়া হয়েছে |';

$langA['NO_KEYWORDS'] = 'এই ফাইলটির জন্য় কোন মুখ্য়শব্দ নির্ধারিত নেই  আপনি কি <a %s>প্রথমে মুখ্য়শব্দ সংযোগ</a> করিতে চান না <a %s>এক্ষনে ব্লগ</a> করিতে চান ?';

$langA['file_id'] = 'ফাইল ID';

//watch
$langA['WATCH_UPDATED'] = 'আপনার <a %s>নিহারণসূচী</a> অদ্য়তন করা হয়েছে |';


$langA['user_permissions'] = 'ব্য়বহারকারী&nbsp;অনুমতি';
