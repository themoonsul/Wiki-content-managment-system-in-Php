<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'আপনার পছন্দগুলি ইতিমধ্য়ে সংরক্ষিত মানগুলি থেকে ভিন্ন নহে |';
$langA['INVALID_PREFS'] = '<b>চেতাবনী :</b> দেওয়া মানা দ্বারা আমরা আপনার পরিবর্তনগুলি সঞ্চিত করিতে পারিনি |';

$langA['EMAIL_PREFS'] = 'পাসওয়ার্ড ভুলে গেলে সাহায্য়ক';

$langA['LANG_PREFS'] = 'ভাষা চয়ন করুন';

$langA['javascript_preferences'] = 'JavaScript পছন্দ';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'JavaScript উন্নতি চালু রাখুন / বন্ধ করুন | JavaScript নিষ্ক্রিয় থাকিলে কিছু বৈশিষ্ট্য় কার্য্য় করিবে না |';

$langA['time_zone'] = 'সময়বলয়';
$langA['TIME_ZONE_PREFS'] = 'আপনার স্থানীয় সময় এবম সার্ভারের সময়ের মধ্য়ে অন্তর : <tt>hh:mm</tt>|';
$langA['TIME_ZONE_PREFS2'] = 'সার্ভারের সময় এখন %s | <br/>আপনার সমন্বয়িত সময় এখন %s|';

$langA['sig'] = 'স‍ই';
$langA['SIGNATURE'] = 'নিজের স‍ই পছন্দমত তৈরী করে নিন wiki দুরন্বয় দ্বারা |';


$langA['home_title'] = 'মুখ্য়পৃষ্ঠা শীর্ষক';
$langA['HOME_TITLE_PREFS'] = 'আপনার মুখ্য়পৃষ্ঠে যা শিরোনাম দৃশ্য় হবে';

$langA['blog_styled_frontpage'] = 'ব্লগের মতন মুখ্য়পৃষ্ঠা';
$langA['BLOG_PREFS'] = 'মুখ্য়পৃষ্ঠাকে ব্লগরূপে দেখান |';

$langA['blogT'] = 'ব্লগ প্রকার ';
$langA['BLOG_TYPE'] = 'ব্লগ করিবার জন্য় উপলব্ধ তথ্য় প্রকার থেকে চয়ন ক্রুন |';

$langA['selective_blogging'] = 'চয়নাত্মক ব্লগ করা';
$langA['SELECTIVE_BLOGGING'] = 'চয়নিত ব্লগ করা আপনাকে কেবলমাত্র সেই পৃষ্ঠাগুলিকে ব্লগ করিতে দেয় যেগুলি আপনি মুখ্য়পৃষ্ঠাতে দেখিতে চান |';

$langA['blog_count'] = 'ব্লগ গুনতি';
$langA['BLOG_COUNT'] = 'আপনার ব্লগে যতগুলি প্রবিষ্টি দেখানো হবে সেই সংখ্য়া |';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'প্রতিটি ফাইলের নীচে "আবন্টন" শৃঙ্খলাটি দেখান |';

$langA['ihelp'] = 'সাহায্য় যোগসুত্র';
$langA['IHELP'] = 'সাহায্য় যোগসুত্র দেখান';

$langA['uServices'] = 'পরিসেবা অদ্য়তন করুন';
$langA['UPDATE_SERVICES'] = 'যখন আপনি নতুন প্রনিষ্টি করিবেন তখন নিম্নোক্ত পরিসেবাগুলি স্বয়ংক্রিয়ভাবে সূচিত হ‍ওবে | লাইনভঙ্গ দ্বারা অকাধিক পরিসেবা URIকে বিভক্ত করুন |';
$langA['BAD_UPDATE_SERVICES'] = 'অদ্য়তন পরিসেবার জন্য় অবৈধ URI দেওয়া';


$langA['VIEW_THEME'] = 'এই বিষয়জগতটির  	<a %s>সম্পাদন/দ্বিত্বকরণ করুন</a> |';

$langA['quick_comment'] = 'ত্বরিত টিপ্পণী';
$langA['QUICK_COMMENT'] = 'অন থাকিলে, বার্তা পৃষ্ঠার উপরের দিকে একটি ফর্ম দৃশ্য়মান থাকিবে দ্রুত টিপ্পণী করিবার জন্য় |';

$langA['textarea rows'] = 'পাঠ্য়ক্ষেত্র সারি';
$langA['TEXTAREA_ROWS_PREFS'] = 'পাঠ্য় ক্ষেত্রের উচ্চতা নির্ধারিত করে |';

$langA['history_rows'] = 'সর্বাধিক ইতিবৃত্ত সারি';
$langA['HISTORY_ROWS_PREFS'] = 'প্রতিটি ফাইলের জন্য় সার্ভারে সঞ্চিত ইতিবৃত্ত সারির সংখ্য়া সীমিত করে |';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'সর্বাধিক %s';

$langA['tab_limit'] = 'ট্য়াব সীমা';
$langA['TAB_LIMIT'] = 'খোলা ট্য়াবের সংখ্য়া এই সীমাতে পৌঁছুলে পরে JavaScript স্বয়ংক্রিয়ভাবে ট্য়াবে বন্ধ করে দেবে | পুর্বনির্ধারিত মান ৭ | এটি ১০০০ অথবা তাহার অধিক করুন যদী আপনি চাননা JavaScript আপনার ট্য়াবের প্রবন্ধন করুক |';

$langA['EXTERNAL_LINKS'] = '"অন" থাকিলে বাহ্য় শৃঙ্খলাগুলি নতুন দৃশ্য়পটে খুলিবে |';

$langA['SCROLL_CONTENT'] = 'পৃষ্ঠার বিষয়বস্তু ক্ষেত্রতেই কেবলমাত্র স্ক্রল করুন সম্পুর্ণ পৃষ্ঠার পরিবর্তে | <br/><span class="sm">(পছন্দমতন বিষয়জগতের আবশ্য়ক হ‍ইবে WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'কীবোর্ড শর্টকাট';
$langA['SHORTK_CONTENT'] = 'কীবোর্ড শর্টকাট পলায়ন অনুক্রমকে পছন্দমত করে নিন (পুনরায় চড়ানো আবশ্য়ক)';


$langA['save_preferences'] = 'পছন্দ সঞ্চয় করুন';

$langA['CONFIRM_CHANGE'] = 'আপনি নিশ্চিত যে আপনি নিজের পছন্দে পরিবর্তন করিতে চান ?';
$langA['preference'] = 'পছন্দ';
$langA['old_value'] = 'পুরাতন মান';
$langA['new_value'] = 'নবীন মান';

$langA['changes'] = 'পরিবর্তন';
$langA['PREFS_CHANGED'] = 'আপনার পছন্দগুলি এখন অদ্য়তন করে দেওয়া হয়েছে |<br/> যে মানগুলির পরিবর্তন হয়েছে সেগুলির সারাংশ নিম্নোক্ত |';


//check edit
$langA['anonymous'] = 'অনাম';
$langA['fEdits'] = 'সম্পাদন পতাকাযুক্ত করুন';
$langA['FLAG_EDITS'] = 'খাতা অধিকারী দ্বারা নিরীক্ষিত না হওয়া পর্য্য়ন্ত, একটি নির্বাচিত অবস্থার বা তাহার নিম্নের ব্য়বহারকারীগণ দ্বারা করা সম্পাদনাগুলি "অনিরীক্ষিত" পতাকাযুক্ত হ‍ইয়া থাকিবে |';

//save all edits
$langA['saveAll'] = 'সমস্ত সম্পাদনা ইতিবৃত্তে লিখুন |';
$langA['SAVEALL'] = '"অন" সমস্ত সম্পাদনা সংশোধন ইতিহাসে সংরক্ষিত করিবে <br/> "অফ" সংশোধন রেকর্ড করিবে সম্পাদনা সত্রের ভিত্তিতে |';
