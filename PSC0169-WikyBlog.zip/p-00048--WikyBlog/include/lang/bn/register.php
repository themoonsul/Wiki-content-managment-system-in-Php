<?php
$langA['ILLEGAL_USERNAME'] = 'ব্য়বহারকারী নামে নিম্নোক্ত অক্ষরগুলি থাকতে পারে না : %s';
$langA['LONG_USERNAME'] = 'ব্য়বহারকারী নাম বড়‍ই লম্বা ছিল';	
$langA['SHORT_USERNAME'] = 'ব্য়বহারকারী নাম বড়‍ই ছোট ছিল';
$langA['USER_TAKEN'] = 'অন্য় কোন ব্য়বহারকারী নাম চয়ন করুন | <tt>%s</tt> ইতিমধ্য়েই নেওয়া হয়ে গেছে | ';
$langA['USERNAME_ALL_DIGITS'] = 'ব্য়বহারকারী নাম সম্পূর্ণভাবে সংখ্য়াসমন্বিত হতে পারেনা |';
$langA['PASSWORDS_DIFFERENT'] = 'পাসওয়ার্ড মেলেনি |';
$langA['SHORT_PASSWORD'] = 'পসওয়ার্ড বড়ই ছোট ছিল';
$langA['EMAIL_REQUIRED'] = 'বৈধ ই-মেল ঠিকানা প্রদান করুন |';


$langA['register'] = 'পঞ্জীকরণ';
$langA['welcome_to'] = 'স্বাগত ';
$langA['REG_USERNAME'] = '৩-২০ অক্ষরের একটি অনুপম ID';
$langA['REG_PASSWORD'] = 'অন্ততত ৫ অক্ষরের দৈর্ঘ্য় আবশ্য়ক';
$langA['confirm_password'] = 'পসওয়ার্ড নিশ্চিত করণ';
$langA['REG_CONFIRM_PASS'] = 'উপরের সমান';
$langA['REG_EMAIL'] = 'বৈকল্পিক তবে পাসওয়ার্ড ভুলে গেলে সাহায্য়ক';
$langA['REQUIRED_FIELD'] = 'আবশ্য়ক ক্ষেত্র ইঙ্গিত করে';

$langA['REGISTRATION_TEXT'] = 'পঞ্জীকরণ ত্বরিত, নিঃশুল্ক এবং অনেক সুবিধে সমন্বিত...';
$langA['REG_A_USER_PAGE'] = '/UserName/Your_Pages';
$langA['REG_A_MAP_PAGE'] = '/Map/Username/Your_Maps';

//login
$langA['LOGGED_IN'] = 'আপনি <tt>%s</tt> রূপে লগ-ইন করে আছেন |';
$langA['WRONG_USERNAME'] = 'দেওয়া ব্য়বহারকারী নাম অস্তিত্বে নেই |আপনি কো %s-কে পঞ্জীকৃত করিতে চান ?';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'সফলতা ! নিজের খাতা সক্রিয় করিবার জন্য় %s-কে পাঠানো ই-মেলে সক্রিয়ণ শৃঙ্খলাতে ক্লিক করুন |';
$langA['ACTIVATE_ACCOUNT'] = 'নিজের খাতা এখন সক্রিয় করুন |';
$langA['ACTIVATED_FROM_EMAIL'] = 'আপনার খাতা সক্রিয় করে দেওয়া হয়েছে |';
$langA['INVALID_CODE'] = 'দেওয়া সুনিশ্চিতিকরণ কোড এখন আর বৈধ নয় |';
