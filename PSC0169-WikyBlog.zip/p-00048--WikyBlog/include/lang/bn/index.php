<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'ফাইল';
$langA['edit'] = 'সম্পাদন';
$langA['edits'] = 'সম্পাদন';
$langA['view_source'] = 'মূল দেখুন';
$langA['talk'] = 'কথাবার্তা';
//$langA['reply'] = 'Reply';
$langA['history'] = 'ইতিহাস';
$langA['diff'] = 'পার্থক্য়';
$langA['watch'] = 'নজর রাখুন';
$langA['unwatch'] = 'নজর রাখা বন্ধ করুন';
$langA['options'] = 'বিকল্প';


$langA['messages'] = 'বার্তা';
$langA['current'] = 'সমসাময়িক';
$langA['blog'] = ' 	 ব্লগ';
$langA['possible'] = 'সম্ভব';

$langA['DEFAULT_CONTENT'] = 'এটি একটি নতুন ফাইল, আপনি কি এটিকে [[%s?cmd=edit|create it]] করিবেন ?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'এটি একটি নতুন ফাইল |  এই ফাইলটির সৃষ্টি করিবার জন্য় আবশ্য়ক উপযুক্ত বিশেষাধিকার সহ আপনার লগ-ইন করা |';

$langA['NOT_OWNER'] = 'এই বৈশিষ্ট্য়টির জন্য় আপনার কাছে উপযুক্ত বিশেষাধিকার নেই |';
$langA['LONG_PATH'] = 'এই ফাইলটির শিরোনাম বেশি লম্বা ছিল এবং সেটিকে ছেঁটে ফেলা হয়েছে |';
$langA['EMPTY_CONTENT'] = 'বিষয়বস্তু একটি আবশ্য়ক ক্ষেত্র |';
$langA['INCOMPLETE_PATH'] = 'দেওয়া path অসম্পূর্ণ';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'দুঃখিত, website-এর প্রবন্ধক ব্য়বহারকর্তা blog নিষ্ক্রিয় করে দিয়েছে | এখানে পাওয়া বৈশিষ্ট্য়সকল সহ সমান bliki নির্মাণহেতু আসুন <a href="http://www.wikyblog.com">WikyBlog.com</a> -এ |';
$langA['TITLE_EXISTS'] = 'এই শিরোনামটি ইতিমধ্য়ে বর্তমান, একটো অন্য় চয়ন করে পুনরায় সংরক্ষিত করুন |';

$langA['HIDDEN_FILE'] = 'এই ফাইলে অনুপ্রবেশ ইহার মালিক দ্বারা সীমবদ্ধ করা | এই ফাইলটি দেখিবার জন্য়া আপনার চাই যথাযথ বিশেষাধিকার |';
$langA['HIDDEN_FILE2'] = 'এই ফাইলটি "লুকোন" | ';
$langA['DELETED_FILE'] = 'এই ফাইলটি বর্তমানে "কুড়োখানা"-তে আছে | যদি আপনি এই খাতার অধিকারী হন, আপনি ফাইলটিকে প্রত্য়ার্পিত করিতে পারেন আপনার নিয়ন্ত্রণ পট্টিকার মাধ্য়মে |';
$langA['PROTECTED_FILE'] = 'এই ফাইলটি সুরক্ষিত | এতে করা কোন পরিবর্তন সঞ্চিত করা হয়নি |';
$langA['INVALID_THEME'] = 'পছন্দে অবৈধ বিষয়জগত নাম নির্ধারিত করা হয়েছে | পূর্বনির্ধারিত বিষয়জগত ব্য়াবহার করা হচ্ছে |';
$langA['link_text'] = 'যোগসুত্র পাঠ্য়';
$langA['SURPASSED_MAX'] = '<b>চেতাবনী :</b> ডিস্কের ব্য়বহার বরাদ্দের উপরে চলে গেছে | আই ফাইলে করা কোনরূপ পরিবর্তন সঞ্চিত হয়নি |';


$langA['REDIRECTED'] = '%s থেকে ঘুরে এসেছে ';
$langA['REDIRECT_TO'] = 'এই পৃষ্ঠাটি %s-এ পুনঃপ্রেষিত হয় |';

//	Data Types
$langA['all'] = 'সমস্ত';
$langA['page'] = 'পৃষ্ঠা';
$langA['comment'] = 'টিপ্পণী';
$langA['map'] = 'মানচিত্র';
$langA['template'] = 'প্রতিরূপ';
$langA['help'] = 'সাহায্য়';
$langA['skeleton'] = 'কাঠামো';
$langA['attach'] = 'সংলগ্নক';

$langA['theme'] = 'বিষয়জগত';

$langA['comments'] = 'টিপ্পণী';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'পৃষ্ঠা';
$langA['CLASScomment'] = 'টিপ্পণী';
$langA['CLASSmap'] = 'মানচিত্র';
$langA['CLASStemplate'] = 'বিষয়জগত';
$langA['CLASShelp'] = 'সাহায্য়';
$langA['IS_CONTENT_TEMPLATE'] = 'এটি একটি বিষয়বস্তু প্রতিরূপ এবং আপনার ব্লগে এটি দেখানো হবেনা |';


$langA['seconds'] = ' সেকন্ড';
$langA['queries'] = ' প্রশ্ন';

$langA['QUERY_TIME'] = ' প্রশ্নের জন্য়';
$langA['INVALID_PATH'] = 'অবৈধ ফাইল পথ দেওয়া : <tt>%s</tt> |';							//replaced with path
$langA['INVALID_REQUEST'] = 'অবৈধ অনুরোধ';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'এটি নতুন বিষয়জগত | এটিকে সম্পাদিত করিতে উপরে প্রদত্ত "সম্পাদন" শৃঘ্খলাতে ক্লিক করুন |<br/> বিষয়জগত সৃষ্টির সময় সমস্ত আবশ্য়ক বিষয়বস্তু পরিবর্তনীয়গুলি অঙ্গীভূত করিতে মনে রাখিবেন |';
$langA['your_theme'] = 'আপনার বিষয়জগত';
$langA['CURRENT_THEME'] = 'আপনি বর্তমানে <b>%s</b> বিষয়জগতটি ব্য়বহার করছেন |'; //replaced with template name

$langA['use_this_theme'] = 'পরিবর্তে এই বিষয়জগতটি ব্য়বহার করুন |';
$langA['using_this_theme'] = 'আপনি বর্তমানে এই বিষয়জগতটি ব্য়বহার করছেন |';
$langA['MAKE_THEME'] = 'আরম্ভ করিতে, এই বিষয়জগতটি নকল করে নিজের পছন্দমতন বিষয়জগত সৃষ্টি করুন |';
$langA['EDIT_THEME_TEXT'] = '<p><h2>সম্পাদনা</h2> বিষয়জগতের সম্পাদনা করিবার সময় আপনার পরিবর্তনগুলি তখুনি দৃশ্য় হবেনা |<br /> আপনাকে "তাজা করুন" বোতামটি ব্য়বহার করিতে হতে পারে সঞ্চয়নের উপরান্তে পরিবর্তনগুলির নিরীক্ষণ করিতে পারেন |';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'সফটওয়েরের একটি অখন্ড অঙ্গরূপে এই সাহায্য় ফাইলটি একটি কেন্দ্রীয় সার্ভারে সংরক্ষিত |<br/> আপনি %sএটির%s এবং অন্য় সাহায্য় ফাইলের পাঠ্য়বস্তু সম্পাদিত করিতে পারেন %s-এ |';

$langA['NEW_HELP'] = 'নতুন সাহায্য় ফাইল সৃষ্টি করুন |';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'স্বচ্ছন্দে দেখুন';
$langA['change_log'] = 'পরিবর্তন ইতিবৃত্ত';
$langA['control_panel'] = 'নিয়ন্ত্রণ পট্টিকা';
$langA['administration'] = 'প্রবন্ধন';
$langA['preferences'] = 'পছন্দ';
$langA['watchlist'] = 'নিহারণসূচী';
$langA['wanted_files'] = 'অভীষ্ট ফাইল';
$langA['dead_end'] = 'পথান্তক ফাইল';
$langA['search'] = 'খুঁজুন';
$langA['orphaned_files'] = 'অনাথ ফাইল';
$langA['most_linked'] = 'সর্বাধিক শৃঙ্খলালক্ষ্য় ফাইল';
$langA['scrl'] = 'উন্নত স্ক্রল';
$langA['nWin'] = 'বাহ্য় যোগসুত্র';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'আরো সাম্প্রতিক প্রবিষ্টি';
$langA['NEED_INTERNET'] = 'এই বৈশিষ্ট্য়টি কেবলমাত্র ইন্টারনেট সহ সংযুক্ত কম্প্য়ূটারের জন্য় উপলব্ধ |';


//	SESSION
$langA['COOKIES_REQUIRED'] = ' <b>চেতাবনী :</b> আগে চলিবার জন্য় Cookie-র প্রয়োজন | যদি আপনি cookie সক্রিয় করে থাকেন তাহা হৈ‍লে এই পৃষ্ঠাটি রিফ্রেশ করুন |';
$langA['LOGIN_REQUIRED'] = 'এই বৈশিষ্ট্য়্টি ব্য়বহার করিবার জন্য় আবশ্য়ক আপনার স‍ই করে প্রবেশ করা |';

$langA['ENTER_USERNAME'] = 'নিজের ব্য়বহারকারী নাম প্রবিষ্ট করুন |';
$langA['ENTER_PASSWORD'] = 'নিজের পাসওয়ার্ড প্রবিষ্ট করুন |';
$langA['LOGGED_OUT'] = 'আপনি সফলভাবে বহির্গমন করেছেন |';
$langA['AUTO_LOGOUT'] = 'আপনার সত্রের মেয়াদ উত্তীর্ণ হয়ে গেছে |';

$langA['LOGIN_FAILED'] = 'লগ-ইন অসফল : ভুল পাসওয়ার্ড | <ul><li>Caps Lock  কি জ্বলছে ? <li>আপনি কি %sনিজের পাসওয়ার্ড ভুলে গেছেন%s ?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'লগ-ইন করিবার সর্বাধিক চেষ্টা %s উত্তীর্ণ হয়ে গেছে | পরবর্তী %s মিনিট পর্য্য়ন্ত আপনার লগ-ইন করিবার অনুমতি নেই |';
						
$langA['create_new'] = 'নতুন&nbsp;সৃষ্টি করুন ';
$langA['remember_me'] = 'আমাকে মনে রাখো';
$langA['log_out'] = 'বহির্গমন করুন';
$langA['log_in'] = 'স‍ই করে প্রবেশ করুন';

//	SAVING 
$langA['syntax_error'] = 'দুরন্বয়';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>দুরন্বয় :</b> সবথেকে সাম্প্রতিক পরিবর্তন দেখানো / সঞ্চয় করা যেতে পারেনি বিসদৃশ বিন্য়াসের জন্য় ';
$langA['SYNTAX_FIXED'] = 'দুরন্বয় ত্রুটি ঠিক করে দেওয়া হয়েছে |';


$langA['NO_CHANGES'] = 'এই ফাইলে কোন পরিবর্তন করা হয়নি | (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'ফাইলটি সঞ্চিত করা যায়নি |(%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'ফাইলটির পরিবর্তনগুলি সঞ্চিত করা হয়েছে |';
$langA['HIDDEN_FILE3'] = '<b>টিপ্পণী :</b> এটি একটি লুকোনো ফাইল, সেহেতু এই ফাইলের তকমাগুলি ব্য়বহারকারী মেনুর মোটে অঙ্গীভুত হবে না |';

$langA['VERSION_CONFLICT'] = 'চেতাবনী : আমরা আপনার পরিবর্তনগুলি সঞ্চিত করিতে পারিনি কারণ পাঠান্তর সংঘাত পাওয়া গিয়েছে |';
$langA['VERSION_CONFLICT_2'] = 	'চেতাবনী : আমরা আপনার পরিবর্তনগুলি সঞ্চিত করিতে পারিনি কারণ পাঠান্তর সংঘাত পাওয়া গিয়েছে | নিম্নোক্ত ঘটনাগুলির জন্য় এই সংঘাতটি ঘটে থাকিতে পারে | <ul><li>আপনি হয়ত বর্তমান কোন ফাইলের উপর লিখে দেওয়ার চেষ্টা করছেন |</li>  <li> আপনার সত্র হয়ত উত্তীর্ণ হয়ে গেছে |</li>  <li> অন্য় কেউ হয়ত এই ফাইলে পরিবর্তন সঞ্চিত করেছে |</li></ul>';

$langA['COPY_TO'] = 'নকল করুন &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>নকল চুড়ান্ত করিতে "সঞ্চয়" ক্লিক করুন  |'; //replaced with paths

$langA['FLOOD_WARN'] = 'সম্পাদন সীমিত করা হয়েছে ফাইল প্রতি %s সেকেন্ড | %s সেকন্ডে আবার চেষ্টা করুন |';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'সঞ্চয় বিকল্প';
$langA['blog_this'] = 'এটিকে ব্লগ করুন';



//	toolHistory2.php
$langA['differences'] = 'অন্তর';
$langA['line_num'] = 'পঙ্ক্তি';


//	toolHistory1.php
$langA['revision'] = 'সংশোধন ';
$langA['revision_as_of'] = 'সংশোধন এ সময়ে ';
$langA['revision_num_as_of'] = 'সংশোধন %s সময়ে %s -এ'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'সংশোধন সম্পাদনা করুন';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'সংশোধন #-তে প্রত্য়াগমন';
$langA['SET_USER_PERMISSIONS'] = 'এই ব্য়বহারকারীর জন্য় আপনার অধিকার নির্দিষ্ট করুন | '; 
$langA['compare_with_prev'] = '←পূর্ববর্তী সংশোধনের সাথে তুলনা করুন';
$langA['current_revision'] = 'বর্তমান সংশোধন';
$langA['compare_with_next'] = 'উত্তরবর্তী সংশোধনের সাথে তুলনা করুন →';
$langA['lines'] = 'পঙ্ক্তি';
$langA['text'] = 'পাঠ্য়';
$langA['vs'] = ' বনাম ';
$langA['content'] = 'বিষয়বস্তু';
$langA['your_text'] = 'আপনার পাঠ্য়';
$langA['show_prev_revision'] = '← সংশোধন %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'সংশোধন %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>চেতাবনী :</b> আপনি এই পৃষ্ঠার সাম্প্রতিকতম পাঠান্তর সম্পাদিত করছেন না | <br /> সঞ্চয় করিলে নবীনতম পাঠান্তরের জায়গা নিয়ে নেবে এই পুরাতন পাঠান্তরটি |';
$langA['SELECT_TWO_VERSIONS'] = 'দুটি বিশিষ্ট পাঠান্তর চয়ন করুন তুলনার জন্য় |';
$langA['NO_UNIQUE_REVISION'] = 'এই অনুরোধের অনন্য় সংশোধন পাওয়া যায়নি |';
$langA['INVALID_REVISION'] = '<b>ত্রুটি :</b> অবৈধ সংশোধন সংখ্য়া |';
$langA['NO_DIFFERENCES'] = 'তুলনার দুটি সংশোধন‍ই সমান |';
$langA['NO_REVISIONS'] = 'তুলনা করিবার জন্য় আবশ্য়ক দুটি বিশিষ্ট সংশোধন |';
$langA['NON_EXISTANT'] = 'এই ফাইলটি এখনো অস্তিত্বে নেই';

//	toolEditPage.php
$langA['bold_text'] = 'গাঢ় হরফের পাঠ্য়';
$langA['italic_text'] = 'বাঁকা হরফের পাঠ্য়';
$langA['headline_text'] = 'শিরোনাম সংযোগ করুন';
$langA['title'] = 'শীর্ষক';
$langA['unordered_list'] = 'অননুক্রমিক সূচি';
$langA['ordered_list'] = 'অনুক্রমিক সূচি';


$langA['internal_link'] = 'অভ্য়ন্তরীণ যোগসুত্র';
$langA['link'] = 'যোগসুত্র';
$langA['external_link'] = 'বাহ্য় যোগসুত্র';
$langA['embed_image'] = 'ছবি অন্তঃস্থাপিত করুন';
$langA['find_images'] = 'ছবি খুঁজুন';
$langA['image'] = 'ছবি';
$langA['nowiki'] = 'wiki নয়';
$langA['NOWIKI_TEXT'] = 'অবিন্য়স্ত পাঠ্য় এখানে প্রবিষ্ট করুন';
$langA['signature'] = 'স‍ই';
$langA['SIGNATURE_TEXT'] = 'নিজের স‍ই এখানে সন্নিবিষ্ট করুন';
$langA['preview'] = 'পূর্বালোকন করুন';
$langA['PREVIEW_TEXT'] = 'আপনার পরিবর্তনগুলির পূর্বালোকন করুন [%s-p]';
$langA['PREVIEW_WARN'] = 'এটি কেবল পূর্বালোকন | আপনার পরিবর্তনগুলি এখনও সঞ্চিত করা হয়নি !';
$langA['SAVE_TEXT'] = 'পরিবর্তন সঞ্চয় করুন [%s-s]';
$langA['reset'] = 'পুনঃস্থাপনা করুন';
$langA['RESET_TEXT'] = 'এই ফর্মটিকে তাহার পুর্বের অবস্থায় প্রত্য়র্পিত করুন [%s-c]';
$langA['changes'] = 'পরিবর্তন';
$langA['CHANGES_TEXT'] = 'এই ফাইলে করা আপনার পরিবর্তনগুলি দেখান | [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'কমা বিভক্ত মুখ্য়শব্দ দ্বারা নিজের প্রবিষ্টি সুবিন্য়স্ত করুন |'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'তকমা';
$langA['edit_summary'] = 'সম্পাদনা সংক্ষিপ্তি';
$langA['syntax_warning'] = 'আন্বয়িক চেতাবনী';
$langA['NO_IMAGES'] = 'কোন ছবি পাওয়া যায়নি';
$langA['insert_emoticons'] = 'ভাবপ্রতীকচিহ্ন সন্নিবিষ্ট করুন';
$langA['upload'] = 'আপলোড';



//searchHistory
$langA['show'] = 'দেখান';
$langA['hide'] = 'Hide';
$langA['compare'] = 'তুলনা করুন';
$langA['timeline'] = 'সময়সীমা';
$langA['summary'] = 'সংক্ষিপ্তি';
$langA['COMPARE_REVISONS'] = 'চয়নিত পাঠান্তরের সাথে তুলনা করুন |';
$langA['unchecked'] = 'অপরিক্ষীত';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'অবৈধ ফাইল প্রকার দেওয়া হয়েছে |';


//	SEARCH
$langA['next'] = 'পরবর্তী';
$langA['previous'] = 'পূর্ববর্তী';
$langA['order_by'] = 'অনুক্রম কাহার দ্বারা';
$langA['ascending'] = 'আরোহী';
$langA['descending'] = 'অবরোহী';
$langA['search_from'] = 'খুঁজুন এই থেকে ';
$langA['all_users'] = 'সমস্ত ব্য়বহারকারী';
$langA['user'] = 'ব্য়বহারকারী';
$langA['from_file_type'] = 'ফাইল প্রকার থেকে খুঁজুন : ';
$langA['read_more'] = 'আরো পড়ুন';
$langA['words'] = ' শব্দ';

$langA['RESULTS'] = 'পরিণাম %s থেকে %s %s-এর'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'খোঁজ অনুমাপকের অনুকুল কোন প্রবিষ্টি পাওয়া যায়নি';

//searchTalk
$langA['add_comment'] = 'নতুন প্রসঙ্গ সংযোজন করুন';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'চেতাবনী অঙ্গীভূত করা যায়নি | প্রতিলিপি প্রবিষ্টির জন্য় অসংরূপিত তথ্য় |';
$langA['duplicate_entry'] = 'প্রতিলিপি প্রবিষ্টি';
$langA['DUPLICATE_ENTRY'] = 'এটি %s-এ পাওয়া পৃষ্ঠার প্রতিলিপি প্রবিষ্টি | <br/>এই পৃষ্ঠাটি মুছে ফেলার পূর্বে এতে পাওয়া সমস্ত আবশ্য়ক তথ্য় মৌলিক পৃষ্ঠাতে অন্তরণ করে দিতে হবে |'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'পাওয়া যায়নি '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>ত্রুটি :</b><br /> এই script চলাকালীন একটি ত্রুটি হয়েছে |<br />  নিজের অনুরোধটি একবার দেখে নিন এবং আমরা ত্রুটি ইতিবৃত্ত দেখে script-এর ত্রুটিসংশোধন করিবার চেষ্টা করিব | %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'পূর্বনির্ধারিত প্রতিরূপ মুছে ফেলা যায়নি |';
$langA['THEME_MISSING_VARS'] = 'আবশ্য়ক পরিবর্তনীয়(গুলি)উধাও : <tt>%s</tt> |';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'নির্দিষ্ট বিষয়বস্তুটি অবৈধ';

//
//	CLASSmap
//
$langA['new_marker']='নবীন চিহ্নক';
$langA['new_route']='নতুন পথ';
$langA['SAVE_HEADER']='সঞ্চয়ের পূর্বে মনে রাখো';
$langA['save_map']='মানচিত্র সঞ্চয় করুন';
$langA['continue_editing']='সম্পাদনা অবিরত রাখুন';
$langA['miles/km'] = 'মাইল/কিলোমীটার';
$langA['MAP_DEFAULT_CONTENT'] = '<b>এটি একটি নতুন মানচিত্র |</b><br/> এই মানচিত্রটিকে সৃষ্ট/সম্পাদিত করিতে, উপরে "সম্পাদন"-এ ক্লিক করুন |';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'দুঃখিত, এই মানচিত্রটির সম্পাদন করিবার জন্য় আপনার কাছে যথেষ্ট বিশেষাধিকার নেই |';
$langA['play'] = 'বাজান';
$langA['stop'] = 'থামুন';
$langA['import'] = 'আমদানি';
$langA['export'] = 'রপ্তানি';
$langA['gpx_data'] = 'GPX তথ্য়';
$langA['gpx_exchange_format'] = 'GPX অন্তরবদল প্রতিরূপ';
$langA['CLICK_EDIT'] = 'এই মানচিত্রটির সম্পাদন করিতে, উপরে "সম্পাদন"-এ ক্লিক করুন |';


//	smileys
$langA['smiles'][':D'] = 'খুব খুশি';
$langA['smiles'][':)'] = 'হাসি';
$langA['smiles'][':('] = 'দুঃখিত';
$langA['smiles'][':o'] = 'অবাক';
$langA['smiles'][':shock:'] = 'ধাক্কা খাওয়া';
$langA['smiles'][':?'] = 'বিহ্বল';
$langA['smiles']['8)'] = 'দারুন';
$langA['smiles'][':lol:'] = 'অট্টহাস্য়';
$langA['smiles'][':x'] = 'মাথা গরম';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'লজ্জিত';
$langA['smiles'][':cry:'] = 'ক্রন্দন অথবা খুব‍ই দুঃখিত';
$langA['smiles'][':evil:'] = 'দানব অথবা রেগে আগুন';
$langA['smiles'][':twisted:'] = 'বক্র দানব';
$langA['smiles'][':roll:'] = 'চোখ বড়-বড়';
$langA['smiles'][':wink:'] = 'চোখ টেপা';
$langA['smiles'][':!:'] = 'বিস্ময়';
$langA['smiles'][':?:'] = 'প্রশ্ন';
$langA['smiles'][':idea:'] = 'ভাবোদয়';
$langA['smiles'][':arrow:'] = 'তীর';
$langA['smiles'][':|'] = 'নিরপেক্ষ';
$langA['smiles'][':mrgreen:'] = 'Mr. Green';

//
//	General Language
//
$langA['or'] = 'অথবা';
$langA['username'] = 'ব্য়বহারকারী নাম';
$langA['password'] = 'পাসওয়ার্ড';
$langA['email'] = 'ই-মেল';
$langA['register'] = 'পঞ্জীকরণ';
$langA['cancel'] = 'রদ্দ';
$langA['language'] = 'ভাষা';
$langA['use'] = 'ব্য়বহার করুন';
$langA['copy'] = 'নকল করুন';
$langA['rename'] = 'পুনরায় নাম দিন';

$langA['on'] = 'চালু';
$langA['partial'] = 'আংশিক';
$langA['off'] = 'বন্ধ';
$langA['save'] = 'সঞ্চয় করুন';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'অপরিভাষিত';
$langA['homepage'] = 'মুখ্য়পৃষ্ঠা';
$langA['home'] = 'মুখ্য়পৃষ্ঠা';
$langA['go'] = 'যান';
$langA['user_menu'] = 'ব্য়বহারকারী মেনু';

$langA['last_modified'] = 'শেষ পরিবর্তন';
$langA['LAST_MODIFIED'] = 'শেষ পরিবর্তন %s %s দ্বারা';//%s replaced with date and username
$langA['accessed_times'] = '%s বার অভিগমন করা';// %s replaced with a number
$langA['modified'] = 'পরিবর্তিত';
$langA['posted'] = 'প্রবিষ্ট';
$langA['created'] = 'সৃষ্ট';
$langA['hidden'] = 'লুকানো';
$langA['what_links_here'] = 'এখানে কারা সংযোগস্থাপন করে';
$langA['share'] = 'আবন্টন করুন';
$langA['INVALID_LINK'] = 'অনুরুদ্ধ পৃষ্ঠা শিরোনামটি অবৈধ | হতে পারে এতে আছে এক অথবা একাধিক সম্প্রতীক যা শিরোনামে ব্য়বহৃত হ‍ইতে পারে না |';
$langA['FILE_MUST_EXIST'] = 'এই প্রক্রিয়াটি করিবার পূর্বে আপনাকে ফাইলটি সঞ্চিত করিতে হবে |';

$langA['OOPS'] = 'ঐ যাঃ, এটা কাজ করল না, আবার চেষ্টা করুন |';


$langA['size'] = 'আকার ';
$langA['bytes'] = 'বাইট';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'অদ্য়তন';
$langA['editing'] = 'সম্পাদনা';
$langA['workgroup'] = 'কার্য্য়সমূহ';
$langA['BROWSE_HIDDEN'] = 'লুকোনো ফাইল খুঁজুন';

$langA['delete'] = 'মুছে ফেলুন';
$langA['confirm_delete'] = 'মুছে ফেলা সুনিশ্চিত করুন';
$langA['continue'] = 'এগিয়ে চলুন';
$langA['back'] = 'পিছনে যান';
$langA['close'] = 'বন্ধ করুন';
$langA['view'] = 'দেখুন';
$langA['empty'] = '-রিক্ত-';
$langA['none'] = 'কোনটাই নয়';
$langA['total'] = 'মোট ';
$langA['files'] = 'ফাইল';
$langA['other'] = 'অন্য়';
$langA['trash'] = 'কুড়োখানা';
$langA['flagged'] = 'পতাকাযুক্ত';

$langA['today'] = 'আজ';
$langA['yesterday'] = 'গতকাল';
$langA['days_ago'] = ' দিন পূর্বে';
$langA['page_contents'] = 'পৃষ্ঠা বিষয়বস্তু';
$langA['more'] = 'আরো';
$langA['download'] = 'ডাউনলোড করুন';


//Date
$langA['date_l'][0] = ' 	 রবিবার';
$langA['date_l'][1] = ' 	 সোমবার';
$langA['date_l'][2] = 'মঙ্গলবার';
$langA['date_l'][3] = ' 	 বুধবার';
$langA['date_l'][4] = ' 	 বৃহস্পতিবার';
$langA['date_l'][5] = ' 	 শুক্রবার';
$langA['date_l'][6] = 'শনিবার';

$langA['date_D'][0] = 'রবিবার';
$langA['date_D'][1] = 'সোমবার';
$langA['date_D'][2] = 'মঙ্গলবার';
$langA['date_D'][3] = 'বুধবার';
$langA['date_D'][4] = 'বৃহস্পতিবার';
$langA['date_D'][5] = 'শুক্রবার';
$langA['date_D'][6] = 'শনিবার';


$langA['date_F'][1] = ' 	 জানুয়ারী';
$langA['date_F'][2] = ' 	 ফেব্রুয়ারী';
$langA['date_F'][3] = ' 	 মার্চ';
$langA['date_F'][4] = 'এপ্রিল';
$langA['date_F'][5] = ' 	 মে';
$langA['date_F'][6] = ' 	 জুন';
$langA['date_F'][7] = ' 	 জুলাই';
$langA['date_F'][8] = ' 	 আগস্ট';
$langA['date_F'][9] = ' 	 সেপ্টেম্বর';
$langA['date_F'][10] = ' 	 অক্টোবর';
$langA['date_F'][11] = ' 	 নভেম্বর';
$langA['date_F'][12] = ' 	 ডিসেম্বর';

$langA['date_M'][1] = ' 	 জানু';
$langA['date_M'][2] = ' 	 ফেব্রু';
$langA['date_M'][3] = ' 	 মার্চ';
$langA['date_M'][4] = ' 	 এপ্রিল';
$langA['date_M'][5] = ' 	 মে';
$langA['date_M'][6] = ' 	 জুন';
$langA['date_M'][7] = ' 	 জুলাই';
$langA['date_M'][8] = 'অগাস্ট';
$langA['date_M'][9] = 'সেপ্টেমবার';
$langA['date_M'][10] = 'অক্টোবার';
$langA['date_M'][11] = 'নভেমবার';
$langA['date_M'][12] = 'ডিসেমবার';

$langA['date_a']['am'] = 'পূর্বাহ্ন';
$langA['date_a']['pm'] = 'অপরাহ্ন';

$langA['date_A']['am'] = 'পূর্বাহ্ন';
$langA['date_A']['pm'] = 'মধ্য়াহ্ন';

$langA['lang']['ar'] = 'আরবী (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'জার্মান (de)';
$langA['lang']['el'] = 'গ্রীক (el)';
$langA['lang']['en'] = 'ইংরিজী (en)';
$langA['lang']['es'] = 'স্পেনীয় (es)';
$langA['lang']['fr'] = 'ফ্রেনচ (fr)';
$langA['lang']['hu'] = 'হাঙারীয় (hu)';
$langA['lang']['it'] = 'ইতালীয় (it)';
$langA['lang']['ja'] = 'জাপানি (ja)';
$langA['lang']['ko'] = 'কোরিয়ান (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'ওলন্দাজী (nl)';
$langA['lang']['pl'] = 'পোলিশ (pl)';
$langA['lang']['ro'] = 'রোমানীয় (ro)';
$langA['lang']['ru'] = 'রাশিয়ান';
$langA['lang']['tr'] = 'তুর্কী (tr)';
$langA['lang']['vi'] = 'ভিয়েতনামী (vi)';
$langA['lang']['zh'] = 'চীনা (zh)';
$langA['lang']['zh-cn'] = 'সরলীকৃত চীনা (zh-cn)';



