<?php

	$langA['googleMapKeys'] =						'Google মানচিত্র API চাবি';


	$langA['ADMIN_ONLY'] =							'এই পাতার অধিকারের জন্য আপনাকে প্রশাসক হতে হবে।';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'এই   প্রশাসনিক পাতাটি এখনও সংজ্ঞায়িত  নয় : <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'এগিয়ে চলার জন্য পাসওয়ার্ড টি নিশ্চিত করুন।';
	$langA['confirm_password'] =						'পসওয়ার্ড নিশ্চিত করণ';
	$langA['confirmation_failed'] =					'পসওয়ার্ড নিশ্চিত করণ প্রক্রিয়া ব্যর্থ। দয়া করে আবার চেষ্টা করুন।';
	
	$langA['run_scheduled_tasks'] =					'অনুসূচিত কার্য্য় চালান';
	$langA['FAILED'] = 								'দুঃখিত, অভিষ্ট কাজটি সফল হয়নি | পুনরায় চেষ্টা করুন |';
	$langA['SUCCESS'] = 								'অভিষ্ট কাজটি সফল হয়েছে |';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'অনুসন্ধানের বৈশিষ্ট্য';
	$langA['search_status'] =						'।নুসন্ধানের অবস্থা';
	$langA['search_enabled'] =						'অনুসন্ধান সক্রিয়';
	$langA['SEARCH_ENABLED'] =						'অন্বেষণ বৈশিষ্ট্য়টি নিষ্ক্রিয় করে দিলে "all_search" তথ্য়ভান্ডারটি খালি হয়ে যাবে | পরে, যদি আপনি পুনরায় অন্বেষণ সক্রিয় করিতে চান, "all_search"-টিকে পুনরায় ভরতে হবে |';
	$langA['disable'] =								'নিস্ক্রিয়';
	
	$langA['search_disabled'] =						'অনুসন্ধান নিস্ক্রিয়';
	$langA['SEARCH_DISABLED'] =						'অন্বেষণ আপাতত নিষ্ক্রিয় | অন্বেষণ সক্রিয় করিতে হলে একটি প্রক্রিয়া আবশ্য়ক যাহা দ্বারা "all_search" তথ্য়ভান্ডার সারণিতে তথ্য়ভান্ডারের সমস্ত ফাইল প্রবিষ্ট করা হয় | বড় আকারের তথ্য়ভান্ডারের জন্য় এই প্রক্রিয়াটি বেশ কিছু সময় নিতে পারে |';
	$langA['SEARCH_IS_DISABLED'] =					'অনুসন্ধান নিস্ক্রিয় করা এবং অনুসন্ধান সারণী ছেঁটে ফেলা হয়েছে';
	$langA['enable'] =								'সক্রিয়';
	
	$langA['FINISHED_ENTRIES'] =						'%s টি ভুক্তি সম্পন্ন , আরও বাকী %s';
	$langA['SEARCH_IS_ENABLED'] =					'ানুসন্ধান প্রকিয়া এখন সক্রিয়';


//
// adminConfig.php
//
	$langA['configuration'] =						'কনফিগারেশন';
	$langA['confighistory'] =						'কনফিগারেশন ইতিহাস';
	$langA['CONFIG_SAVING'] =						'নতুন বিন্য়াস সঞ্চয় করা হয়েছে আপাতমানগুলি না মিটিয়ে, যাতে পরে আবশ্য়ক হইলে আপনি পরিবর্তনগুলি উল্টে দিতে পারেন ...';
	$langA['CONFIG_STAT'] =							'সংরচনাতে %s সংশোধন করা হয়েছে';
	$langA['CONFIG_CONFIRM_REVERT'] =				'আপনি নিশ্চিত যে আপনি সংশোধন সংখ্য়া %s-তে প্রত্য়াগমন করিতে চান? এগিয়ে চলার জন্য় <tt>Save</tt> ক্লিক করুন';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'অনুপলব্ধ';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'এমন কিছু যা এই বাক্য়টির সঙ্গে প্রয়োগ করা যেতে পারে : "সার্ভারনাম১-এ স্বাগতম" |';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://সার্ভারনাম2';

//default user

	$langA['max_upload']['desc'] = 					'আপলোড করা ফাইলের সর্বোচ্চ আকার।';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'রূপে প্রযুক্ত করে ব্য়বহারকারীগণের পঞ্জীকৃত হ‍ইবার অনুমতি নেই |';
	
	$langA['maxErrorFileSize']['desc'] = 			'ত্রুটি ইতিবৃত্ত ফাইলের জন্য় অনুমত সর্বাধিক আকার | পূর্বনির্ধারিত 10,000 বাইট';
	$langA['errorEmail']['desc'] = 					'ই-মেইল ঠিকানা প্রদান করুন ';
	
	
	$langA['include']['desc'] = 						'প্রতিটি অনুরোধের সাথে একটি php ফাইল স্বয়ংক্রিয়ভাবে অঙ্গীভূত করিতে বলুন সফটওয়ারকে | ফাইলের নাম দেওয়া যেতে পারে কমা বিভক্ত করে এবং আপনার মূল নির্দেশিকার সাপেক্ষে |';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'সাধারণ সেটিংস';
	$langA['performance'] = 							'কার্য্য়নিষ্পাদন';
	
	$langA['serverName1']['alias'] = 				'Pretty সার্ভারের নাম';
	$langA['serverName2']['alias'] = 				'সার্ভারের নাম';
	$langA['serverName3']['alias'] = 				'সম্পূর্ণ সার্ভার Url';
	
	
	$langA['total_usage'] = 						'মোট ব্য়বহার';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'সর্বাধিক আপলোড';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'ভাষা';
	$langA['reservedWords']['alias'] = 				'সংরক্ষিত শব্দ';
	
	$langA['developer_aids'] = 						'নির্মাতা সহায়';
	$langA['maxErrorFileSize']['alias'] = 			'ত্রুটি ইতিবৃত্ত আকার';
	$langA['errorEmail']['alias'] = 					'ভুল ই-মেল';
	$langA['include']['alias'] = 					'PHP অঙ্গীভুত';

//
//	default user
//
	$langA['default_user_vars'] = 				'পূর্বনির্ধারিত ব্য়বহারকারী বিন্য়াস';
	
	$langA['defaultUser:homeTitle']['alias'] =		'মুখ্য়পৃষ্ঠা শীর্ষক';
	$langA['defaultUser:homeTitle']['desc'] =		'হোমপেজের শিরোনাম হিসাবে দেখাবে।';
	
	$langA['defaultUser:template']['alias'] =		'ব্যাবহারকারী প্রতিরূপ';
	$langA['defaultUser:template']['desc'] =		'Main/Home টি হলো পূর্বনির্ধারিত উইকিব্লগ টেমপ্লেট।';
	
	$langA['defaultUser:textareaY']['alias'] =		'পাঠ্য় ক্ষেত্রের উচ্চতা';
	$langA['defaultUser:textareaY']['desc'] =		'পাঠ্য় ক্ষেত্রের পূর্বনিধারিত উচ্চতা';
	
	$langA['defaultUser:isBlog']['alias'] =			'ব্লগ মুখ্য়পৃষ্ঠা ';
	$langA['defaultUser:isBlog']['desc'] =			'এটি ব্লগ styled হোমপেজ চালু এবং বন্ধ করবে।';
	
	$langA['defaultUser:timezone']['alias'] =		'সময়বলয়';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'সর্বাধিক ইতিবৃত্ত সারি';
	$langA['defaultUser:maxHistory']['desc'] =		'ইতিহাস সারির পূর্বনির্ধারিত সর্বোচ্চ মান।';

	$langA['defaultUser:pTemplate']['alias'] =		'পূর্বনির্ধারিত বিষয়জগত';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'ব্য়বহারকারী সমূহ';
	$langA['add_group'] = 'সমূহ সংযোজন করুন';
	$langA['unlimited'] = 'অসীমিত';
	$langA['group'] = 'সমূহ';
	$langA['related_links'] = 'সম্বদ্ধ যোগসুত্র';
	
//
//	registration
//	
	$langA['registration'] = 						'পঞ্জীকরণ';
	$langA['register:reqemail']['alias'] = 				'ই-মেল ঠিকানা আবশ্য়ক';
	$langA['register:register']['alias'] =				'দৃষ্য় শিরোনাম পঞ্জীকৃত করুন';
	$langA['register:registered']['alias'] =				'পঞ্জীকৃত দৃষ্য় শিরোনাম';
	$langA['register:captcha']['alias'] =				'Captcha ব্য়বহার করুন';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'ব্য়বহারকারী পরিসংখ্য়া';
	$langA['user_stats'] =							'ব্য়বহারকারী পরিসংখ্য়া';
	$langA['user_account'] =							'ব্য়বহারকারী খাতা';
	$langA['entries'] =								'প্রবিষ্টি';
	$langA['history Rows'] =							'ইতিবৃত্ত সারি';
	$langA['last_visit'] = 							'শেষ অভিগমন';
	
	$langA['users_found'] =							'পাওয়া ব্য়বহারকারী';
	$langA['showing_of_found'] =						'%s থেকে %s দেখানো';
	$langA['cpanel'] =								'নিয়ন্ত্রণ পট্টিকা';
	$langA['details'] =								'বিবরণ';
	
	$langA['within_the_hour'] =						'  < ১ ঘন্টা পূর্বে';
	$langA['hours'] =								'ঘন্টা';
	$langA['days'] =									'দিন';
	$langA['months'] =								'মাস';
	$langA['years'] = 								'বত্সর';
	$langA['ago'] = 									'পুর্বে';
	
	$langA['TIMEOUT'] = 								'<b>সময়োত্তীর্ণ ত্রুটি :</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>চেতাবনি:</b> "মুখ্য়" খাতা মুছে ফেলা যাবেনা';
	$langA['CONFIRM_DELETE_USER'] = 					'আপনি নিশ্চিত যে আপনি <b>%s</b> মুছে ফেলতে চান ?';
	$langA['CONFIRM_DELETE_USER2'] = 				'মুছে দিলে <i>সম্পূর্ণভাবে মুছে যাবে</i> খাতার সমস্ত ফাইল যাতে অঙ্গীভুত :';
	$langA['userfiles_directory'] = 					'ব্য়বহারকারী ফাইল নির্দেশিকা ';
	$langA['template_directory'] = 					'প্রতিরূপ নির্দেশিকা ';
	$langA['database_entries'] = 					'এবং সমস্ত তথ্য়ভান্ডার প্রবিষ্টি : পৃষ্ঠা, পৃষ্ঠাইতিহাস, টিপ্পণী ইত্য়াদি';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'তথ্য়কোষ প্রবিষ্টি মুছে ফেলা হয়েছে';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>চেতাবনি:</b> তথ্য়কোষ প্রবিষ্টি মুছে ফেলা যায়নি';
	
	$langA['DELETED_USERFILES'] = 					'ব্য়বহারকারী ফাইল নির্দেশিকা মুছে ফেলা হয়েছে';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>চেতাবনি:</b> ব্য়বহারকারী ফাইল নির্দেশিকা মুছে ফেলা যায়নি';
	
	$langA['DELETED_TEMPLATES'] = 					'প্রতিরূপ নির্দেশিকা মুছে ফেলা হয়েছে';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>চেতাবনি:</b> ব্য়বহারকারী প্রতিরূপ নির্দেশিকা মুছে ফেলা যায়নি';
	
	$langA['USER_DELETED'] = 						'%s সম্পূর্ণভাবে মুছে ফেলা হয়েছে ';
	$langA['USER_NOT_DELETED'] = 					'%s সম্পূর্ণভাবে মুছে ফেলা যায়নি ';
	$langA['DELETE_ACCOUNT'] = 						'এই খাতাটি সম্পূর্ণভাবে মুছে ফেলুন |';
	$langA['DISABLE_ACCOUNT'] = 					'ফাইল সম্পাদনা নিষ্ক্রিয় করে দিন |';
	$langA['SUSPEND_ACCOUNT'] = 					'সমস্ত ব্য়বহার নিলম্বিত করে দিন'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'সমস্ত বাহ্য় যোগসুত্রে "পশ্চাত্ধাবন নয়" সংযুক্ত করুন |';
	$langA['updated'] = 							'অদ্য়তন করুন';
	$langA['suspend'] = 							'নিলম্বিত করুন';
	$langA['activate'] = 							'সক্রিয় করুন';
	$langA['lost_page'] = 							'হারানো পাতা';
	$langA['suspended'] =							'নিলম্বিত';
	$langA['disabled'] =							'নিষ্ক্রিয়';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'ত্রুটি ইতিবৃত্ত মুছে ফেলা যায়নি';
	$langA['ERROR_LOG_DELETED'] = 					'ত্রুটি ইতিবৃত্ত মুছে ফেলা হয়েছে';
	$langA['ERROR_LOG_MAXED'] = 						'ত্রুটি ইতিবৃত্ত ফাইল নিজের সর্বাধিক আকার নিয়ে নিয়েছে, ফাইলটি খালি করে দিন যাহাতে script-টি ত্রুটি প্রবিষ্ট করা চালিয়ে রাখতে পারে | %s';


	$langA['select'] = 								'চয়ন করুন';
	$langA['description'] = 						'বর্ণনা';


//	adminPlugins
	$langA['data_types'] = 							'তথ্য় প্রকার'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'বর্তমান প্রকার';
	$langA['available_plugins'] = 					'উপলব্ধ প্লাগ-ইন';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'সবকটিতে টিক মার্কা দিয়ে দিন / সবকটি থেকে টিক মার্কা সরিয়ে দিন';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'অনলাইন';
	$langA['wbConfig']['online']['desc'] = 			'এটি ইন্টারনেট সংযোগের জন্র যথেষ্ঠ?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'প্লাবন অন্তরাল';
	$langA['wbConfig']['floodInterval']['desc'] = 	'দুটি সম্পাদনার মাঝে একজন বিনা অনুমতির ব্য়বহারকারীকে যত সেকেন্ড অপেক্ষা করিতে হবে |';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'অনাম ব্য়বহারকারিদের জন্য় JavaScript উন্নতির স্তর নির্ধারিত করে |';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'সম্ভাব্য় প্রবিষ্টি ত্রুটি সংশোধন করিতে HTML Tidy ব্য়বহার করুন |';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'সম্পূর্ণ বৈশিষ্ট্য়সহ';
	$langA['wbConfig']['allUsers']['desc'] = 		'সমস্ত পঞ্জীকৃত ব্য়বহারকারীদের নিজের ব্লগ রাখবার অনুমতি দিন |';
	
	$langA['wbConfig']['pUser']['desc'] = 			'অতিথি যদি ব্য়বহারকারী খাতা না দেন তাহা হ‍ইলে যে খাতাটো দেখানো হ‍ইবে সেটি চয়ন করুন |';
	$langA['wbConfig']['pUser']['alias'] = 			'পূর্বনির্ধারিত ব্য়বহারকারী';

	$langA['wbConfig']['sesslevel']['desc'] = 		'সত্র পুষ্টি করিবার কালে ব্য়বহারকারীর IP ঠিকানা কতটা পরীক্ষা করা হবে নির্ধারিত করে |';
	$langA['wbConfig']['sesslevel']['alias'] = 		'সত্রের স্তর';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

