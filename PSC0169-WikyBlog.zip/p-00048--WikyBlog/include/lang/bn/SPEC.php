<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'অনুমতি';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'এই বিশেষ পৃষ্ঠাটি এখনও পরিভাষিত হয়নি : <tt>%s</tt>';

//	control panel
$langA['general'] = 'সাধারণ';
$langA['attachments'] = 'সংলগ্নক';
$langA['account_info'] = 'খাতা তথ্য়';
$langA['error_log'] = 'ত্রুটি ইতিবৃত্ত';
$langA['advanced_search'] = 'উন্নত&nbsp;খোঁজ';
$langA['configuration'] = 'কনফিগারেশন';
$langA['search_options'] = 'অনুসন্ধানের বৈশিষ্ট্য';
$langA['data_types'] = 'তথ্য় প্রকার';
$langA['plugins'] = 'প্লাগ-ইন';
$langA['dynamic_content'] = ' 	 পরিবর্তনশীল বিষয়বস্তু';

$langA['tabs'] = 'ট্য়াব';
$langA['account_display'] = 'খাতা প্রদর্শন';
$langA['links'] = 'যোগসুত্র';
$langA['go_to'] = '%s-এ যান |';


$langA['user_statistics'] = 'ব্য়বহারকারী পরিসংখ্য়া';
$langA['database_info'] = 'তথ্য়ভান্ডার&nbsp;সূচনা';
$langA['user_preferences'] = 'ব্য়বহারকারী পছন্দ';
$langA['content_license'] = 'বিষয়বস্তু&nbsp;লাইসেন্স';
$langA['user_permissions'] = 'ব্য়বহারকারী অনুমতি';
$langA['default_page_options'] = 'পূর্বনির্ধারিত&nbsp;পৃষ্ঠা&nbsp;বিকল্প';
$langA['account_details'] = 'খাতা&nbsp;বিবরণ';
$langA['manage_images'] = 'ছবির&nbsp;প্রবন্ধন করুন';
$langA['manage_files'] = 'ফাইলের&nbsp;প্রবন্ধন করুন';
$langA['upload_files'] = 'ফাইল আপলোড করুন';
$langA['public_templates'] = 'সার্বজনীন&nbsp;প্রতিরূপ';
$langA['feeds'] = 'প্রকাশন-সংঘ প্রকাশন / সরবরাহ';
$langA['recently_modified'] = 'সম্প্রতি পরিবর্তিত';
$langA['recently_posted'] = 'সম্প্রতি প্রবিষ্ট';
$langA['user_edits'] = 'ব্য়বহারকারী সম্পাদন';

$langA['CONTROL_PANEL_1'] = 'এটি <tt>%s</tt>-এর নিয়ন্ত্রণপট্টিকা |';
$langA['CONTROL_PANEL_2'] = 'আপনি নিজের %s দেখিতে চান ?';

//specTemplates
$langA['pTemplate'] = 'মোড়ককরা বিষয়জগত';
$langA['custom_theme'] = 'পছন্দমতন পরিবর্তিত বিষয়জগত';
$langA['current_theme'] = 'বর্তমান বিষয়জগত';
$langA['TEMPLATES_UNAVAILABLE'] = 'মোড়ক প্রতিরূপ নির্দেশিকা অনুপলব্ধ';
$langA['themes']['default'] = 'পূর্বনির্ধারিত';
$langA['themes']['simple'] = 'সরল';
$langA['themes']['three_columns'] = '৩-টি কলাম';
$langA['themes']['floating'] = 'ভাস্য়মান';
$langA['themes']['graphic'] = 'চিত্র';

$langA['colors']['colors'] = 'বর্ণ';
$langA['colors']['black'] = 'কালো';
$langA['colors']['blue'] = 'নীল';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'খয়েরি';
$langA['colors']['green'] = 'সবুজ';
$langA['colors']['light_blue'] = 'হাল্কা নীল';
$langA['colors']['green'] = 'সবুজ';
$langA['colors']['tan'] = 'গাঢ় স্বর্ণাভ';
$langA['colors']['red'] = 'লাল';
$langA['colors']['orange'] = 'কমলা';
$langA['colors']['gray'] = 'ধূসরাভ';


$langA['customize_this_theme'] = 'এই বিষয়জগতটি পছন্দমতন পরিবর্তিত করে নিন';



//searchHidden.php
$langA['browse_hidden'] = 'লুকানো স্বচ্ছন্দে দেখুন';
$langA['editor_visible'] = 'সম্পাদকদের জন্য় দৃশ্য়';


//	WorkGroup.php
$langA['update_permissions'] = 'অনুমতি অদ্য়তন করুন';
$langA['username_or_ip'] = 'ব্য়বহারকারী নাম অথবা IP';
$langA['status'] = 'স্থিতি';
$langA['workgroup'] = 'কার্য্য়সমূহ';
$langA['admin'] = 'প্রবন্ধক';
$langA['full_owner'] = 'সম্পূর্ণ / অধিকারী';
$langA['ban'] = 'নিষিদ্ধ করুন';
$langA['banned'] = 'নিষিদ্ধ';

//	friends.php
$langA['friends'] = 'বন্ধু';
$langA['my_status'] = 'আমার অবস্থা';


$langA['EX_USERNAMES'] = 'উদাহরণ : <a>BillyJoe</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'আপনি কোন অনুমতি নির্দিষ্ট করেননি |';
$langA['view_users'] = 'দেখুন এই ব্য়বহারকারীর...';
$langA['change'] = 'পরিবর্তন করুন';
$langA['users'] = 'ব্য়বহারকারী';

$langA['USER_REMOVED'] = 'ব্য়বহারকারী <tt>%s</tt>-কে এই কার্য্য়সমূহ থেকে সরিয়ে দেওয়া হয়েছে |';
$langA['USER_NOT_REMOVED'] = 'ব্য়বহারকারী <tt>%s</tt>-কে এই কার্য্য়সমূহ থেকে সফলভাবে সরানো যায়নি | ';
$langA['ADDED_PERMISSIONS'] = '<tt>%s</tt>-র জন্য় অনুমতি সংযোজিত |';
$langA['UPDATED_PERMISSIONS'] = '<tt>%s</tt>-র জন্য় অনুমতি অদ্য়তন করা |';
$langA['NOT_A_USER'] = 'ব্য়বহারকারী নাম <tt>%s</tt> পাওয়া যায়নি |';
$langA['IP_NOT_ADDED'] = '<tt>%s</tt>-র জন্য় অনুমতি সংযোজিত/অদ্য়তন করা যায়নি |';
$langA['ALREADY_OWNER'] = '<b>চেতাবনী :</b> ব্য়বহারকারী <tt>%s</tt> আগে থেকেই এই খাতার অধিকারী |';
$langA['IP_WRONG_LEVEL'] = '<b>চেতাবনী :</b> IP ঠিকানাদের "কার্য্য়সমূহ"-এর উপরের বিশেষাধিকার দেওয়া যেতে পারে না |';
$langA['SET_PERMISSIONS'] = '"%s"-র জন্য় অনুমতি নির্দিষ্ট করিতে ইপ্সিত অবস্থা চয়ন করে "অনুমতি অদ্য়তন" ক্লিক করুন | ';


//	specLostPass
$langA['lost_password'] = 'পাসওয়ার্ড হারিয়ে গেছে';



//	specFileManager
$langA['file_manager'] = 'ফাইল প্রবন্ধক';
$langA['image_manager'] = 'ছবি প্রবন্ধক';
$langA['CONFIRM_FILE_DELETE'] = 'আপনি নিশ্চিত যে আপনি <b>%s</b> মুছে ফেলতে চান ?';
$langA['IMAGE_MANAGER_INTRO'] = 'এই চিত্রগুলি নিজের পৃষ্ঠাতে অঙ্গীভুত করিবার জন্য় আপনি বর্তমান wiki অথবা html দুরন্বয় ব্য়বহার করিতে পারেন | কিছু নির্দিষ্ট ফাইলপ্রকারের জন্য় (প্রতিরূপ, মানচিত্র...) আমরা সুপারিশ করি html দুরন্বয় |';
$langA['FILE_MANAGER_INTRO'] = 'এই ফাইলগুলি নিজের পৃষ্ঠাতে অঙ্গীভুত করিবার জন্য় আপনি বর্তমান wiki অথবা html দুরন্বয় ব্য়বহার করিতে পারেন | কিছু নির্দিষ্ট ফাইলপ্রকারের জন্য় (প্রতিরূপ, মানচিত্র...) আমরা সুপারিশ করি html দুরন্বয় |';
$langA['file_name'] = 'ফাইল নাম';
$langA['available_space'] = 'উপলব্ধ জায়গা';
$langA['UPLOAD_INTRO'] = 'জন্য় ফাইল সংলগ্নক এবং চিত্র আপলোড করুন |';
$langA['file_upload'] = 'ফাইল আপলোড	';
$langA['file_info'] = 'ফাইল সূচনা';
$langA['width'] = 'প্রস্থ';
$langA['height'] = 'উচ্চতা';
$langA['file_location'] = 'ফাইল অবস্থান';
$langA['wiki_syntax'] = ' 	 Wiki দুরন্বয়';
$langA['html_syntax'] = 'HTML দুরন্বয়';
$langA['append_to'] = 'সংযোজন এতে';
$langA['count'] = 'গুনতি';
$langA['total_size'] = 'মোট আকার';
$langA['images'] = 'ছবি';
$langA['overwrite_existing'] = 'বর্তমানের উপরে কলম চালিয়ে লিখুন';
$langA['compression'] = 'সঙ্কুচন';

$langA['NOT_AN_IMAGE'] = 'ফাইলটি চিত্র বলে মনে হয়না | ফাইলটি নিরীক্ষা করে নিয়ে পুনরায় চেষ্টা করুন | (%s) | ';
$langA['IMAGE_NOT_DELETED'] = '<tt>%s</i>-তে ফাইলটি মুছে ফেলা যায়নি |';
$langA['UPLOADED'] = 'ফাইল <tt>%s</tt> সফলভাবে আপলোড করা হয়েছে |';
$langA['UPLOADED_RENAMED'] = 'ফাইল <tt>%s</tt> আপলোড হয়েছে <tt>%s</tt> রূপে  | আপনি এটিকে <a %s>পুনঃনামকরণ করিতে পারেন %s-রূপে </a>|';
$langA['RENAMED'] = 'এই ফাইলটির সফলভাবে পুনঃনামকরণ করা হয়েছে |';
$langA['UPLOAD_FAILED'] = 'ফাইল <tt>%s</tt>-এর দ্বিত্বকরণ করা যায়নি |';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'ফাইল <tt>%s</tt> আপলোড করা যায়নি |<br/> ফাইলের আকার <tt>%s</tt> বাইটের নিম্নে হওয়া আবশ্য়ক |';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'যাঃ, <tt>%s</tt> কেবলমাত্র আম্শিকভাবে আপলোড হয়েছে | পুনরায় চেষ্টা করুন |';

//	specDefaultOptions
$langA['select_a_file_type'] = 'ফাইল প্রকার চয়ন করুন :';
$langA['default_options'] = 'পূর্বনির্ধারিত বিকল্প';
$langA['UNKNOWN_FILE_TYPE'] = 'অজানা পৃষ্ঠা প্রকার: <tt>%s</tt>|';

//	specAccountDetails
$langA['account'] = 'খাতা';
$langA['entries'] = 'প্রবিষ্টি';
$langA['average'] = 'গড়';
$langA['uploaded_files'] = 'আপলোড করা ফাইল';


//	searchTrash
$langA['deleted'] = 'মুছে ফেলা হয়েছে';
$langA['restore'] = 'পুনঃস্থাপন';
$langA['empty_trash'] = 'কুঁড়োখানা খালি করুন';
$langA['CONFIRM_EMPTY_TRASH'] = 'আপনি নিশ্চিত যে আপনি নিজের কুঁড়োখানা খালি করে দিতে চান ?';

$langA['DELETED_AFTER_30'] = '৩০ দিন উপরান্তে স্বয়ংক্রিয়ভাবে ফাইল মুছে যাবে |';
$langA['check_uncheck'] = 'সবকটিতে টিক মার্কা দিয়ে দিন / সবকটি থেকে টিক মার্কা সরিয়ে দিন';
$langA['DELETED_FILES'] = 'চয়নিত ফাইল সফলভাবে মুছে ফেলা হয়েছে |';
$langA['NOTHING_DELETED'] = 'কিছুই মুছে ফেলা হয়নি |';
$langA['DELETE_FILES'] = 'মোছে ফেলার জন্য় ফাইল চয়ন করুন |';
$langA['MAP_INVALID_PT'] = 'অবৈধ মানচিত্র তথ্য় : অবৈধ বিন্দু প্রতিরূপ';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'এই সাইটের অন্বেষণ বৈশিষ্ট্য় মনে হয় না সক্রিয় | সাইট প্রবন্ধক এই বৈশিষ্ট্য়টিকে সক্রিয় করিতে পারেন নিয়ন্ত্রণ পট্টিকার অন্বেষণ বিকল্প দ্বারা |';
$langA['search:'] = 'খুঁজুন ';
$langA['search_for'] = 'এই খুঁজুন ';
$langA['registered'] = 'পঞ্জীকৃত';
$langA['restricted'] = 'অবরুদ্ধ';
$langA['locked'] = 'তালাবন্ধ';
$langA['disabled'] = 'নিষ্ক্রিয়';
$langA['editing_option'] = 'সম্পাদনা বিকল্প';
$langA['comments_option'] = 'টিপ্পণী বিকল্প';
$langA['visibility_option'] = 'দৃশ্য়তা বিকল্প';
$langA['normal'] = 'স্বাভাবিক';
$langA['advanced'] = 'উন্নত';
$langA['relevance'] = 'প্রাসঙ্গিকতা';
$langA['SEARCH_ONE'] = 'অন্তত কোন একটি শব্দের জন্য়';
$langA['SEARCH_ALL'] = 'সব কটি শব্দের জন্য়';
$langA['SEARCH_EXACT'] = 'অবিকল বাক্য়াংশের জন্য়';
$langA['SEARCH_WITHOUT'] = 'শব্দবিহীন';
$langA['SEARCH_BEGIN'] = 'শব্দের অগ্রাংশ এমন';


//	searchKeywords
$langA['keyword_search'] = 'মুখ্য়শব্দ খোঁজ';
$langA['non_tagged_files'] = 'তকমাবিহীন ফাইল';

//	searchChangeLog
$langA['new'] = 								'নবীন';
$langA['DIFF_TITLE'] = 							'সবথেকে সাম্প্রতিক সংশোধনের সাথে তুলনা করুন';
$langA['indicates_syntax_error'] = 				'দুরন্বয় ত্রুটির ইঙ্গিতি |';
$langA['indicates_unchecked'] = 				'অপরিক্ষীত ফাইলের ইঙ্গিতি |';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'লাইসেন্স চয়ন করুন';
$langA['SELECT_LICENSE_DESC'] = 'একটি পপআপ দৃশ্য়পটে একটি Creative Commons ওয়েবপৃষ্ঠা খোলে';
$langA['DELETE_LICENSE_DESC'] = 'এটি আপনার বর্তমান বিষয়বস্তু লাইসেনস সরিয়ে দেবে |';
$langA['LICENSE_UPDATED'] = 'আপনার বিষয়বস্তু লাইসেনস সফলভাবে অদ্য়তন করা হয়েছে |';
$langA['LICENSE_DELETED'] = 'লাইসেন্স মুছে ফেলা হয়েছে';
$langA['LICENSE_DELETED2'] = 'লাইসেন্স আগে থেকেই মুছে ফেলা হয়েছে';
$langA['customize_license'] = 'নিজের লাইসেনসটি পছন্দমতন তৈরী করে নিন';

$langA['text_before'] = 'যোগসুত্রের অগ্র-পাঠ্য়';
$langA['text_after'] = 'যোগসুত্রের পশ্চাত্পাঠ্য়';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'নির্দিষ্টভাবে টীকা না দেওয়া থাকিলে, এই কাজটি অন্তর্ভুক্ত লাইসেনসের ';
$langA['LICENSE_TEXT_LINK'] = 'Creative Commons লাইসেনস';
$langA['LICENSE_TEXT_AFTER'] = '|';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'পুনঃব্য়বস্থাপনা করুন';
$langA['from'] = 'প্রেরক';
$langA['to'] = 'প্রাপক';
$langA['KEYWORDS_UPDATED'] = 'আপনার মুখ্য়শব্দ অদ্য়তন করা হয়েছে |';
$langA['KEYWORDS_EMPTY'] = 'আপনি এখনো পর্য্য়ন্ত মুখ্য়শব্দ সংযুক্ত কোন ফাইল নির্মান করেননি |';
$langA['REORGANIZE'] = 'এখানে, মুখ্য়শব্দের পুনরায় নামকরণ করিয়া আপনি নিজের ফাইলগুলির পুনঃগঠন করিতে পারেন |';

//watch
$langA['WATCH_UPDATED'] = 'আপনার <a %s>নিহারণসূচী</a> অদ্য়তন করা হয়েছে |';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'লেবেল';
$langA['description'] = 'বর্ণনা';
$langA['add_link'] = 'যোগসুত্র সংযোজন করুন';
$langA['link_groups'] = 'সমূহ সংযুক্ত করুন';
$langA['group'] = 'সমূহ';
$langA['name'] = 'নাম';
$langA['add_group'] = 'সমূহ সংযোজন করুন';
$langA['add_page'] = 'পৃষ্ঠা সংযুক্ত করুন';

$langA['limit'] = 'সীমা';
$langA['random'] = 'এলোমেলো';
$langA['order'] = ' 	 অনুক্রম';
$langA['LEAVE_EMPTY'] = 'অসীমের জন্য় রিক্ত ছেড়ে দিন';
$langA['unlimited'] = 'অসীমিত';
$langA['type'] = 'প্রকার';
$langA['auto_detect'] = 'স্বয়ং সন্ধান';
$langA['bookmarklet'] = 'চতুর বুকমার্ক';
$langA['move_up'] = 'উপরে উঠিয়ে দিন';
$langA['move_down'] = 'নিচে নামিয়ে দিন';
$langA['redirect'] = 'পুনঃপ্রেষিত করুন';
$langA['content_template'] = 'বিষয়বস্তু প্রতিরূপ';

