<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Permissions';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'This special page has not been defined yet: <tt>%s</tt>';

//	control panel
$langA['general'] = 'General';
$langA['attachments'] = 'Attachments';
$langA['account_info'] = '帐户信息';
$langA['error_log'] = 'Error Log';
$langA['advanced_search'] = 'Advanced&nbsp;Search';
$langA['configuration'] = '配置';
$langA['search_options'] = '搜索选项';
$langA['data_types'] = '数据类型';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Tabs';
$langA['account_display'] = '帐号显示';
$langA['links'] = '图像链接';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = '用户统计';
$langA['database_info'] = 'Database&nbsp;Information';
$langA['user_preferences'] = 'User Preferences';
$langA['content_license'] = 'Content&nbsp;License';
$langA['user_permissions'] = 'User Permissions';
$langA['default_page_options'] = 'Default&nbsp;Page&nbsp;Options';
$langA['account_details'] = 'Account&nbsp;Details';
$langA['manage_images'] = 'Manage&nbsp;Images';
$langA['manage_files'] = '管理文件&nbsp;';
$langA['upload_files'] = '上传文件';
$langA['public_templates'] = 'Public&nbsp;Templates';
$langA['feeds'] = 'Syndication / Feeds';
$langA['recently_modified'] = 'Recently Modified';
$langA['recently_posted'] = 'Recently Posted';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = '这是<tt>%s</tt>的控制面板。';
$langA['CONTROL_PANEL_2'] = 'Would you like to see your %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'The Package Templates directory is unavailable.';
$langA['themes']['default'] = '默认';
$langA['themes']['simple'] = 'Simple';
$langA['themes']['three_columns'] = 'Three Columns';
$langA['themes']['floating'] = '浮动';
$langA['themes']['graphic'] = 'Graphic';

$langA['colors']['colors'] = '颜色';
$langA['colors']['black'] = 'Black';
$langA['colors']['blue'] = '蓝色';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = '绿色';
$langA['colors']['light_blue'] = '淡蓝色';
$langA['colors']['green'] = '绿色';
$langA['colors']['tan'] = '黄褐色';
$langA['colors']['red'] = '红色';
$langA['colors']['orange'] = 'Orange';
$langA['colors']['gray'] = 'Gray';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = '浏览隐藏文件';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = '更新权限';
$langA['username_or_ip'] = '用户名或IP';
$langA['status'] = '状态';
$langA['workgroup'] = '工作组';
$langA['admin'] = 'Admin';
$langA['full_owner'] = 'Full / Owner';
$langA['ban'] = '屏蔽';
$langA['banned'] = '被屏蔽';

//	friends.php
$langA['friends'] = '好友';
$langA['my_status'] = '我的状态';


$langA['EX_USERNAMES'] = '例如：<a>BillyJoe</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = '您没有指定任何权限。';
$langA['view_users'] = 'View This User\'s...';
$langA['change'] = '更改';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = 'User <tt>%s</tt> was removed from this workgroup.';
$langA['USER_NOT_REMOVED'] = 'User <tt>%s</tt> was not successfully removed from this workgroup. ';
$langA['ADDED_PERMISSIONS'] = 'Added permissions for <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Updated permissions for <tt>%s</tt>.';
$langA['NOT_A_USER'] = '用户名<tt>%s</tt>没有找到。';
$langA['IP_NOT_ADDED'] = 'Could not add/update permissions for <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>Warning:</b> User <tt>%s</tt> is already the owner of this account.';
$langA['IP_WRONG_LEVEL'] = '<b>Warning:</b> IP addresses cannot be given privileges higher than "workgroup".';
$langA['SET_PERMISSIONS'] = 'To set permissions for "%s", select the desired status then click "Update Permissions".';


//	specLostPass
$langA['lost_password'] = '忘记密码';



//	specFileManager
$langA['file_manager'] = '文件管理';
$langA['image_manager'] = '管理图片';
$langA['CONFIRM_FILE_DELETE'] = '你确信要删除<b>%s</b>?';
$langA['IMAGE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these images in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['FILE_MANAGER_INTRO'] = '您可以使用wiki的语法或者是html语法在页面调用这些文件。对于某些文件类型(模板，地图等等)我们推荐您用html语法。';
$langA['file_name'] = '文件名';
$langA['available_space'] = '可用空间';
$langA['UPLOAD_INTRO'] = '上传图片并加入页面';
$langA['file_upload'] = '文件上传';
$langA['file_info'] = '文件信息';
$langA['width'] = '宽度';
$langA['height'] = '高度';
$langA['file_location'] = '文件位置';
$langA['wiki_syntax'] = 'Wiki语法';
$langA['html_syntax'] = 'HTML语法';
$langA['append_to'] = '依赖';
$langA['count'] = '次数';
$langA['total_size'] = '文件大小';
$langA['images'] = '图片';
$langA['overwrite_existing'] = 'Overwrite Existing';
$langA['compression'] = 'Compression';

$langA['NOT_AN_IMAGE'] = '此文件不是图片。请检查后重新上传。(%s)。 ';
$langA['IMAGE_NOT_DELETED'] = '不能删除此文件<tt>%s</i>。';
$langA['UPLOADED'] = '文件<tt>%s</tt>上传成功。';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = '文件重命名名成功。';
$langA['UPLOAD_FAILED'] = '文件复制失败：<tt>%s</tt>。';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = '选择文件类型：';
$langA['default_options'] = '默认选项';
$langA['UNKNOWN_FILE_TYPE'] = '未知页面类型：<tt>%s</tt>。';

//	specAccountDetails
$langA['account'] = '总计';
$langA['entries'] = '条目';
$langA['average'] = '平均';
$langA['uploaded_files'] = '已上传文件';


//	searchTrash
$langA['deleted'] = '已删除';
$langA['restore'] = '恢复';
$langA['empty_trash'] = '清空回收站';
$langA['CONFIRM_EMPTY_TRASH'] = '您确信要清空回收站吗？';

$langA['DELETED_AFTER_30'] = '30天后自动删除文件。';
$langA['check_uncheck'] = 'Check All / Uncheck All';
$langA['DELETED_FILES'] = '选中文件已被成功删除。';
$langA['NOTHING_DELETED'] = '未删除任何文件。';
$langA['DELETE_FILES'] = '请选择要删除的文件。';
$langA['MAP_INVALID_PT'] = '无效地图数据：无效定点格式';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = '本站搜索功能尚未开启。管理员可通过控制面板中的搜索设置开启';
$langA['search:'] = '搜索： ';
$langA['search_for'] = '搜索： ';
$langA['registered'] = '已注册';
$langA['restricted'] = '已受限';
$langA['locked'] = '已锁定';
$langA['disabled'] = '已禁用';
$langA['editing_option'] = '编辑选项';
$langA['comments_option'] = '评论选项';
$langA['visibility_option'] = '隐藏选项';
$langA['normal'] = '标准';
$langA['advanced'] = '高级';
$langA['relevance'] = '适中';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'For all of the words';
$langA['SEARCH_EXACT'] = 'For the exact phrase';
$langA['SEARCH_WITHOUT'] = 'Without the words';
$langA['SEARCH_BEGIN'] = 'For words beginning with';


//	searchKeywords
$langA['keyword_search'] = '关键字搜索';
$langA['non_tagged_files'] = '未标签文件';

//	searchChangeLog
$langA['new'] = 								'新建';
$langA['DIFF_TITLE'] = 							'比较与最近修订版本的异同';
$langA['indicates_syntax_error'] = 				'Indicates a syntax error.';
$langA['indicates_unchecked'] = 				'Indicates an unchecked file.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = '选择授权';
$langA['SELECT_LICENSE_DESC'] = '在新窗口中打开 Creative Commons 站点。';
$langA['DELETE_LICENSE_DESC'] = '移除当前设定的内容许可。';
$langA['LICENSE_UPDATED'] = '内容许可已更新成功';
$langA['LICENSE_DELETED'] = '内容许可移除成功';
$langA['LICENSE_DELETED2'] = '容许可已被移除';
$langA['customize_license'] = '自定义内容许可';

$langA['text_before'] = '文字在链接之前';
$langA['text_after'] = '文字在链接之后';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = '除非特别申明，该文档遵循 ';
$langA['LICENSE_TEXT_LINK'] = '创作共用授权';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = '重新整理';
$langA['from'] = '从';
$langA['to'] = '到';
$langA['KEYWORDS_UPDATED'] = '您的关键字已经更新完毕。';
$langA['KEYWORDS_EMPTY'] = '您还没有创建任何关键字。';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = '描述';
$langA['add_link'] = 'Add Link';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Group';
$langA['name'] = 'Name';
$langA['add_group'] = '增加新的组';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Limit';
$langA['random'] = 'Random';
$langA['order'] = 'Order';
$langA['LEAVE_EMPTY'] = 'Leave empty for no limit';
$langA['unlimited'] = 'Unlimited';
$langA['type'] = 'Type';
$langA['auto_detect'] = 'Auto Detect';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'Move Up';
$langA['move_down'] = 'Move Down';
$langA['redirect'] = 'Redirect';
$langA['content_template'] = 'Content Template';

