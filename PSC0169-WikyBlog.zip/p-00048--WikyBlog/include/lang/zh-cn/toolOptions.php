<?php

//	toolOptions.php
$langA['properties'] = '属性';
$langA['file_name'] = '文件名';
$langA['update_from'] = 'Update from';
$langA['COPY_SYSTEM_FILES'] = 'Copy the most recent system help files from %s.';

$langA['EDITING_OPTIONS'] = 'Control who is allowed to edit this file.';
$langA['registered_users'] = '注册用户';
$langA['restricted_to'] = 'Restricted To ';
$langA['admin_only'] = 'Admin Only';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Owner Only';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = 'Visibility';
$langA['VISIBILITY_OPTIONS'] = 'Hide this file if you\'re not ready to show it to the world.';
$langA['visible'] = '可见';

$langA['COMMENT_OPTIONS'] = '禁用评论';
$langA['enabled'] = '已启用';
$langA['disabled'] = '已禁用';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = '其他';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = '从Blog中删除';
$langA['repost'] = '重新发布';
$langA['copy_to'] = '复制到';
$langA['send_to_trash'] = '发送到回收站';
$langA['default_options'] = '默认选项';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = '将%s设置为此数据类型。'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'This file was reposted.';
$langA['NOT_REPOSTED'] = '<b>Error:</b> Could not repost this file.';
$langA['OPTIONS_NOT_CHANGED'] = 'The file options were not changed.';
$langA['OPTIONS_UPDATED'] = 'The file options were updated successfully.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not <b>警<b>警告:</b> 文件选项没有更新。';

$langA['redirect'] = 'Redirect';
$langA['REMOVE_REDIRECT'] = 'If you no longer want this file to redirect, you can either delete or edit it. ';


$langA['UNCHECKED_REMOVED'] = '此文件的"Unchecked"已经被删除。';

$langA['NO_KEYWORDS'] = '此文件还没有任何关键字。您现在需要<a %s>添加关键字</a>或者<a %s>添加此文到blog</a>吗?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'User&nbsp;Permissions';
