<?php
//
//	WBmap.php
//
$langA['loading_map'] = '载入地图...';
$langA['MAP_DEBUG_O'] = 'An error occured while loading this page and the map you requested could not be shown.<p> </p>A log of the error has been created and the website administrators should resolve the issue soon.';
$langA['MAP_DEBUG_1'] = 'The Google Maps API does not appear to be compatible with your browser.<p>If you know your browser is compatible, make sure the correct map key is being used and that you are connected to the internet.</p><p>You can <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">get more information</a> about browser support from google.com.</p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>警告:</b> 地图需要JavaScript支持。</p><p>  您的浏览器似乎目前没有启用JavaScript，请为您的浏览器启用JavaScript支持并刷新此页面。 </p>';