<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = '文件名没有改变。';
$langA['NOT_RENAMED'] = 'This file could not be renamed to <tt>%s</tt>. Please make sure this file does not already exist.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = '不能重命名此文件。';
$langA['redirected_to'] = 'Redirected to';
$langA['RENAMED'] = '文件重命名名成功。';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b>已经恢复。 ';
$langA['ERROR_RESTORING'] = '<b>Error:</b> Could not restore the file at <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = '文件已经恢复。';
$langA['WAS_DELETED'] = '<b>%s</b> was deleted. This file will be stored in the %s for 30 days.';
$langA['ERROR_DELETING'] = '<b>Error:</b> Could not delete the file at <tt>%s.</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt>已删除。';
