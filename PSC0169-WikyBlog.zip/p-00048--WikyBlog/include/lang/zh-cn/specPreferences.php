<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'Your preferences have not changed from the values already saved.';
$langA['INVALID_PREFS'] = '<b>Warning:</b> Could not save your preferences with the supplied values.';

$langA['EMAIL_PREFS'] = '如果您忘记密码有用。';

$langA['LANG_PREFS'] = '选择语言。';

$langA['javascript_preferences'] = 'JavaScript Preferences';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Turn on/off JavaScript enhancements. Some features will not work properly when JavaScript is disabled.';

$langA['time_zone'] = '时区';
$langA['TIME_ZONE_PREFS'] = 'Time difference between your local time and the server time: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'Server time is now %s. <br/>Your adjusted time is %s.';

$langA['sig'] = '签名';
$langA['SIGNATURE'] = '使用wiki的语法自定义您的签名。';


$langA['home_title'] = '主页标题';
$langA['HOME_TITLE_PREFS'] = 'The title to be displayed on your home page.';

$langA['blog_styled_frontpage'] = 'Blog Styled Frontpage';
$langA['BLOG_PREFS'] = 'Display the home page as a blog.';

$langA['blogT'] = 'blog类型';
$langA['BLOG_TYPE'] = '为blog选择可用的数据类型。';

$langA['selective_blogging'] = 'Selective Blogging';
$langA['SELECTIVE_BLOGGING'] = 'Selective Blogging allows you to blog only those pages you want displayed on the front page.';

$langA['blog_count'] = 'Blog Count';
$langA['BLOG_COUNT'] = 'The number of entries to show on your blog.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = '在每个页面底部显示“分享”链接。';

$langA['ihelp'] = 'Help Links';
$langA['IHELP'] = 'Show help links.';

$langA['uServices'] = '更新通知服务。';
$langA['UPDATE_SERVICES'] = '当您发布一篇文章时，会自动通知更新服务。每行写一个更新通知服务的地址。';
$langA['BAD_UPDATE_SERVICES'] = '更新服务的URI不合法';


$langA['VIEW_THEME'] = '<a %s>Edit or copy</a> this theme.';

$langA['quick_comment'] = '快速评论';
$langA['QUICK_COMMENT'] = 'When on, a form will be displayed at the top of talk pages for faster commenting.';

$langA['textarea rows'] = '文本区域行数';
$langA['TEXTAREA_ROWS_PREFS'] = 'Determines the height of editing areas.';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'Limits the number of history rows stored on the server for each file.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Maximum %s.';

$langA['tab_limit'] = 'Tab Limit';
$langA['TAB_LIMIT'] = 'JavaScript will automatically close tabs once the number of opened tabs has reached this limit. Defaults to 7. Set to 1000 or more if you don\'t want JavaScript to manage your tabs.';

$langA['EXTERNAL_LINKS'] = '当启用时，外部链接将在浏览器的新窗口打开。';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = '快捷键';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = '保存参数';

$langA['CONFIRM_CHANGE'] = 'Are you sure you want to change your preferences?';
$langA['preference'] = '参数';
$langA['old_value'] = 'Old Value';
$langA['new_value'] = 'New Value';

$langA['changes'] = '更改';
$langA['PREFS_CHANGED'] = 'Your preferences have been updated.<br/> Below is a summary of the values that have changed.';


//check edit
$langA['anonymous'] = '匿名用户';
$langA['fEdits'] = '编辑标记';
$langA['FLAG_EDITS'] = 'Edits made by users with status at or below the selected status will be flagged as "Unchecked" until it is reviewed by the account owner.';

//save all edits
$langA['saveAll'] = 'Log All Edits';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
