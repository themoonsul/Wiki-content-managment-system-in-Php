<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = '文件';
$langA['edit'] = '编辑';
$langA['edits'] = 'Edits';
$langA['view_source'] = '查看源代码';
$langA['talk'] = '讨论';
//$langA['reply'] = 'Reply';
$langA['history'] = '历史';
$langA['diff'] = '比对';
$langA['watch'] = '监视';
$langA['unwatch'] = 'Unwatch';
$langA['options'] = '选项';


$langA['messages'] = '消息';
$langA['current'] = '当前';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Possible';

$langA['DEFAULT_CONTENT'] = '这是一个新的文件，您想现在就编辑[[%s?cmd=edit|create it]]它吗？'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = '这是一个新文件。要创建此文件，你需要以适当的权限来登录。';

$langA['NOT_OWNER'] = '你没有适当的权限来访问此特性。';
$langA['LONG_PATH'] = 'The title for this file was too long and has been truncated.';
$langA['EMPTY_CONTENT'] = 'Content is a required field';
$langA['INCOMPLETE_PATH'] = 'The supplied path is incomplete.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Sorry, the website administrator has disabled user blogging. To create a bliki with the same features found here, visit <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = '这是隐藏文件。 ';
$langA['DELETED_FILE'] = 'This file is currently in the "trash". If you are the owner of this account, you can restore this file via your control panel.';
$langA['PROTECTED_FILE'] = 'This file is protected. Any changes made to this file were not saved.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = '文字链接';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'This page redirects to %s.';

//	Data Types
$langA['all'] = '所有';
$langA['page'] = 'Page';
$langA['comment'] = '评论';
$langA['map'] = '地图';
$langA['template'] = '模板';
$langA['help'] = '帮助';
$langA['skeleton'] = 'Skeleton';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = '评论';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = '页面';
$langA['CLASScomment'] = '评论';
$langA['CLASSmap'] = '地图';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = '帮助';
$langA['IS_CONTENT_TEMPLATE'] = '这个文件是您的内容模板，它不会显示在您的blog页面上。';


$langA['seconds'] = ' 秒';
$langA['queries'] = ' 查询';

$langA['QUERY_TIME'] = ' for queries';
$langA['INVALID_PATH'] = 'Invalid file path supplied: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Invalid Request.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = '创建一个新帮助文件';



//	Special Files that need to be in with main lang file
$langA['browse'] = '浏览';
$langA['change_log'] = '更改历史';
$langA['control_panel'] = '控制面板';
$langA['administration'] = 'Administration';
$langA['preferences'] = '参数设置';
$langA['watchlist'] = 'Watchlist';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = '搜索';
$langA['orphaned_files'] = '孤儿文件';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = '外部链接';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'More Recent Posts.';
$langA['NEED_INTERNET'] = 'This feature is only available for systems connected to the internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Warning:</b> Cookies are required to continue. Refresh this page if you have cookies enabled.';
$langA['LOGIN_REQUIRED'] = 'You must be signed in to use this feature.';

$langA['ENTER_USERNAME'] = '请输入您的用户名。';
$langA['ENTER_PASSWORD'] = '请输入您的密码。';
$langA['LOGGED_OUT'] = '您已成功退出。';
$langA['AUTO_LOGOUT'] = '您的登录已超时。';

$langA['LOGIN_FAILED'] = 'Log in failed: Incorrect Password.<ul><li>Is Caps Lock on?<li> Have you %sforgotten your password%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'The maximum number of %s login attempts has been exceeded. You will not be allowed to login for the next %s minutes.';
						
$langA['create_new'] = 'Create&nbsp;New ';
$langA['remember_me'] = '提醒我';
$langA['log_out'] = '退出';
$langA['log_in'] = '登录';

//	SAVING 
$langA['syntax_error'] = '语法错误';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Syntax Error:</b> Unable to Save/Display the most recent changes to this file due to an incompatible syntax.';
$langA['SYNTAX_FIXED'] = 'The syntax error has been fixed.';


$langA['NO_CHANGES'] = 'No changes were made to this file. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = '无法保存这个文件。(%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Changes to this file have been saved.';
$langA['HIDDEN_FILE3'] = '<b>Note:</b> This is a hidden file, therefore tags for this file will not be included in the user menu totals.';

$langA['VERSION_CONFLICT'] = 'Warning: We could not save your changes because we detected a version conflict.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Editing has been limited to one file every %s seconds. Please try again in %s seconds.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = '保存设置';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = 'difference(s)';
$langA['line_num'] = 'Line #';


//	toolHistory1.php
$langA['revision'] = '版本 ';
$langA['revision_as_of'] = 'Revision as of ';
$langA['revision_num_as_of'] = 'Revision %s as of %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = '编辑版本';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = '恢复到版本#';
$langA['SET_USER_PERMISSIONS'] = 'Set your permissions for this user: '; 
$langA['compare_with_prev'] = '← Compare with Previous Revision';
$langA['current_revision'] = '目前版本';
$langA['compare_with_next'] = 'Compare with Next Revision →';
$langA['lines'] = 'Lines';
$langA['text'] = '文本';
$langA['vs'] = ' vs ';
$langA['content'] = '内容';
$langA['your_text'] = '您的文字';
$langA['show_prev_revision'] = '← Revision %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revision %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Warning:</b> You are not editing the most recent version of this page.<br /> Saving will replace the newest version with this out-of-date version.';
$langA['SELECT_TWO_VERSIONS'] = 'Please select two distinct versions to compare.';
$langA['NO_UNIQUE_REVISION'] = 'Could not find a unique revision for this request.';
$langA['INVALID_REVISION'] = '<b>Error:</b> Invalid Revision Number.';
$langA['NO_DIFFERENCES'] = 'The two revisions being compared are identical.';
$langA['NO_REVISIONS'] = 'There must be two distinct revisions before a comparison can be made.';
$langA['NON_EXISTANT'] = '文件不存在。';

//	toolEditPage.php
$langA['bold_text'] = '黑体';
$langA['italic_text'] = '斜体';
$langA['headline_text'] = 'Insert Heading';
$langA['title'] = 'Title';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = '内部链接';
$langA['link'] = '链接';
$langA['external_link'] = '外部链接';
$langA['embed_image'] = 'Embed Image';
$langA['find_images'] = 'Find Images';
$langA['image'] = '图片';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'Insert non-formatted text here';
$langA['signature'] = '签名';
$langA['SIGNATURE_TEXT'] = '插入您的签名';
$langA['preview'] = '预览';
$langA['PREVIEW_TEXT'] = '预览更改[%s-p]';
$langA['PREVIEW_WARN'] = 'This is only a preview. Your changes have not been saved yet!';
$langA['SAVE_TEXT'] = '保存更改[%s-s]';
$langA['reset'] = '重设参数';
$langA['RESET_TEXT'] = 'Reset this form to it\'s original state [%s-c]';
$langA['changes'] = '更改';
$langA['CHANGES_TEXT'] = 'Show the changes you\'ve made to this file. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organize your posts with comma separated keywords'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = '标签';
$langA['edit_summary'] = '编辑摘要';
$langA['syntax_warning'] = '语法警告';
$langA['NO_IMAGES'] = 'No Images Found';
$langA['insert_emoticons'] = '插入表情';
$langA['upload'] = '上传';



//searchHistory
$langA['show'] = '显示';
$langA['hide'] = 'Hide';
$langA['compare'] = '比较';
$langA['timeline'] = '时间轴';
$langA['summary'] = '摘要';
$langA['COMPARE_REVISONS'] = '比较选定的版本。';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = '不支持此文件类型。';


//	SEARCH
$langA['next'] = '下一页';
$langA['previous'] = '上一页';
$langA['order_by'] = '排序：';
$langA['ascending'] = '升序';
$langA['descending'] = '降序';
$langA['search_from'] = 'Search From: ';
$langA['all_users'] = '所有用户';
$langA['user'] = 'User';
$langA['from_file_type'] = 'Search From File Type: ';
$langA['read_more'] = '阅读更多';
$langA['words'] = ' words';

$langA['RESULTS'] = 'Results %s to %s of %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'No entries found for the search criteria.';

//searchTalk
$langA['add_comment'] = 'Add New Topic';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Could not include warning. Poorly formatted data for duplicate entry.';
$langA['duplicate_entry'] = 'Duplicate Entry';
$langA['DUPLICATE_ENTRY'] = 'This is a duplicate entry for the page found at %s. <br/>Any non redundant information found here should be transfered to the original before this page is deleted.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = '没有找到： '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Error:</b><br /> An error occurred while executing this script.<br /> Please check your request and we will attempt to debug the script with the error log. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Cannot delete the default template.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'The specified theme was invalid.';

//
//	CLASSmap
//
$langA['new_marker']='New Marker';
$langA['new_route']='New Route';
$langA['SAVE_HEADER']='Before Saving Remember';
$langA['save_map']='Save Map';
$langA['continue_editing']='Continue Editing';
$langA['miles/km'] = 'miles/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>This is a new map.</b><br/> To create/edit this map, click "Edit" above.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = '对不起，您没有权限编辑地图。';
$langA['play'] = 'Play';
$langA['stop'] = '停止';
$langA['import'] = '导入';
$langA['export'] = '导出';
$langA['gpx_data'] = 'GPX数据';
$langA['gpx_exchange_format'] = 'GPX交换类型';
$langA['CLICK_EDIT'] = 'To edit the map, click "edit" above';


//	smileys
$langA['smiles'][':D'] = 'Very Happy';
$langA['smiles'][':)'] = 'Smile';
$langA['smiles'][':('] = 'Sad';
$langA['smiles'][':o'] = 'Surprised';
$langA['smiles'][':shock:'] = 'Shocked';
$langA['smiles'][':?'] = 'Confused';
$langA['smiles']['8)'] = 'Cool';
$langA['smiles'][':lol:'] = 'Laughing';
$langA['smiles'][':x'] = 'Mad';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Embarassed';
$langA['smiles'][':cry:'] = 'Crying or Very sad';
$langA['smiles'][':evil:'] = 'Evil or Very Mad';
$langA['smiles'][':twisted:'] = 'Twisted Evil';
$langA['smiles'][':roll:'] = 'Rolling Eyes';
$langA['smiles'][':wink:'] = 'Wink';
$langA['smiles'][':!:'] = 'Exclamation';
$langA['smiles'][':?:'] = '问题';
$langA['smiles'][':idea:'] = '想法';
$langA['smiles'][':arrow:'] = '箭头';
$langA['smiles'][':|'] = '中立';
$langA['smiles'][':mrgreen:'] = 'Mr. Green';

//
//	General Language
//
$langA['or'] = '或者';
$langA['username'] = '用户名';
$langA['password'] = '密码';
$langA['email'] = '电子邮件';
$langA['register'] = '注册';
$langA['cancel'] = '取消';
$langA['language'] = '语言';
$langA['use'] = 'Use';
$langA['copy'] = '复制';
$langA['rename'] = '重命名';

$langA['on'] = 'On';
$langA['partial'] = '部分';
$langA['off'] = 'Off';
$langA['save'] = '保存';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = '没有定义';
$langA['homepage'] = 'Homepage';
$langA['home'] = '主页';
$langA['go'] = '提交';
$langA['user_menu'] = 'User Menu';

$langA['last_modified'] = '上次修改';
$langA['LAST_MODIFIED'] = 'Last modified %s by %s.';//%s replaced with date and username
$langA['accessed_times'] = 'Accessed %s times';// %s replaced with a number
$langA['modified'] = '修改';
$langA['posted'] = '提交';
$langA['created'] = '创建';
$langA['hidden'] = '隐藏';
$langA['what_links_here'] = '链入页面';
$langA['share'] = '分享';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'The file must be saved before you can perform this operation.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = '大小 ';
$langA['bytes'] = '字节';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = '更新';
$langA['editing'] = '编辑';
$langA['workgroup'] = '工作组';
$langA['BROWSE_HIDDEN'] = '查找隐藏文件';

$langA['delete'] = '删除';
$langA['confirm_delete'] = '确认删除';
$langA['continue'] = '继续';
$langA['back'] = '后退';
$langA['close'] = 'Close';
$langA['view'] = '查看';
$langA['empty'] = '-空-';
$langA['none'] = 'None';
$langA['total'] = '总共 ';
$langA['files'] = '文件';
$langA['other'] = '其他';
$langA['trash'] = '回收站';
$langA['flagged'] = 'Flagged';

$langA['today'] = '今天';
$langA['yesterday'] = '昨天';
$langA['days_ago'] = ' 天前';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = '更多';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = '星期日';
$langA['date_l'][1] = '星期一';
$langA['date_l'][2] = '星期二';
$langA['date_l'][3] = '星期三';
$langA['date_l'][4] = '星期四';
$langA['date_l'][5] = '星期五';
$langA['date_l'][6] = '星期六';

$langA['date_D'][0] = 'Sun';
$langA['date_D'][1] = 'Mon';
$langA['date_D'][2] = 'Tue';
$langA['date_D'][3] = 'Wed';
$langA['date_D'][4] = 'Thu';
$langA['date_D'][5] = 'Fri';
$langA['date_D'][6] = 'Sat';


$langA['date_F'][1] = '1月';
$langA['date_F'][2] = '2月';
$langA['date_F'][3] = '3月';
$langA['date_F'][4] = '4月';
$langA['date_F'][5] = '5月';
$langA['date_F'][6] = '6月';
$langA['date_F'][7] = '7月';
$langA['date_F'][8] = '8月';
$langA['date_F'][9] = '9月';
$langA['date_F'][10] = '10月';
$langA['date_F'][11] = '11月';
$langA['date_F'][12] = '12月';

$langA['date_M'][1] = '1月';
$langA['date_M'][2] = '2月';
$langA['date_M'][3] = '3月';
$langA['date_M'][4] = '4月';
$langA['date_M'][5] = '5月';
$langA['date_M'][6] = '6月';
$langA['date_M'][7] = '7月';
$langA['date_M'][8] = '8月';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = '10月';
$langA['date_M'][11] = '11月';
$langA['date_M'][12] = '12月';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabic (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = '德语(de)';
$langA['lang']['el'] = 'Greek (el)';
$langA['lang']['en'] = '英语(en)';
$langA['lang']['es'] = 'Spanish (es)';
$langA['lang']['fr'] = '法语(fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italian (it)';
$langA['lang']['ja'] = '日文(ja)';
$langA['lang']['ko'] = 'Korean (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Dutch (nl)';
$langA['lang']['pl'] = '波兰语(pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Russian (ru)';
$langA['lang']['tr'] = '土耳其语(tr)';
$langA['lang']['vi'] = '越南语(vi)';
$langA['lang']['zh'] = 'Chinese (zh)';
$langA['lang']['zh-cn'] = 'Chinese Simplified (zh-cn)';



