<?php
$langA['ILLEGAL_USERNAME'] = 'The Username cannot include the following characters: %s';
$langA['LONG_USERNAME'] = '用户名太长。';	
$langA['SHORT_USERNAME'] = '用户名太短。';
$langA['USER_TAKEN'] = '请选择别的用户名。<tt>%s</tt> 已经被别人使用。 ';
$langA['USERNAME_ALL_DIGITS'] = '用户名不能全都是数字。';
$langA['PASSWORDS_DIFFERENT'] = '密码不匹配。';
$langA['SHORT_PASSWORD'] = '密码太短。';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = '注册';
$langA['welcome_to'] = '欢迎 ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = '至少5个字符';
$langA['confirm_password'] = '确认密码';
$langA['REG_CONFIRM_PASS'] = '和上面的一样。';
$langA['REG_EMAIL'] = '不是必须的，当您忘记密码时有用。';
$langA['REQUIRED_FIELD'] = '必填为项。';

$langA['REGISTRATION_TEXT'] = '注册很快，而且是免费的，并且有很多好处...';
$langA['REG_A_USER_PAGE'] = '/UserName/Your_Pages';
$langA['REG_A_MAP_PAGE'] = '/Map/Username/Your_Maps';

//login
$langA['LOGGED_IN'] = 'You are logged in as <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'The supplied username does not exist. Would you like to register %s.';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Activate your account now.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Your account has been activated.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
