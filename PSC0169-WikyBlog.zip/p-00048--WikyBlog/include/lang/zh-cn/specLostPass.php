 <?php

$langA['CHANGE_PASS_INTRO'] = 'To change your password, we first need to send you a "Permission Key" so that you may access this restricted feature. Once you have received the key, return to this page and enter the information below. Please note, your "Permission Key" will only work for your Username.';

$langA['next_step'] = '下一步';

$langA['PASS_EMAIL_SUBJECT'] = 'Permission Key for %s.';
$langA['PASS_EMAIL_TEXT'] ='Your permission key for %s is %s.';

$langA['get_your_key'] = 'Get Your Permission Key';
$langA['GET_YOUR_KEY'] = 'Your key will be sent to the email address you provided when registering.';

$langA['send_key'] = 'Send Permission Key';

$langA['change_password'] = '更改密码';
$langA['permission_key'] = 'Permission Key';
$langA['new_password'] = '新密码';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = 'Password Change failed: Incorrect Permission Key or Username';
$langA['PASSWORD_CHANGED'] = '<tt>%s</tt>的密码已经成功更新.';
$langA['PROVIDE_PASSWORD'] = '您必须提供一个新密码。';
$langA['PROVIDE_PERMISSION_KEY'] = 'You must provide a Permission Key to change your password';
$langA['PERMISSION_KEY_SENT'] = 'Permission Key sent successfully. Retrieve the key form your email and use it to change your password using the form below.';
$langA['PERMISSION_KEY_NOT_SENT'] = 'Failed to send Permission Key to the provided email address, please contact the website administrator for additional help.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = 'An email address was not provided for this account. Please contact the website administrator for additional help.';

