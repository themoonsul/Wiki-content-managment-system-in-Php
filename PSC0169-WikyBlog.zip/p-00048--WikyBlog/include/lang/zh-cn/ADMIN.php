<?php

	$langA['googleMapKeys'] =						'Google Maps API Key';


	$langA['ADMIN_ONLY'] =							'管理员才能访问此页。';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'管理页面没有定义： <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'请再次输入您的密码。';
	$langA['confirm_password'] =						'确认密码';
	$langA['confirmation_failed'] =					'密码验证失败，请再试一次。';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'搜索选项';
	$langA['search_status'] =						'搜索状态';
	$langA['search_enabled'] =						'搜索启用';
	$langA['SEARCH_ENABLED'] =						'禁用搜索功能将会清空数据库的"all_search"表格。以后，如果您想重新激活搜索功能，"all_search"表格会自动重新构成。';
	$langA['disable'] =								'禁用';
	
	$langA['search_disabled'] =						'搜索已禁用';
	$langA['SEARCH_DISABLED'] =						'搜索功能目前被禁用。启用搜索功能需要用数据库的所有文件重新填充表格"all_search"，如果数据库比较大，这个过程可能需要很长的时间。';
	$langA['SEARCH_IS_DISABLED'] =					'搜索已经禁用，搜索表格也清空完毕。';
	$langA['enable'] =								'启用';
	
	$langA['FINISHED_ENTRIES'] =						'%s 篇文章处理完毕，还剩下 %s 篇。';
	$langA['SEARCH_IS_ENABLED'] =					'搜索功能已启用。';


//
// adminConfig.php
//
	$langA['configuration'] =						'配置';
	$langA['confighistory'] =						'配置历史';
	$langA['CONFIG_SAVING'] =						'新的配置已经保存，原先的配置没有被覆盖，以便您在需要的时候撤消以前的修改。';
	$langA['CONFIG_STAT'] =							'配置有 %s 个版本。';
	$langA['CONFIG_CONFIRM_REVERT'] =				'您确信要返回版本号 %s ？ 点击 <tt>保存</tt> 以继续。';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'可以用诸如这样的语句：“欢迎访问服务器1”。';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'允许上传文件的最大字节数(byte)。';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'不允许注册的用户名，请使用逗号(,)隔开。';
	
	$langA['maxErrorFileSize']['desc'] = 			'错误日志文件的最大大小。默认是10,000字节(10kb)。';
	$langA['errorEmail']['desc'] = 					'请提供一个电子邮箱地址 ';
	
	
	$langA['include']['desc'] = 						'在请求时自动include php文件,请使用相对您的网站根目录的文件名并且用逗号(,)隔开它们。';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'一般设置';
	$langA['performance'] = 							'性能';
	
	$langA['serverName1']['alias'] = 				'网站名称';
	$langA['serverName2']['alias'] = 				'服务器名称';
	$langA['serverName3']['alias'] = 				'服务器全路径';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'最大上传';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'语言';
	$langA['reservedWords']['alias'] = 				'保留词语';
	
	$langA['developer_aids'] = 						'开发者帮助';
	$langA['maxErrorFileSize']['alias'] = 			'错误日志大小';
	$langA['errorEmail']['alias'] = 					'错误Email';
	$langA['include']['alias'] = 					'包括PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'默认用户设置';
	
	$langA['defaultUser:homeTitle']['alias'] =		'主页标题';
	$langA['defaultUser:homeTitle']['desc'] =		'作为首页的标题显示。';
	
	$langA['defaultUser:template']['alias'] =		'用户模板';
	$langA['defaultUser:template']['desc'] =		'Main/Home是wikyblog默认的模板。';
	
	$langA['defaultUser:textareaY']['alias'] =		'文本域高度';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Blog主页';
	$langA['defaultUser:isBlog']['desc'] =			'打开或关闭blog主页模式。';
	
	$langA['defaultUser:timezone']['alias'] =		'时区';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'最大历史行数';
	$langA['defaultUser:maxHistory']['desc'] =		'默认历史最大行数。';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = '增加新的组';
	$langA['unlimited'] = 'Unlimited';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'用户统计';
	$langA['user_stats'] =							'用户状态';
	$langA['user_account'] =							'用户账号';
	$langA['entries'] =								'条目';
	$langA['history Rows'] =							'历史行数';
	$langA['last_visit'] = 							'最后一次访问';
	
	$langA['users_found'] =							'找到用户';
	$langA['showing_of_found'] =						'显示从 %s 到 %s';
	$langA['cpanel'] =								'控制面板';
	$langA['details'] =								'详细';
	
	$langA['within_the_hour'] =						' 小于1小时';
	$langA['hours'] =								'小时';
	$langA['days'] =									'天';
	$langA['months'] =								'月';
	$langA['years'] = 								'年';
	$langA['ago'] = 									'以前';
	
	$langA['TIMEOUT'] = 								'<b>超时:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'你确信要删除<b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'删除将 <i>完全清空</i>此帐号的所有文件，包括：';
	$langA['userfiles_directory'] = 					'用户文件目录： ';
	$langA['template_directory'] = 					'模板目录： ';
	$langA['database_entries'] = 					'和所有数据库条目：页面，页面历史，评论等等。';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'删除数据库条目。';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>警告:</b>无法删除数据库相关内容。';
	
	$langA['DELETED_USERFILES'] = 					'已经删除用户文件目录。';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>警告:</b>无法删除用户文件目录。';
	
	$langA['DELETED_TEMPLATES'] = 					'已经删除模板目录。';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Warning:</b>无法删除模板目录。';
	
	$langA['USER_DELETED'] = 						'%s已经完全删除: ';
	$langA['USER_NOT_DELETED'] = 					'%s没有完全删除: ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activate';
	$langA['lost_page'] = 							'丢失的页面';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'已禁用';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'不能删除此错误日志.';
	$langA['ERROR_LOG_DELETED'] = 					'错误日志已删除.';
	$langA['ERROR_LOG_MAXED'] = 						'The Error Log file has reached is maximum size, please empty the file so the script can continue to log errors. %s';


	$langA['select'] = 								'选择';
	$langA['description'] = 						'描述';


//	adminPlugins
	$langA['data_types'] = 							'数据类型'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'已有类型';
	$langA['available_plugins'] = 					'可用插件';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Check All / Uncheck All';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'在线';
	$langA['wbConfig']['online']['desc'] = 			'是否连上互联网?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Flood Interval';
	$langA['wbConfig']['floodInterval']['desc'] = 	'前后编辑之间禁止用户的秒数。';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'用HTML Tidy修正可能出现的输入错误。';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'所有特性';
	$langA['wbConfig']['allUsers']['desc'] = 		'允许所有的注册用户拥有他们自己的blog。';
	
	$langA['wbConfig']['pUser']['desc'] = 			'选择匿名用户访问时的帐号';
	$langA['wbConfig']['pUser']['alias'] = 			'默认用户。';

	$langA['wbConfig']['sesslevel']['desc'] = 		'决定验证会话时如何检查用户的IP';
	$langA['wbConfig']['sesslevel']['alias'] = 		'会话等级';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

