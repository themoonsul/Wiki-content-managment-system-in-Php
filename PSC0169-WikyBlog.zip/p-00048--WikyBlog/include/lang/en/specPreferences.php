<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'Your preferences have not changed from the values already saved.';
$langA['INVALID_PREFS'] = '<b>Warning:</b> Could not save your preferences with the supplied values.';

$langA['EMAIL_PREFS'] = 'Useful if you forget your password.';

$langA['LANG_PREFS'] = 'Select a language.';

$langA['javascript_preferences'] = 'JavaScript Preferences';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Turn on/off JavaScript enhancements. Some features will not work properly when JavaScript is disabled.';

$langA['time_zone'] = 'Time Zone';
$langA['TIME_ZONE_PREFS'] = 'Time difference between your local time and the server time: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'Server time is now %s. <br/>Your adjusted time is %s.';

$langA['sig'] = 'Signature';
$langA['SIGNATURE'] = 'Customize your signature with wiki syntax.';


$langA['home_title'] = 'Home Title';
$langA['HOME_TITLE_PREFS'] = 'The title to be displayed on your home page.';

$langA['blog_styled_frontpage'] = 'Blog Styled Frontpage';
$langA['BLOG_PREFS'] = 'Display the home page as a blog.';

$langA['blogT'] = 'Blog Type';
$langA['BLOG_TYPE'] = 'Select among available data types to blog.';

$langA['selective_blogging'] = 'Selective Blogging';
$langA['SELECTIVE_BLOGGING'] = 'Selective Blogging allows you to blog only those pages you want displayed on the front page.';

$langA['blog_count'] = 'Blog Count';
$langA['BLOG_COUNT'] = 'The number of entries to show on your blog.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'Display the "Share" link at the bottom of each file.';

$langA['ihelp'] = 'Help Links';
$langA['IHELP'] = 'Show help links.';

$langA['uServices'] = 'Update Services';
$langA['UPDATE_SERVICES'] = 'When you publish a new post, the following update services will automatically be notified. Separate multiple service URIs with line breaks.';
$langA['BAD_UPDATE_SERVICES'] = 'Invalid URI(s) given for Update Services';


$langA['VIEW_THEME'] = '<a %s>Edit or copy</a> this theme.';

$langA['quick_comment'] = 'Quick Comment';
$langA['QUICK_COMMENT'] = 'When on, a form will be displayed at the top of talk pages for faster commenting.';

$langA['textarea rows'] = 'Textarea Rows';
$langA['TEXTAREA_ROWS_PREFS'] = 'Determines the height of editing areas.';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'Limits the number of history rows stored on the server for each file.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Maximum %s.';

$langA['tab_limit'] = 'Tab Limit';
$langA['TAB_LIMIT'] = 'JavaScript will automatically close tabs once the number of opened tabs has reached this limit. Defaults to 7. Set to 1000 or more if you don\'t want JavaScript to manage your tabs.';

$langA['EXTERNAL_LINKS'] = 'External links will be opened in a new window when "On".';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'Keyboard Shortcuts';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = 'Save Preferences';

$langA['CONFIRM_CHANGE'] = 'Are you sure you want to change your preferences?';
$langA['preference'] = 'Preference';
$langA['old_value'] = 'Old Value';
$langA['new_value'] = 'New Value';

$langA['changes'] = 'Changes';
$langA['PREFS_CHANGED'] = 'Your preferences have been updated.<br/> Below is a summary of the values that have changed.';


//check edit
$langA['anonymous'] = 'Anonymous';
$langA['fEdits'] = 'Flag Edits';
$langA['FLAG_EDITS'] = 'Edits made by users with status at or below the selected status will be flagged as "Unchecked" until it is reviewed by the account owner.';

//save all edits
$langA['saveAll'] = 'Log All Edits';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
