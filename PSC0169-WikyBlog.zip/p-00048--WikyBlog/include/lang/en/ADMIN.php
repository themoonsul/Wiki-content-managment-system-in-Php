<?php

	$langA['googleMapKeys'] =						'Google Maps API Key';


	$langA['ADMIN_ONLY'] =							'You must be an administrator to access this page.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'This admin page has not been defined yet: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Please confirm your password to continue.';
	$langA['confirm_password'] =						'Confirm Password';
	$langA['confirmation_failed'] =					'Password confirmation failed. Please try again.';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Search Options';
	$langA['search_status'] =						'Search Status';
	$langA['search_enabled'] =						'Search Enabled';
	$langA['SEARCH_ENABLED'] =						'Disabling the search feature will empty the `all_search` database table. Later, if you would like to enable search again, the `all_search` table will have to be re-populated.';
	$langA['disable'] =								'Disable';
	
	$langA['search_disabled'] =						'Search Disabled';
	$langA['SEARCH_DISABLED'] =						'Search is currently disabled. Enabling search requires a process that will fill the `all_search` database table with entries for all files in the database. This process may take a fair amount of time for large databases.';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'Enable';
	
	$langA['FINISHED_ENTRIES'] =						'%s entries done, %s more to go.';
	$langA['SEARCH_IS_ENABLED'] =					'The search feature is now enabled.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Configuration';
	$langA['confighistory'] =						'Configuration History';
	$langA['CONFIG_SAVING'] =						'New configurations are saved without overwriting the current values, enabling you to undo changes if need be...';
	$langA['CONFIG_STAT'] =							'There have been %s revisions made to the configuration.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Are you sure you want revert to revision number %s. Click <tt>Save</tt> to continue.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Something that can be used with a sentence like: "Welcome to serverName1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'Maximum size of an uploaded file.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Maximum file size to be allowed for the Error Log. Defaults to 10,000 bytes.';
	$langA['errorEmail']['desc'] = 					'Provide an email address ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'General Settings';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'Pretty Server Name';
	$langA['serverName2']['alias'] = 				'Server Name';
	$langA['serverName3']['alias'] = 				'Full Server Url';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Max Upload';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Language';
	$langA['reservedWords']['alias'] = 				'Reserved Words';
	
	$langA['developer_aids'] = 						'Developer Aids';
	$langA['maxErrorFileSize']['alias'] = 			'Error Log Size';
	$langA['errorEmail']['alias'] = 					'Error Email';
	$langA['include']['alias'] = 					'Include PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Default User Settings';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Home Title';
	$langA['defaultUser:homeTitle']['desc'] =		'Displayed as the title of the home page.';
	
	$langA['defaultUser:template']['alias'] =		'User Template';
	$langA['defaultUser:template']['desc'] =		'Main/Home is the default wikyblog template.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Textarea Height';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Blog Home Page';
	$langA['defaultUser:isBlog']['desc'] =			'Turns blog styled homepage on and off.';
	
	$langA['defaultUser:timezone']['alias'] =		'Timezone';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Max History Rows';
	$langA['defaultUser:maxHistory']['desc'] =		'Default maximum for history rows.';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Add Group';
	$langA['unlimited'] = 'Unlimited';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'User Statistics';
	$langA['user_stats'] =							'User Stats';
	$langA['user_account'] =							'User Account';
	$langA['entries'] =								'Entries';
	$langA['history Rows'] =							'History Rows';
	$langA['last_visit'] = 							'Last Visit';
	
	$langA['users_found'] =							'Users Found';
	$langA['showing_of_found'] =						'Showing %s through %s';
	$langA['cpanel'] =								'CPanel';
	$langA['details'] =								'Details';
	
	$langA['within_the_hour'] =						' < 1 hour ago';
	$langA['hours'] =								'hours';
	$langA['days'] =									'days';
	$langA['months'] =								'months';
	$langA['years'] = 								'years';
	$langA['ago'] = 									'ago';
	
	$langA['TIMEOUT'] = 								'<b>Timeout error:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'Are you sure you want to delete <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Deleting will <i>completely erase</i> all files for the account including:';
	$langA['userfiles_directory'] = 					'Userfiles directory: ';
	$langA['template_directory'] = 					'Template directory: ';
	$langA['database_entries'] = 					'And all database entries: pages, pagehistory, comments etc.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Deleted database entries.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Warning:</b> Could not delete the database entries.';
	
	$langA['DELETED_USERFILES'] = 					'Deleted Userfiles Directory.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Warning:</b> Could not delete the Userfiles Directory.';
	
	$langA['DELETED_TEMPLATES'] = 					'Deleted Tempalate Directory.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Warning:</b> Could not delete the Template Directory.';
	
	$langA['USER_DELETED'] = 						'%s was completely deleted: ';
	$langA['USER_NOT_DELETED'] = 					'%s was NOT completely deleted: ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activate';
	$langA['lost_page'] = 							'Lost Page';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'Disabled';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Could not delete the error log.';
	$langA['ERROR_LOG_DELETED'] = 					'The Error Log was deleted.';
	$langA['ERROR_LOG_MAXED'] = 						'The Error Log file has reached is maximum size, please empty the file so the script can continue to log errors. %s';


	$langA['select'] = 								'Select';
	$langA['description'] = 						'Description';


//	adminPlugins
	$langA['data_types'] = 							'Data Types'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Existing Types';
	$langA['available_plugins'] = 					'Available Plugins';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Check All / Uncheck All';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Online';
	$langA['wbConfig']['online']['desc'] = 			'Is this implementation connected to the internet?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Flood Interval';
	$langA['wbConfig']['floodInterval']['desc'] = 	'The number of seconds a user without permissions will have to wait between edits.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Use HTML Tidy to correct possible user input errors.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Full Featured.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Allow all registered users to have their own blog.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

