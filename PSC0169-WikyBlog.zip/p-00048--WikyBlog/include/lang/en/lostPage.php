<?php

$langA['lost_page'] = 'Lost Page';
$langA['PAGE_NOT_FOUND'] = 'The requested page <tt>%s</tt> was not found.';
$langA['REGISER_AS_USER'] = 'It appears the user account <tt>%s</tt> has not been created. Would you like to %s with this username?';
$langA['LINK_TYPO'] = ' Check for a link typo on the refering page: ';
$langA['REGISTER_TO_CREATE'] = 'Create this page by first registering with the username <tt>%s</tt>.';