<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'تفضيلاتك لم تتغير عن القيم المحفوظة سابقاً.';
$langA['INVALID_PREFS'] = '<b>تحذير:</b> تعذر حفظ تفضيلاتك بوجود القيم المزودة.';

$langA['EMAIL_PREFS'] = 'مفيد إن نسيت كلمة السر.';

$langA['LANG_PREFS'] = 'اختر لغة.';

$langA['javascript_preferences'] = 'تفضيلات جافاسكريبت';
$langA['javascript'] = 'جافاسكربت';
$langA['JAVASCRIPT_PREFS'] = 'شغـّل/أطفئ تحسينات جافاسكربت. بعض المزايا لا تعمل بشكل جيد عندما تكون جافاسكربت معطلة.';

$langA['time_zone'] = 'المنطقة الزمنية';
$langA['TIME_ZONE_PREFS'] = 'فارق الوقت بين وقتك المحلي ووقت الخادم: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'وقت الخادم هو الآن %s. <br/>وقتك المعدّل هو %s.';

$langA['sig'] = 'توقيع';
$langA['SIGNATURE'] = 'خصّص توقيعك مع تركيبة ويكي.';


$langA['home_title'] = 'عنوان الصفحة الرئيسية';
$langA['HOME_TITLE_PREFS'] = 'العنوان الذي سيظهر على صفحة بدايتك.';

$langA['blog_styled_frontpage'] = 'Frontpage المدونة المزخرفة';
$langA['BLOG_PREFS'] = 'إظهار صفحة البداية كمدوّنة.';

$langA['blogT'] = 'نوع المدوّنة';
$langA['BLOG_TYPE'] = 'اختر من بين أنواع البيانات المتاحة لنشر المدوّنة.';

$langA['selective_blogging'] = 'التدوين الانتقائي';
$langA['SELECTIVE_BLOGGING'] = 'التدوين الانتقائي يسمح لك بتدوين الصفحات التي تريد عرضها على الصفحة الأمامية فقط.';

$langA['blog_count'] = 'عدّ المدونة';
$langA['BLOG_COUNT'] = 'عدد المدخلات للعرض على مدوّنتك.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'أظهر رابط "تشارك" في أسفل كل ملف.';

$langA['ihelp'] = 'روابط المساعدة';
$langA['IHELP'] = 'عرض روابط المساعدة';

$langA['uServices'] = 'حدّث الخدمات';
$langA['UPDATE_SERVICES'] = 'عندما تنشر موضوعاً جديداً، ستنبَّه خدمات التحيث التالية تلقائياً. افصل بين أسماء مواقع الخدمات المتعددة بفواصل أسطر.';
$langA['BAD_UPDATE_SERVICES'] = 'اسم موقع (أسماء مواقع) معطى لخدمات التحديث';


$langA['VIEW_THEME'] = '<a %s> حرّر أو انسخ </a> هذا الموضوع.';

$langA['quick_comment'] = 'تعليق سريع';
$langA['QUICK_COMMENT'] = 'عندما تكون مضاءة، سوف تـُعرض نافذة أعلى بقية صفحات المحادثة للتعليق السريع.';

$langA['textarea rows'] = 'صفوف مساحة النص';
$langA['TEXTAREA_ROWS_PREFS'] = 'تحدد ارتفاع مساحات التحرير.';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'تحدد عدد صفوف التاريخ المخزنة على الخادم لكل ملف.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'حدّ أقصى %s.';

$langA['tab_limit'] = 'حدّ مفتاح Tab';
$langA['TAB_LIMIT'] = 'سوف تغلق جافاسكربت التبويبات عندما يبلغ عدد التبويبات المفتوحة الحد الأقصى. الافتراضي هو 7. ضع الحد الأقصى على 1000 أو أكثر إن لم ترد من جافاسكربت أن تدير تبويباتك.';

$langA['EXTERNAL_LINKS'] = 'الروابط الخارجية ستـُفتح في نافذة جديدة عندما يكون على "On".';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'اختصارات لوحة المفاتيح';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = 'حفظ التفضيلات';

$langA['CONFIRM_CHANGE'] = 'هل أنت متأكد أنك تريد تغيير تفضيلاتك؟';
$langA['preference'] = 'التفضيل';
$langA['old_value'] = 'قيمة قديمة';
$langA['new_value'] = 'قيمة جديدة';

$langA['changes'] = 'التعديلات';
$langA['PREFS_CHANGED'] = 'لقد حُدّثت تفضيلاتك.<br/>في الأسفل ملخص عن القيم التي تغيرت.';


//check edit
$langA['anonymous'] = 'مجهول';
$langA['fEdits'] = 'تحريرات الأعلام';
$langA['FLAG_EDITS'] = 'التحريرات التي قام بها المستخدمون والتي تكون عند أو أقل من الحالة المنتقاة سوف تـُعلّم بـ "غير متحقق منها" حتى تـُراجع من قبل مالك الحساب.';

//save all edits
$langA['saveAll'] = 'سجل كلّ التحريرات';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
