<?php

//	toolOptions.php
$langA['properties'] = 'خصائص';
$langA['file_name'] = 'اسم الملف';
$langA['update_from'] = 'تحديث من';
$langA['COPY_SYSTEM_FILES'] = 'نسح أحدث ملفات مساعدة النظام من %s.';

$langA['EDITING_OPTIONS'] = 'التحكم بمن يُسمح له بتحرير هذا الملف.';
$langA['registered_users'] = 'المستخدمين المسجلين';
$langA['restricted_to'] = 'حصريّ لـ ';
$langA['admin_only'] = 'المدير فقط';
$langA['editor_visible'] = 'مرئي بالنسبة للمحررين';
$langA['owner_only'] = 'المالك فقط';
$langA['use_captcha'] = 'استخدم كابتشا';
		

$langA['visibility'] = 'الظهور لـ';
$langA['VISIBILITY_OPTIONS'] = 'اخفِ هذا الملف إن لم تكن مستعداً لإظهاره أمام العالم.';
$langA['visible'] = 'مرئي';

$langA['COMMENT_OPTIONS'] = 'عطّل التعليقات لهذا الملف.';
$langA['enabled'] = 'مفعّل';
$langA['disabled'] = 'معطّل';
$langA['RECENT_COMMENTS'] = 'أظهر التعليقات الأخيرة.';

$langA['anti_spam'] = 'ضد البريد المزعج';
$langA['nofollow'] = 'لا تتبع';

$langA['other'] = 'آخر';
$langA['related_links'] = 'روابط مرتبطة';
$langA['unblog'] = 'أزل من المدوّنة';
$langA['repost'] = 'إعادة نشر';
$langA['copy_to'] = 'نسخ إلى...';
$langA['send_to_trash'] = 'أرسل إلى سلة المهملات';
$langA['default_options'] = 'الخيارات الافتراضية';
$langA['restore_defaults'] = 'استرجع الافتراضيات';
$langA['SET_DEFAULT_OPTIONS'] = 'عيّن %s إلى نوع الملفات هذا.'; //replaced with link
$langA['add_to_tabs'] = 'أضف إلى التبويبات';
$langA['add_to_links'] = 'أضف الى الروابط';

$langA['REPOSTED'] = 'أعيد نشر الملف.';
$langA['NOT_REPOSTED'] = '<b>خطأ:</b>تعذرت إعادة نشر هذا الملف.';
$langA['OPTIONS_NOT_CHANGED'] = 'لم تتغير خيارات الملف.';
$langA['OPTIONS_UPDATED'] = 'حُدّثت خيارات الملف بنجاح.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>تحذير:</b> لم تـُرفع خيارات الملف.';

$langA['redirect'] = 'إعادة توجيه';
$langA['REMOVE_REDIRECT'] = 'إن لم تكن تريد هذا الملف أن يعيد التوجيه بعد الآن، يمكنك حذفه أو تحريره. ';


$langA['UNCHECKED_REMOVED'] = 'علامة "غير متحقق منه" أزيلت عن هذا الملف.';

$langA['NO_KEYWORDS'] = 'لا يوجد كلمات أساسية معينة في هذا الملف. هل تودّ أن <a %s>تضيف الكلمات الأساسية أولاً</a> أم <a %s>تنشر في المدوّنة الآن</a>؟';

$langA['file_id'] = 'معرّف الملف';

//watch
$langA['WATCH_UPDATED'] = '<a %s>قائمة المشاهدة</a> الخاصة بك حُدّثت.';


$langA['user_permissions'] = 'أذونات&nbsp;المستخدم';
