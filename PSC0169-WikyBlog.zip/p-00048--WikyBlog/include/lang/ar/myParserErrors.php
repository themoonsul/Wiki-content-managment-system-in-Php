<?php

$langA['end_of_document'] = ' --- نهاية المستند --- ';
$langA['syntax_warning'] = ' تحذير تركيبة: ';

$langA['XML_ERROR_INVALID_TOKEN'] = 'اكتـُشف الخطأ في السطر %s في الموضع %s، ولكنه قد يكون ناتجاً عن الأسطر السابقة.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>random &lt;text</tt> instead of <tt>random &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> instead of <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> instead of <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = 'وسوم إغلاق HTML مطلوبة لإكمال هذا المستند: "<em>%s</em>".';

$langA['unnecessary_closing_tag'] = 'وسم إغلاق غير ضروري.';
$langA['should_be'] = ' ينبغي أن يكون ببساطة ';

$langA['CLOSING_AN_UNOPENED_TAG'] = 'إغلاق وسم غير مفنوح.<br /> ليس هناك وسم مفتوح لوسم الإغلاق <tt>&lt;/%s&gt;</tt>.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>&lt;/tag&gt;</tt> without <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> instead of <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Missing closing tag. <br /> The <tt>&lt;%s&gt;</tt> tag must be closed using <tt>%s</tt> ';
$langA['MISSING_CLOSING_TAG2'] = ' قبل وسم الإغلاق <tt>&lt;/%s&gt;</tt>.';

$langA['AUTOMATED_SYNTAX_ERROR'] = 'خطأ تركيبة آلي:';
$langA['AUTOMATED_SYNTAX_ERROR2'] = '(%s) في السطر %s (من أصل %s سطراً) في الموقع %s ';
$langA['last_open_tag'] = '<br />آخر وسم مفتوح ';
