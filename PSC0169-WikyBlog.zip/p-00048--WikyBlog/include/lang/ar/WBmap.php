<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'جارٍ تحميل الخريطة...';
$langA['MAP_DEBUG_O'] = 'حصل خطأ أثناء تحميل هذه الصفحة، والخريطة التي طلبتها لن تظهر.<p></p>أُنشئ سجل أخطاء وسيقوم مدراء الموقع بحل هذه المشكلة قريباً.';
$langA['MAP_DEBUG_1'] = 'The Google Maps API does not appear to be compatible with your browser.<p>If you know your browser is compatible, make sure the correct map key is being used and that you are connected to the internet.</p><p>You can <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">get more information</a> about browser support from google.com.</p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>تحذير:</b> الخرائط تتطلب جافا سكربت لتعمل.</p><p> يبدو أن جافا سكربت غير مفعّلة في متصفحك. لرؤية هذه الريطة، فعّل جافا سكربت في متصفحك رجاءً ثمّ أنعش/أعد تحميل هذه الصفحة. </p>';