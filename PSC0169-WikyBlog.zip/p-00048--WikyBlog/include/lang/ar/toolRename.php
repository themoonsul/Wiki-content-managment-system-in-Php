<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'لم يتغير اسم الملف.';
$langA['NOT_RENAMED'] = 'هذا الملف لا يمكن إعادة تسميته إلى <tt>%s</tt>. رجاءً تأكد من أن هذا الملف موجود أصلاً.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'تعذرت إعادة تسمية هذا الملف.';
$langA['redirected_to'] = 'موجّه إلى';
$langA['RENAMED'] = 'أعيد تسمية الملف بنجاح.';


//	toolDelete
$langA['FILE_RESTORED'] = 'استـُرجع <b>%s</b>. ';
$langA['ERROR_RESTORING'] = '<b>خطأ:</b> تعذر استرجاع الملف في <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = 'لقد سبق واستـُرجع الملف.';
$langA['WAS_DELETED'] = 'حُذف <b>%s</b>، سوف يُحفظ الملف في %s لمدة 30 يوماً.';
$langA['ERROR_DELETING'] = '<b>خطأ:</b> لم يمكن حذف الملف في <tt>%s.</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = 'حُذف <tt>%s</tt>.';
