<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'ملف';
$langA['edit'] = 'تحرير';
$langA['edits'] = 'التحريرات';
$langA['view_source'] = 'رؤية المصدر';
$langA['talk'] = 'تحدث';
//$langA['reply'] = 'Reply';
$langA['history'] = 'تاريخ';
$langA['diff'] = 'فروق';
$langA['watch'] = 'شاهد';
$langA['unwatch'] = 'ألغ المشاهدة';
$langA['options'] = 'خيارات';


$langA['messages'] = 'الرسائل';
$langA['current'] = 'الحالي';
$langA['blog'] = 'المدوّنة';
$langA['possible'] = 'ممكن';

$langA['DEFAULT_CONTENT'] = 'هذا ملف جديد، هل تريد [[%s?cmd=edit|إنشاءه]]؟'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'هذا ملف جديد. لإنشاء هذا الملف، عليك أن تسجل دخولاً بالصلاحيات اللازمة.';

$langA['NOT_OWNER'] = 'أنت لا تملك الصلاحيات اللازمة لهذه الميزة.';
$langA['LONG_PATH'] = 'عنوان هذا الملف طويل جداً لذا فقد بُتر.';
$langA['EMPTY_CONTENT'] = 'المحتوى هو حقل مطلوب';
$langA['INCOMPLETE_PATH'] = 'المسار المزوّد غير مكتمل.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'عذراً، لقد عطّل مدير الموقع مدونات المستخدمين. لإنشاء bliki بنفس الميزات الموجودة هنا، زُر <a href="http://www.wikyblog.com">WikyBlog.com</a>';
$langA['TITLE_EXISTS'] = 'العنوان موجود مسبقاً، رجاءً اختر واحداً آخر ثم احفظ ثانية.';

$langA['HIDDEN_FILE'] = 'الوصول إلى هذا الملف حصريّ لمالكه. لعرض هذا الملف، تحتاج الصلاحيات اللازمة.';
$langA['HIDDEN_FILE2'] = 'هذا الملف "مخفي". ';
$langA['DELETED_FILE'] = 'هذا الملف حالياً في "سلة المهملات". إن كنت مالك هذا الحساب، يمكنك استرجاع هذا الملف عن طريق لوحة التحكم';
$langA['PROTECTED_FILE'] = 'هذا الملف محمي. لن تـُحفظ أي تعديلات على هذا الملف.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'نص الرابط';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'موجّه من قبل %s.';
$langA['REDIRECT_TO'] = 'هذه الصفحة تحولك إلى %s.';

//	Data Types
$langA['all'] = 'الكل';
$langA['page'] = 'صفحة';
$langA['comment'] = 'تعليق';
$langA['map'] = 'خريطة';
$langA['template'] = 'قالب';
$langA['help'] = 'مساعدة';
$langA['skeleton'] = 'هيكل';
$langA['attach'] = 'مرفقات';

$langA['theme'] = 'Theme';

$langA['comments'] = 'تعليقات';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'صفحات';
$langA['CLASScomment'] = 'تعليقات';
$langA['CLASSmap'] = 'خرائط';
$langA['CLASStemplate'] = 'مواضيع';
$langA['CLASShelp'] = 'مساعدة';
$langA['IS_CONTENT_TEMPLATE'] = 'هذا الملف هو قالب محتوى ولن يظهر في مدوّنتك.';


$langA['seconds'] = ' ثوان';
$langA['queries'] = ' استعلامات';

$langA['QUERY_TIME'] = ' للاستعلامات';
$langA['INVALID_PATH'] = 'مسار الملف المزود غير صالح: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'طلب غير صالح.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'موضوعك';
$langA['CURRENT_THEME'] = 'أنت حاليا تستخدم موضوع <b> %s </b>.'; //replaced with template name

$langA['use_this_theme'] = 'إستخدم هذا الموضوع بدلا من ذلك';
$langA['using_this_theme'] = 'أنت حاليا تستخدم هذا الموضوع. ';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'كجزء متكامل من هذا البرنامج، ملف المساعدة هذا مخزن على خادم مركزي.<br/> يمكنك تحرير محتويات %sهذا%s وبقية ملفات المساعدة في %s.';

$langA['NEW_HELP'] = 'أنشئ ملف مساعدة جديد';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'استعرض';
$langA['change_log'] = 'سجل التغييرات';
$langA['control_panel'] = 'لوحة التحكم';
$langA['administration'] = 'الإدارة';
$langA['preferences'] = 'التفضيلات';
$langA['watchlist'] = 'قائمة المشاهدة';
$langA['wanted_files'] = 'الملفات المطلوبة';
$langA['dead_end'] = 'الملفات المنتهية الأجل';
$langA['search'] = 'بحث';
$langA['orphaned_files'] = 'الملفات اليتيمة';
$langA['most_linked'] = 'الملفات الأكثر ارتباطاً';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'روابط خارجية';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'مواضيع حديثة أخرى.';
$langA['NEED_INTERNET'] = 'هذه الميزة متاحة فقط للأنظمة الموصولة بالإنترنت.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>تحذير:</b> الكعكات مطلوبة للمتابعة. أنعش هذه الصفحة إن كانت الكعكات لديك مفعلة.';
$langA['LOGIN_REQUIRED'] = 'عليك تسجيل دخولك لاستخدام هذه الميزة.';

$langA['ENTER_USERNAME'] = 'أدخل اسم المستخدم رجاءً.';
$langA['ENTER_PASSWORD'] = 'أدخل كلمة السر رجاءً.';
$langA['LOGGED_OUT'] = 'لقد سجلت خروجك بنجاح.';
$langA['AUTO_LOGOUT'] = 'انتهت مدة جلستك.';

$langA['LOGIN_FAILED'] = 'فشل تسجيل الدخول: كلمة السر خطأ.<ul><li>هل مفتاح الأحرف الكبيرة مضاء؟<li>هل %sنسيت كلمة السر%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'لقد تجاوزت العدد الأقصى لمحاولات دخول %s. لن يُسمح لك بتسجيل دخولك لمدة %s دقيقة.';
						
$langA['create_new'] = 'أنشئ&nbsp;جديد ';
$langA['remember_me'] = 'تذكرني';
$langA['log_out'] = 'خروج';
$langA['log_in'] = 'دخول';

//	SAVING 
$langA['syntax_error'] = 'خطأ في التركيبة';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>خطأ في التركيبة:</b> تعذر حفظ/عرض التعديلات الأكثر حداثة الخاصة بهذا الملف بسبب تركيبة غير متوافقة.';
$langA['SYNTAX_FIXED'] = 'أصلِح خطأ التركيبة.';


$langA['NO_CHANGES'] = 'لا تعديلات أجريت على هذا الملف. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'تعذر حفظ هذا الملف. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'حُفظت التعديلات على ها الملف.';
$langA['HIDDEN_FILE3'] = '<b>ملاحظة:</b> هذا ملف مخفي، لذا لن تـُشمل وسوم هذا الملف في مجموع قائمة المستخدم.';

$langA['VERSION_CONFLICT'] = 'تحذير: لم نتمكن من حفظ تعديلاتك لأننا اكتشفنا وجود اختلاف بين النـُسخ.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'انسخ &nbsp; <b>%s</b> &nbsp; إلى &nbsp; <b>%s</b>.<br/>انقر على "حفظ" لإنهاء النسخ.'; //replaced with paths

$langA['FLOOD_WARN'] = 'التحرير محدد بملف واحد كل %s ثانية. رجاءً حاول مجدداً بعد %s ثانية.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'حفظ الخيارات';
$langA['blog_this'] = 'دوّن هذا';



//	toolHistory2.php
$langA['differences'] = 'الفروق';
$langA['line_num'] = 'السطر #';


//	toolHistory1.php
$langA['revision'] = 'المراجعة ';
$langA['revision_as_of'] = 'المراجعة من أصل ';
$langA['revision_num_as_of'] = 'المراجعة %s من أصل %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'تحرير المراجعة';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'إرجاع إلى المراجعة #';
$langA['SET_USER_PERMISSIONS'] = 'اضبط أذونات هذا المستخدم: '; 
$langA['compare_with_prev'] = '→ قارن مع المراجعة السابقة';
$langA['current_revision'] = 'المراجعة الحالية';
$langA['compare_with_next'] = 'قارن بالمراجعة القادمة →';
$langA['lines'] = 'السطور';
$langA['text'] = 'النص';
$langA['vs'] = ' ضد ';
$langA['content'] = 'المحتوى';
$langA['your_text'] = 'نصّك';
$langA['show_prev_revision'] = '← مراجعة %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'مراجعة %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>تحذير:</b> أنت لا تحرر النسخة الأحدث من هذه الصفحة.<br />الحفظ سوف يبدل هذه النسخة القديمة مكان النسخة الأحدث.';
$langA['SELECT_TWO_VERSIONS'] = 'اختر رجاءً نسختين مختلفتين لمقارنتهما.';
$langA['NO_UNIQUE_REVISION'] = 'لا يمكن إيجاد مراجعة وحيدة لهذا الطلب.';
$langA['INVALID_REVISION'] = '<b>خطأ:</b> رقم المراجعة غير صالح.';
$langA['NO_DIFFERENCES'] = 'المراجعتان المقارنتان متشابهتان.';
$langA['NO_REVISIONS'] = 'يجب أن يكون هناك مراجعتان منفصلتان لكي تحصل المقارنة.';
$langA['NON_EXISTANT'] = 'هذا الملف غير موجود حتى الآن.';

//	toolEditPage.php
$langA['bold_text'] = 'نص سميك';
$langA['italic_text'] = 'نص مائل';
$langA['headline_text'] = 'أدرج ترويسة';
$langA['title'] = 'عنوان';
$langA['unordered_list'] = 'قائمة غير مرتبة';
$langA['ordered_list'] = 'قائمة مرتبة';


$langA['internal_link'] = 'رابط داخلي';
$langA['link'] = 'رابط';
$langA['external_link'] = 'رابط خارجي';
$langA['embed_image'] = 'صورة مضمنة';
$langA['find_images'] = 'اوجد صورا';
$langA['image'] = 'صورة';
$langA['nowiki'] = 'لا ويكي';
$langA['NOWIKI_TEXT'] = 'أدخل نصاً غير منسق هنا';
$langA['signature'] = 'توقيع';
$langA['SIGNATURE_TEXT'] = 'أدخل توقيعك';
$langA['preview'] = 'معاينة';
$langA['PREVIEW_TEXT'] = 'عاين تعديلاتك [%s-p]';
$langA['PREVIEW_WARN'] = 'هذه مجرد معاينة، لم تـُحفظ تعديلاتك بعد!';
$langA['SAVE_TEXT'] = 'حفظ تعديلاتك [%s-s]';
$langA['reset'] = 'إعادة ضبط';
$langA['RESET_TEXT'] = 'أعد ضبط هذا الشكل إلى حالته الأصلية [%s-c]';
$langA['changes'] = 'التعديلات';
$langA['CHANGES_TEXT'] = 'أظهر التعديلات التي أجريتها على هذا الملف. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'نظم ردودك بالكلمات المفصولة بفاصلة'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'الوسوم';
$langA['edit_summary'] = 'تحرير الملخص';
$langA['syntax_warning'] = 'تحذير تركيبة';
$langA['NO_IMAGES'] = 'لم يُعثر على أي صور';
$langA['insert_emoticons'] = 'أدرج ابتسامات';
$langA['upload'] = 'رفع';



//searchHistory
$langA['show'] = 'أظهر';
$langA['hide'] = 'Hide';
$langA['compare'] = 'قارن';
$langA['timeline'] = 'الجدول الزمني';
$langA['summary'] = 'ملخص';
$langA['COMPARE_REVISONS'] = 'قارن عم النسخة المحددة.';
$langA['unchecked'] = 'غير متحقق منه';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'نوع الملف المزود غير صالح.';


//	SEARCH
$langA['next'] = 'التالي';
$langA['previous'] = 'السابق';
$langA['order_by'] = 'ترتيب:';
$langA['ascending'] = 'تصاعدي';
$langA['descending'] = 'تنازلي';
$langA['search_from'] = 'البحث من: ';
$langA['all_users'] = 'كل المستخدمين';
$langA['user'] = 'المستخدم';
$langA['from_file_type'] = 'البحث من نوع الملف: ';
$langA['read_more'] = 'اقرأ المزيد';
$langA['words'] = ' كلمات';

$langA['RESULTS'] = 'النتائج من %s إلى %s لـ %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'لم يُعثر على مدخلات موافقة لمعايير البحث';

//searchTalk
$langA['add_comment'] = 'أضف موضوعاً جديداً';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'لم يمكن تضمين التحذير. البيانات منسقة بشكل سيء للإدخال المضاعف.';
$langA['duplicate_entry'] = 'مدخلة مكررة';
$langA['DUPLICATE_ENTRY'] = 'هذه مدخلة مكررة للصفحة الموجودة في %s. <br/> أي معلومة زائدة موجودة هنا ينبغي أن تـُنقل إلى الصفحة الأصلية قبل حذف هذه الصفحة.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'غير موجود: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>خطأ:</b><br />حصل خطأ أثناء تنفيذ هذا السكربت.<br /> رجاءً تحقق من طلبك وسوف نحاول تنقيح السكربت بمساعدة سجل الأخطاء. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'لا يمكن حذف القالب الافتراضي.';
$langA['THEME_MISSING_VARS'] = 'المتغيّر (ات) المطلوبة المفقودة : <tt> %s </tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'السمة المحددة غير صالحة.';

//
//	CLASSmap
//
$langA['new_marker']='علامة جديدة';
$langA['new_route']='وجهة جديدة';
$langA['SAVE_HEADER']='قبل الحفظ تذكر ';
$langA['save_map']='حفظ الخريطة';
$langA['continue_editing']='تابع التحرير';
$langA['miles/km'] = 'أميال/كم';
$langA['MAP_DEFAULT_CONTENT'] = '<b>هذه خريطة جديدة.</b><br/> لإنشاء/تعديل هذه الخريطة، اضغط على "تحرير" في الأعلى.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'عذراً، أنت لا تملك الصلاحيات الكافية لتحرير هذه الخريطة.';
$langA['play'] = 'تشغيل';
$langA['stop'] = 'إيقاف';
$langA['import'] = 'استيراد';
$langA['export'] = 'تصدير';
$langA['gpx_data'] = 'بيانات GPX';
$langA['gpx_exchange_format'] = 'صيغة تبادل GPX';
$langA['CLICK_EDIT'] = 'لتحرير الخريطة، انقر على "تحرير" في الأعلى';


//	smileys
$langA['smiles'][':D'] = 'سعيد جداً';
$langA['smiles'][':)'] = 'ابتسامة';
$langA['smiles'][':('] = 'حزين';
$langA['smiles'][':o'] = 'متفاجئ';
$langA['smiles'][':shock:'] = 'مصدوم';
$langA['smiles'][':?'] = 'مشوّش';
$langA['smiles']['8)'] = 'لطيف';
$langA['smiles'][':lol:'] = 'ضاحك';
$langA['smiles'][':x'] = 'مجنون';
$langA['smiles'][':P'] = 'هازئ';
$langA['smiles'][':oops:'] = 'محرج';
$langA['smiles'][':cry:'] = 'باكٍ أو حزين جداً';
$langA['smiles'][':evil:'] = 'شرير أو مجنون جداً';
$langA['smiles'][':twisted:'] = 'شرير منحل';
$langA['smiles'][':roll:'] = 'عيون دائرة';
$langA['smiles'][':wink:'] = 'غمزة';
$langA['smiles'][':!:'] = 'تعجب';
$langA['smiles'][':?:'] = 'سؤال';
$langA['smiles'][':idea:'] = 'فكرة';
$langA['smiles'][':arrow:'] = 'سهم';
$langA['smiles'][':|'] = 'حيادي';
$langA['smiles'][':mrgreen:'] = 'السيد غرين';

//
//	General Language
//
$langA['or'] = 'أو';
$langA['username'] = 'اسم المستخدم';
$langA['password'] = 'كلمة السر';
$langA['email'] = 'البريد الإلكتروني';
$langA['register'] = 'تسجيل';
$langA['cancel'] = 'إلغاء';
$langA['language'] = 'اللغة';
$langA['use'] = 'استخدم';
$langA['copy'] = 'انسخ';
$langA['rename'] = 'أعد تسمية';

$langA['on'] = 'مضاء';
$langA['partial'] = 'جزئي';
$langA['off'] = 'مطفأ';
$langA['save'] = 'حفظ';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'غير معرّف';
$langA['homepage'] = 'صفحة البداية';
$langA['home'] = 'الموطن';
$langA['go'] = 'اذهب';
$langA['user_menu'] = 'قائمة المستخدم';

$langA['last_modified'] = 'آخر تعديل';
$langA['LAST_MODIFIED'] = 'آخر تعديل عند %s من قِبل %s.';//%s replaced with date and username
$langA['accessed_times'] = 'دُخل عليه %s مرة';// %s replaced with a number
$langA['modified'] = 'معدل';
$langA['posted'] = 'منشور';
$langA['created'] = 'مُنشأ';
$langA['hidden'] = 'مخفي';
$langA['what_links_here'] = 'ما يربط هنا';
$langA['share'] = 'تشارك';
$langA['INVALID_LINK'] = 'عنوان الصفحة المطلوبة غير صالح. لعله يحتوي على حرف أو أكثر لا يمكن استخدامها في العناوين.';
$langA['FILE_MUST_EXIST'] = 'يجب أن يُحفظ الملف قبل أن تستطيع إنجاز هذه العملية.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'الحجم ';
$langA['bytes'] = 'بايتات';
$langA['kb'] = 'كيلو بايت';
$langA['mb'] = 'م ب';
$langA['gb'] = 'ج ب';
$langA['update'] = 'تحديث';
$langA['editing'] = 'التحرير';
$langA['workgroup'] = 'مجموعة عمل';
$langA['BROWSE_HIDDEN'] = 'اوجد ملفات مخفية';

$langA['delete'] = 'حذف';
$langA['confirm_delete'] = 'تأكيد الحذف';
$langA['continue'] = 'متابعة';
$langA['back'] = 'عودة';
$langA['close'] = 'أغلق';
$langA['view'] = 'عرض';
$langA['empty'] = '-فارغ-';
$langA['none'] = 'لا شيء';
$langA['total'] = 'المجموع ';
$langA['files'] = 'الملفات';
$langA['other'] = 'آخر';
$langA['trash'] = 'سلة المهملات';
$langA['flagged'] = 'معلّم';

$langA['today'] = 'اليوم';
$langA['yesterday'] = 'أمس';
$langA['days_ago'] = ' أيام مضت';
$langA['page_contents'] = 'محتويات الصفخة';
$langA['more'] = 'المزيد';
$langA['download'] = 'تحميل';


//Date
$langA['date_l'][0] = 'الأحد';
$langA['date_l'][1] = 'الاثنين';
$langA['date_l'][2] = 'الثلاثاء';
$langA['date_l'][3] = 'الأربعاء';
$langA['date_l'][4] = 'الخميس';
$langA['date_l'][5] = 'الجمعة';
$langA['date_l'][6] = 'السبت';

$langA['date_D'][0] = 'أحد';
$langA['date_D'][1] = 'اثنين';
$langA['date_D'][2] = 'ثلاثاء';
$langA['date_D'][3] = 'أربعاء';
$langA['date_D'][4] = 'خميس';
$langA['date_D'][5] = 'جمعة';
$langA['date_D'][6] = 'سبت';


$langA['date_F'][1] = 'يناير';
$langA['date_F'][2] = 'فبراير';
$langA['date_F'][3] = 'مارس';
$langA['date_F'][4] = 'أبريل';
$langA['date_F'][5] = 'مايو';
$langA['date_F'][6] = 'يونيو';
$langA['date_F'][7] = 'يوليو';
$langA['date_F'][8] = 'أغسطس';
$langA['date_F'][9] = 'سبتمبر';
$langA['date_F'][10] = 'أكتوبر';
$langA['date_F'][11] = 'نوفمبر';
$langA['date_F'][12] = 'ديسمبر';

$langA['date_M'][1] = 'ينا';
$langA['date_M'][2] = 'فبر';
$langA['date_M'][3] = 'مار';
$langA['date_M'][4] = 'أبر';
$langA['date_M'][5] = 'مايو';
$langA['date_M'][6] = 'يون';
$langA['date_M'][7] = 'يول';
$langA['date_M'][8] = 'أغس';
$langA['date_M'][9] = 'سبتم';
$langA['date_M'][10] = 'أكت';
$langA['date_M'][11] = 'نوف';
$langA['date_M'][12] = 'ديس';

$langA['date_a']['am'] = 'صباحاً';
$langA['date_a']['pm'] = 'مساءً';

$langA['date_A']['am'] = 'قبل الظهر';
$langA['date_A']['pm'] = 'بعد الظهر';

$langA['lang']['ar'] = 'عربي (ar)';
$langA['lang']['bn'] = 'بنغالي (بن)';
$langA['lang']['de'] = 'ألماني (de)';
$langA['lang']['el'] = 'يوناني (el)';
$langA['lang']['en'] = 'إنجليزي (en)';
$langA['lang']['es'] = 'اسباني (es)';
$langA['lang']['fr'] = 'فرنسي (fr)';
$langA['lang']['hu'] = 'هنغاري (هن)';
$langA['lang']['it'] = 'إيطالي (it)';
$langA['lang']['ja'] = 'ياباني (ja)';
$langA['lang']['ko'] = 'كوري (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'هولندي (nl)';
$langA['lang']['pl'] = 'بولندي (pl)';
$langA['lang']['ro'] = 'روماني (رو)';
$langA['lang']['ru'] = 'روسي (ru)';
$langA['lang']['tr'] = 'تركي (tr)';
$langA['lang']['vi'] = 'فيتنامي (vi)';
$langA['lang']['zh'] = 'صيني (zh)';
$langA['lang']['zh-cn'] = 'صيني مبسّط (zh-cn)';



