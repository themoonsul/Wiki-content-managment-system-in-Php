<?php

	$langA['googleMapKeys'] =						'مفتاح API خرائط جوجل';


	$langA['ADMIN_ONLY'] =							'عليك أن تكون مديراً لتدخل هذه الصفحة.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'صفحة المدير هذه لم تـُعرّف بعد: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'أعد كتابة كلمة السر رجاءً للمتابعة.';
	$langA['confirm_password'] =						'تأكيد كلمة السر';
	$langA['confirmation_failed'] =					'فشل تأكيد كلمة السر، حاول ثانية.';
	
	$langA['run_scheduled_tasks'] =					'شغّل المهمات المجدولة';
	$langA['FAILED'] = 								'عذراً، فشل الإجراء المرغوب به. رجاءً حاول ثانية.';
	$langA['SUCCESS'] = 								'نجح الإجراء المرغوب به.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'خيارات البحث';
	$langA['search_status'] =						'حالة البحث';
	$langA['search_enabled'] =						'البحث مفعّل';
	$langA['SEARCH_ENABLED'] =						'تعطيل ميزة البحث سوف يفرغ جدول قاعدة بيانات `all_search`. إن أردت تفعيل البحث لاحقاً، فسيُعاد ملء جدول `all_search`.';
	$langA['disable'] =								'تعطيل';
	
	$langA['search_disabled'] =						'البحث معطّل';
	$langA['SEARCH_DISABLED'] =						'البحث معطّل حالياً. يتطلب تفعيل البحث عملية ستملأ جدول قاعدة بيانات `all_search` بالمدخلات لكل الملفات في قاعدة البيانات. هذه العملية قد تأخذ وقتاً طويلاً لقواعد البيانات الضخمة.';
	$langA['SEARCH_IS_DISABLED'] =					'عُطّل البحث وهُجر جدول البحث.';
	$langA['enable'] =								'تفعيل';
	
	$langA['FINISHED_ENTRIES'] =						'انتهت %s مُدخلة/مُدخلات، وبقي %s.';
	$langA['SEARCH_IS_ENABLED'] =					'ميزة البحث مفعّلة الآن';


//
// adminConfig.php
//
	$langA['configuration'] =						'الإعدادات';
	$langA['confighistory'] =						'تاريخ الإعدادات';
	$langA['CONFIG_SAVING'] =						'الإعدادات الجديدة تـُحفظ دون أن تـُكتب فوق القيم الحالية، مما يمكنك من التراجع عن التعديلات إن اقتضت الحاجة...';
	$langA['CONFIG_STAT'] =							'هناك %s مراجعة/مراجعات على الإعدادات.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'هل أنت متأكد أنك تريد حفظ المراجعة رقم %s. انقر <tt>حفظ</tt> للمتابعة.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'غير متوفر';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'شيء ما يمكن استخدامه مع جملة مثل: "أهلاً بك في سيرفر1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://اسم_الخادم2';

//default user

	$langA['max_upload']['desc'] = 					'الحجم الأقصى للملف المرفوع.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'لا يُسمح للمستخدمين أن يتسجلوا باستخدام هذه النصوص المفصولة بفاصلة كأسماء مستخدمين.';
	
	$langA['maxErrorFileSize']['desc'] = 			'حجم الملف الأقصى المسموح لسجلات الأخطاء. الافتراضي هو 10.000 بايت.';
	$langA['errorEmail']['desc'] = 					'زوّد بريداً إلكترونياً ';
	
	
	$langA['include']['desc'] = 						'اجعل البرنامج يضمّن ملف php في كل طلب تلقائياً. يمكن إدخال أسماء الملفات عن طريق فصلها بفاصلة ونسبياً إلى مجلد الجذر.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'الإعدادات العامة';
	$langA['performance'] = 							'الأداء';
	
	$langA['serverName1']['alias'] = 				'اسم السيرفر اللطيف';
	$langA['serverName2']['alias'] = 				'اسم السيرفر';
	$langA['serverName3']['alias'] = 				'ال URL الكامل الخاص بالسيرفر';
	
	
	$langA['total_usage'] = 						'الإستخدام الكليّ';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'حجم الرفع الأقصى';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'اللغة';
	$langA['reservedWords']['alias'] = 				'الكلمات المحجوزة';
	
	$langA['developer_aids'] = 						'مساعدات المطورين';
	$langA['maxErrorFileSize']['alias'] = 			'حجم سجلات الأخطاء';
	$langA['errorEmail']['alias'] = 					'بريد الأخطاء';
	$langA['include']['alias'] = 					'يضمّ PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'إعدادات المستخدم الافتراضية';
	
	$langA['defaultUser:homeTitle']['alias'] =		'عنوان الصفحة الرئيسية';
	$langA['defaultUser:homeTitle']['desc'] =		'تـُعرض كعنوان للصفحة الرئيسية.';
	
	$langA['defaultUser:template']['alias'] =		'قالب المستخدم';
	$langA['defaultUser:template']['desc'] =		'رئيسي/موطن هو القالب الافتراضي لـ wikyblog.';
	
	$langA['defaultUser:textareaY']['alias'] =		'ارتفاع مساحة النص';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'صفحة المدونة الرئيسية';
	$langA['defaultUser:isBlog']['desc'] =			'تشغيل أو إطفاء صفحة المدوّنة الرئيسية المزيّنة.';
	
	$langA['defaultUser:timezone']['alias'] =		'المنطقة الزمنية';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'جافاسكربت';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'عدد صفوف التاريخ الأقصى';
	$langA['defaultUser:maxHistory']['desc'] =		'العدد الافتراضي الأقصى لصفوف التاريخ.';

	$langA['defaultUser:pTemplate']['alias'] =		'موضوع قياسي';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'فريق مستخدم';
	$langA['add_group'] = 'أضف مجموعة';
	$langA['unlimited'] = 'غير محدود';
	$langA['group'] = 'مجموعة';
	$langA['related_links'] = 'روابط مرتبطة';
	
//
//	registration
//	
	$langA['registration'] = 						'تسجيل';
	$langA['register:reqemail']['alias'] = 				'يتطلّب عنوان بريد الكتروني';
	$langA['register:register']['alias'] =				'عنوان عرض السّجل';
	$langA['register:registered']['alias'] =				'عنوان العرض المسجّل';
	$langA['register:captcha']['alias'] =				'استخدم كابتشا';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'إحصائيات المستخدم';
	$langA['user_stats'] =							'حالة المستخدم';
	$langA['user_account'] =							'حساب المستخدم';
	$langA['entries'] =								'الإدخالات';
	$langA['history Rows'] =							'صفوف التاريخ';
	$langA['last_visit'] = 							'آخر زيارة';
	
	$langA['users_found'] =							'المستخدمون الذين وُجدوا';
	$langA['showing_of_found'] =						'إظهار %s عبر %s';
	$langA['cpanel'] =								'لوحة التحكم';
	$langA['details'] =								'التفاصيل';
	
	$langA['within_the_hour'] =						' < ساعة مضت';
	$langA['hours'] =								'ساعات';
	$langA['days'] =									'أيام';
	$langA['months'] =								'شهور';
	$langA['years'] = 								'سنوات';
	$langA['ago'] = 									'قبل';
	
	$langA['TIMEOUT'] = 								'<b>خطأ انتهاء المهلة:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>تحذير</b> لا يمكن حذف الحساب "الرئيسي"';
	$langA['CONFIRM_DELETE_USER'] = 					'هل أنت متأكد من أنك تريد حذف <b>%s</b>؟';
	$langA['CONFIRM_DELETE_USER2'] = 				'الحذف سوف <i>يمسح كلياً</i> كل الملفات التي يحويها الحساب:';
	$langA['userfiles_directory'] = 					'مجلد ملفات المستخدم: ';
	$langA['template_directory'] = 					'مجلد القوالب: ';
	$langA['database_entries'] = 					'وكل مدخلات قاعدة البيانات: صفحات، تاريخ الصفحات، تعليقات، إلخ.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'حُذفت مُدخلات قاعدة البيانات.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>تحذير:</b> لم يمكن حذف مُدخلات قاعدة البيانات.';
	
	$langA['DELETED_USERFILES'] = 					'حُذف مجلد ملفات المستخدم.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>تحذير:</b> لم يمكن حذف مجلد ملفات المستخدم.';
	
	$langA['DELETED_TEMPLATES'] = 					'حُذف مجلد القوالب.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>تحذير:</b> لم يمكن حذف مجلد القوالب.';
	
	$langA['USER_DELETED'] = 						'حُذف %s كلياً: ';
	$langA['USER_NOT_DELETED'] = 					'لم يُحذف %s كلياً: ';
	$langA['DELETE_ACCOUNT'] = 						'احذف هذا الحساب كلياً.';
	$langA['DISABLE_ACCOUNT'] = 					'عطّل تحرير الملفات.';
	$langA['SUSPEND_ACCOUNT'] = 					'علّق كلّ إستخدام.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'أضف "لا تتبع" إلى كل الروابط الخارجية.';
	$langA['updated'] = 							'محدّث';
	$langA['suspend'] = 							'إيقاف';
	$langA['activate'] = 							'تنشيط';
	$langA['lost_page'] = 							'صفحة ضائعة';
	$langA['suspended'] =							'موقف';
	$langA['disabled'] =							'معطّل';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'تعذر حذف سجل الأخطاء.';
	$langA['ERROR_LOG_DELETED'] = 					'حُذف سجل الأخطاء.';
	$langA['ERROR_LOG_MAXED'] = 						'ملف سجل الأخطاء قد بلغ حجمه الأقصى، رجاءً أفرغ الملف لكي يتمكن السركبت من مواصلة تسجيل الأخطاء. %s';


	$langA['select'] = 								'اختر';
	$langA['description'] = 						'الوصف';


//	adminPlugins
	$langA['data_types'] = 							'أنواع البيانات'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'الأنواع الموجودة';
	$langA['available_plugins'] = 					'الإضافات المتاحة';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'تأشير الكل / إلغاء تأشير الكل';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'متواجد';
	$langA['wbConfig']['online']['desc'] = 			'هل هذا التطبيق موصول بالإنترنت؟';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'مهلة الإغراق (Flood)';
	$langA['wbConfig']['floodInterval']['desc'] = 	'عدد الثواني الي سينتظره مستخدم بدون أذونات بين التحريرات.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'جافاسكربت';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'استخدم HTML Tidy لتصحيح أخطاء إدخالات المستخدم المحتملة.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'كامل الميزات.';
	$langA['wbConfig']['allUsers']['desc'] = 		'اسمح لجميع المستخدمين المسجلين بالحصول على مدوّناتهم الحاصة.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'اختر حساب المستخدم الذي سيُعرض إن لم يدخل الزائر بواحد.';
	$langA['wbConfig']['pUser']['alias'] = 			'المستخدم الافتراضي.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'يحدد كم مرة سيُتحقق من ال IP الخاص بالمستخدم عند التحقق من صحة الجلسات.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'مستوى الجلسة';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

