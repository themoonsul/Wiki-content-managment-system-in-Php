<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'الأذونات';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'هذه الصفحة الخاصة لم تـُعرّف بعد: <tt>%s</tt>';

//	control panel
$langA['general'] = 'عام';
$langA['attachments'] = 'المرفقات';
$langA['account_info'] = 'معلومات الحساب';
$langA['error_log'] = 'سجل الأخطاء';
$langA['advanced_search'] = 'بحث&nbsp;متقدم';
$langA['configuration'] = 'الإعدادات';
$langA['search_options'] = 'خيارات البحث';
$langA['data_types'] = 'أنواع البيانات';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'محتويات ديناميكية';

$langA['tabs'] = 'التبويبات';
$langA['account_display'] = 'عرض الحساب';
$langA['links'] = 'روابط';
$langA['go_to'] = 'إذهب إلى %s.';


$langA['user_statistics'] = 'إحصائيات المستخدم';
$langA['database_info'] = 'معلومات&nbsp;قاعدة البيانات';
$langA['user_preferences'] = 'تفضيلات المستخدم';
$langA['content_license'] = 'رخصة&nbsp;المحتوى';
$langA['user_permissions'] = 'أذونات المستخدم';
$langA['default_page_options'] = 'خيارات&nbsp;الصفحة&nbsp;الافتراضية';
$langA['account_details'] = 'تفاصيل&nbsp;الحساب';
$langA['manage_images'] = 'إدارة&nbsp;الصور';
$langA['manage_files'] = 'إدارة&nbsp;الملفات';
$langA['upload_files'] = 'ارفع الملفات';
$langA['public_templates'] = 'القوالب&nbsp;العامة';
$langA['feeds'] = 'ترويج / ردود';
$langA['recently_modified'] = 'معدّل حديثاً';
$langA['recently_posted'] = 'منشور حديثاً';
$langA['user_edits'] = 'تحريرات المستخدم';

$langA['CONTROL_PANEL_1'] = 'هذه هي لوحة التحكم لـ <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'هل تريد أن ترى %s الخاص بك.';

//specTemplates
$langA['pTemplate'] = 'مواضيع الرزمة';
$langA['custom_theme'] = 'الموضوع حسب الطّلب';
$langA['current_theme'] = 'الموضوع الحالي';
$langA['TEMPLATES_UNAVAILABLE'] = 'مجلد قوالب الحزمات غير متاحة.';
$langA['themes']['default'] = 'افتراضي';
$langA['themes']['simple'] = 'بسيط';
$langA['themes']['three_columns'] = 'ثلاثة أعمدة';
$langA['themes']['floating'] = 'عائم';
$langA['themes']['graphic'] = 'رسومي';

$langA['colors']['colors'] = 'الألوان';
$langA['colors']['black'] = 'أسود';
$langA['colors']['blue'] = 'أزرق';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'بني';
$langA['colors']['green'] = 'أخضر';
$langA['colors']['light_blue'] = 'أزرق فاتح';
$langA['colors']['green'] = 'أخضر';
$langA['colors']['tan'] = 'بني فاتح';
$langA['colors']['red'] = 'أحمر';
$langA['colors']['orange'] = 'برتقالي';
$langA['colors']['gray'] = 'رمادي';


$langA['customize_this_theme'] = 'فصّل هذا الموضوع';



//searchHidden.php
$langA['browse_hidden'] = 'استعرض المخفيات';
$langA['editor_visible'] = 'مرئي بالنسبة للمحررين';


//	WorkGroup.php
$langA['update_permissions'] = 'حدّث الأذونات';
$langA['username_or_ip'] = 'اسم المستخدم أو ال IP';
$langA['status'] = 'الحالة';
$langA['workgroup'] = 'مجموعة عمل';
$langA['admin'] = 'مدير';
$langA['full_owner'] = 'كامل / مالك';
$langA['ban'] = 'حظر';
$langA['banned'] = 'محظور';

//	friends.php
$langA['friends'] = 'الأصدقاء';
$langA['my_status'] = 'حالتي';


$langA['EX_USERNAMES'] = 'مثال: <a>عباس السريع</a>، <a>127.0.0.1</a>، <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'لم تحدد أي أذونات.';
$langA['view_users'] = 'عرض هذا المستخدم...';
$langA['change'] = 'غيّر';
$langA['users'] = 'مستخدمون';

$langA['USER_REMOVED'] = 'أزيل المستخدم <tt>%s</tt> من مجموعة العمل هذه.';
$langA['USER_NOT_REMOVED'] = 'لم يُحذف المستخدم <tt>%s</tt> من هذه المجموعة بنجاح. ';
$langA['ADDED_PERMISSIONS'] = 'الأذونات المضافة لـ <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'الأذونات المحدّثة لـ <tt>%s</tt>.';
$langA['NOT_A_USER'] = 'اسم المستخدم <tt>%s</tt> غير موجود.';
$langA['IP_NOT_ADDED'] = 'تعذر إضافة/تحديث الأذونات لـ <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>تحذير:</b> المستخدم <tt>%s</tt> هو مالك هذا الحساب أصلاً.';
$langA['IP_WRONG_LEVEL'] = '<b>تحذير:</b> عناوين ال IP لا يمكن إعطاؤها صلاحيات أكثر من "مجموعة عمل".';
$langA['SET_PERMISSIONS'] = 'لضبط أذونات "%s"، اختر الحالة المرجوة ثم انقر على "حدّث الأذونات".';


//	specLostPass
$langA['lost_password'] = 'كلمة السر المفقودة';



//	specFileManager
$langA['file_manager'] = 'مدير الملفات';
$langA['image_manager'] = 'مدير الصور';
$langA['CONFIRM_FILE_DELETE'] = 'هل أنت متأكد من أنك تريد حذف <b>%s</b>؟';
$langA['IMAGE_MANAGER_INTRO'] = 'يمكنك استخدام تركيبة ويكي أو html لتضمين هذه الصور في صفحاتك. لبعض أنواع الملفات (قوالب، خرائط...)، نفضـّل استخدام تركيبة html.';
$langA['FILE_MANAGER_INTRO'] = 'قد تستخدم تركيبة ويكي أو html لتضمين هذه الملفات في صفحاتك. لبعض انواع الملفات (القوالب، الخرائط،...) نفضـّل استخدام تركيبة html.';
$langA['file_name'] = 'اسم الملف';
$langA['available_space'] = 'المساحة المتاحة';
$langA['UPLOAD_INTRO'] = 'ارفع ملصقات الملفات والصور لتضمينها في صفحاتك.';
$langA['file_upload'] = 'رفع الملف';
$langA['file_info'] = 'معلومات الملف';
$langA['width'] = 'العرض';
$langA['height'] = 'الارتفاع';
$langA['file_location'] = 'موقع الملف';
$langA['wiki_syntax'] = 'تركيبة ويكي';
$langA['html_syntax'] = 'تركيبة HTML';
$langA['append_to'] = 'إضافة إلى';
$langA['count'] = 'تعداد';
$langA['total_size'] = 'الحجم الكلي';
$langA['images'] = 'الصور';
$langA['overwrite_existing'] = 'الكتابة فوق موجودة';
$langA['compression'] = 'ضغط';

$langA['NOT_AN_IMAGE'] = 'الملف لا يبدو كصورة. رجاءً تحقق من الملف ثم حاول ثانية. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'تعذر حذف <tt>%s</i>.';
$langA['UPLOADED'] = 'رُفع الملف <tt>%s</tt> بنجاح.';
$langA['UPLOADED_RENAMED'] = 'رُفع الملف <tt>%s</tt> كـ <tt>%s</tt>. يمكنك <a %s>إعادة تسميته إلى %s</a>.';
$langA['RENAMED'] = 'أعيد تسمية الملف بنجاح.';
$langA['UPLOAD_FAILED'] = 'فشل نسخ الملف: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'لا يمكن رفع الملف <tt>%s</tt>. <br/>الملفات يجب أن تكون أصغر من <tt>%s</tt> بايتاً.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'اختر نوع الملف:';
$langA['default_options'] = 'الخيارات الافتراضية';
$langA['UNKNOWN_FILE_TYPE'] = 'نوع الصفحة غير معروف: <tt>%s</tt>';

//	specAccountDetails
$langA['account'] = 'الحساب';
$langA['entries'] = 'الإدخالات';
$langA['average'] = 'متوسط';
$langA['uploaded_files'] = 'الملفات المرفوعة';


//	searchTrash
$langA['deleted'] = 'محذوف';
$langA['restore'] = 'استرجاع';
$langA['empty_trash'] = 'أفرغ سلة المهملات';
$langA['CONFIRM_EMPTY_TRASH'] = 'هل أنت متأكد أنك تريد إفراغ سلة المهمات؟';

$langA['DELETED_AFTER_30'] = 'سوف تـُحذف الملفات آلياً بعد 30 يوماً.';
$langA['check_uncheck'] = 'تأشير الكل / إلغاء تأشير الكل';
$langA['DELETED_FILES'] = 'حُذفت الملفات المحددة بنجاح.';
$langA['NOTHING_DELETED'] = 'لا شيء حُذف.';
$langA['DELETE_FILES'] = 'رجاءً اختر الملفات لحذفها.';
$langA['MAP_INVALID_PT'] = 'بيانات الخريطة غير صالحة: تنسيق النقطة غير صالح';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'ميزة البحث في هذا الموقع تبدو كأنها غير مفعّلة. يمكن لمديري الموقع تفعيل هذه الميزة من خلال خيارات البحث في لوحة التحكم.';
$langA['search:'] = 'بحث: ';
$langA['search_for'] = 'بحث عن: ';
$langA['registered'] = 'مسجّل';
$langA['restricted'] = 'حصريّ';
$langA['locked'] = 'مقفل';
$langA['disabled'] = 'معطّل';
$langA['editing_option'] = 'خيار التحرير';
$langA['comments_option'] = 'خيار التعليقات';
$langA['visibility_option'] = 'خيار الرؤية';
$langA['normal'] = 'عادي';
$langA['advanced'] = 'متقدم';
$langA['relevance'] = 'الصلة';
$langA['SEARCH_ONE'] = 'على الأقل لواحدة من الكلمات';
$langA['SEARCH_ALL'] = 'لكل الكلمات';
$langA['SEARCH_EXACT'] = 'للعبارة ذاتها';
$langA['SEARCH_WITHOUT'] = 'بدون الكلمات';
$langA['SEARCH_BEGIN'] = 'للكلمات التي تبدأ بـ';


//	searchKeywords
$langA['keyword_search'] = 'بحث الكلمات الأساسية';
$langA['non_tagged_files'] = 'الملفات غير الموسومة';

//	searchChangeLog
$langA['new'] = 								'جديد';
$langA['DIFF_TITLE'] = 							'قارن الفروق مع أحدث مراجعة';
$langA['indicates_syntax_error'] = 				'يشير إلى خطأ في التركيبة.';
$langA['indicates_unchecked'] = 				'يشير إلى ملف غير متحقـَّق منه';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'اختر رخصة';
$langA['SELECT_LICENSE_DESC'] = 'يفتح صفحة ويب Creative Commons في نافذة منبثقة.';
$langA['DELETE_LICENSE_DESC'] = 'هذا سوف يزيل رخصة محتواك الحالي.';
$langA['LICENSE_UPDATED'] = 'رخصة محتواك قد حُدّثت بنجاح.';
$langA['LICENSE_DELETED'] = 'حُذفت الرخصة';
$langA['LICENSE_DELETED2'] = 'لقد سبق وأن حُذفت الرخصة';
$langA['customize_license'] = 'خصّص رخصتك';

$langA['text_before'] = 'النص أمام الرابط';
$langA['text_after'] = 'النص بعد الرابط';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'باستثناء المنصوص عليه خلاف ذلك، هذا العمل مرخص تحت ';
$langA['LICENSE_TEXT_LINK'] = 'رخصة Creative Commons';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'تحريراتي';

//reorganize
$langA['reorganize'] = 'أعد التنظيم';
$langA['from'] = 'من';
$langA['to'] = 'إلى';
$langA['KEYWORDS_UPDATED'] = 'حُدّثت كلماتك الأساسية.';
$langA['KEYWORDS_EMPTY'] = 'لم تنشئ أي ملفات مع كلمات أساسية حتى الآن.';
$langA['REORGANIZE'] = 'هنا، يمكنك أن تعيد بناء ملفاتك من خلال إعادة تسمية الكلمات الأساسية التي استخدمتها.';

//watch
$langA['WATCH_UPDATED'] = '<a %s>قائمة المشاهدة</a> الخاصة بك حُدّثت.';

//links
$langA['uri'] = 'اسم الموقع';
$langA['label'] = 'عنوان';
$langA['description'] = 'الوصف';
$langA['add_link'] = 'إضافة رابط';
$langA['link_groups'] = 'مجموعات الروابط';
$langA['group'] = 'مجموعة';
$langA['name'] = 'الاسم';
$langA['add_group'] = 'أضف مجموعة';
$langA['add_page'] = 'إضافة صفحة';

$langA['limit'] = 'حدّ';
$langA['random'] = 'عشوائي';
$langA['order'] = 'ترتيب';
$langA['LEAVE_EMPTY'] = 'اتركه خالياً ليصبح بدون حدّ';
$langA['unlimited'] = 'غير محدود';
$langA['type'] = 'النوع';
$langA['auto_detect'] = 'اكتشاف تلقائي';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'تحرك إلى الأعلى';
$langA['move_down'] = 'تحرك إلى الأسفل';
$langA['redirect'] = 'إعادة توجيه';
$langA['content_template'] = 'قالب المحتوى';

