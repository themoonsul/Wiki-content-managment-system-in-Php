<?php
$langA['ILLEGAL_USERNAME'] = 'اسم المستخدم لايمكنه تضمّن الحروف التالية: %s';
$langA['LONG_USERNAME'] = 'اسم المستخدم طويل جداً.';	
$langA['SHORT_USERNAME'] = 'اسم المستخدم قصير جداً.';
$langA['USER_TAKEN'] = 'رجاءً اختر اسم مستخدم مختلف. الاسم <tt>%s</tt> مأخوذ. ';
$langA['USERNAME_ALL_DIGITS'] = 'لا يمكن لاسم المستخدم أن يكون أرقاماً كله.';
$langA['PASSWORDS_DIFFERENT'] = 'كلمات السر لم تتطابق.';
$langA['SHORT_PASSWORD'] = 'كلمة السر قصيرة جداً.';
$langA['EMAIL_REQUIRED'] = 'رجاءا زوّد بعنوان بريد إلكتروني صحيح.';


$langA['register'] = 'تسجيل';
$langA['welcome_to'] = 'أهلاً في ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = 'يجب أن تكون 5 أحرف على الأقل.';
$langA['confirm_password'] = 'تأكيد كلمة السر';
$langA['REG_CONFIRM_PASS'] = 'نفس الأمر أعلاه.';
$langA['REG_EMAIL'] = 'اختياري ولكن مفيد في حال نسيت كلمة السر.';
$langA['REQUIRED_FIELD'] = 'تشير إلى حقل إجباري.';

$langA['REGISTRATION_TEXT'] = 'التسجيل سريع، مجاني وله فوائد عديدة...';
$langA['REG_A_USER_PAGE'] = '/اسم المستخدم/صفحاتك';
$langA['REG_A_MAP_PAGE'] = '/خريطة/اسم المستخدم/خرائطك';

//login
$langA['LOGGED_IN'] = 'أنت مسجل باسم <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'اسم المستخدم المزوّد غير موجود. هل تريد أن تسجّل عضوية %s.';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'فعّل حسابك الآن.';
$langA['ACTIVATED_FROM_EMAIL'] = 'تم تفعيل حسابك.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
