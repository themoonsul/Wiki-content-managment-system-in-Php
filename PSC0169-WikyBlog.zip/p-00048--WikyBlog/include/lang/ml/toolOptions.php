<?php

//	toolOptions.php
$langA['properties'] = 'സവിശേഷതകള്‍';
$langA['file_name'] = 'ഫയില് പേര്';
$langA['update_from'] = 'ഇവിടെ നിന്നും പുതുക്കുക';
$langA['COPY_SYSTEM_FILES'] = 'ഏറ്റവും പുതിയ സഹായ ഫയലുകള്‍ %s ഇല്‍ നിന്നും പകര്‍ത്തുക';

$langA['EDITING_OPTIONS'] = 'ഇ ഫയലുകളില്‍ മാറ്റം അധികാരമുള്ളവരെ നിയന്ത്രിക്കുക.';
$langA['registered_users'] = 'രജി്സ്റ്റ്ര് ചെയ്യപെട്ട ഉപഭോക്താക്കള്‍ ';
$langA['restricted_to'] = 'നിരോധിക്കപെട്ടിരിക്കുന്നു  ';
$langA['admin_only'] = 'അട്മിന് മാത്രം';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Owner Only';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = 'കാണാന്‍ സാധിക്കുക';
$langA['VISIBILITY_OPTIONS'] = 'ലോകത്തെ കാണിക്കാന്‍ തയറല്ലെന്ങില്‍ ഇ ഫയിലിനെ ഒളിപ്പിച്ചു വയ്കുക.';
$langA['visible'] = 'കാണുക';

$langA['COMMENT_OPTIONS'] = 'ഇ ഫയിലിന്‍െറ് അഭിപ്രായങ്ങള്‍ അസധുവാക്കുക';
$langA['enabled'] = 'സാധ്യം';
$langA['disabled'] = 'അസാധ്യമാക്കുക';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = 'മറ്റുള്ളവ';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Remove From Blog';
$langA['repost'] = 'വീണ്ടും പോസ്റ്റു ചെയ്യുക';
$langA['copy_to'] = 'പകര്‍ത്തുക...';
$langA['send_to_trash'] = 'ഉപേക്ഷിക്കുക';
$langA['default_options'] = 'സാധ്യമായ ഓപ്ഷന്സ്';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = 'ഫയില് ടൈപ്പിനു %s സെറ്റുചെയ്യുക '; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = ' ഫയില് വീണ്ടും അയച്ചു.';
$langA['NOT_REPOSTED'] = '<b>എറര്:</b> ഫയില് വീണ്ടും അയയ്ക്കാനാവില്ല.';
$langA['OPTIONS_NOT_CHANGED'] = ' ഫയില് ഒപ്ഷനുകലു മാറ്റിയില്ല.';
$langA['OPTIONS_UPDATED'] = ' ഫയില് ഒപ്ഷനുകലു വിജയകരമായി മാറ്റപെട്ടു.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not updated.';

$langA['redirect'] = 'തിരിച്ചുവിടുക';
$langA['REMOVE_REDIRECT'] = 'ഫയലിനെ തിരിച്ചു വിടാന് തീരുമാനമില്ലെന്കില്  ഇല്ലതാക്കുകയോ  മാറ്റുകയോ ആവാം. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'ഉപഭോക്താവ്&nbsp;അനുവാദം നല്കുക';
