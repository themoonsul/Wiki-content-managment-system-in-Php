<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'The file name has not changed.';
$langA['NOT_RENAMED'] = 'This file could not be renamed to <tt>%s</tt>. Please make sure this file does not already exist.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'Could not rename this file.';
$langA['redirected_to'] = 'Redirected to';
$langA['RENAMED'] = 'This file was successfully renamed.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b>പുന:സ്ഥാപിക്കാപെട്ടു  ';
$langA['ERROR_RESTORING'] = '<b>Error:</b> Could not restore the file at <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = 'ഇ ഫയില്‍ സംരക്ഷിക്കപെട്ടതാണ്.';
$langA['WAS_DELETED'] = '<b>%s</b> ഇല്ലതാക്കി. മുപ്പതു ദിവസത്തേക്ക് ഇ ഫയിലിനെ %s ലേക്ക് സംരക്ഷിച്ചിരിക്കുന്നു.';
$langA['ERROR_DELETING'] = '<b>എറര്:</b>ഫയിലുകളെ ഇല്ലാതാകാന്‍ സാധ്യമല്ല്ല <tt>%s.</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt>ഇല്ലതാക്കി';
