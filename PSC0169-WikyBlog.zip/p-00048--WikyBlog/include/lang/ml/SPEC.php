<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'അനുവാദം നല്കുക';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'ഇ പ്രത്യേക പേജ് ഇതുവരെ വിശദീകരിച്ചിട്ടില്ല:<tt>%s</tt>';

//	control panel
$langA['general'] = 'സാധാരണ';
$langA['attachments'] = 'Attachments';
$langA['account_info'] = 'Account Info';
$langA['error_log'] = 'എറര് ലോഗ്';
$langA['advanced_search'] = 'വിപുലമായ &nbsp;അന്വേഷണം';
$langA['configuration'] = 'കോണ്‍ഫിഗറേഷന്‍';
$langA['search_options'] = 'അന്വേഷണ താല്പര്യങ്ങള്';
$langA['data_types'] = 'ഡാറ്റ രീതികള്‍';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Tabs';
$langA['account_display'] = 'അക്കൌണ്ട് കാണിക്കുന്നത് ';
$langA['links'] = 'Links';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = 'ഉപഭോക്താവിന്ടെ സ്ഥിതിവിവരകണക്ക് ';
$langA['database_info'] = 'ഡാറ്റാബേസ്&nbsp;വിവരം ';
$langA['user_preferences'] = ' ഉപഭോക്താവ് നല്കുന്ന പ്രാധാന്യം';
$langA['content_license'] = 'മാറ്റര്&nbsp;ലൈസന്സ്';
$langA['user_permissions'] = 'User Permissions';
$langA['default_page_options'] = 'സാധ്യമായ&nbsp;പേജ്&nbsp;ഓപ്ഷന്സ്';
$langA['account_details'] = 'അക്കൌണ്ട്&nbsp;വിശദ വിവരങ്ങള്';
$langA['manage_images'] = 'നിയന്ത്രണം&nbsp;ചിത്രങ്ങള്';
$langA['manage_files'] = 'Manage&nbsp;Files';
$langA['upload_files'] = 'Upload Files';
$langA['public_templates'] = 'സമൂഹം&nbsp;ടെമ്പ്ലേറ്റ്';
$langA['feeds'] = 'ഏജന്സി/പ്രോത്സാഹനം  ';
$langA['recently_modified'] = 'അവസാനം പുതുക്കിയത';
$langA['recently_posted'] = 'അവസാനം അയച്ചത്';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = 'This is the Control Panel for <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Would you like to see your %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'ടെമ്പ്ലേറ്റ് ദയറ്ക്ട്രി പാക്കേജ് ലഭ്യമല്ല.';
$langA['themes']['default'] = 'Default';
$langA['themes']['simple'] = 'Simple';
$langA['themes']['three_columns'] = 'Three Columns';
$langA['themes']['floating'] = 'Floating';
$langA['themes']['graphic'] = 'Graphic';

$langA['colors']['colors'] = 'Colors';
$langA['colors']['black'] = 'Black';
$langA['colors']['blue'] = 'Blue';
$langA['colors']['blue-green'] = 'നീല കലര്ന്ന പച്ച';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Green';
$langA['colors']['light_blue'] = 'Light Blue';
$langA['colors']['green'] = 'Green';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Red';
$langA['colors']['orange'] = 'Orange';
$langA['colors']['gray'] = 'Gray';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = 'മറഞ്ഞിരിക്കുന്നത് തിരയുക';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = 'അനുവാദം പുതുക്കുക';
$langA['username_or_ip'] = 'ഉപഭോക്താവിന്റെ പേര് അല്ലെന്കില് ഐ പി ';
$langA['status'] = 'സ്ഥിതി';
$langA['workgroup'] = 'കൂട്ടായ്മ';
$langA['admin'] = 'അട്മിന്';
$langA['full_owner'] = 'മൊത്തം ഉടമ';
$langA['ban'] = 'നിരോധനം';
$langA['banned'] = 'നിരോധിച്ചു';

//	friends.php
$langA['friends'] = 'Friends';
$langA['my_status'] = 'My Status';


$langA['EX_USERNAMES'] = 'ഉദാ:<a>ബില്ലിജോ</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'You have not specefied any permissions.';
$langA['view_users'] = 'ഇ ഉപഭോകതാവിനെ കാണുക...';
$langA['change'] = 'മാറ്റുക';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = 'ഉപഭോക്താവ്<tt>%s</tt> കൂട്ടായ്മയില് നിന്നും മാറ്റപെട്ടു.';
$langA['USER_NOT_REMOVED'] = 'ഉപഭോക്താവ്<tt>%s</tt> കൂട്ടായ്മയില് നിന്നും വിജയകരമായി മാറ്റപെട്ടില്ല. ';
$langA['ADDED_PERMISSIONS'] = 'അനുവാദം കൂട്ടുക<tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'അനുവാദം പുതുക്കുക<tt>%s</tt>.';
$langA['NOT_A_USER'] = 'ഉപഭോക്താവിന്റെ പേര് <tt>%s</tt> കണ്ടെത്താനായില്ല.';
$langA['IP_NOT_ADDED'] = 'ചേറ്ക്കാനോ/അനുവാദം പുതുക്കാനോ <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>ജാഗ്രത:</b>ഉപഭോക്താവ്<tt>%s</tt> മുന്പ് തന്നെ അക്കൌണ്ട്റിന്റെ ഉടമയാണ്    ';
$langA['IP_WRONG_LEVEL'] = '<b>ജാഗ്രത: </b> "കൂട്ടായ്മ" യ്കപ്പുറം ഐ പി അഡ്രസ്സ് നല്കാന് സാധ്യമല്ല.';
$langA['SET_PERMISSIONS'] = 'അനുവാദം നല്കു "%s", പ്രത്യേക സ്ഥിതി തിരഞ്ഞെടുത്തു "അനുവാദം പുതുക്കുക" ക്ലിക്ക് ചെയ്യുക.';


//	specLostPass
$langA['lost_password'] = 'നഷ്ടമായ അടയാളവാക്ക്';



//	specFileManager
$langA['file_manager'] = 'ഫയല്‍ മാനേജര്‍';
$langA['image_manager'] = 'Image Manager';
$langA['CONFIRM_FILE_DELETE'] = 'വേണ്ടന്ന് ഉറപ്പാണോ <b>%s</b>?';
$langA['IMAGE_MANAGER_INTRO'] = 'ഇ പേജുകള് ഉള്പ്പെടുത്താന് വികി സിന്്റാക്സ് അല്ലെന്കില് എച്ച് റ്റി എം എല് ഉപയോഗിക്കാം. പ്രത്യേക ഫയല് ടിപുകള്ക്ക്( ടെമ്പ്ലേറ്റ്, മാപ്, മുതലായവ...) എച്ച് റ്റി എം എല് സിന്്റാക്സ് ഉപയോഗിക്കാന് നിര്ദേശം.';
$langA['FILE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these files in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['file_name'] = 'ഫയില് പേര്';
$langA['available_space'] = 'സാധ്യമായ സ്ഥലം';
$langA['UPLOAD_INTRO'] = 'Upload file attachments and images for inclusion in your pages.';
$langA['file_upload'] = 'ഫയില് അപ് ലോഡ്';
$langA['file_info'] = 'ഫയല്‍ വിവരം';
$langA['width'] = 'വീതി';
$langA['height'] = 'ഉയരം ';
$langA['file_location'] = 'ഫയിലിന്റെ സ്ഥലം ';
$langA['wiki_syntax'] = 'വിക്കി സിന്്റാക്സ്';
$langA['html_syntax'] = 'HTML സിന്്റാക്സ ';
$langA['append_to'] = 'ചെര്ക്കപെട്ടു';
$langA['count'] = 'Count';
$langA['total_size'] = 'Total Size';
$langA['images'] = 'Images';
$langA['overwrite_existing'] = 'Overwrite Existing';
$langA['compression'] = 'Compression';

$langA['NOT_AN_IMAGE'] = 'The file does not appear to be an image. Please check the file then try again. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'ഫയലിനെ ഇല്ലതാക്കുക സാധ്യമല്ല <tt>%s</i>.';
$langA['UPLOADED'] = ' ഫയില് <tt>%s</tt> വിജയകരമായി മാറ്റപെട്ടു.';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = 'This file was successfully renamed.';
$langA['UPLOAD_FAILED'] = 'ഫയല് പകര്തുന്നതി പരാജയപെട്ടു: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'ഫയില് ടൈപ്പിനു സെറ്റുചെയ്യുക:';
$langA['default_options'] = 'സാധ്യമായ ഓപ്ഷന്സ്';
$langA['UNKNOWN_FILE_TYPE'] = 'അറിയാത്ത പേജ് ടൈപ്:<tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'അക്കൌണ്ട് ';
$langA['entries'] = 'റികൊര്ട് ചെയ്യപെട്ടത്‌ ';
$langA['average'] = 'ശരാശരി';
$langA['uploaded_files'] = 'അപ് ലോട് ഫയില്';


//	searchTrash
$langA['deleted'] = 'ഇല്ലതാക്കി';
$langA['restore'] = 'പുന:സ്ഥാപിക്കുക';
$langA['empty_trash'] = 'Empty Trash';
$langA['CONFIRM_EMPTY_TRASH'] = 'Are you sure you want to empty your trash?';

$langA['DELETED_AFTER_30'] = 'മുപ്പതു ദിവസത്തിനു ശേഷം ഫയലുകള് തനിയെ ഇല്ലാതാവും.';
$langA['check_uncheck'] = 'എല്ലാം ചെക്ക് ചെയ്യുക / എല്ലാം ചെക്ക് ചെയ്യാതിരിക്കുക ';
$langA['DELETED_FILES'] = ' തിരഞ്ഞെടുത് ഫയലുകള് വിജയകരമായി ഇല്ലതാക്കി.';
$langA['NOTHING_DELETED'] = 'ഒന്നും ഇല്ലാതാക്കിയിട്ടില്ല.';
$langA['DELETE_FILES'] = 'വേണ്ടാത്ത ഫയലുകള് തിരഞ്ഞെടുക്കുക ';
$langA['MAP_INVALID_PT'] = 'അസാധു മാപ് വിവരം. അസാധു പോയിന്റ് ഫോര്മാറ്റ് ';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'അന്വേഷണം ഇന്ന ഫീച്ചര അസാധു. അന്വേഷണം ഇന്ന ഫീച്ചര് ഉപയോഗ യോഗമാക്കാന് അന്വേഷണ ഒപ്ഷനിലെ കണ്ട്രോള് പാനല് വഴി സാധ്യമാണ്.';
$langA['search:'] = 'അന്വേഷണം ';
$langA['search_for'] = 'അന്വേഷണം ഇതില് നിന്നും: ';
$langA['registered'] = 'രജി്സ്റ്റ്ര് ചെയ്യപെട്ടു';
$langA['restricted'] = 'നിരോധിക്കപെട്ടിരിക്കുന്നു ';
$langA['locked'] = 'പൂട്ടിയിരിക്കുന്ന്നു';
$langA['disabled'] = 'അസാധ്യമാക്കുക';
$langA['editing_option'] = 'മാറ്റം വരുത്തുക എന്ന ഓപ്ഷന്';
$langA['comments_option'] = 'അഭിപ്രായങ്ങള് ഓപ്ഷന്';
$langA['visibility_option'] = 'കാണാന് സാധിക്കുക എന്ന ഓപ്ഷന്';
$langA['normal'] = 'സാധാരണ';
$langA['advanced'] = 'വിപുലമായ';
$langA['relevance'] = 'പ്രാധാന്യം';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'For all of the words';
$langA['SEARCH_EXACT'] = 'For the exact phrase';
$langA['SEARCH_WITHOUT'] = 'Without the words';
$langA['SEARCH_BEGIN'] = 'For words beginning with';


//	searchKeywords
$langA['keyword_search'] = 'കീ വാക്ക് അന്വേഷണം';
$langA['non_tagged_files'] = 'ടാഗ് ചെയ്യപെടാത്ത ഫയലുകള്';

//	searchChangeLog
$langA['new'] = 								'പുതിയ';
$langA['DIFF_TITLE'] = 							'അടുത്ത മാറ്റവുമായി താരതമ്യം ചെയ്യുക';
$langA['indicates_syntax_error'] = 				'Indicates a syntax error.';
$langA['indicates_unchecked'] = 				'Indicates an unchecked file.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'ലൈസന്സ് തിരഞ്ഞെടുക്കുക';
$langA['SELECT_LICENSE_DESC'] = 'ഒരു പുതിയ ജന്നലില് സര്ഗ്ഗാത്മക പൊതു വെബ് പേജു തുറക്കപെട്ടു.';
$langA['DELETE_LICENSE_DESC'] = 'ഇതു ഇപ്പോഴത്തെ ലൈസന്സ് മാറ്റും.';
$langA['LICENSE_UPDATED'] = 'നിങ്ങളുടെ ലൈസന്സ് വിജയകരമായി മാറ്റപെട്ടു.';
$langA['LICENSE_DELETED'] = 'ലൈസന്സ ഇല്ലതാക്കി';
$langA['LICENSE_DELETED2'] = 'ലൈസന്സ് നേരത്തെ തന്നെ ഇല്ലതാക്കി';
$langA['customize_license'] = 'നിങ്ങളുടെ ലൈസന്സ് ആവശ്യാനുസരണം മാറ്റുക';

$langA['text_before'] = 'മാറ്റ്ര് ലിങിനു മുന്പ്';
$langA['text_after'] = 'മാറ്റ്ര് ലിങിനു ശേഷം';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Except where expressly noted, this work is licensed under a ';
$langA['LICENSE_TEXT_LINK'] = 'സര്ഗ്ഗാത്മക പൊതു ലൈസന്സ്';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganize';
$langA['from'] = 'From';
$langA['to'] = 'To';
$langA['KEYWORDS_UPDATED'] = 'Your keywords have been updated.';
$langA['KEYWORDS_EMPTY'] = 'You have not created any files with keywords yet.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = 'വിശധ വിവരം';
$langA['add_link'] = 'Add Link';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Group';
$langA['name'] = 'Name';
$langA['add_group'] = 'Add Group';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Limit';
$langA['random'] = 'Random';
$langA['order'] = 'Order';
$langA['LEAVE_EMPTY'] = 'Leave empty for no limit';
$langA['unlimited'] = 'അപരിമിതം';
$langA['type'] = 'Type';
$langA['auto_detect'] = 'Auto Detect';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'Move Up';
$langA['move_down'] = 'Move Down';
$langA['redirect'] = 'തിരിച്ചുവിടുക';
$langA['content_template'] = 'Content Template';

