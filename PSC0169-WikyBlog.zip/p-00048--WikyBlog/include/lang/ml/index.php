<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = ' ഫയില്‍';
$langA['edit'] = 'മാറ്റം';
$langA['edits'] = 'Edits';
$langA['view_source'] = 'സ്രോതസ്സ് കാണുക';
$langA['talk'] = 'പറയുക';
//$langA['reply'] = 'Reply';
$langA['history'] = 'ചരിത്രം';
$langA['diff'] = 'വ്യത്യാസം';
$langA['watch'] = 'Watch';
$langA['unwatch'] = 'Unwatch';
$langA['options'] = 'ഒപ്ഷനുകലു';


$langA['messages'] = 'ര്‍ദേശങ്ങള്‍ ';
$langA['current'] = 'ഇപ്പോഴത്തെ';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Possible';

$langA['DEFAULT_CONTENT'] = 'ഇതാണ് പുതിയ ഫയില്‍, തുടരണോ [[%s?cmd=മാറ്റം|ഉണ്ടാക്കുക]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'ഇതാണ് പുതിയ ഫയില്‍. സാധ്യമായ അവകശ്ങ്ങള് ഉപയോഗിച്ചു ലോഗിന്‍ ചെയ്തു പുതിയ ഫയില്‍ തുറക്കണം';

$langA['NOT_OWNER'] = 'ഇ ഫീച്ചര്‍ ഉപയോഗിക്കാന്‍ അവകാശം ഇല്ല ';
$langA['LONG_PATH'] = 'The title for this file was too long and has been truncated.';
$langA['EMPTY_CONTENT'] = 'മാറ്റര്‍ അത്യാവശ്യം';
$langA['INCOMPLETE_PATH'] = 'തന്നിരിക്കുന്ന വഴി പൂര്‍ണമല്ല';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'ക്ഷമിക്കുക, അട്മിനിസട്രേറ്റ്റ്റ്ര് നിങ്ങളുടെ ബ്ലോഗിങ്ങ് അസ്സാധ്യമാക്കിയിരിക്കുന്നു. അതേ ഫെച്ചു‌രുകളോട് കൂടിയ ബ്ലോഗ് ഉണ്ടാകാന്‍, സന്ദര്ഷിക്ക് <a href="http://www.wikyblog.com">WikyBlog.com</a>. ';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = 'ഫയില് "മറഞ്ഞിരിക്കുന്നു" ';
$langA['DELETED_FILE'] = 'ഇ ഫയിലിപ്പോള്‍ ട്രാഷിലാണ്. ഇ അക്കൌന്ടിന്ടെ ഉടമ നിങ്ങളാണെന്കില്, കണ്ട്രോള്‍ പാനല്‍ വഴി  അത് വീണ്ടെടുക്കാനാവും.';
$langA['PROTECTED_FILE'] = ' ഫയില് സംരക്ഷിക്കപെട്ടു. ഫയലിലെ മാറ്റങ്ങള് സംരക്ഷിക്പെട്ടില്ല.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'ലിങ്ക് മാറ്റ്ര്';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'പേജ് %s ലേക്ക് പോകുന്നു.';

//	Data Types
$langA['all'] = 'എല്ലാം';
$langA['page'] = 'പേജ്';
$langA['comment'] = 'നിര്ദേശം ';
$langA['map'] = 'മാപ്';
$langA['template'] = 'ടെമ്പ്ലേറ്റ്';
$langA['help'] = 'സഹായം';
$langA['skeleton'] = 'രൂപരേഖ';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'അഭിപ്രായങ്ങള്‍';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'പേജുകള്‍ ';
$langA['CLASScomment'] = 'അഭിപ്രായങ്ങള്‍';
$langA['CLASSmap'] = 'മാപുകള്‍ ';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'സഹായം';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' സെക്കണ്ടസ്';
$langA['queries'] = ' ചോദ്യങ്ങള്‍';

$langA['QUERY_TIME'] = ' ചോദ്യങ്ങള്‍ക്കായി';
$langA['INVALID_PATH'] = 'ഫയിലിന്റെ വഴി അസാധു:<tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Invalid Request.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = 'പുതിയ സഹായ ഫയില്‍ നിര്‍മ്മിക്കുക';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'തിരയുക';
$langA['change_log'] = 'ലോഗ് മാറ്റുക';
$langA['control_panel'] = 'കണ്ട്രോള്‍ പാനല്‍ ';
$langA['administration'] = 'അധികാരം ';
$langA['preferences'] = 'പ്രാധാന്യം';
$langA['watchlist'] = 'Watchlist';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'അന്വേഷണം';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'External Links';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'അടുത്ത കാലത്ത് അയച്ചവ';
$langA['NEED_INTERNET'] = 'ഇന്റര്നെറ്റുമായി ബന്ധിപ്പിച്ച സിസ്റ്റത്തില്‍ മാത്രം ലഭ്യമായ ഫീച്ചര്‍';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>ജാഗ്രത: </b> തുടരാന്‍ കുക്കീസ് ആവശ്യമാണ്. കുക്കീസ് സാധ്യമാനെങ്ങില്‍ ഇ പേജ് മിനുക്കി തുടരുക.';
$langA['LOGIN_REQUIRED'] = 'ഇ ഫീച്ചര് ഉപയോഗിക്കാന് സൈന്‍ ഇന്‍ ചെയ്യണം.';

$langA['ENTER_USERNAME'] = 'പുതിയ തലകെട്ട് ഉള്പെടുത്തുക';
$langA['ENTER_PASSWORD'] = 'ഉപഭോക്താവ്‌ പേര്‍ എന്റര്‍ ചെയ്യുക';
$langA['LOGGED_OUT'] = 'നിങ്ങള്‍ വിജകരമായി പുറത്തിറങ്ങിയിരിക്കുന്നു.';
$langA['AUTO_LOGOUT'] = 'നിങ്ങളുടെ സെഷാന്റെ സമയം കഴിഞ്ഞു  ';

$langA['LOGIN_FAILED'] = 'ലോഗിന്‍ പരാജയപെട്ടു. അടയാള വാക്ക് തെറ്റു<ul><li>. വലിയ അക്ഷരം ഓണ്‍ ആണോ?<li>നിങ്ങള്‍ %sഅടയാള വാക് മറന്നോ%s? </li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'പരമാവതി %s ലോഗിന്‍ പ്രയത്നങ്ങളുടെ എണ്ണം അധികരിചിരിക്കുന്ന്നു. അടുത്ത %s മിനുടുകളില്‍ നിങ്ങളുടെ ലോഗിന്‍ അനുവദനീയമല്ല. ';
						
$langA['create_new'] = 'ഉണ്ടാകകുക&nbsp;പുതിയ ';
$langA['remember_me'] = 'ഓര്‍ക്കുക';
$langA['log_out'] = 'പുറത്തിറങ്ങുക  ';
$langA['log_in'] = 'ലോഗിന്‍';

//	SAVING 
$langA['syntax_error'] = 'സിന്‍്റാക്സ് തെറ്റ്‌ ';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>സിന്്റാക്സ് തെറ്റ്:</b> അനുയോജ്യമായ സിന്റ്റാക്സ് അല്ലതതിനെ തുടര്‍ന്നു ഏറ്റവും മുതിയ മാറ്റങ്ങള്‍ സംരക്ഷിക്കാനോ/ കാണിക്കാനോ സാധ്യമല്ല.   ';
$langA['SYNTAX_FIXED'] = 'സിന്റ്റാക്സ് തെറ്റു തിരുത്തി.';


$langA['NO_CHANGES'] = 'ഇ ഫയിലിനു മാറ്റങ്ങള്‍ വരുത്തിയിട്ടില്ല. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'ഫയലിനെ രക്ഷിക്കാന് സാധ്യമല്ല.(%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'ഫയലിലെ മാറ്റങ്ങള്‍ സംരക്ഷിക്കപെട്ടു';
$langA['HIDDEN_FILE3'] = '<b>ശ്രദ്ധിക്കുക:</b> ഇതൊരു ഒളിപിച്ച ഫയലാണ്‌, അതിനാല്‍ മൊത്തം ഉപഭോക്താവ്‌ മെനുവില്‍ ഇതുള്‍പെടില്ല  ';

$langA['VERSION_CONFLICT'] = 'ജാഗ്രത:വെര്ഷന് വ്യത്യാസം കാരണം മാറ്റങ്ങള് സംരക്ഷികാന് സാധ്യമല്ല ';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'ഓരോ %s സേക്കണ്ടിലും ഒരു ഫയില്‍ മാത്രമെ മാറ്റാന്‍ കഴിയു . %s സെകന്ദ്‌ കഴിഞ്ഞു  വീണ്ടും ശ്രമിക്കുക .';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'ഓപ്ഷന്‍സ് രക്ഷിക്കുക ';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = 'വ്യത്യാസങ്ങള്‍ ';
$langA['line_num'] = 'വരി #';


//	toolHistory1.php
$langA['revision'] = 'മാറ്റങ്ങള്‍ ';
$langA['revision_as_of'] = 'മാറ്റങ്ങള്‍ അതുപോലെ ';
$langA['revision_num_as_of'] = 'മാറ്റങ്ങള്‍ %s അതുപോലെ %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'മാറ്റങ്ങള്‍ തിരുത്തുക';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'തിരിച്ചു മാറത്തിലെക്ക് # ';
$langA['SET_USER_PERMISSIONS'] = 'ഇ ഉപഭോക്താവിന് അനുവാദം നല്കുക '; 
$langA['compare_with_prev'] = '←മുന്സ്ഥിതിയുമായി താരതമ്യം ചെയ്യുക';
$langA['current_revision'] = 'ഇപ്പോഴത്തെ മാറ്റം';
$langA['compare_with_next'] = 'അടുത്ത മാറ്റവുമായി താരതമ്യം ചെയ്യുക→';
$langA['lines'] = 'വരികള്‍';
$langA['text'] = 'മാറ്റ്ര്‍';
$langA['vs'] = ' വിസ് ';
$langA['content'] = 'മാറ്റര്';
$langA['your_text'] = 'നിങ്ങളുടെ മാറ്റ്ര്';
$langA['show_prev_revision'] = '← മാറ്റങ്ങള് %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'മാറ്റങ്ങള് %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>ജാഗ്രത:</b> ഏറ്റവും പുതിയ മാറ്റങ്ങളില്‍ വീണ്ടും മാറ്റമില്ല.<br /> സംരക്ഷിക്കല്‍ ഏറ്റവും പുതിയ വെര്‍ഷനെ നിലനിര്‍ത്തുന്നു.';
$langA['SELECT_TWO_VERSIONS'] = 'ദയവായി രണ്ടു വ്യത്യസ്ത വെര്‍ഷനുകളെ താരതമ്യം ചെയ്യുക.';
$langA['NO_UNIQUE_REVISION'] = 'ഇ ആവശ്യത്തിനു ഒരു പ്രത്യേക വെര്‍ഷനെ കണ്ടെത്താനായില്ല.';
$langA['INVALID_REVISION'] = '<b>മാറ്റങ്ങള്:</b>റിവിഷന് അക്കം അസാധു ';
$langA['NO_DIFFERENCES'] = 'രണ്ടു റിവിഷനുകള്‍ താരതമയ്പെടുതിയപ്പോള്‍ മാറ്റമില്ല.';
$langA['NO_REVISIONS'] = 'രണ്ടു റിവിഷനുകള് താരതമയ്പെടുതിയപ്പോള് അത്യാവശ്യം.';
$langA['NON_EXISTANT'] = 'This file does not exist yet.';

//	toolEditPage.php
$langA['bold_text'] = 'ഖനമുള്ള മാറ്റ്ര്';
$langA['italic_text'] = 'മാറ്റ്ര്';
$langA['headline_text'] = 'തലകെട്ട് ഉള്പെടുത്തുക';
$langA['title'] = 'തലകെട്ട്';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = 'ഉള്ളിലുള്ള ലിങ്ക് ';
$langA['link'] = 'ലിങ്ക് ';
$langA['external_link'] = 'പുറത്തുള്ള ലിങ്ക് ';
$langA['embed_image'] = 'ഉള്ള ചിത്രം';
$langA['find_images'] = 'Find Images';
$langA['image'] = 'ചിത്രം';
$langA['nowiki'] = 'വികിഇല്ല ';
$langA['NOWIKI_TEXT'] = 'ക്രമീകരിച്ച മാറ്റ്ര് ഇവിടെ ഉള്പെടുത്തുക';
$langA['signature'] = 'Signature';
$langA['SIGNATURE_TEXT'] = 'Insert your Signature';
$langA['preview'] = 'കാണുക';
$langA['PREVIEW_TEXT'] = 'Preview your changes [%s-p]';
$langA['PREVIEW_WARN'] = 'ഇതു കാണുന്നതില്‍ മാത്രമെ ഉള്ളു. മാറ്റങ്ങള് സംരക്ഷിക്പെട്ടില്ല!';
$langA['SAVE_TEXT'] = 'മാറ്റങ്ങള്‍ രക്ഷിക്കുക [%s-s]';
$langA['reset'] = 'പുനര്‍ക്രമീകരിക്കുക';
$langA['RESET_TEXT'] = 'Reset this form to it\'s original state [%s-c]';
$langA['changes'] = 'മാറ്റങ്ങള്‍';
$langA['CHANGES_TEXT'] = 'Show the changes you\'ve made to this file. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'കൊമ്മായാല്‍ വേര്‍തിരിച്ച തകോല്‍ വാക്കുകളാല്‍ നിങ്ങളുടെ പോസ്റ്റുകളെ ക്രമീകരിക്കുക'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'ടാഗുകള്‍';
$langA['edit_summary'] = 'സംക്ഷിപ്ത രൂപത്തെ മാറ്റുക';
$langA['syntax_warning'] = 'സിന്്റാക്സ് ജാഗ്രത';
$langA['NO_IMAGES'] = 'ചിത്രങ്ങള്‍ കന്ടെത്തിയില്ല';
$langA['insert_emoticons'] = 'ചിഹ്നങ്ങള്‍ ഉള്പെടുത്തുക';
$langA['upload'] = 'അപ് ലോഡ്';



//searchHistory
$langA['show'] = 'കാണിക്കുക';
$langA['hide'] = 'Hide';
$langA['compare'] = 'താരതമ്യപെടുത്തുക';
$langA['timeline'] = 'സമയരേഖ';
$langA['summary'] = 'സംക്ഷിപ്ത രൂപം';
$langA['COMPARE_REVISONS'] = 'തിരഞ്ഞെടുത്ത മാറ്റവുമായി താരതമ്യം ചെയ്യുക→';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'തന്നിരിക്കുന്ന ഫയില്‍ ടൈപ്പ് അസാധു.';


//	SEARCH
$langA['next'] = 'അടുത്തത്';
$langA['previous'] = 'മുമ്പത്തെ';
$langA['order_by'] = 'അവശ്യ പ്രകാരം:';
$langA['ascending'] = 'ക്രമമായി മുകളിലോട്ട്';
$langA['descending'] = 'ക്രമമായി താഴോട്ടു ';
$langA['search_from'] = 'അന്വേഷണം ഇതില്‍ നിന്നും: ';
$langA['all_users'] = 'എല്ലാ ഉപഭോക്താക്കളും';
$langA['user'] = 'ഉപഭോക്താവ്';
$langA['from_file_type'] = 'ഫയില്‍ ടൈ്പ്പില് നിന്നും അന്വേഷിക്കുക: ';
$langA['read_more'] = 'അധികം വായിക്കുക';
$langA['words'] = ' വാക്കുകള്';

$langA['RESULTS'] = 'റിസള്‍ട്ട് %s മുതല്‍%s ന്ടെ %s '; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'അന്വേഷണ മാനദണ്ടത്തില് പുതിയ എന്‍ട്രി ഉള്പെട്ടില്ല.';

//searchTalk
$langA['add_comment'] = 'പുതിയ വിഷയം ഉള്‍പ്പെടുത്തുക';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'ജഗത ഉള്പ്പെടുതനവില്ല. അധിക എന്‍ട്രി ക്രമീകരണം നന്നായിട്ടില്ല.';
$langA['duplicate_entry'] = 'അധിക എന്‍ട്രി';
$langA['DUPLICATE_ENTRY'] = ' ലെ പേജില്‍ ഇതൊരു അധിക എന്‍ട്രി ആണ്%s. <br/>ഇ പേജ് തിരഞ്ഞെടുക്കുനതിനു മുന്പ് അധികമായ എന്ട്രികളെ ഒഴിവാക്കണം.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'കന്ടെത്തിയില്ല: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>എറരr:</b><br /> ഇ സ്ക്രിപ്റ്റ് നടപ്പിലാക്കുമ്പോള്‍ ഒരു എറര്‍ സംഭവിച്ചു.<br /> ഇ അഭ്യര്‍ഥന മാനിച്ച്‌ എറര്‍ ലോഗിലെ തെറ്റുതിരുത്താന്‍ ശ്രമിക്കുക.%s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'നിലവിളുണ്ടായിരുന്ന സ്റൈലുകളെ മാറ്റാന്‍ സാധ്യമല്ല';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'സി എസ് എസ്1';
$langA['css2'] = 'സി എസ് എസ്2';
$langA['INVALID_THEME'] = 'പറഞ്ഞിരുന്ന തീം അസാധു';

//
//	CLASSmap
//
$langA['new_marker']='പുതിയ അടയാളം ';
$langA['new_route']='പുതിയ റൂട്ട് ';
$langA['SAVE_HEADER']='സംരക്ഷിക്കുനതിനു മുന്പ് ഓര്ക്കുക';
$langA['save_map']='മാപ് രക്ഷിക്കുക';
$langA['continue_editing']='മാറ്റംവരുതല് തുടരുക';
$langA['miles/km'] = 'മൈല്സ്/ കിലോമീറ്റര്‍';
$langA['MAP_DEFAULT_CONTENT'] = '<b>ഇതാണ് പുതിയ മാപ്.</b><br/>മാപ് ഉണ്ടാക്കാനോ മാറ്റം വരുതാണോ,"മാറ്റം"ത്തില് അമര്ത്തുക.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'ക്ഷമിക്കുക, സാധ്യമായ അവകാശം ഉപയോഗിച്ചു മാപ് മാറ്റാന്‍ സാധ്യമല്ല. ';
$langA['play'] = 'തുടങ്ങുക';
$langA['stop'] = 'നിര്‍ത്തുക';
$langA['import'] = 'ഇറക്കുമതി';
$langA['export'] = 'കയറ്റുമതി';
$langA['gpx_data'] = 'GPX ഡാറ്റ ';
$langA['gpx_exchange_format'] = 'GPX കൈമാറല്‍് രീതി';
$langA['CLICK_EDIT'] = 'മാപില്‍ മാറ്റം വരുത്താന്‍, "മാറ്റം" അമര്‍ത്തുക ';


//	smileys
$langA['smiles'][':D'] = 'വളരെ സന്തോഷം';
$langA['smiles'][':)'] = 'പുഞ്ചിരി';
$langA['smiles'][':('] = 'ദു:ഖം';
$langA['smiles'][':o'] = 'അതിശയം';
$langA['smiles'][':shock:'] = 'ഞെട്ടല്‍';
$langA['smiles'][':?'] = 'സംശയം';
$langA['smiles']['8)'] = 'സമാധാനം';
$langA['smiles'][':lol:'] = 'ചിരി';
$langA['smiles'][':x'] = 'ഭ്രാന്തു';
$langA['smiles'][':P'] = 'മുരളല്‍';
$langA['smiles'][':oops:'] = 'അപകര്‍ഷതാ';
$langA['smiles'][':cry:'] = 'കരയുക അല്ലെങ്കില്‍ വളരെ ദു:ഖത്തോടെ';
$langA['smiles'][':evil:'] = 'ദോഷൈക ദൃക്ക് അല്ലെങ്കില്‍ ഭ്രാന്തു';
$langA['smiles'][':twisted:'] = 'തലതിരിഞ്ഞ ദോഷൈക ദൃക്ക്';
$langA['smiles'][':roll:'] = 'കറങ്ങുന്ന കണ്ണുകള്‍';
$langA['smiles'][':wink:'] = 'ചിമ്മുക';
$langA['smiles'][':!:'] = 'അതിശയം';
$langA['smiles'][':?:'] = 'ചോദ്യം';
$langA['smiles'][':idea:'] = 'ആലോചന';
$langA['smiles'][':arrow:'] = 'അസ്ത്രം';
$langA['smiles'][':|'] = 'നിര്‍വീര്യം';
$langA['smiles'][':mrgreen:'] = 'നിര്‍വീര്യം';

//
//	General Language
//
$langA['or'] = 'അല്ലെങ്കില്‍';
$langA['username'] = 'ഉപഭോക്താവിന്റെ പേര്‍ ';
$langA['password'] = 'അടയാളവാക്ക്';
$langA['email'] = 'ഇ-മെയില്';
$langA['register'] = 'രജി്സ്റ്റ്ര്';
$langA['cancel'] = 'നിരസിക്കുക';
$langA['language'] = 'ഭാഷ';
$langA['use'] = 'Use';
$langA['copy'] = 'Copy';
$langA['rename'] = 'Rename';

$langA['on'] = 'ഓണ്‍';
$langA['partial'] = 'പകുതി';
$langA['off'] = 'ഓഫ്';
$langA['save'] = 'രക്ഷിക്കുക';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'വിശദീകരികാത്തത് ';
$langA['homepage'] = 'ഗൃഹം പേജ്';
$langA['home'] = 'ഗൃഹം ';
$langA['go'] = 'Go';
$langA['user_menu'] = 'User Menu';

$langA['last_modified'] = 'അവസാനം പുതുക്കിയത';
$langA['LAST_MODIFIED'] = 'അവസാനം പുതുക്കിയത് %s ആരാല്‍ %s.';//%s replaced with date and username
$langA['accessed_times'] = '%s പ്രാവശ്യം കയറി';// %s replaced with a number
$langA['modified'] = 'പുതുക്കിയത്';
$langA['posted'] = 'ഉണ്ടാക്കി';
$langA['created'] = 'ഉണ്ടാക്കി';
$langA['hidden'] = 'മറഞ്ഞിരിക്കുന്നത്‌';
$langA['what_links_here'] = 'What Links Here';
$langA['share'] = 'Share';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'ഇ മാറ്റങ്ങള്‍ വരുത്തുന്നതിന് മുന്പ് ഫയില്‍ സംരക്ഷിക്കുക.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'വലുപ്പം ';
$langA['bytes'] = 'ബൈത്സ്';
$langA['kb'] = 'കെ ബി';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'പുതുക്കുക ';
$langA['editing'] = 'മാറ്റം വരുത്തുക';
$langA['workgroup'] = 'കൂട്ടായ്മ';
$langA['BROWSE_HIDDEN'] = 'മറഞ്ഞിരിക്കുന്നത് ഫയിലിനെ കണ്ടെത്തുക';

$langA['delete'] = 'ഇല്ലാതാക്കുക';
$langA['confirm_delete'] = 'ഇല്ലാതാക്കല്‍ ഉറപ്പിക്കുക ';
$langA['continue'] = 'തുടരുക';
$langA['back'] = 'പിന്നോട്ട് പോവുക';
$langA['close'] = 'Close';
$langA['view'] = 'കാണുക';
$langA['empty'] = '-ശൂന്യമാക്കുക-';
$langA['none'] = 'None';
$langA['total'] = 'ആകെ തുക ';
$langA['files'] = 'ആകെ തുക';
$langA['other'] = 'മറ്റുള്ളവ';
$langA['trash'] = 'ഉപേക്ഷിക്കുക';
$langA['flagged'] = 'Flagged';

$langA['today'] = 'ഇന്നു';
$langA['yesterday'] = 'ഇന്നലെ';
$langA['days_ago'] = ' ദിവസങ്ങള്‍ക്ക് മുന്നേ';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'More';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'Sunday';
$langA['date_l'][1] = 'Monday';
$langA['date_l'][2] = 'Tuesday';
$langA['date_l'][3] = 'Wednesday';
$langA['date_l'][4] = 'Thursday';
$langA['date_l'][5] = 'Friday';
$langA['date_l'][6] = 'Saturday';

$langA['date_D'][0] = 'Sun';
$langA['date_D'][1] = 'Mon';
$langA['date_D'][2] = 'Tue';
$langA['date_D'][3] = 'Wed';
$langA['date_D'][4] = 'Thu';
$langA['date_D'][5] = 'Fri';
$langA['date_D'][6] = 'Sat';


$langA['date_F'][1] = 'January';
$langA['date_F'][2] = 'February';
$langA['date_F'][3] = 'March';
$langA['date_F'][4] = 'April';
$langA['date_F'][5] = 'May';
$langA['date_F'][6] = 'June';
$langA['date_F'][7] = 'July';
$langA['date_F'][8] = 'August';
$langA['date_F'][9] = 'September';
$langA['date_F'][10] = 'October';
$langA['date_F'][11] = 'November';
$langA['date_F'][12] = 'December';

$langA['date_M'][1] = 'Jan';
$langA['date_M'][2] = 'Feb';
$langA['date_M'][3] = 'Mar';
$langA['date_M'][4] = 'Apr';
$langA['date_M'][5] = 'May';
$langA['date_M'][6] = 'Jun';
$langA['date_M'][7] = 'Jul';
$langA['date_M'][8] = 'Aug';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'Oct';
$langA['date_M'][11] = 'Nov';
$langA['date_M'][12] = 'Dec';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabic (ar)';
$langA['lang']['bn'] = 'ബംഗാളി(bn)';
$langA['lang']['de'] = 'German (de)';
$langA['lang']['el'] = 'Greek (el)';
$langA['lang']['en'] = ' ഇംഗ്ലീഷ് ( ഇ ന )';
$langA['lang']['es'] = 'Spanish (es)';
$langA['lang']['fr'] = 'French (fr)';
$langA['lang']['hu'] = 'ഹനഗേറിയന് (ഹ)';
$langA['lang']['it'] = 'Italian (it)';
$langA['lang']['ja'] = 'Japanese (ja)';
$langA['lang']['ko'] = 'Korean (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Dutch (nl)';
$langA['lang']['pl'] = 'Polish (pl)';
$langA['lang']['ro'] = 'റോമാനിയന്‍ (റോ)';
$langA['lang']['ru'] = 'Russian (ru)';
$langA['lang']['tr'] = ' ടര്കിഷ് ( ടി ര )';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'Chinese (zh)';
$langA['lang']['zh-cn'] = 'Chinese Simplified (zh-cn)';



