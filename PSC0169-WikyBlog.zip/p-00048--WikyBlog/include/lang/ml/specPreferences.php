<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'നിലവിലുള്ള മൂല്യങ്ങളില് മാറ്റമില്ല ';
$langA['INVALID_PREFS'] = ' <b>ജാഗ്രത:</b>നിലവിലുള്ള മൂല്യങ്ങളില് മാറ്റം സാധ്യമല്ല.';

$langA['EMAIL_PREFS'] = 'അടയാളവാക്ക് മറന്നാല് ഉപയോഗപ്രദം';

$langA['LANG_PREFS'] = 'ഭാഷ തിരഞ്ഞെടുക്കുക';

$langA['javascript_preferences'] = 'JavaScript Preferences';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Turn on/off JavaScript enhancements. Some features will not work properly when JavaScript is disabled.';

$langA['time_zone'] = 'സമയ സോണ് ';
$langA['TIME_ZONE_PREFS'] = 'സരുവരിലെ സമയവും ലോക്കല് സമയവും തമ്മില്ലുള്ള വ്യത്യാസം : <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'Server time is now %s. <br/>Your adjusted time is %s.';

$langA['sig'] = 'Signature';
$langA['SIGNATURE'] = 'Customize your signature with wiki syntax.';


$langA['home_title'] = 'ഗൃഹ തലകെട്ട് ';
$langA['HOME_TITLE_PREFS'] = 'ഗൃഹപേജിലെ തലകേട്ടില് ഉള്ളതു പോലെ.  ';

$langA['blog_styled_frontpage'] = 'ബ്ലോഗ് സ്റ്റൈല് ഗൃഹ പേജ്';
$langA['BLOG_PREFS'] = 'ഗൃഹ പേജ് ബ്ലോഗായി കാണിക്കുക ';

$langA['blogT'] = 'Blog Type';
$langA['BLOG_TYPE'] = 'Select among available data types to blog.';

$langA['selective_blogging'] = 'Selective Blogging';
$langA['SELECTIVE_BLOGGING'] = 'Selective Blogging allows you to blog only those pages you want displayed on the front page.';

$langA['blog_count'] = 'ബ്ലോഗിന്റെ എണ്ണം';
$langA['BLOG_COUNT'] = 'നിങ്ങളുടെ ബ്ലോഗ് നിരീക്ഷിച്ചവരുടെ എണ്ണം';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'Display the "Share" link at the bottom of each file.';

$langA['ihelp'] = 'Help Links';
$langA['IHELP'] = 'Show help links.';

$langA['uServices'] = 'Update Services';
$langA['UPDATE_SERVICES'] = 'When you publish a new post, the following update services will automatically be notified. Separate multiple service URIs with line breaks.';
$langA['BAD_UPDATE_SERVICES'] = 'Invalid URI(s) given for Update Services';


$langA['VIEW_THEME'] = '<a %s>Edit or copy</a> this theme.';

$langA['quick_comment'] = ' പെട്ടന്നുള്ള നിര്ദേശം ';
$langA['QUICK_COMMENT'] = 'When on, a form will be displayed at the top of talk pages for faster commenting.';

$langA['textarea rows'] = ' 	 എഴുതാവുന്ന വാക്കുകളുടെ നിരകള്';
$langA['TEXTAREA_ROWS_PREFS'] = 'എഴുതാവുന്ന വാക്കുകളുടെ വിസ്തീരണവും ഉയരവും ';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'സെര്വ്റില്  ഓരോ ഫയിലിനും ചരിത്ര നിരകള് പരിമിതപെടുത്തുന്നു.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Maximum %s.';

$langA['tab_limit'] = 'ടാബിന്റെ പരിധി ';
$langA['TAB_LIMIT'] = 'JavaScript will automatically close tabs once the number of opened tabs has reached this limit. Defaults to 7. Set to 1000 or more if you don\'t want JavaScript to manage your tabs.';

$langA['EXTERNAL_LINKS'] = 'External links will be opened in a new window when "On".';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'കീബോര്‍ഡിലെ കുറുക്ക് വഴികള്‍';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = 'മാറ്റങ്ങള് രക്ഷിക്കുക';

$langA['CONFIRM_CHANGE'] = 'നിലവിലുള്ള മൂല്യങ്ങളില് മാറ്റണമെന്ന് ഉറപ്പോ?';
$langA['preference'] = 'Preference';
$langA['old_value'] = 'പഴയ മൂല്യങ്ങള് ';
$langA['new_value'] = 'പുതിയ മൂല്യങ്ങള് ';

$langA['changes'] = 'മാറ്റങ്ങള്‍';
$langA['PREFS_CHANGED'] = 'Your preferences have been updated.<br/> Below is a summary of the values that have changed.';


//check edit
$langA['anonymous'] = 'Anonymous';
$langA['fEdits'] = 'Flag Edits';
$langA['FLAG_EDITS'] = 'Edits made by users with status at or below the selected status will be flagged as "Unchecked" until it is reviewed by the account owner.';

//save all edits
$langA['saveAll'] = 'Log All Edits';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
