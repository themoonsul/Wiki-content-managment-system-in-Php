<?php

	$langA['googleMapKeys'] =						'ഗൂഗിള്‍ മാപിന്റെ എ പി ഐ കീ.';


	$langA['ADMIN_ONLY'] =							'ഈ താളിലെത്താന്‍ നിങ്ങള്‍ ഒരു നിര്‍വ്വാഹകന്‍ ആയിരിക്കണം';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'നിര്‍വ്വാഹകതാള്‍ ഇതു വരെ നിര്‍വ്വചിച്ചിട്ടില്ല';
	
	$langA['CONFIRM_PASSWORD'] =						'ദയവായി നിങ്ങളുടെ അടയാളവാക്ക് ഉറപ്പാക്കുക';
	$langA['confirm_password'] =						'അടയാളവാക്ക് ഉറപ്പാക്കുക';
	$langA['confirmation_failed'] =					'അടയാളവാക്ക് ഉറപ്പാക്കല്‍ പരാജയപ്പെട്ടു.വീണ്ടും ശ്രമിക്കുക';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'അന്വേഷണ താല്പര്യങ്ങള്';
	$langA['search_status'] =						'അന്വേഷണ സ്ഥിതി';
	$langA['search_enabled'] =						'അന്വേഷണം സാധ്യം';
	$langA['SEARCH_ENABLED'] =						'അന്വേഷണം ഇന്ന ഫീച്ചര്‍ അസാധുവാക്കുന്നത് വഴി  "എല്ലാ അന്വേഷണം" ഡാറ്റാബേസ് ടേബിള്‍ ശൂന്യമാകുന്നു.വീണ്ടും അന്വേഷണം ഇന്ന ഫീച്ചര്‍ ഉപയോഗ യോഗമാക്കാന്‍  "എല്ലാ അന്വേഷണം" ഡാറ്റാബേസ് ടേബിള്‍ നിരയ്കേണ്ടിയിരിക്കുന്നു';
	$langA['disable'] =								'അസാധ്യമാക്കുക';
	
	$langA['search_disabled'] =						'അന്വേഷണം അസാധ്യമാക്കി';
	$langA['SEARCH_DISABLED'] =						'അന്വേഷണം ഇപ്പൊള്‍ അസാധുവാക്കിയിരിക്കുന്നു. അന്വേഷണം ഉപയോഗ യോഗമാക്കക്കുന്നതിനു "എല്ലാ അന്വേഷണം" ഡാറ്റാബേസ് ടേബിളില്‍ എല്ലാ ഫയിലുകളും ചേര്ത്തു ഒരു പദ്ധതി നടപ്പിലാക്കണം. വലിയ ഡാറ്റാബേസിനു കൂടുതല്‍ സമയം വേണ്ടി വന്നേക്കാം. ';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'സാധ്യമാക്കി';
	
	$langA['FINISHED_ENTRIES'] =						'%s തവണ പുതുക്കിയിട്ടുണ്ട്. %s ബാക്കിയുണ്ട്.';
	$langA['SEARCH_IS_ENABLED'] =					'അന്വേഷണം ഇപ്പോള്‍ അസാധ്യമാക്കി';


//
// adminConfig.php
//
	$langA['configuration'] =						'കോണ്‍ഫിഗറേഷന്‍';
	$langA['confighistory'] =						'കോണ്‍ഫിഗറേഷന്‍ ചരിത്രം';
	$langA['CONFIG_SAVING'] =						'നിലവിലുള്ള നിയമങ്ങള്‍ മാറ്റാതെ പുതിയ കോണ്‍ഫിഗറേഷന്‍ സേവ് ചെയ്യുക.അവശ്യം വന്നാല്‍ വരുത്തിയ മാറ്റങ്ങള്‍ പൂര്‍വസ്ഥിതിയില്‍ ആക്കാന്‍ സാധ്യമാണ്‌.  ';
	$langA['CONFIG_STAT'] =							'കോണ്‍ഫിഗറേഷനില്‍ %s തവണ പുതുക്കിയിട്ടുണ്ട്.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'റിവിഷന്‍ അക്കം %s അക്കണമെന്ന് ഉറപ്പാണോ? <tt>Sസേവി</tt>ല്‍ അമര്‍ത്തുക.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'"സെര്‍വര്‍പേര്‍ 1 ലേക്ക് സ്വാഗതം " എന്ന വാചകവുമായി ചേര്‍ത്തു ഉപയോഗിക്കാവുന്നത്. ';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'അപ് ലോട് ചെയ്യേണ്ട ഫയിലിന്‍റെ ഏറ്റവും കൂടിയ വലിപ്പം.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'എറര്‍ ലോകിലെ ഫയലിന് നല്‍കാവുന്ന പരമാവധി വലുപ്പം. സാധ്യമായത്‌ 10,000 ബൈത്സ്. ';
	$langA['errorEmail']['desc'] = 					'ഒരു ഇ- മെയില്‍ അഡ്രസ്സ് നല്കുക.   ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'സാധാരണ സെറ്റിങ്ങ്സ്';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'ചെറിയ സെര്‍വര്‍ പേര്‌';
	$langA['serverName2']['alias'] = 				'സെര്‍വര്‍ പേര്‌';
	$langA['serverName3']['alias'] = 				'മൊത്തം സെര്‍വര്‍ Url';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'പരമാവധി അപ് ലോഡ്';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'ഭാഷ';
	$langA['reservedWords']['alias'] = 				'ഉപയോഗത്തിലിരിക്കുന്ന വാക്കുകള്‍';
	
	$langA['developer_aids'] = 						'ഡവലപ്പറിന്‍റെ ഉപകരണങ്ങള്‍';
	$langA['maxErrorFileSize']['alias'] = 			'എറര്‍ ലോഗിന്റെ വലിപ്പം';
	$langA['errorEmail']['alias'] = 					'എറര്‍ ഇ- മെയില്‍';
	$langA['include']['alias'] = 					'PHP ഉള്‍പ്പെടുത്തുക ';

//
//	default user
//
	$langA['default_user_vars'] = 				'സാധാരണ ഉപഭോക്താവ്‌ സെറ്റിങ്ങ്സ്';
	
	$langA['defaultUser:homeTitle']['alias'] =		'ഗൃഹ തലകെട്ട് ';
	$langA['defaultUser:homeTitle']['desc'] =		'ഗൃഹപേജിലെ തലകേട്ടില്‍ ഉള്ളതു പോലെ.  ';
	
	$langA['defaultUser:template']['alias'] =		'ഉപഭോക്താവ്‌ ടെമ്പ്ലേറ്റ്';
	$langA['defaultUser:template']['desc'] =		'ഗൃഹം/ പ്രധാനം എന്നിവ വികകിബ്ലോഗ് ടെമ്പ്ലേറ്റില്‍ ഡീഫോള്‍ട്ട് ആയി ഉള്ളതു.';
	
	$langA['defaultUser:textareaY']['alias'] =		'എഴുതാവുന്ന വാക്കുകളുടെ വിസ്തീരണവും ഉയരവും ';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'ബ്ലൊഗിന്‍റെ ഗൃഹ പേജ്.';
	$langA['defaultUser:isBlog']['desc'] =			'ബ്ലോഗ് സ്റ്റൈല്‍ ഗൃഹപേജിനെ ഓണോ ഓഫോ ആക്കുക. ';
	
	$langA['defaultUser:timezone']['alias'] =		'സമയ മേഘല.';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'പരമാവധി ചരിത്ര വരികള്‍';
	$langA['defaultUser:maxHistory']['desc'] =		'സാധ്യമായ പരമാവധി ചരിത്ര നിരകള്‍ ';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Add Group';
	$langA['unlimited'] = 'അപരിമിതം';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'ഉപഭോക്താവിന്ടെ സ്ഥിതിവിവരകണക്ക് ';
	$langA['user_stats'] =							'ഉപഭോക്താവിന്ടെ  നില';
	$langA['user_account'] =							'ഉപഭോക്താവിന്ടെ അക്കൌണ്ട് ';
	$langA['entries'] =								'റികൊര്ട് ചെയ്യപെട്ടത്‌ ';
	$langA['history Rows'] =							'ചരിത്ര നിരകള്‍';
	$langA['last_visit'] = 							'മുമ്പത്തെ സഞ്ചാരം';
	
	$langA['users_found'] =							'ഉപഭോക്താവ്‌ കണ്ടെത്തി';
	$langA['showing_of_found'] =						'%s വഴി %s കാണിക്കുന്നു';
	$langA['cpanel'] =								'Cപാനല്‍';
	$langA['details'] =								'വിശദ വിവരങ്ങള്‍';
	
	$langA['within_the_hour'] =						' < 1 മണിക്കുറിനു മുന്പ് ';
	$langA['hours'] =								'മണികൂര്‍';
	$langA['days'] =									'ദിവസം ';
	$langA['months'] =								'മാസം';
	$langA['years'] = 								'വര്‍ഷം ';
	$langA['ago'] = 									'മുന്പ്';
	
	$langA['TIMEOUT'] = 								'<b>പ്രതായ സമയത്തിന്റെ എറര്‍:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'വേണ്ടന്ന് ഉറപ്പാണോ <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'ഇല്ലാതാക്കുന്നത്‌ <i>മുഴുവനായും</i> എല്ലാ ഫയിലുകളെയും അകൌന്ടീനെയും  ഇല്ലാതാക്കും:';
	$langA['userfiles_directory'] = 					'ഉപഭോക്താവ്‌ ഫയലിന്‍്ടെ ദയറ്ക്ട്രി  ';
	$langA['template_directory'] = 					'ടെമ്പ്ലേറ്റ് ദയറ്ക്ട്രി  ';
	$langA['database_entries'] = 					'പിന്നെ എല്ലാ ഡാറ്റാബേസുകളും പേജുകളും പേജു ചരിത്രങ്ങളും അഭിപ്രായങ്ങളും...';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'ഇല്ലാതാക്കിയ ഡാറ്റാബേസുകള്‍്';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>ജാഗ്രത: </b> ഡാറ്റാബേസുകള്് ഇല്ലാതാക്കാന്‍് പറ്റില്ല ';
	
	$langA['DELETED_USERFILES'] = 					'ഉപഭോക്താവ് ദയറ്ക്ട്രി ഫയലി ഇല്ലതാ്കിദയറ്ക്ട്രി ';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>ജാഗ്രത: </b> ഉപഭോക്താവ് ദയറ്ക്ട്രി ഫയലി ഇല്ലാതാക്കാന്് പറ്റില്ല ';
	
	$langA['DELETED_TEMPLATES'] = 					'ടെമ്പ്ലേറ്റ് ദയറ്ക്ട്രി ഇല്ലതാ്കി';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>ജാഗ്രത: </b> ടെമ്പ്ലേറ്റ് ദയറ്ക്ട്രി ഇല്ലാതാക്കാന്് പറ്റില്ല ';
	
	$langA['USER_DELETED'] = 						'%s മുഴുവനായി ഇല്ലതാക്കി ';
	$langA['USER_NOT_DELETED'] = 					'%s മുഴുവനായി ഇല്ലതാക്കിയിട്ടില്ല  ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activate';
	$langA['lost_page'] = 							'നഷ്‌ടമായ പേജ്';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'അസാധ്യമാക്കുക';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				' എറര്‍ ലോഗിനെ ഇല്ലതാക്കിയിട്ടില്ല ';
	$langA['ERROR_LOG_DELETED'] = 					' എറര്‍ ലോഗിനെ ഇല്ലതാ്കി';
	$langA['ERROR_LOG_MAXED'] = 						'എറര് ലോകിലെ ഫയലിന് നല്കാവുന്ന പരമാവധി വലുപ്പം.എറര് ലോകിലെ ഫയലിന് ശൂന്യമാക്കുക, അതോടെ സ്ക്രിപ്റ്റ് തുടരാം %s ';


	$langA['select'] = 								'തിരഞ്ഞെടുക്കുക';
	$langA['description'] = 						'വിശധ വിവരം';


//	adminPlugins
	$langA['data_types'] = 							'ഡാറ്റ രീതികള്‍'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'നിലവിലുള്ള രീതികള്‍';
	$langA['available_plugins'] = 					'ലഭ്യമായ പ്ലുഗ് ഇന്നുകള്‍';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'എല്ലാം ചെക്ക് ചെയ്യുക / എല്ലാം ചെക്ക് ചെയ്യാതിരിക്കുക ';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'ഓണ്‍ലൈന്‍ ';
	$langA['wbConfig']['online']['desc'] = 			'ഈ നടപടി ഇന്‍റ‍്നെറ്റുമായി ബന്ധിപ്പിചിട്ടുണ്ടോ?‍';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'കവിഞ്ഞ ഇടവേള ';
	$langA['wbConfig']['floodInterval']['desc'] = 	'തിരുത്തലുകള്‍ക്കിടയില്‍ അനുവാദമില്ലാതെ കടന്ന ഉപഭോക്താവ്‌ കാത്തിക്കേന്ട സമയം സെക്കണ്ടസില്‍ ';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML വൃത്തി ';
	$langA['wbConfig']['tidy']['desc'] =				'ഉപയോഗിച്ച എറര്‍ തിരുത്താന്‍ HTML വൃത്തി ഉപയോഗിക്കുക';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'മൊത്തത്തില്‍ വിവരിക്കപെട്ടത്‌ ';
	$langA['wbConfig']['allUsers']['desc'] = 		'എല്ലാ രജിസ്റ്റര്‍ ചെയ്യപെട്ട ഉപഭോക്താവിനും അവരുടെ ബ്ലോഗ് ഉണ്ടാകേണ്ടാതാണ്. ';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

