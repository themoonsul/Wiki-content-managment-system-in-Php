<?php

//	toolOptions.php
$langA['properties'] = 'プロパティ';
$langA['file_name'] = 'ファイル名';
$langA['update_from'] = 'から更新';
$langA['COPY_SYSTEM_FILES'] = '%sから最新のシステムヘルプファイルをコピーする';

$langA['EDITING_OPTIONS'] = 'このファイルを編集できるひとを制限する';
$langA['registered_users'] = '登録済み利用者';
$langA['restricted_to'] = 'に制限 ';
$langA['admin_only'] = '管理者のみ';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Owner Only';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = '見えるかどうか';
$langA['VISIBILITY_OPTIONS'] = 'まだみんなに見せる準備ができていないならこのファイルを隠す';
$langA['visible'] = '見える';

$langA['COMMENT_OPTIONS'] = 'このファイルへのコメントをつけられなくする';
$langA['enabled'] = '可能にする';
$langA['disabled'] = '不可能にする';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = '他';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Remove From Blog';
$langA['repost'] = '再投稿';
$langA['copy_to'] = 'へコピー';
$langA['send_to_trash'] = 'ゴミ箱に送る';
$langA['default_options'] = '初期設定済みのオプション';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = 'このファイルタイプに%sを設定する'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'このファイルは再投稿されました';
$langA['NOT_REPOSTED'] = '<b>エラー：</b>このファイルは再投稿できません';
$langA['OPTIONS_NOT_CHANGED'] = 'ファイルオプションは変更されていません';
$langA['OPTIONS_UPDATED'] = 'ファイルオプションは変更されました';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not updated.';

$langA['redirect'] = '転送';
$langA['REMOVE_REDIRECT'] = 'もうこのファイルを転送したくないなら、削除するか編集してください ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = '利用者&nbsp;許可';
