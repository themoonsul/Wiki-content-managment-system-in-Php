<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = '保存されているプリファレンスから変更はありません';
$langA['INVALID_PREFS'] = '<b>警告：</b>入力値をプリファレンスとして保存できません。';

$langA['EMAIL_PREFS'] = 'パスワードを忘れた時に便利';

$langA['LANG_PREFS'] = '言語を選ぶ';

$langA['javascript_preferences'] = 'JavaScript Preferences';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Turn on/off JavaScript enhancements. Some features will not work properly when JavaScript is disabled.';

$langA['time_zone'] = 'タイムゾーン';
$langA['TIME_ZONE_PREFS'] = '現地時間とサーバーの時間の差: <tt>hh:mm</tt>';
$langA['TIME_ZONE_PREFS2'] = 'Server time is now %s. <br/>Your adjusted time is %s.';

$langA['sig'] = 'Signature';
$langA['SIGNATURE'] = 'Customize your signature with wiki syntax.';


$langA['home_title'] = 'ホームタイトル';
$langA['HOME_TITLE_PREFS'] = 'ホームページに表示されるタイトル';

$langA['blog_styled_frontpage'] = 'ブログスタイルフロントページ';
$langA['BLOG_PREFS'] = 'ホームページをブログとして表示';

$langA['blogT'] = 'Blog Type';
$langA['BLOG_TYPE'] = 'Select among available data types to blog.';

$langA['selective_blogging'] = 'Selective Blogging';
$langA['SELECTIVE_BLOGGING'] = 'Selective Blogging allows you to blog only those pages you want displayed on the front page.';

$langA['blog_count'] = 'Blog Count';
$langA['BLOG_COUNT'] = 'The number of entries to show on your blog.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'Display the "Share" link at the bottom of each file.';

$langA['ihelp'] = 'Help Links';
$langA['IHELP'] = 'Show help links.';

$langA['uServices'] = 'Update Services';
$langA['UPDATE_SERVICES'] = 'When you publish a new post, the following update services will automatically be notified. Separate multiple service URIs with line breaks.';
$langA['BAD_UPDATE_SERVICES'] = 'Invalid URI(s) given for Update Services';


$langA['VIEW_THEME'] = '<a %s>Edit or copy</a> this theme.';

$langA['quick_comment'] = 'クイックコメント';
$langA['QUICK_COMMENT'] = 'オンに設定されると、簡単コメント用に会話ページの一番上にフォームが表示されます。';

$langA['textarea rows'] = 'テキストエリアの行';
$langA['TEXTAREA_ROWS_PREFS'] = '編集エリアの高さを決める';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'それぞれのファイルについてサーバーに保存されている履歴行の最大値';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Maximum %s.';

$langA['tab_limit'] = 'タブの制限値';
$langA['TAB_LIMIT'] = 'JavaScript will automatically close tabs once the number of opened tabs has reached this limit. Defaults to 7. Set to 1000 or more if you don\'t want JavaScript to manage your tabs.';

$langA['EXTERNAL_LINKS'] = 'External links will be opened in a new window when "On".';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'キーボードショートカット';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = 'プリファレンスを保存';

$langA['CONFIRM_CHANGE'] = 'プリファレンスを変更していいですか？';
$langA['preference'] = 'プリファレンス';
$langA['old_value'] = '古い値';
$langA['new_value'] = '新しい値';

$langA['changes'] = '変更';
$langA['PREFS_CHANGED'] = 'Your preferences have been updated.<br/> Below is a summary of the values that have changed.';


//check edit
$langA['anonymous'] = 'Anonymous';
$langA['fEdits'] = 'Flag Edits';
$langA['FLAG_EDITS'] = 'Edits made by users with status at or below the selected status will be flagged as "Unchecked" until it is reviewed by the account owner.';

//save all edits
$langA['saveAll'] = 'Log All Edits';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
