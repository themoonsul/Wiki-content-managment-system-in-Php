<?php

	$langA['googleMapKeys'] =						'Google Maps API キー';


	$langA['ADMIN_ONLY'] =							'このページにアクセスするには管理者でなければなりません。';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'この管理ページはまだ定義されていません｡';
	
	$langA['CONFIRM_PASSWORD'] =						'続けるためにパスワードを確認してください。';
	$langA['confirm_password'] =						'パスワードを確認してください。';
	$langA['confirmation_failed'] =					'パスワード確認が失敗しました｡もう一度試してください｡';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'検索オプション';
	$langA['search_status'] =						'検索ステイタス';
	$langA['search_enabled'] =						'検索可能';
	$langA['SEARCH_ENABLED'] =						'検索をしないようにすると全検索データベースのテーブルが空になります。後で検索を再び可能にする時に全検索テーブルを再度構築する必要があります。';
	$langA['disable'] =								'不可能';
	
	$langA['search_disabled'] =						'検索しない';
	$langA['SEARCH_DISABLED'] =						'現在、検索はできないようにしてあります。検索を可能にするには全検索データベースに全ファイルのエントリーを入れる作業が必要です。この作業は大きなデータベースの場合、かなり時間がかかることがあります。';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'可能にする';
	
	$langA['FINISHED_ENTRIES'] =						'%sエントリー終了、あと%s';
	$langA['SEARCH_IS_ENABLED'] =					'検索機能が可能になりました。';


//
// adminConfig.php
//
	$langA['configuration'] =						'設定';
	$langA['confighistory'] =						'設定履歴';
	$langA['CONFIG_SAVING'] =						'新しい設定が上書きされずに保存されました。変更を元に戻すことが可能です。';
	$langA['CONFIG_STAT'] =							'これまで%s回の設定変更がなされています。';
	$langA['CONFIG_CONFIRM_REVERT'] =				'%sの版に戻しますがいいですか？保存ボタンをクリックして続けてください。';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'"Welcome to serverName1"のような文とともに使われるもの';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://サーバー名';

//default user

	$langA['max_upload']['desc'] = 					'アップロードできるファイルの最大サイズ';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'エラーログファイルの最大値。初期設定値は10,000バイト';
	$langA['errorEmail']['desc'] = 					'電子メールアドレスを ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'一般設定';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'Prettyサーバ名';
	$langA['serverName2']['alias'] = 				'サーバ名';
	$langA['serverName3']['alias'] = 				'サーバのURL（フルアドレス）';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'最大のアップロード';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'言語';
	$langA['reservedWords']['alias'] = 				'予約された言葉';
	
	$langA['developer_aids'] = 						'開発者支援';
	$langA['maxErrorFileSize']['alias'] = 			'エラーログサイズ';
	$langA['errorEmail']['alias'] = 					'エラーメール';
	$langA['include']['alias'] = 					'PHPを含む';

//
//	default user
//
	$langA['default_user_vars'] = 				'初期ユーザ設定値';
	
	$langA['defaultUser:homeTitle']['alias'] =		'ホームタイトル';
	$langA['defaultUser:homeTitle']['desc'] =		'ホームページのタイトルとして表示される';
	
	$langA['defaultUser:template']['alias'] =		'利用者テンプレート';
	$langA['defaultUser:template']['desc'] =		'Main/Homeがwikyblogテンプレートの初期設定値です。';
	
	$langA['defaultUser:textareaY']['alias'] =		'テキストエリアの高さ';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'ブログホームページ';
	$langA['defaultUser:isBlog']['desc'] =			'ブログスタイルのホームページにする/しない';
	
	$langA['defaultUser:timezone']['alias'] =		'タイムゾーン';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'履歴行の最大値';
	$langA['defaultUser:maxHistory']['desc'] =		'履歴の行の最大値の初期設定値';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Add Group';
	$langA['unlimited'] = '制限無し';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'利用者統計';
	$langA['user_stats'] =							'利用者統計';
	$langA['user_account'] =							'利用者アカウント';
	$langA['entries'] =								'エントリー';
	$langA['history Rows'] =							'履歴行';
	$langA['last_visit'] = 							'最終訪問';
	
	$langA['users_found'] =							'利用者が見つかる';
	$langA['showing_of_found'] =						' %sから %sを見せる';
	$langA['cpanel'] =								'コントロールパネル';
	$langA['details'] =								'詳細';
	
	$langA['within_the_hour'] =						' 1時間前';
	$langA['hours'] =								'時間';
	$langA['days'] =									'日';
	$langA['months'] =								'月';
	$langA['years'] = 								'年';
	$langA['ago'] = 									'前';
	
	$langA['TIMEOUT'] = 								'<b>タイムアウトエラー:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'<b>%s</b>を削除してもいいですか？';
	$langA['CONFIRM_DELETE_USER2'] = 				'削除は　:を含むアカウントのすべてのファイルを<i>完全に消去</i>します。 ';
	$langA['userfiles_directory'] = 					'利用者フィアルディレクトリ ';
	$langA['template_directory'] = 					'テンプレートディレクトリ ';
	$langA['database_entries'] = 					'すべてのデータベースエントリー、ページ、ページ履歴、コメント、etc.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'削除されたデータベースエントリー';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>警告:</b>データベースエントリーを削除できません';
	
	$langA['DELETED_USERFILES'] = 					'削除された利用者ファイルディレクトリ';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>警告:</b>利用者ファイルディレクトリを削除できません';
	
	$langA['DELETED_TEMPLATES'] = 					'削除されたテンプレートディレクトリ';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>警告:</b>テンプレートディレクトリを削除できません';
	
	$langA['USER_DELETED'] = 						'%s は完全に削除されたました: ';
	$langA['USER_NOT_DELETED'] = 					'%s は完全には削除されていません: ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activate';
	$langA['lost_page'] = 							'失われたページ';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'不可能にする';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'エラーログを削除できません';
	$langA['ERROR_LOG_DELETED'] = 					'エラーログを削除されました';
	$langA['ERROR_LOG_MAXED'] = 						'エラーログフィアルが最大サイズに達しました。エラーログをさらに書き込むにはファイルの中身を空にしてください。%s';


	$langA['select'] = 								'選択';
	$langA['description'] = 						'説明';


//	adminPlugins
	$langA['data_types'] = 							'データタイプ'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'存在しているタイプ';
	$langA['available_plugins'] = 					'利用可能なプラグイン';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'すべてをチェック/すべてのチェックを外す';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'オンライン';
	$langA['wbConfig']['online']['desc'] = 			'この作業の実行はインターネットに接続されていますか？';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Flood間隔';
	$langA['wbConfig']['floodInterval']['desc'] = 	'許可のない利用者が編集する時に次の編集まで待たなければならない秒数';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'ありがちな利用者の入力ミスを修正するにはHTML Tidyを使ってください。';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'フル機能';
	$langA['wbConfig']['allUsers']['desc'] = 		'すべての登録済利用者に自分のブログを解説することを許可する。';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

