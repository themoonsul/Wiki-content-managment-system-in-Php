<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = '許可 ';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'この特別ページはまだ定義されていません。<tt>%s</tt>';

//	control panel
$langA['general'] = '一般';
$langA['attachments'] = 'Attachments';
$langA['account_info'] = 'Account Info';
$langA['error_log'] = 'エラーログ';
$langA['advanced_search'] = '高度な&nbsp;検索';
$langA['configuration'] = '設定';
$langA['search_options'] = '検索オプション';
$langA['data_types'] = 'データタイプ';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Tabs';
$langA['account_display'] = 'アカウント表示';
$langA['links'] = 'リンク';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = '利用者統計';
$langA['database_info'] = 'データベース&nbsp;情報';
$langA['user_preferences'] = '利用者の参照';
$langA['content_license'] = '内容&nbsp;ライセンス';
$langA['user_permissions'] = '利用者 許可';
$langA['default_page_options'] = '初期値&nbsp;ページ&nbsp;オプション';
$langA['account_details'] = 'アカウント&nbsp;詳細';
$langA['manage_images'] = '管理&nbsp;画像';
$langA['manage_files'] = '管理&nbsp;ファイル';
$langA['upload_files'] = 'ファイルをアップロード';
$langA['public_templates'] = '公開&nbsp;テンプレート';
$langA['feeds'] = 'ウェブシンジーケーション/フィード';
$langA['recently_modified'] = '最終変更';
$langA['recently_posted'] = '最終投稿';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = 'This is the Control Panel for <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Would you like to see your %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'テンプレートパッケージディレクトリが使えません';
$langA['themes']['default'] = 'デフォルト';
$langA['themes']['simple'] = 'Simple';
$langA['themes']['three_columns'] = '３列';
$langA['themes']['floating'] = 'Floating';
$langA['themes']['graphic'] = 'Graphic';

$langA['colors']['colors'] = 'Colors';
$langA['colors']['black'] = 'Black';
$langA['colors']['blue'] = 'Blue';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Green';
$langA['colors']['light_blue'] = 'Light Blue';
$langA['colors']['green'] = 'Green';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Red';
$langA['colors']['orange'] = 'Orange';
$langA['colors']['gray'] = 'Gray';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = '隠されているのを見る';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = '許可を更新する';
$langA['username_or_ip'] = '利用者名またはIP';
$langA['status'] = '状態';
$langA['workgroup'] = 'ワークグループ';
$langA['admin'] = '管理者';
$langA['full_owner'] = 'フル/所有者';
$langA['ban'] = '禁止';
$langA['banned'] = '禁止されている';

//	friends.php
$langA['friends'] = 'Friends';
$langA['my_status'] = 'My Status';


$langA['EX_USERNAMES'] = '例：<a>ビリージョー</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'You have not specefied any permissions.';
$langA['view_users'] = 'この利用者を見る';
$langA['change'] = '変更';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = '利用者<tt>%s</tt>はこのワークグループから外されました';
$langA['USER_NOT_REMOVED'] = '利用者<tt>%s</tt>はこのワークグループから外されませんでした ';
$langA['ADDED_PERMISSIONS'] = '<tt>%s</tt>に追加された許可';
$langA['UPDATED_PERMISSIONS'] = '<tt>%s</tt>の更新された許可';
$langA['NOT_A_USER'] = '利用者<tt>%s</tt>は見つかりません';
$langA['IP_NOT_ADDED'] = '<tt>%s</tt>に対する許可の追加や更新ができません';
$langA['ALREADY_OWNER'] = '<b>警告：</b>利用者<tt>%s</tt>はすでにこのアカウントの所有者です。';
$langA['IP_WRONG_LEVEL'] = '<b>警告：</b>IPアドレスにはワークグループ以上の権限は与えられません。';
$langA['SET_PERMISSIONS'] = '"%s"に対する許可を設定するには、希望する条件を選んで"許可を更新"するをクリックしてください';


//	specLostPass
$langA['lost_password'] = 'パスワード紛失';



//	specFileManager
$langA['file_manager'] = 'ファイルマネージャー';
$langA['image_manager'] = '画像マネージャー';
$langA['CONFIRM_FILE_DELETE'] = '<b>%s</b>を削除してもいいですか？';
$langA['IMAGE_MANAGER_INTRO'] = '画像を貼り付けるにはwiki文法またはhtmlが使えます。テンプレートや地図などのファイルタイプにはhtmlを使うことを推奨します。';
$langA['FILE_MANAGER_INTRO'] = 'これらのファイルをページに含めるのにwikiまたはhtml文法が使えます。いくつかのタイプ（テンプレート、地図）のファイルには､html文法を推奨します。';
$langA['file_name'] = 'ファイル名';
$langA['available_space'] = '利用可能な容量';
$langA['UPLOAD_INTRO'] = 'ページに含めるために添付と画像をアップロードする';
$langA['file_upload'] = 'ファイルアップロード';
$langA['file_info'] = 'ファイル情報';
$langA['width'] = '幅';
$langA['height'] = '高さ';
$langA['file_location'] = 'ファイルの場所';
$langA['wiki_syntax'] = 'Wiki文法';
$langA['html_syntax'] = 'HTML文法';
$langA['append_to'] = 'に追加';
$langA['count'] = 'カウント';
$langA['total_size'] = 'トータルサイズ';
$langA['images'] = '画像';
$langA['overwrite_existing'] = 'Overwrite Existing';
$langA['compression'] = 'Compression';

$langA['NOT_AN_IMAGE'] = 'ファイルは画像ではないようです。ファイルをチェックしてもう一度試してください。(%s) ';
$langA['IMAGE_NOT_DELETED'] = '<tt>%s</tt> は削除できません';
$langA['UPLOADED'] = '<tt>%s</tt> はアップロードされました';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = 'This file was successfully renamed.';
$langA['UPLOAD_FAILED'] = 'ファイル<tt>%s</tt> のコピーに失敗';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'ファイルタイプを選ぶ';
$langA['default_options'] = '初期設定済みのオプション';
$langA['UNKNOWN_FILE_TYPE'] = 'ページタイプが分かりません: <tt>%s</tt>';

//	specAccountDetails
$langA['account'] = 'アカウント';
$langA['entries'] = 'エントリー';
$langA['average'] = '平均';
$langA['uploaded_files'] = 'アップロードされたファイル';


//	searchTrash
$langA['deleted'] = '削除された';
$langA['restore'] = '復元された ';
$langA['empty_trash'] = 'Empty Trash';
$langA['CONFIRM_EMPTY_TRASH'] = 'Are you sure you want to empty your trash?';

$langA['DELETED_AFTER_30'] = 'ファイルは30日後に自動的に削除されます';
$langA['check_uncheck'] = 'すべてをチェック/すべてのチェックを外す';
$langA['DELETED_FILES'] = '選ばれたファイルは削除されました';
$langA['NOTHING_DELETED'] = 'なにも削除されていません';
$langA['DELETE_FILES'] = '削除するファイルを選んでください';
$langA['MAP_INVALID_PT'] = '地図データが正しくないです：ポイントのフォーマットが正しくないです';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'このサイトの検索機能が利用可能でないようです。サイト管理者がコントロールパネルの検索オプションから利用可能にできます。';
$langA['search:'] = '検索 ';
$langA['search_for'] = 'を検索 ';
$langA['registered'] = '登録済み';
$langA['restricted'] = '制限されている';
$langA['locked'] = 'ロック済み';
$langA['disabled'] = '不可能にする';
$langA['editing_option'] = '編集オプション';
$langA['comments_option'] = 'コメントオプション';
$langA['visibility_option'] = '見え方オプション';
$langA['normal'] = '通常 ';
$langA['advanced'] = '高度な';
$langA['relevance'] = '関連';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'For all of the words';
$langA['SEARCH_EXACT'] = 'For the exact phrase';
$langA['SEARCH_WITHOUT'] = 'Without the words';
$langA['SEARCH_BEGIN'] = 'For words beginning with';


//	searchKeywords
$langA['keyword_search'] = 'キーワード検索';
$langA['non_tagged_files'] = 'タグ無しファイル';

//	searchChangeLog
$langA['new'] = 								'新';
$langA['DIFF_TITLE'] = 							'最新版との違いを比較する';
$langA['indicates_syntax_error'] = 				'Indicates a syntax error.';
$langA['indicates_unchecked'] = 				'Indicates an unchecked file.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'ライセンスを選ぶ';
$langA['SELECT_LICENSE_DESC'] = 'クリエイティブコモンズのHPを別窓で開く';
$langA['DELETE_LICENSE_DESC'] = '現在のコンテンツライセンスを外します';
$langA['LICENSE_UPDATED'] = 'コンテンツライセンスは更新されました';
$langA['LICENSE_DELETED'] = 'ライセンスは削除されました';
$langA['LICENSE_DELETED2'] = 'ライセンスはすでに削除されています';
$langA['customize_license'] = 'ライセンスをカスタマイズします';

$langA['text_before'] = 'リンクの前にテキスト';
$langA['text_after'] = 'リンクの後にテキスト';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = '特に注記がない限りこの著作物は以下のライセンスの元で作成されています。 ';
$langA['LICENSE_TEXT_LINK'] = 'クリエイティブコモンライセンス';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganize';
$langA['from'] = 'あなたのアドレス';
$langA['to'] = 'あて先';
$langA['KEYWORDS_UPDATED'] = 'Your keywords have been updated.';
$langA['KEYWORDS_EMPTY'] = 'You have not created any files with keywords yet.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = '説明';
$langA['add_link'] = 'Add Link';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Group';
$langA['name'] = 'メッセージ名';
$langA['add_group'] = 'Add Group';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Limit';
$langA['random'] = 'Random';
$langA['order'] = 'Order';
$langA['LEAVE_EMPTY'] = 'Leave empty for no limit';
$langA['unlimited'] = '制限無し';
$langA['type'] = 'Type';
$langA['auto_detect'] = 'Auto Detect';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'Move Up';
$langA['move_down'] = 'Move Down';
$langA['redirect'] = '転送';
$langA['content_template'] = 'Content Template';

