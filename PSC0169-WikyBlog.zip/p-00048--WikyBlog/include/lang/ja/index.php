<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l、F、j、Y'; //format to be used with php's date() function

$langA['file'] = 'ファイル';
$langA['edit'] = '編集';
$langA['edits'] = 'Edits';
$langA['view_source'] = 'ソースを見る';
$langA['talk'] = '会話 ';
//$langA['reply'] = 'Reply';
$langA['history'] = '履歴';
$langA['diff'] = '差分';
$langA['watch'] = 'ウォッチリストに追加';
$langA['unwatch'] = 'ウォッチリストから削除';
$langA['options'] = 'オプション';


$langA['messages'] = 'メッセージ';
$langA['current'] = '現在';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Possible';

$langA['DEFAULT_CONTENT'] = 'これは新しいファイルです。[[%s?cmd=edit|新しく作りますか]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'これは新しいファイルです。このファイルを作るにはログインしてかつ権限がなければなりません。';

$langA['NOT_OWNER'] = 'この機能のための権限がありません。';
$langA['LONG_PATH'] = 'このファイルのタイトルは長すぎますので省略されました。';
$langA['EMPTY_CONTENT'] = '内容が必要です';
$langA['INCOMPLETE_PATH'] = 'パスが不完全です';
$langA['ADMIN_DISABLED_ALL_USERS'] = '管理者が利用者のブログを停止しました。ここと同じような機能のblikiを作るには<a href="http://www.wikyblog.com">WikyBlog.com</a>を見てください。このファイルへのアクセスはファイルの所有者によって制限されています。';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = 'このファイルは隠されています ';
$langA['DELETED_FILE'] = 'このファイルは現在ゴミ箱に入っています。あなたがこのアカウントの持ち主ならコントロールパネルからファイルを元に戻すことができます。';
$langA['PROTECTED_FILE'] = 'このファイルは保護されています。このファイルに対する変更は保存されません。';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'リンクテキスト';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'このページは%sにリダイレクト';

//	Data Types
$langA['all'] = 'すべて';
$langA['page'] = 'ページ';
$langA['comment'] = 'コメント';
$langA['map'] = '地図';
$langA['template'] = 'テンプレート';
$langA['help'] = 'ヘルプ';
$langA['skeleton'] = 'スケルトン';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'コメント';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'ページ';
$langA['CLASScomment'] = 'コメント';
$langA['CLASSmap'] = '地図';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'ヘルプ';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' 秒 ';
$langA['queries'] = ' クエリー';

$langA['QUERY_TIME'] = ' クエリーのため';
$langA['INVALID_PATH'] = '正しくないファイルパスです。: <tt>%s</tt>';							//replaced with path
$langA['INVALID_REQUEST'] = 'Invalid Request.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = '新しいヘルプファイルを作る';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'ブラウズ';
$langA['change_log'] = '変更ログ';
$langA['control_panel'] = 'コントロールパネル';
$langA['administration'] = '管理';
$langA['preferences'] = '参照';
$langA['watchlist'] = 'Watchlist';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = '検索';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'External Links';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = '最近の投稿をもっと見る';
$langA['NEED_INTERNET'] = 'この機能はインターネットに接続されたシステムだけで利用できます。';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>警告：</b>　続けるにはクッキーが必要です。もしクッキーを有効にしているならこのページを再度読み込んでください。';
$langA['LOGIN_REQUIRED'] = 'この機能を使うにはサインインしてください';

$langA['ENTER_USERNAME'] = 'ユーザ名を入れてください';
$langA['ENTER_PASSWORD'] = 'パスワードを入れてください';
$langA['LOGGED_OUT'] = 'ログアウトに成功しました';
$langA['AUTO_LOGOUT'] = 'セッションが時間切れしました';

$langA['LOGIN_FAILED'] = 'ログイン失敗。パスワードが正しくありません。<ul><li> Caps Lock がオンになっていませんか？<li>%sパスワードを忘れましたか？%s</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'ログインの試みの最大値%sを越えました。これから%s分はログインできません。';
						
$langA['create_new'] = '新規に作る&nbsp; ';
$langA['remember_me'] = '憶えておく';
$langA['log_out'] = 'ログアウト';
$langA['log_in'] = 'ログイン';

//	SAVING 
$langA['syntax_error'] = '文法エラー';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>文法エラー：</b>　最新の変更を保存したり表示したりできません。';
$langA['SYNTAX_FIXED'] = '文法エラーは修復されました';


$langA['NO_CHANGES'] = 'このファイルには変更がなされていません。(%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'このファイルを保存できません。(%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'このファイルの変更が保存されました';
$langA['HIDDEN_FILE3'] = '<b>注意：</b> これは隠されたファイルです。このファイルのタグは利用者のメニューには表示されません。';

$langA['VERSION_CONFLICT'] = '警告：版の衝突があったので変更は保存されませんでした。';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = '編集は %s 秒で１ファイルに制限されています。 %s 秒して試してください。';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'オプションを保存';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = '差分';
$langA['line_num'] = '行 #';


//	toolHistory1.php
$langA['revision'] = '版 ';
$langA['revision_as_of'] = '時点の版 ';
$langA['revision_num_as_of'] = '%s 時点の版 %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = '編集の版';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = '版 # に戻す';
$langA['SET_USER_PERMISSIONS'] = 'この利用者に許可する '; 
$langA['compare_with_prev'] = '←以前の版と比較する';
$langA['current_revision'] = '現在の版';
$langA['compare_with_next'] = '次の版と比較する→';
$langA['lines'] = '行';
$langA['text'] = 'テキスト ';
$langA['vs'] = ' vs ';
$langA['content'] = '内容';
$langA['your_text'] = 'あなたのテキスト';
$langA['show_prev_revision'] = '← 版 %s'; //%s replaced with a revision number
$langA['show_next_revision'] = '版 %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>警告：</b>このページの最新版を編集していません<br />保存を実行するとこの古い版で最新版を上書きします。';
$langA['SELECT_TWO_VERSIONS'] = '比較する２つの版を選んでください';
$langA['NO_UNIQUE_REVISION'] = 'リクエストされた版が見つかりませんでした';
$langA['INVALID_REVISION'] = '<b>エラー：</b>版の番号が正しくありません';
$langA['NO_DIFFERENCES'] = '比較された２つの版は同一です';
$langA['NO_REVISIONS'] = '比較がなされる前に２つの違う版が必要です';
$langA['NON_EXISTANT'] = 'このファイルはもはや存在しません';

//	toolEditPage.php
$langA['bold_text'] = '太字テキスト';
$langA['italic_text'] = 'イタリックテキスト';
$langA['headline_text'] = '見出しを挿入する';
$langA['title'] = 'タイトル';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = '内部リンク';
$langA['link'] = 'リンク';
$langA['external_link'] = '外部リンク';
$langA['embed_image'] = '画像を埋め込む';
$langA['find_images'] = 'Find Images';
$langA['image'] = '画像';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'ここにファーマットなしのテキストを挿入する';
$langA['signature'] = 'Signature';
$langA['SIGNATURE_TEXT'] = 'Insert your Signature';
$langA['preview'] = 'プレビュー';
$langA['PREVIEW_TEXT'] = '変更をプレビュー[%s-p]';
$langA['PREVIEW_WARN'] = 'これはプレビューのみです。変更はまだ保存されていません。';
$langA['SAVE_TEXT'] = '変更を保存する[%s-s]';
$langA['reset'] = 'リセット';
$langA['RESET_TEXT'] = 'このフォームを元の状態に戻す[%s-c]';
$langA['changes'] = '変更';
$langA['CHANGES_TEXT'] = 'このファイルに加えた変更を示す[%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = '投稿をコンマで区切ったキーワードで整理する'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'タグ';
$langA['edit_summary'] = '変更内容の要約';
$langA['syntax_warning'] = '文法の警告';
$langA['NO_IMAGES'] = '画像が見つかりません';
$langA['insert_emoticons'] = 'エモコンを挿入する';
$langA['upload'] = 'アップロード';



//searchHistory
$langA['show'] = '示す';
$langA['hide'] = 'Hide';
$langA['compare'] = '比較する';
$langA['timeline'] = 'タイムライン';
$langA['summary'] = 'サマリー';
$langA['COMPARE_REVISONS'] = '選択された版と比較する';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = '正しくないファイルタイプです';


//	SEARCH
$langA['next'] = '次';
$langA['previous'] = '前';
$langA['order_by'] = 'の順序';
$langA['ascending'] = '昇順';
$langA['descending'] = '降順';
$langA['search_from'] = 'から検索 ';
$langA['all_users'] = 'すべての利用者';
$langA['user'] = '利用者';
$langA['from_file_type'] = 'ファイルタイプから検索 ';
$langA['read_more'] = 'もっと読む';
$langA['words'] = ' 語';

$langA['RESULTS'] = '%sのうちの %s から %s までの結果'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'この検索では何も見つかりませんでした';

//searchTalk
$langA['add_comment'] = '新しいトピックを追加する';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = '警告：重複したエントリーに対する間違ったフォーマットのデータは含めることができませんでした。';
$langA['duplicate_entry'] = '重複したエントリーです';
$langA['DUPLICATE_ENTRY'] = 'これは %s で見つかったページに対する重複エントリーです。<br/>ここにある重複していない情報はこのページが削除される前にオリジナルページに移動されます。'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = '見つかりません '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>エラー：</b><br />このスクリプトを実行中にエラーが起きました。<br />　リクエストをチェックしてください。エラーログ %s を見てスクリプトをデバッグしようとします。'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = '初期値設定のテンプレートは削除できません。';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'ＣＳＳ１';
$langA['css2'] = 'ＣＳＳ２';
$langA['INVALID_THEME'] = '特定されたテーマは正しくありません。';

//
//	CLASSmap
//
$langA['new_marker']='新しいマーカー';
$langA['new_route']='新しいルート';
$langA['SAVE_HEADER']='保存する前に忘れないで';
$langA['save_map']='地図を保存';
$langA['continue_editing']='編集を続ける';
$langA['miles/km'] = 'マイル/キロメートル';
$langA['MAP_DEFAULT_CONTENT'] = '<b>これは新しい地図です</b><br/>　この地図を新しく作ったり編集するには "編集"をクリックしてください。';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'この地図を編集できる権限がありません。';
$langA['play'] = 'プレイ';
$langA['stop'] = 'ストップ';
$langA['import'] = 'インポート';
$langA['export'] = 'エクスポート';
$langA['gpx_data'] = 'GPXデータ';
$langA['gpx_exchange_format'] = 'GPX Exchangeフォーマット';
$langA['CLICK_EDIT'] = '地図を編集するには"編集"をクリックしてください';


//	smileys
$langA['smiles'][':D'] = '超ハッピー';
$langA['smiles'][':)'] = '笑顔';
$langA['smiles'][':('] = '悲しい';
$langA['smiles'][':o'] = '驚き';
$langA['smiles'][':shock:'] = 'ショック';
$langA['smiles'][':?'] = 'わかんない';
$langA['smiles']['8)'] = 'かっこいい';
$langA['smiles'][':lol:'] = '笑い';
$langA['smiles'][':x'] = '変';
$langA['smiles'][':P'] = 'や～い';
$langA['smiles'][':oops:'] = '恥ずかしい';
$langA['smiles'][':cry:'] = '泣き';
$langA['smiles'][':evil:'] = '超変';
$langA['smiles'][':twisted:'] = '悪魔';
$langA['smiles'][':roll:'] = 'ぎょろぎょろ';
$langA['smiles'][':wink:'] = 'ウィンク';
$langA['smiles'][':!:'] = 'びっくり';
$langA['smiles'][':?:'] = '質問';
$langA['smiles'][':idea:'] = 'アイディア';
$langA['smiles'][':arrow:'] = '矢印';
$langA['smiles'][':|'] = '中立';
$langA['smiles'][':mrgreen:'] = 'グリーン氏';

//
//	General Language
//
$langA['or'] = 'または';
$langA['username'] = '利用者名';
$langA['password'] = 'パスワード';
$langA['email'] = '電子メール';
$langA['register'] = '登録';
$langA['cancel'] = 'キャンセル';
$langA['language'] = '言語';
$langA['use'] = 'Use';
$langA['copy'] = 'Copy';
$langA['rename'] = 'Rename';

$langA['on'] = 'オン';
$langA['partial'] = '一部の';
$langA['off'] = 'オフ';
$langA['save'] = '保存';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = '定義されていない';
$langA['homepage'] = 'ホームページ';
$langA['home'] = 'ホーム';
$langA['go'] = '表示';
$langA['user_menu'] = 'User Menu';

$langA['last_modified'] = '最終変更';
$langA['LAST_MODIFIED'] = '%sによって最終変更　%s';//%s replaced with date and username
$langA['accessed_times'] = 'アクセス %s 回';// %s replaced with a number
$langA['modified'] = '変更';
$langA['posted'] = '投稿';
$langA['created'] = '新規作成';
$langA['hidden'] = '隠されている';
$langA['what_links_here'] = 'リンク元';
$langA['share'] = 'Share';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'この作業をする前にファイルは保存されなければいけません';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'サイズ ';
$langA['bytes'] = 'バイト';
$langA['kb'] = 'ＫＢ';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = '更新';
$langA['editing'] = '編集';
$langA['workgroup'] = 'ワークグループ';
$langA['BROWSE_HIDDEN'] = '隠されたファイルを探す';

$langA['delete'] = '削除';
$langA['confirm_delete'] = '削除を確認';
$langA['continue'] = '続ける';
$langA['back'] = '戻る';
$langA['close'] = 'Close';
$langA['view'] = '見る';
$langA['empty'] = '空';
$langA['none'] = 'なし';
$langA['total'] = 'トータル ';
$langA['files'] = 'ファイル';
$langA['other'] = '他';
$langA['trash'] = 'ゴミ箱';
$langA['flagged'] = 'Flagged';

$langA['today'] = '今日';
$langA['yesterday'] = '昨日';
$langA['days_ago'] = ' 日前';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'More';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = '日曜日';
$langA['date_l'][1] = '月曜日';
$langA['date_l'][2] = '火曜日';
$langA['date_l'][3] = '水曜日';
$langA['date_l'][4] = '木曜日';
$langA['date_l'][5] = '金曜日';
$langA['date_l'][6] = '土曜日';

$langA['date_D'][0] = 'Sun';
$langA['date_D'][1] = 'Mon';
$langA['date_D'][2] = 'Tue';
$langA['date_D'][3] = 'Wed';
$langA['date_D'][4] = 'Thu';
$langA['date_D'][5] = 'Fri';
$langA['date_D'][6] = 'Sat';


$langA['date_F'][1] = '1月';
$langA['date_F'][2] = '2月';
$langA['date_F'][3] = '3月';
$langA['date_F'][4] = '4月';
$langA['date_F'][5] = '5月';
$langA['date_F'][6] = '6月';
$langA['date_F'][7] = '7月';
$langA['date_F'][8] = '8月';
$langA['date_F'][9] = '9月';
$langA['date_F'][10] = '10月';
$langA['date_F'][11] = '11月';
$langA['date_F'][12] = '12月';

$langA['date_M'][1] = '1月';
$langA['date_M'][2] = '2月';
$langA['date_M'][3] = '3月';
$langA['date_M'][4] = '4月';
$langA['date_M'][5] = '5月';
$langA['date_M'][6] = '6月';
$langA['date_M'][7] = '7月';
$langA['date_M'][8] = '8月';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = '10月';
$langA['date_M'][11] = '11月';
$langA['date_M'][12] = '12月';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabic (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'ドイツ語(de)';
$langA['lang']['el'] = 'Greek (el)';
$langA['lang']['en'] = '英語(en)';
$langA['lang']['es'] = 'Spanish (es)';
$langA['lang']['fr'] = 'フランス語(fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italian (it)';
$langA['lang']['ja'] = '日本語(ja)';
$langA['lang']['ko'] = 'Korean (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Dutch (nl)';
$langA['lang']['pl'] = 'Polish (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Russian (ru)';
$langA['lang']['tr'] = 'トルコ語(tr)';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'Chinese (zh)';
$langA['lang']['zh-cn'] = 'Chinese Simplified (zh-cn)';



