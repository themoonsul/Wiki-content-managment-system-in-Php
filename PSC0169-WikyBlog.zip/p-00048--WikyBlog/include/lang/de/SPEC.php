<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Berechtigungen';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'Diese besondere Seite wurde noch nicht definiert: <tt>%s</tt>';

//	control panel
$langA['general'] = 'Allgemein';
$langA['attachments'] = 'Anhänge';
$langA['account_info'] = 'Account Info';
$langA['error_log'] = 'Fehlerlog';
$langA['advanced_search'] = 'Fortgeschrittene Suche';
$langA['configuration'] = 'Konfiguration';
$langA['search_options'] = 'Suchoptionen';
$langA['data_types'] = 'Dateitypen';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Tabs';
$langA['account_display'] = 'Kontoanzeige';
$langA['links'] = 'Bildverweise';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = 'Benutzerstatistiken';
$langA['database_info'] = 'Datenbankinformation';
$langA['user_preferences'] = 'Benutzereinstellungen';
$langA['content_license'] = 'Content&nbsp;License';
$langA['user_permissions'] = 'Benutzerrechte ';
$langA['default_page_options'] = 'Default&nbsp;Page&nbsp;Options';
$langA['account_details'] = 'Kontodetails';
$langA['manage_images'] = 'Verwalte%nbsp;Bilder';
$langA['manage_files'] = 'Verwalte&nbsp;Dateien';
$langA['upload_files'] = 'Uploade Dateien';
$langA['public_templates'] = 'Public&nbsp;Templates';
$langA['feeds'] = 'Syndication / Feeds';
$langA['recently_modified'] = 'Kürzlich Verändert';
$langA['recently_posted'] = 'Recently Posted';
$langA['user_edits'] = 'Benutzer-Änderungen';

$langA['CONTROL_PANEL_1'] = 'This is the Control Panel for <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Would you like to see your %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'Package Template-Verzeichnis ist momentan nicht verfügbar.';
$langA['themes']['default'] = 'default';
$langA['themes']['simple'] = 'Simple';
$langA['themes']['three_columns'] = 'Drei Spalten';
$langA['themes']['floating'] = 'Floating';
$langA['themes']['graphic'] = 'Graphic';

$langA['colors']['colors'] = 'Colors';
$langA['colors']['black'] = 'Black';
$langA['colors']['blue'] = 'Blue';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Green';
$langA['colors']['light_blue'] = 'Light Blue';
$langA['colors']['green'] = 'Green';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Red';
$langA['colors']['orange'] = 'Orange';
$langA['colors']['gray'] = 'Gray';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = 'Versteckte Dateien durchsuchen';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = 'Aktualisiere Rechte';
$langA['username_or_ip'] = 'Benutzername oder IP';
$langA['status'] = 'Status';
$langA['workgroup'] = 'Arbeitsgruppe';
$langA['admin'] = 'Admin';
$langA['full_owner'] = 'Voll / Besitzer';
$langA['ban'] = 'sperre';
$langA['banned'] = 'gesperrt';

//	friends.php
$langA['friends'] = 'Friends';
$langA['my_status'] = 'My Status';


$langA['EX_USERNAMES'] = 'Beispiel: <a>BillyJoe</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'You have not specefied any permissions.';
$langA['view_users'] = 'Zeige dieses Benutzers...';
$langA['change'] = 'Ändere';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = 'Benutzer <tt>%s</tt> wurde von dieser Arbeitsgruppe entfernt.';
$langA['USER_NOT_REMOVED'] = 'Benutzer <tt>%s</tt> konnte nicht von dieser Arbeitsgruppe entfernt werden. ';
$langA['ADDED_PERMISSIONS'] = 'Rechte hinzugefügt für <tt>%s</tt>';
$langA['UPDATED_PERMISSIONS'] = 'Rechte für <tt>%s</tt> wurden aktualisiert.';
$langA['NOT_A_USER'] = 'Benutzername <tt>%s</tt> nicht gefunden.';
$langA['IP_NOT_ADDED'] = 'Konnte die Rechte für <tt>%s</tt> nicht hinzufügen/aktualisieren.';
$langA['ALREADY_OWNER'] = '<b>Achtung:</b> Benutzer <tt>%s</tt> ist bereits der Besitzer dieses Kontos.';
$langA['IP_WRONG_LEVEL'] = '<b>Warnung:</b> IP Adressen können nicht höhere Rechte als "Arbeitsgruppe"gegeben werden';
$langA['SET_PERMISSIONS'] = 'To set permissions for "%s", select the desired status then click "Update Permissions".';


//	specLostPass
$langA['lost_password'] = 'Passwort vergessen';



//	specFileManager
$langA['file_manager'] = 'Datei Manager';
$langA['image_manager'] = 'Bildverwalter';
$langA['CONFIRM_FILE_DELETE'] = 'Sind Sie sicher, dass Sie <b>%s</b> löschen wollen?';
$langA['IMAGE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these images in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['FILE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these files in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['file_name'] = 'Dateiname';
$langA['available_space'] = 'Verfügbarer Platz';
$langA['UPLOAD_INTRO'] = 'Uploade Anhang um sie in deinen Seiten zu verwenden.';
$langA['file_upload'] = 'Dateiupload';
$langA['file_info'] = 'Dateiinfo';
$langA['width'] = 'Breite';
$langA['height'] = 'Höhe';
$langA['file_location'] = 'File Location';
$langA['wiki_syntax'] = 'Wiki Syntax';
$langA['html_syntax'] = 'HTML Syntax';
$langA['append_to'] = 'append to';
$langA['count'] = 'Count';
$langA['total_size'] = 'Gesamtgröße';
$langA['images'] = 'Bilder';
$langA['overwrite_existing'] = 'Overwrite Existing';
$langA['compression'] = 'Kompression';

$langA['NOT_AN_IMAGE'] = 'Die Datei scheint kein Bild zu sein. Prüfe die Datei und versuche es nochmals (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'Could not delete the file <tt>%s</i>.';
$langA['UPLOADED'] = 'File <tt>%s</tt> uploaded successfully.';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = 'This file was successfully renamed.';
$langA['UPLOAD_FAILED'] = 'Failed to copy file: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Select a File Type:';
$langA['default_options'] = 'Standarteinstellungen';
$langA['UNKNOWN_FILE_TYPE'] = 'Unknown Page Type: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Account';
$langA['entries'] = 'Einträge';
$langA['average'] = 'Durchschnittlich';
$langA['uploaded_files'] = 'Hochgeladene Dateien';


//	searchTrash
$langA['deleted'] = 'Gelöscht';
$langA['restore'] = 'Zurücksetzen';
$langA['empty_trash'] = 'Empty Trash';
$langA['CONFIRM_EMPTY_TRASH'] = 'Are you sure you want to empty your trash?';

$langA['DELETED_AFTER_30'] = 'Die Dateien werden nach 30 Tagen automatisch gelöscht.';
$langA['check_uncheck'] = 'Markiere Alle/Nichts';
$langA['DELETED_FILES'] = 'Die ausgewählten Dateien wurden erfolgreich gelöscht.';
$langA['NOTHING_DELETED'] = 'Es wurde nichts gelöscht.';
$langA['DELETE_FILES'] = 'Please select files to delete.';
$langA['MAP_INVALID_PT'] = 'Invalid Map Data: Invalid Point Format';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'The search feature for this site does not appear to be enabled. Site administrators can enable this feature via Search Options in the Control Panel.';
$langA['search:'] = 'Suche: ';
$langA['search_for'] = 'Suche nach: ';
$langA['registered'] = 'Registriert';
$langA['restricted'] = 'Restricted';
$langA['locked'] = 'Verschlossen';
$langA['disabled'] = 'Deaktiviert';
$langA['editing_option'] = 'Editing Option';
$langA['comments_option'] = 'Comments Option';
$langA['visibility_option'] = 'Visibility Option';
$langA['normal'] = 'Normal';
$langA['advanced'] = 'Fortgeschritten';
$langA['relevance'] = 'Relevanz';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'For all of the words';
$langA['SEARCH_EXACT'] = 'For the exact phrase';
$langA['SEARCH_WITHOUT'] = 'Ohne die Wörter';
$langA['SEARCH_BEGIN'] = 'For words beginning with';


//	searchKeywords
$langA['keyword_search'] = 'Schlüsselwort Suche';
$langA['non_tagged_files'] = 'Non-Tagged Files';

//	searchChangeLog
$langA['new'] = 								'Neu';
$langA['DIFF_TITLE'] = 							'Compare differences with most recent revision';
$langA['indicates_syntax_error'] = 				'Indicates a syntax error.';
$langA['indicates_unchecked'] = 				'Indicates an unchecked file.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Wähle eine Lizenz';
$langA['SELECT_LICENSE_DESC'] = 'Opens a Creative Commons webpage in a popup window.';
$langA['DELETE_LICENSE_DESC'] = 'This will remove your current content license.';
$langA['LICENSE_UPDATED'] = 'Your content license has been updated successfully.';
$langA['LICENSE_DELETED'] = 'Lizenz wurde gelöscht';
$langA['LICENSE_DELETED2'] = 'Lizenz wurde bereits gelöscht';
$langA['customize_license'] = 'Passe deine Lizenz an';

$langA['text_before'] = 'Text Before Link';
$langA['text_after'] = 'Text After Link';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Except where expressly noted, this work is licensed under a ';
$langA['LICENSE_TEXT_LINK'] = 'Creative Commons License';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganize';
$langA['from'] = 'Von';
$langA['to'] = 'An';
$langA['KEYWORDS_UPDATED'] = 'Your keywords have been updated.';
$langA['KEYWORDS_EMPTY'] = 'You have not created any files with keywords yet.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = 'Beschreibung';
$langA['add_link'] = 'Link hinzufügen';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Group';
$langA['name'] = 'Name';
$langA['add_group'] = 'Add Group';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Limit';
$langA['random'] = 'Random';
$langA['order'] = 'Order';
$langA['LEAVE_EMPTY'] = 'Leave empty for no limit';
$langA['unlimited'] = 'Unbegrenzt';
$langA['type'] = 'Type';
$langA['auto_detect'] = 'Auto Detect';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'Move Up';
$langA['move_down'] = 'Move Down';
$langA['redirect'] = 'Umleiten';
$langA['content_template'] = 'Inhalts-Template';

