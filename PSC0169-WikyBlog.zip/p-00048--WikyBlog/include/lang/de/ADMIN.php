<?php

	$langA['googleMapKeys'] =						'Google Maps API Schlüssel';


	$langA['ADMIN_ONLY'] =							'Du musst ein Administrator sein, um Zugang zu dieser Seiter zu erhalten.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Diese Administrationsseite wurde noch nicht definiert: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Bitte bestätige dein Passwort um fortzufahren.';
	$langA['confirm_password'] =						'Passwort bestätigen.';
	$langA['confirmation_failed'] =					'Passwortbestätigung fehlgeschlagen. Bitte versuche es erneut.';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Die gewünschte Aktion konnte nicht ausgeführt werden. Bitte versuchen Sie später noch einmal.';
	$langA['SUCCESS'] = 								'Die gewünschte Aktion war erfolgreich.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Suchoptionen';
	$langA['search_status'] =						'Suchstatus';
	$langA['search_enabled'] =						'Suche aktiviert';
	$langA['SEARCH_ENABLED'] =						'Deaktivieren der Suchfunktion hat eine Leerung der Datenbank-Tabelle \'all_search\' zur Folge. Bei erneuter Aktivierung der Suchfunktion muss die Tabelle \'all_search\' neu bestückt werden.';
	$langA['disable'] =								'Deaktivieren';
	
	$langA['search_disabled'] =						'Suche deaktiviert';
	$langA['SEARCH_DISABLED'] =						'Search is currently disabled. Enabling search requires a process that will fill the `all_search` database table with entries for all files in the database. This process may take a fair amount of time for large databases.';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'Aktivieren';
	
	$langA['FINISHED_ENTRIES'] =						'%s Einträge fertig, %s noch zu erledigen.';
	$langA['SEARCH_IS_ENABLED'] =					'Die Suchfunktion ist jetzt aktiviert.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Konfiguration';
	$langA['confighistory'] =						'Einstellungsverlauf';
	$langA['CONFIG_SAVING'] =						'Neue Einstellungen werden gespeichert, ohne dass die derzeitigen Werte überschrieben werden, sodass man Veränderungen rückgänig machen kann.';
	$langA['CONFIG_STAT'] =							'There have been %s revisions made to the configuration.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Sind Sie sicher, dass Sie zur Version Nummer %s zurückkehren wollen? Klicken Sie <tt>Speichern</tt> um fortzufahren.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Something that can be used with a sentence like: "Welcome to serverName1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'Maximale Größe einer hochgeladenen Datei.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Maximum file size to be allowed for the Error Log. Defaults to 10,000 bytes.';
	$langA['errorEmail']['desc'] = 					'Geben Sie eine Emailadresse ein ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Allgemeine Einstellungen';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'Netter Server Name';
	$langA['serverName2']['alias'] = 				'Server Name';
	$langA['serverName3']['alias'] = 				'Vollständige Server URL';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Maximaler Upload';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Sprache';
	$langA['reservedWords']['alias'] = 				'Seitenverkehrte Wörter';
	
	$langA['developer_aids'] = 						'Entwicklerhilfe';
	$langA['maxErrorFileSize']['alias'] = 			'Fehlerverlaufsgröße';
	$langA['errorEmail']['alias'] = 					'Fehler Emails';
	$langA['include']['alias'] = 					'PHP mit Einschließen';

//
//	default user
//
	$langA['default_user_vars'] = 				'Standart Benutzereinstellungen';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Hauptseitentitel';
	$langA['defaultUser:homeTitle']['desc'] =		'Wird als Titel der Homepage angezeigt.';
	
	$langA['defaultUser:template']['alias'] =		'Benutzerschablone';
	$langA['defaultUser:template']['desc'] =		'Main/Home ist die Standartschablone für wikyblog.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Textbereichshöhe';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Bloghauptseite';
	$langA['defaultUser:isBlog']['desc'] =			'Schaltet Blog-Stil der Homepage ein und aus.';
	
	$langA['defaultUser:timezone']['alias'] =		'Zeitzone';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Höhstzahl an Verlaufszeilen';
	$langA['defaultUser:maxHistory']['desc'] =		'Standartmaximum für Verlaufszeilen';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Add Group';
	$langA['unlimited'] = 'Unbegrenzt';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Captcha benützen';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Benutzerstatistiken';
	$langA['user_stats'] =							'Nutzerstatistiken';
	$langA['user_account'] =							'Benutzerkonto';
	$langA['entries'] =								'Einträge';
	$langA['history Rows'] =							'History Rows';
	$langA['last_visit'] = 							'Letzter Besuch';
	
	$langA['users_found'] =							'Benutzer gefunden';
	$langA['showing_of_found'] =						'Zeige %s von %s';
	$langA['cpanel'] =								'CPannel';
	$langA['details'] =								'Details';
	
	$langA['within_the_hour'] =						' vor weniger als einer Stunde';
	$langA['hours'] =								'Stunden';
	$langA['days'] =									'Tage';
	$langA['months'] =								'Monate';
	$langA['years'] = 								'Jahre';
	$langA['ago'] = 									'her';
	
	$langA['TIMEOUT'] = 								'<b>Auszeit Fehler</b> %s';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'Sind Sie sicher, dass Sie <b>%s</b> löschen wollen?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Dieser Vorgang wird alle Dateien dieses Accounts <i>komplett löschen</i> inklusive:';
	$langA['userfiles_directory'] = 					'Benutzerdateien-Verzeichnis ';
	$langA['template_directory'] = 					'Template-Verzeichnis ';
	$langA['database_entries'] = 					'Und alle Datenbankeinträge: Seite, Seitenhistorie, Kommentare, etc.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Gelöschte Datenbankeinträge.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Warnung:</b>Konnte Datenbankeinträge nicht löschen.';
	
	$langA['DELETED_USERFILES'] = 					'Gelöschtes Benutzerdateien-Verzeichnis';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Warnung:</b> Benutzerdateien-Verzeichnis konnte nicht gelöscht werden';
	
	$langA['DELETED_TEMPLATES'] = 					'Template Verzeichnis gelöscht.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Warnung:</b>Template-Verzeichnis konnte nicht gelöscht werden';
	
	$langA['USER_DELETED'] = 						'%s wurde vollständig gelöscht: ';
	$langA['USER_NOT_DELETED'] = 					'%s wurde NICHT vollständig gelöscht: ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'"nofollow" zu allen externen Links hinzufügen';
	$langA['updated'] = 							'Aktualisiert';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Aktivieren';
	$langA['lost_page'] = 							'Verlorene Seite';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'Deaktiviert';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Konnte das error log nicht löschen.';
	$langA['ERROR_LOG_DELETED'] = 					'Das error log wurde gelöscht.';
	$langA['ERROR_LOG_MAXED'] = 						'The Error Log file has reached is maximum size, please empty the file so the script can continue to log errors. %s';


	$langA['select'] = 								'Auswählen';
	$langA['description'] = 						'Beschreibung';


//	adminPlugins
	$langA['data_types'] = 							'Dateitypen'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Vorhandene Typen';
	$langA['available_plugins'] = 					'Verfügbare Plugins';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Markiere Alle/Nichts';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Online';
	$langA['wbConfig']['online']['desc'] = 			'Ist diese Implementierung an das Internet angeschlossen?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Flood Interval';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Anzahl Sekunden, Benutzer ohne Erlaubnis müssen warten zwischen Änderungen';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Benutze HTML Tidy um mögliche Benutzer Eingabefehler zu korrigieren.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Full Featured.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Erlaube allen registrierten Benutzern ihre eigenes Blog zu haben.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

