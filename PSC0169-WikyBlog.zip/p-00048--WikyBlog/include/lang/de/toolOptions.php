<?php

//	toolOptions.php
$langA['properties'] = 'Properties';
$langA['file_name'] = 'Dateiname';
$langA['update_from'] = 'Aktualisiere von';
$langA['COPY_SYSTEM_FILES'] = 'Copy the most recent system help files from %s.';

$langA['EDITING_OPTIONS'] = 'Control who is allowed to edit this file.';
$langA['registered_users'] = 'Registrierte Benutzer';
$langA['restricted_to'] = 'Beschränkt auf ';
$langA['admin_only'] = 'Nur für Admin';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Owner Only';
$langA['use_captcha'] = 'Captcha benützen';
		

$langA['visibility'] = 'Sichtbarkeit';
$langA['VISIBILITY_OPTIONS'] = 'Verstecke diese Datei wenn du noch nicht bereit bist sie der Welt zu präsentieren.';
$langA['visible'] = 'Sichtbar';

$langA['COMMENT_OPTIONS'] = 'Kommentare für diese Datei deaktivieren.';
$langA['enabled'] = 'Aktiviert';
$langA['disabled'] = 'Deaktiviert';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nicht folgen';

$langA['other'] = 'Andere';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Remove From Blog';
$langA['repost'] = 'Repost';
$langA['copy_to'] = 'Kopiere nach...';
$langA['send_to_trash'] = 'Werfe in den Mülleimer';
$langA['default_options'] = 'Standarteinstellungen';
$langA['restore_defaults'] = 'Standard wiederherstellen';
$langA['SET_DEFAULT_OPTIONS'] = 'Set %s for this file type.'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'This file was reposted.';
$langA['NOT_REPOSTED'] = '<b>Error:</b> Could not repost this file.';
$langA['OPTIONS_NOT_CHANGED'] = 'Die Dateieinstellungen wurden nicht verändert';
$langA['OPTIONS_UPDATED'] = 'Die Dateieinstellungen wurden erfolgreich aktualisiert.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not updated.';

$langA['redirect'] = 'Umleiten';
$langA['REMOVE_REDIRECT'] = 'Damit diese Datei nicht mehr umleitet, muss sie gelöscht oder bearbeitet werden. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'Datei ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'Benutzerrechte&nbsp;';
