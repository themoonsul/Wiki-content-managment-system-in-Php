<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'Loading Map...';
$langA['MAP_DEBUG_O'] = 'An error occured while loading this page and the map you requested could not be shown.<p> </p>A log of the error has been created and the website administrators should resolve the issue soon.';
$langA['MAP_DEBUG_1'] = 'The Google Maps API does not appear to be compatible with your browser.<p>If you know your browser is compatible, make sure the correct map key is being used and that you are connected to the internet.</p><p>You can <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">get more information</a> about browser support from google.com.</p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>Warning:</b> Maps require JavaScript to function.</p><p> It seems JavaScript has not been enabled in your browser. To see this map, please enable JavaScript in your browser then refresh/reload this page. </p>';