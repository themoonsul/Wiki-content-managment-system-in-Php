<?php
$langA['ILLEGAL_USERNAME'] = 'The Username cannot include the following characters: %s';
$langA['LONG_USERNAME'] = 'Username was too long.';	
$langA['SHORT_USERNAME'] = 'Username was too short.';
$langA['USER_TAKEN'] = 'Please select a different Username. <tt>%s</tt> is taken. ';
$langA['USERNAME_ALL_DIGITS'] = 'The Username cannot be all digits.';
$langA['PASSWORDS_DIFFERENT'] = 'Passwords did not match.';
$langA['SHORT_PASSWORD'] = 'Password was too short.';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = 'Registrieren';
$langA['welcome_to'] = 'Welcome to ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = 'Must be at least 5 characters long.';
$langA['confirm_password'] = 'Passwort bestätigen.';
$langA['REG_CONFIRM_PASS'] = 'The same as the above.';
$langA['REG_EMAIL'] = 'Optional but useful if you forget your password.';
$langA['REQUIRED_FIELD'] = 'Indicates a required field.';

$langA['REGISTRATION_TEXT'] = 'Registration is fast, free and has many benefits...';
$langA['REG_A_USER_PAGE'] = '/UserName/Your_Pages';
$langA['REG_A_MAP_PAGE'] = '/Map/Username/Your_Maps';

//login
$langA['LOGGED_IN'] = 'You are logged in as <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'The supplied username does not exist. Would you like to register %s.';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Activate your account now.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Your account has been activated.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
