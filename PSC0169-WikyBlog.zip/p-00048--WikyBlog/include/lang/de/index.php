<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Datei';
$langA['edit'] = 'Bearbeiten';
$langA['edits'] = 'Änderungen';
$langA['view_source'] = 'Quelltext betrachten';
$langA['talk'] = 'Forum';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Versionen';
$langA['diff'] = 'Unterschied';
$langA['watch'] = 'beobachten';
$langA['unwatch'] = 'nicht mehr beobachten';
$langA['options'] = 'Optionen';


$langA['messages'] = 'Mitteilungen';
$langA['current'] = 'Aktuell';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Möglich';

$langA['DEFAULT_CONTENT'] = 'Dies ist eine neue Datei. Möchten Sie diese Datei [[%s?cmd=edit|erstellen]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Dies ist eine neue Datei. Um diese Datei zu erstellen, müssen  sie mit den notwendigen Rechten eingeloggt sein.';

$langA['NOT_OWNER'] = 'Sie verfügen nicht über die notwendigen Rechte für diese Funktion';
$langA['LONG_PATH'] = 'Der Dateititel war zu lang und wurde gekürzt.';
$langA['EMPTY_CONTENT'] = 'Inhalt ist ein obligatorisches Feld';
$langA['INCOMPLETE_PATH'] = 'Der angegebene Pfad ist unvolständig.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Sorry, the website administrator has disabled user blogging. To create a bliki with the same features found here, visit <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Der Zugang zu dieser Datei wurde vom Besitzer eingeschränkt. Um die Datei ansehen zu können, benötigen Sie die entsprechenden Rechte.';
$langA['HIDDEN_FILE2'] = 'Dies Datei ist "versteckt". ';
$langA['DELETED_FILE'] = 'This file is currently in the "trash". If you are the owner of this account, you can restore this file via your control panel.';
$langA['PROTECTED_FILE'] = 'Diese Datei ist geschützt. Alle Änderungen in dieser Datei wurden nicht gespeichert.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Link Text';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'This page redirects to %s.';

//	Data Types
$langA['all'] = 'alle';
$langA['page'] = 'Seite';
$langA['comment'] = 'Kommentar';
$langA['map'] = 'Map';
$langA['template'] = 'Vorlage';
$langA['help'] = 'Hilfe';
$langA['skeleton'] = 'Skeleton';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Kommentare';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Seiten';
$langA['CLASScomment'] = 'Kommentare';
$langA['CLASSmap'] = 'Maps';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'Hilfe';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' Sekunden';
$langA['queries'] = ' queries';

$langA['QUERY_TIME'] = ' for queries';
$langA['INVALID_PATH'] = 'Invalid file path supplied: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Ungültige Anfrage.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = 'Create a new help file';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Blättern';
$langA['change_log'] = 'Change Log';
$langA['control_panel'] = 'Control Panel';
$langA['administration'] = 'Administration';
$langA['preferences'] = 'Einstellungen';
$langA['watchlist'] = 'Watchlist';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'Suche';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'External Links';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'More Recent Posts.';
$langA['NEED_INTERNET'] = 'This feature is only available for systems connected to the internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Warning:</b> Cookies are required to continue. Refresh this page if you have cookies enabled.';
$langA['LOGIN_REQUIRED'] = 'You must be signed in to use this feature.';

$langA['ENTER_USERNAME'] = 'Bitte gib deinen Benutzernamen ein.';
$langA['ENTER_PASSWORD'] = 'Bitte gib dein Passwort ein.';
$langA['LOGGED_OUT'] = 'Sie wurden erfolgreich ausgeloggt.';
$langA['AUTO_LOGOUT'] = 'Your session has expired.';

$langA['LOGIN_FAILED'] = 'Log in failed: Incorrect Password.<ul><li>Is Caps Lock on?<li> Have you %sforgotten your password%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'The maximum number of %s login attempts has been exceeded. You will not be allowed to login for the next %s minutes.';
						
$langA['create_new'] = 'Create&nbsp;New ';
$langA['remember_me'] = 'Dauerhaftes Einloggen';
$langA['log_out'] = 'Abmelden';
$langA['log_in'] = 'anmelden';

//	SAVING 
$langA['syntax_error'] = 'Syntaxfehler';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Syntax Error:</b> Unable to Save/Display the most recent changes to this file due to an incompatible syntax.';
$langA['SYNTAX_FIXED'] = 'The syntax error has been fixed.';


$langA['NO_CHANGES'] = 'No changes were made to this file. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Unable to save this File. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Changes to this file have been saved.';
$langA['HIDDEN_FILE3'] = '<b>Note:</b> This is a hidden file, therefore tags for this file will not be included in the user menu totals.';

$langA['VERSION_CONFLICT'] = 'Warning: We could not save your changes because we detected a version conflict.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Editing has been limited to one file every %s seconds. Please try again in %s seconds.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Save Options';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = 'difference(s)';
$langA['line_num'] = 'Zeile #';


//	toolHistory1.php
$langA['revision'] = 'Revision ';
$langA['revision_as_of'] = 'Revision as of ';
$langA['revision_num_as_of'] = 'Revision %s as of %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Edit Revision';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Reverted to revision #';
$langA['SET_USER_PERMISSIONS'] = 'Set your permissions for this user: '; 
$langA['compare_with_prev'] = '← Compare with Previous Revision';
$langA['current_revision'] = 'Aktuelle Version';
$langA['compare_with_next'] = 'Compare with Next Revision →';
$langA['lines'] = 'Lines';
$langA['text'] = 'Text';
$langA['vs'] = ' vs ';
$langA['content'] = 'Inhalt';
$langA['your_text'] = 'Dein Text';
$langA['show_prev_revision'] = '← Revision %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revision %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Warning:</b> You are not editing the most recent version of this page.<br /> Saving will replace the newest version with this out-of-date version.';
$langA['SELECT_TWO_VERSIONS'] = 'Please select two distinct versions to compare.';
$langA['NO_UNIQUE_REVISION'] = 'Could not find a unique revision for this request.';
$langA['INVALID_REVISION'] = '<b>Error:</b> Invalid Revision Number.';
$langA['NO_DIFFERENCES'] = 'The two revisions being compared are identical.';
$langA['NO_REVISIONS'] = 'There must be two distinct revisions before a comparison can be made.';
$langA['NON_EXISTANT'] = 'Diese Datei exestiert noch nicht.';

//	toolEditPage.php
$langA['bold_text'] = 'Fetter Text';
$langA['italic_text'] = 'kursiver Text';
$langA['headline_text'] = 'Insert Heading';
$langA['title'] = 'Titel';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = 'Interner Link';
$langA['link'] = 'Link';
$langA['external_link'] = 'External Link';
$langA['embed_image'] = 'Embed Image';
$langA['find_images'] = 'Find Images';
$langA['image'] = 'Bild';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'Unformatierten Text hier einfügen';
$langA['signature'] = 'Signature';
$langA['SIGNATURE_TEXT'] = 'Insert your Signature';
$langA['preview'] = 'Vorschau';
$langA['PREVIEW_TEXT'] = 'Preview your changes [%s-p]';
$langA['PREVIEW_WARN'] = 'Dies ist nur eine Vorschau. Deine Änderungen wurden noch nicht gespeichert!';
$langA['SAVE_TEXT'] = 'Speichere deine Änderungen [%s-s]';
$langA['reset'] = 'Zurücksetzen';
$langA['RESET_TEXT'] = 'Reset this form to it\'s original state [%s-c]';
$langA['changes'] = 'Änderungen';
$langA['CHANGES_TEXT'] = 'Show the changes you\'ve made to this file. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organize your posts with comma separated keywords'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Tags';
$langA['edit_summary'] = 'Zusammenfassung der Bearbeitung';
$langA['syntax_warning'] = 'Syntax Warning';
$langA['NO_IMAGES'] = 'Keine Bilder gefunden';
$langA['insert_emoticons'] = 'Emoticons einfügen';
$langA['upload'] = 'Hochladen';



//searchHistory
$langA['show'] = 'Anzeigen';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Vergleichen';
$langA['timeline'] = 'Zeitleiste';
$langA['summary'] = 'Zusammenfassung';
$langA['COMPARE_REVISONS'] = 'Vergleiche mit der ausgewählten Version.';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Falscher Dateityp geboten.';


//	SEARCH
$langA['next'] = 'weiter';
$langA['previous'] = 'zurück';
$langA['order_by'] = 'Order by:';
$langA['ascending'] = 'Aufsteigend';
$langA['descending'] = 'Absteigend';
$langA['search_from'] = 'Suche von: ';
$langA['all_users'] = 'Alle Benutzer';
$langA['user'] = 'Benutzer';
$langA['from_file_type'] = 'Suche von Dateityp: ';
$langA['read_more'] = 'Lese mehr';
$langA['words'] = ' Wörter';

$langA['RESULTS'] = 'Results %s to %s of %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Für die Suchkriterien keine Einträge gefunden.';

//searchTalk
$langA['add_comment'] = 'Neues Thema hinzufügen';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Could not include warning. Poorly formatted data for duplicate entry.';
$langA['duplicate_entry'] = 'Eintrag duplizieren';
$langA['DUPLICATE_ENTRY'] = 'This is a duplicate entry for the page found at %s. <br/>Any non redundant information found here should be transfered to the original before this page is deleted.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Nicht gefunden: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Error:</b><br /> An error occurred while executing this script.<br /> Please check your request and we will attempt to debug the script with the error log. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Kann die Standartschablone nicht löschen';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'Die gewählte Schablone war ungültig';

//
//	CLASSmap
//
$langA['new_marker']='New Marker';
$langA['new_route']='New Route';
$langA['SAVE_HEADER']='Vor dem Sichern vergiss nicht:';
$langA['save_map']='Karte Speichern';
$langA['continue_editing']='Fahre mit dem Bearbeiten fort';
$langA['miles/km'] = 'Meilen/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>This is a new map.</b><br/> To create/edit this map, click "Edit" above.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Sorry, you don\'t have sufficient privileges to edit this map.';
$langA['play'] = 'Play';
$langA['stop'] = 'Stop';
$langA['import'] = 'Importieren';
$langA['export'] = 'Exportieren';
$langA['gpx_data'] = 'GPX Data';
$langA['gpx_exchange_format'] = 'GPX Exchange Format';
$langA['CLICK_EDIT'] = 'To edit the map, click "edit" above';


//	smileys
$langA['smiles'][':D'] = 'Sehr glücklich';
$langA['smiles'][':)'] = 'Lächel';
$langA['smiles'][':('] = 'Traurig';
$langA['smiles'][':o'] = 'Überrascht';
$langA['smiles'][':shock:'] = 'Schockiert';
$langA['smiles'][':?'] = 'verwirrt';
$langA['smiles']['8)'] = 'Cool';
$langA['smiles'][':lol:'] = 'Lachend';
$langA['smiles'][':x'] = 'Wütend/Verrückt';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Verlegen';
$langA['smiles'][':cry:'] = 'Weinen oder sehr traurig';
$langA['smiles'][':evil:'] = 'Teuflisch/Sehr verrückt';
$langA['smiles'][':twisted:'] = 'Hinterlistig teuflisch';
$langA['smiles'][':roll:'] = 'Augenrollen';
$langA['smiles'][':wink:'] = 'Zwinkern';
$langA['smiles'][':!:'] = 'Ausrufezeichen';
$langA['smiles'][':?:'] = 'Frage';
$langA['smiles'][':idea:'] = 'Idee';
$langA['smiles'][':arrow:'] = 'Pfeil';
$langA['smiles'][':|'] = 'Neutral';
$langA['smiles'][':mrgreen:'] = 'Mr. Green';

//
//	General Language
//
$langA['or'] = 'oder';
$langA['username'] = 'Benutzername';
$langA['password'] = 'Passwort';
$langA['email'] = 'E-mail';
$langA['register'] = 'Registrieren';
$langA['cancel'] = 'Abbrechen';
$langA['language'] = 'Sprache';
$langA['use'] = 'Benutzen';
$langA['copy'] = 'Kopieren';
$langA['rename'] = 'Umbenennen';

$langA['on'] = 'An';
$langA['partial'] = 'Teilweise';
$langA['off'] = 'Aus';
$langA['save'] = 'Speichern';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Undefiniert';
$langA['homepage'] = 'Homepage';
$langA['home'] = 'Hauptseite';
$langA['go'] = 'Zeige';
$langA['user_menu'] = 'User Menu';

$langA['last_modified'] = 'Letzte Änderung';
$langA['LAST_MODIFIED'] = 'Letzte Änderung %s von %s.';//%s replaced with date and username
$langA['accessed_times'] = '%s mal aufgerufen';// %s replaced with a number
$langA['modified'] = 'Bearbeitet';
$langA['posted'] = 'Posted';
$langA['created'] = 'Erstellt';
$langA['hidden'] = 'Versteckt';
$langA['what_links_here'] = 'Was zeigt hierhin';
$langA['share'] = 'Teilen';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'The file must be saved before you can perform this operation.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Größe ';
$langA['bytes'] = 'Bytes';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Aktualisiere';
$langA['editing'] = 'Bearbeitung';
$langA['workgroup'] = 'Arbeitsgruppe';
$langA['BROWSE_HIDDEN'] = 'Finde versteckte Dateien';

$langA['delete'] = 'Löschen';
$langA['confirm_delete'] = 'Bestätige Löschvorgang';
$langA['continue'] = 'Fortsetzen';
$langA['back'] = 'Zurück';
$langA['close'] = 'Schliessen';
$langA['view'] = 'Betrachte';
$langA['empty'] = '-leer-';
$langA['none'] = 'Keine';
$langA['total'] = 'Gesamt ';
$langA['files'] = 'Dateien';
$langA['other'] = 'Andere';
$langA['trash'] = 'Müll';
$langA['flagged'] = 'Flagged';

$langA['today'] = 'Heute';
$langA['yesterday'] = 'Gestern';
$langA['days_ago'] = ' tage her';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'More';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'Sonntag';
$langA['date_l'][1] = 'Montag';
$langA['date_l'][2] = 'Dienstag';
$langA['date_l'][3] = 'Mittwoch';
$langA['date_l'][4] = 'Donnerstag';
$langA['date_l'][5] = 'Freitag';
$langA['date_l'][6] = 'Samstag';

$langA['date_D'][0] = 'Sun';
$langA['date_D'][1] = 'Mon';
$langA['date_D'][2] = 'Tue';
$langA['date_D'][3] = 'Wed';
$langA['date_D'][4] = 'Thu';
$langA['date_D'][5] = 'Fri';
$langA['date_D'][6] = 'Sat';


$langA['date_F'][1] = 'Januar';
$langA['date_F'][2] = 'Februar';
$langA['date_F'][3] = 'März';
$langA['date_F'][4] = 'April';
$langA['date_F'][5] = 'Mai';
$langA['date_F'][6] = 'Juni';
$langA['date_F'][7] = 'Juli';
$langA['date_F'][8] = 'August';
$langA['date_F'][9] = 'September';
$langA['date_F'][10] = 'Oktober';
$langA['date_F'][11] = 'November';
$langA['date_F'][12] = 'Dezember';

$langA['date_M'][1] = 'Jan';
$langA['date_M'][2] = 'Feb';
$langA['date_M'][3] = 'Mär';
$langA['date_M'][4] = 'Apr';
$langA['date_M'][5] = 'Mai';
$langA['date_M'][6] = 'Jun';
$langA['date_M'][7] = 'Jul';
$langA['date_M'][8] = 'Aug';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'Okt';
$langA['date_M'][11] = 'Nov';
$langA['date_M'][12] = 'Dez';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabisch (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'Deutsch (de)';
$langA['lang']['el'] = 'Greek (el)';
$langA['lang']['en'] = 'Englisch(en)';
$langA['lang']['es'] = 'Spanish (es)';
$langA['lang']['fr'] = 'Französisch (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italien (it)';
$langA['lang']['ja'] = 'Japanisch (ja)';
$langA['lang']['ko'] = 'Korean (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Dutch (nl)';
$langA['lang']['pl'] = 'Polish (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Russian (ru)';
$langA['lang']['tr'] = 'Türkish(tr)';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'Chinese (zh)';
$langA['lang']['zh-cn'] = 'Chinese Simplified (zh-cn)';



