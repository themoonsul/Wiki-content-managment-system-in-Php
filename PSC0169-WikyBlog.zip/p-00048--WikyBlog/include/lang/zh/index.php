<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = '文件';
$langA['edit'] = '编辑';
$langA['edits'] = 'Edits';
$langA['view_source'] = '查看代码';
$langA['talk'] = '聊天';
//$langA['reply'] = 'Reply';
$langA['history'] = '履历';
$langA['diff'] = '差异';
$langA['watch'] = 'Watch';
$langA['unwatch'] = 'Unwatch';
$langA['options'] = '选项';


$langA['messages'] = '消息';
$langA['current'] = '当前';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Possible';

$langA['DEFAULT_CONTENT'] = '这是一个新文件，您想要 [[%s?cmd=编辑|创建 它吗]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = '这是一个新文件，要创建该文件，您需要以相应的权限登入。';

$langA['NOT_OWNER'] = '您没有使用该特性的相应的权限。';
$langA['LONG_PATH'] = '文件名太长因而被修短。';
$langA['EMPTY_CONTENT'] = '内容是需要填入的字段。';
$langA['INCOMPLETE_PATH'] = '提供的路径不完整。';
$langA['ADMIN_DISABLED_ALL_USERS'] = '抱歉，网站管理员已经禁止用户写blog的功能。欲建立一个具有与此处同样功能的 bliki，请访问 <a href="http://www.wikyblog.com">WikyBlog.com</a>。';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = '该文件为"隐藏" ';
$langA['DELETED_FILE'] = '该文件目前在"垃圾桶",如果您是这个账号的主人,您可以在控制面板回收该文件.';
$langA['PROTECTED_FILE'] = '该文件已被保护,对该文件的修改将不被保存.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Link Text';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = '该页面重定向至 %s.';

//	Data Types
$langA['all'] = '全部';
$langA['page'] = '页面';
$langA['comment'] = '评论';
$langA['map'] = '地图';
$langA['template'] = '模板';
$langA['help'] = '帮助';
$langA['skeleton'] = '骨架';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = '评论';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = '页面';
$langA['CLASScomment'] = '评论';
$langA['CLASSmap'] = '地图';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = '帮助';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' 部分';
$langA['queries'] = ' 查询';

$langA['QUERY_TIME'] = ' 为了查询';
$langA['INVALID_PATH'] = '提供了非法的文件路径： <tt>%s</tt>';							//replaced with path
$langA['INVALID_REQUEST'] = 'Invalid Request.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = '制作新的帮助文件';



//	Special Files that need to be in with main lang file
$langA['browse'] = '浏览';
$langA['change_log'] = '变更纪录';
$langA['control_panel'] = '控制面板';
$langA['administration'] = 'U管理';
$langA['preferences'] = '參數選擇';
$langA['watchlist'] = 'Watchlist';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = '查找';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'External Links';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = '更多新贴';
$langA['NEED_INTERNET'] = '只有连入因特网的系统，该功能才有效。';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>警告：</b> 继续需要Cookies支持，如果您已启用cookies，刷新该页面。';
$langA['LOGIN_REQUIRED'] = '您必须登入以使用该功能。';

$langA['ENTER_USERNAME'] = '请输入您的用户名。';
$langA['ENTER_PASSWORD'] = '请输入您的密码。';
$langA['LOGGED_OUT'] = '您已经成功登入。';
$langA['AUTO_LOGOUT'] = '您的会话已经过期。';

$langA['LOGIN_FAILED'] = '登入失败：错误的密码。<ul><li>键盘状态是大写？<li> 是否您已%s忘记密码%s？</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = '尝试登入次数已经超过最大值 %s。您将在 %s 分钟之内不允许登入。';
						
$langA['create_new'] = '新建 ';
$langA['remember_me'] = '记住我';
$langA['log_out'] = '登出';
$langA['log_in'] = '登入';

//	SAVING 
$langA['syntax_error'] = '语法错误';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>语法错误：</b> 因为有一个不兼容的语法，无法保存/显示对该文件的最近更新。';
$langA['SYNTAX_FIXED'] = '语法错误已被修正。';


$langA['NO_CHANGES'] = '该文件未被更改。(%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = '无法保存该文件。(%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = '对文件的更新已被保存。';
$langA['HIDDEN_FILE3'] = '<b>注：</b> 这是一个隐藏文件，因此对该文件设置的标签将不被包含在用户菜单内。';

$langA['VERSION_CONFLICT'] = '警告： 我们不能保存您所作的更改，因为检测到一个版本冲突。';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = '编辑已被限制在每文件间隔 %s 秒，请在 %s 秒之后重试。';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = '保存选项';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = '差异';
$langA['line_num'] = '行 #';


//	toolHistory1.php
$langA['revision'] = '修订版 ';
$langA['revision_as_of'] = '修订版 自 ';
$langA['revision_num_as_of'] = '修订版  %s 自 %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = '编辑修订版';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = '恢复到修订版 #';
$langA['SET_USER_PERMISSIONS'] = '设置您给该用户的权限： '; 
$langA['compare_with_prev'] = '← 与前一个修订版比较';
$langA['current_revision'] = '当前修订版';
$langA['compare_with_next'] = '与下一个修订版比较 →';
$langA['lines'] = '行';
$langA['text'] = '文字';
$langA['vs'] = ' vs ';
$langA['content'] = '内容';
$langA['your_text'] = '您的文字';
$langA['show_prev_revision'] = '← 修订版 %s'; //%s replaced with a revision number
$langA['show_next_revision'] = '修订版 %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>警告：</b>您不是在修改该页面最新版。<br />保存将用这个老版本覆盖最新版本。';
$langA['SELECT_TWO_VERSIONS'] = '请选择两个不同的版本进行比较。';
$langA['NO_UNIQUE_REVISION'] = '找不到该请求的唯一版本。';
$langA['INVALID_REVISION'] = '<b>错误：</b>无效的修订版本号。';
$langA['NO_DIFFERENCES'] = '比较两个版本的结果一致。';
$langA['NO_REVISIONS'] = '在进行比较之前必须先有两个不同的版本。';
$langA['NON_EXISTANT'] = 'This file does not exist yet.';

//	toolEditPage.php
$langA['bold_text'] = '粗体';
$langA['italic_text'] = '斜体';
$langA['headline_text'] = '插入标题';
$langA['title'] = '标题';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = '内部链接';
$langA['link'] = '链接';
$langA['external_link'] = '外部链接';
$langA['embed_image'] = '嵌入图像';
$langA['find_images'] = 'Find Images';
$langA['image'] = '图像';
$langA['nowiki'] = '非wiki';
$langA['NOWIKI_TEXT'] = '在此插入非格式化文本';
$langA['signature'] = 'Signature';
$langA['SIGNATURE_TEXT'] = 'Insert your Signature';
$langA['preview'] = '预览';
$langA['PREVIEW_TEXT'] = '预览您的更改[%s-p]';
$langA['PREVIEW_WARN'] = '这只是一个预览，您的修改还未被保存。';
$langA['SAVE_TEXT'] = '保存您的更改[%s-p]';
$langA['reset'] = '重置';
$langA['RESET_TEXT'] = '把当前表单重置到初始状态[%s-c]';
$langA['changes'] = '更改';
$langA['CHANGES_TEXT'] = '显示您对该文件所作的修改。[%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = '用逗号分割的关键字组织您的文章'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = '标签';
$langA['edit_summary'] = '编辑概要';
$langA['syntax_warning'] = '语法警告';
$langA['NO_IMAGES'] = '找不到图片';
$langA['insert_emoticons'] = '插入表情';
$langA['upload'] = 'Upload';



//searchHistory
$langA['show'] = '显示';
$langA['hide'] = 'Hide';
$langA['compare'] = '比较';
$langA['timeline'] = '时间表';
$langA['summary'] = '概要';
$langA['COMPARE_REVISONS'] = '比较所选的版本。';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = '提供的是无效的文件类型。';


//	SEARCH
$langA['next'] = '下一个';
$langA['previous'] = '上一个';
$langA['order_by'] = '排序：';
$langA['ascending'] = '升序';
$langA['descending'] = '降序';
$langA['search_from'] = '查找从： ';
$langA['all_users'] = '所有用户';
$langA['user'] = '用户';
$langA['from_file_type'] = '从文件类型查找： ';
$langA['read_more'] = '阅读更多';
$langA['words'] = ' 词';

$langA['RESULTS'] = '%s 结果中的 %s 到 %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = '该查询标准下找不到文章';

//searchTalk
$langA['add_comment'] = '增加新话题';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = '不能包含的警告，格式不完整的数据有重复的入口。';
$langA['duplicate_entry'] = '重复的入口';
$langA['DUPLICATE_ENTRY'] = '这是一个重复的入口，于 %s 找到的页面。<br/> 在删除该页面之前，在这儿找到的任何非冗余信息，必须先转移至原始状态。'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = '未找到： '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>错误：</b>在执行该脚本的时候发生错误，请检查您的请求，我们将根据错误记录调试该脚本。'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = '不能删除默认模板。';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = '指定的布景无效。';

//
//	CLASSmap
//
$langA['new_marker']='新的标记';
$langA['new_route']='新的路由';
$langA['SAVE_HEADER']='保存前须记';
$langA['save_map']='保存地图';
$langA['continue_editing']='继续编辑';
$langA['miles/km'] = '公里/千米';
$langA['MAP_DEFAULT_CONTENT'] = '<b>这是一个新地图。</b><br/> 若要创建/编辑该地图，请点以上的“编辑”。';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = '抱歉，您没有足够的权限来编辑这个地图。';
$langA['play'] = '播放';
$langA['stop'] = '停止';
$langA['import'] = '导入';
$langA['export'] = '导出';
$langA['gpx_data'] = 'GPX 数据';
$langA['gpx_exchange_format'] = 'GPX 交换格式';
$langA['CLICK_EDIT'] = '欲编辑该地图，点以上的“编辑”';


//	smileys
$langA['smiles'][':D'] = '非常高兴';
$langA['smiles'][':)'] = '微笑';
$langA['smiles'][':('] = '悲伤';
$langA['smiles'][':o'] = '惊奇';
$langA['smiles'][':shock:'] = '震惊';
$langA['smiles'][':?'] = '困惑';
$langA['smiles']['8)'] = '酷';
$langA['smiles'][':lol:'] = '笑';
$langA['smiles'][':x'] = '疯了';
$langA['smiles'][':P'] = '冷笑';
$langA['smiles'][':oops:'] = '困窘';
$langA['smiles'][':cry:'] = '哭或非常悲伤';
$langA['smiles'][':evil:'] = '邪恶或非常疯狂';
$langA['smiles'][':twisted:'] = '扭曲的邪恶';
$langA['smiles'][':roll:'] = '转动的眼睛';
$langA['smiles'][':wink:'] = '眨眼';
$langA['smiles'][':!:'] = '惊叹';
$langA['smiles'][':?:'] = '问题';
$langA['smiles'][':idea:'] = '想法';
$langA['smiles'][':arrow:'] = '箭头';
$langA['smiles'][':|'] = '中立';
$langA['smiles'][':mrgreen:'] = '格林先生';

//
//	General Language
//
$langA['or'] = '或';
$langA['username'] = '用户名';
$langA['password'] = '密码';
$langA['email'] = '电子邮件';
$langA['register'] = '注册';
$langA['cancel'] = '取消';
$langA['language'] = '語系';
$langA['use'] = 'Use';
$langA['copy'] = 'Copy';
$langA['rename'] = 'Rename';

$langA['on'] = '在';
$langA['partial'] = '部分';
$langA['off'] = '关闭';
$langA['save'] = '保存';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = '未定义';
$langA['homepage'] = '主页';
$langA['home'] = '首页';
$langA['go'] = 'Go';
$langA['user_menu'] = 'User Menu';

$langA['last_modified'] = '最后更新';
$langA['LAST_MODIFIED'] = '最后更新 %s 由 %s 。';//%s replaced with date and username
$langA['accessed_times'] = '访问过 %s 次';// %s replaced with a number
$langA['modified'] = '被修改';
$langA['posted'] = '被发表';
$langA['created'] = '被创建';
$langA['hidden'] = '隐藏';
$langA['what_links_here'] = 'What Links Here';
$langA['share'] = 'Share';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = '要先保存文件您才能完成本運轉.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = '尺寸 ';
$langA['bytes'] = '字节';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = '更新';
$langA['editing'] = '编辑';
$langA['workgroup'] = '工作组';
$langA['BROWSE_HIDDEN'] = '查找隐藏文件';

$langA['delete'] = '删除';
$langA['confirm_delete'] = '确认删除';
$langA['continue'] = '继续';
$langA['back'] = '返回';
$langA['close'] = 'Close';
$langA['view'] = '查看';
$langA['empty'] = '-空-';
$langA['none'] = '無';
$langA['total'] = '总数 ';
$langA['files'] = '文件';
$langA['other'] = '其他';
$langA['trash'] = '垃圾桶';
$langA['flagged'] = 'Flagged';

$langA['today'] = '今日';
$langA['yesterday'] = '昨日';
$langA['days_ago'] = ' 天之前';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'More';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'Sunday';
$langA['date_l'][1] = 'Monday';
$langA['date_l'][2] = 'Tuesday';
$langA['date_l'][3] = 'Wednesday';
$langA['date_l'][4] = 'Thursday';
$langA['date_l'][5] = 'Friday';
$langA['date_l'][6] = 'Saturday';

$langA['date_D'][0] = 'Sun';
$langA['date_D'][1] = 'Mon';
$langA['date_D'][2] = 'Tue';
$langA['date_D'][3] = 'Wed';
$langA['date_D'][4] = 'Thu';
$langA['date_D'][5] = 'Fri';
$langA['date_D'][6] = 'Sat';


$langA['date_F'][1] = 'January';
$langA['date_F'][2] = 'February';
$langA['date_F'][3] = 'March';
$langA['date_F'][4] = 'April';
$langA['date_F'][5] = 'May';
$langA['date_F'][6] = 'June';
$langA['date_F'][7] = 'July';
$langA['date_F'][8] = 'August';
$langA['date_F'][9] = 'September';
$langA['date_F'][10] = 'October';
$langA['date_F'][11] = 'November';
$langA['date_F'][12] = 'December';

$langA['date_M'][1] = 'Jan';
$langA['date_M'][2] = 'Feb';
$langA['date_M'][3] = 'Mar';
$langA['date_M'][4] = 'Apr';
$langA['date_M'][5] = 'May';
$langA['date_M'][6] = 'Jun';
$langA['date_M'][7] = 'Jul';
$langA['date_M'][8] = 'Aug';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'Oct';
$langA['date_M'][11] = 'Nov';
$langA['date_M'][12] = 'Dec';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabic (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'German (de)';
$langA['lang']['el'] = 'Greek (el)';
$langA['lang']['en'] = 'English (en)';
$langA['lang']['es'] = 'Spanish (es)';
$langA['lang']['fr'] = 'French (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italian (it)';
$langA['lang']['ja'] = 'Japanese (ja)';
$langA['lang']['ko'] = 'Korean (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Dutch (nl)';
$langA['lang']['pl'] = 'Polish (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Russian (ru)';
$langA['lang']['tr'] = 'Turkish (tr)';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'Chinese (zh)';
$langA['lang']['zh-cn'] = 'Chinese Simplified (zh-cn)';



