<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'The file name has not changed.';
$langA['NOT_RENAMED'] = 'This file could not be renamed to <tt>%s</tt>. Please make sure this file does not already exist.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = '無法更改檔案名稱';
$langA['redirected_to'] = 'Redirected to';
$langA['RENAMED'] = '檔案名稱更改成功';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b> 已被恢复。 ';
$langA['ERROR_RESTORING'] = '<b>Error:</b> Could not restore the file at <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = '该文件已被恢复。';
$langA['WAS_DELETED'] = '<b>%s</b> 已被删除。该文件将在30天内保存于 %s。';
$langA['ERROR_DELETING'] = '<b>错误：</b> 不能在 <tt>%s.</tt> 删除该文件。';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> was deleted.';
