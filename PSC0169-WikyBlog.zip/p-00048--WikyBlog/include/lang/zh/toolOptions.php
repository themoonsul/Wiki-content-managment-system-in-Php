<?php

//	toolOptions.php
$langA['properties'] = '属性';
$langA['file_name'] = 'File Name';
$langA['update_from'] = '更新自';
$langA['COPY_SYSTEM_FILES'] = '从%s复制最新的系统帮助文件。';

$langA['EDITING_OPTIONS'] = '控制谁能编辑该文件。';
$langA['registered_users'] = '注册用户';
$langA['restricted_to'] = '限定至 ';
$langA['admin_only'] = '仅管理员';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Owner Only';
$langA['use_captcha'] = '使用CAPTCHA';
		

$langA['visibility'] = '可见';
$langA['VISIBILITY_OPTIONS'] = '隐藏该文件，如果您不想把他公诸于众。';
$langA['visible'] = '可见';

$langA['COMMENT_OPTIONS'] = '禁止对该文件评论。';
$langA['enabled'] = '激活';
$langA['disabled'] = '禁止';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = '其他';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Remove From Blog';
$langA['repost'] = '重新发表';
$langA['copy_to'] = '复制到...';
$langA['send_to_trash'] = '发送到垃圾桶';
$langA['default_options'] = '默认选项';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = '对该文件类型设置 %s 。'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = '本文件被再郵寄了.';
$langA['NOT_REPOSTED'] = '<b>錯誤:</b> 無會再郵寄本文件.';
$langA['OPTIONS_NOT_CHANGED'] = '檔案選擇沒有被改變.';
$langA['OPTIONS_UPDATED'] = '檔案選擇已成功被改變了.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not updated.';

$langA['redirect'] = '重定向';
$langA['REMOVE_REDIRECT'] = '您如果不再要本檔案重定向,請或者刪除它或者編輯它. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'User&nbsp;Permissions';
