<?php

	$langA['googleMapKeys'] =						'Google Maps API Key';


	$langA['ADMIN_ONLY'] =							'你必須是管理者才能存取這個頁面';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'這個管理頁面尚未被定義:<tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'請再次輸入您的密碼進行確認';
	$langA['confirm_password'] =						'確認密碼';
	$langA['confirmation_failed'] =					'密碼驗證失敗, 請再試一次';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'尋找選項';
	$langA['search_status'] =						'尋找結果';
	$langA['search_enabled'] =						'啟用尋找';
	$langA['SEARCH_ENABLED'] =						'禁止检索功能将请空数据库的`all_search`表格。以后，如果您想重新激活检索功能，`all_search`表格需要将被重新构成。';
	$langA['disable'] =								'停用';
	
	$langA['search_disabled'] =						'停用尋找';
	$langA['SEARCH_DISABLED'] =						'检索功能目前无效。启用检索功能需要用数据库里的所有文件重新填充表格`all_search` ，如果数据库比较大，这个过程可能需要很长的时间。';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'啟用';
	
	$langA['FINISHED_ENTRIES'] =						'%s 篇文章处理完毕，还剩下 %s 篇。';
	$langA['SEARCH_IS_ENABLED'] =					'搜尋功能已經啟用';


//
// adminConfig.php
//
	$langA['configuration'] =						'系統設定';
	$langA['confighistory'] =						'系統設定履历';
	$langA['CONFIG_SAVING'] =						'新的設定已经保存，原先的設定没有被覆盖，以便您撤销修改（如有必要）...';
	$langA['CONFIG_STAT'] =							'設定有 %s 个修订的履历。';
	$langA['CONFIG_CONFIRM_REVERT'] =				'您确信要返回版本号 %s ？ 点 <tt>保存</tt> 以继续。';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'可以用诸如这样的语句：“欢迎访问服务器1”。';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'允许上传文件的最大尺寸。';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'错误日志的最大文件尺寸，默认为10,000字节。';
	$langA['errorEmail']['desc'] = 					'請提供一個電子郵件位址 ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'一般設定';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'網站名稱';
	$langA['serverName2']['alias'] = 				'伺服器名稱';
	$langA['serverName3']['alias'] = 				'完整的伺服器URL';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'最大上传';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'語系';
	$langA['reservedWords']['alias'] = 				'保留字';
	
	$langA['developer_aids'] = 						'开发者目标';
	$langA['maxErrorFileSize']['alias'] = 			'错误日志尺寸';
	$langA['errorEmail']['alias'] = 					'錯誤的電子郵件';
	$langA['include']['alias'] = 					'Include PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'預設使用者設定';
	
	$langA['defaultUser:homeTitle']['alias'] =		'首頁標題';
	$langA['defaultUser:homeTitle']['desc'] =		'以首页标题显示。';
	
	$langA['defaultUser:template']['alias'] =		'使用者範本';
	$langA['defaultUser:template']['desc'] =		'Main/Home是wikyblog的默认模板。';
	
	$langA['defaultUser:textareaY']['alias'] =		'文字區塊高度';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'部落格首頁';
	$langA['defaultUser:isBlog']['desc'] =			'打开/关闭Blog主页模式。';
	
	$langA['defaultUser:timezone']['alias'] =		'時區';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'最大歷史記錄';
	$langA['defaultUser:maxHistory']['desc'] =		'默认最大履历行数。';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Add Group';
	$langA['unlimited'] = 'Unlimited';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'使用CAPTCHA';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'使用者統記表';
	$langA['user_stats'] =							'使用者狀態';
	$langA['user_account'] =							'使用者帳號';
	$langA['entries'] =								'文章';
	$langA['history Rows'] =							'履历行数';
	$langA['last_visit'] = 							'最近一次造訪';
	
	$langA['users_found'] =							'用户找到';
	$langA['showing_of_found'] =						'显示 %s 于 %s';
	$langA['cpanel'] =								'控制台';
	$langA['details'] =								'詳細資訊';
	
	$langA['within_the_hour'] =						' 最近一個小時內';
	$langA['hours'] =								'小時';
	$langA['days'] =									'天';
	$langA['months'] =								'月';
	$langA['years'] = 								'年';
	$langA['ago'] = 									'之前';
	
	$langA['TIMEOUT'] = 								'<b>超时错误:</b> %s 。';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'你確定要刪除 <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'删除动作将<i>完全擦掉</i>所有该账号所拥有的文件:';
	$langA['userfiles_directory'] = 					'用户文件目录： ';
	$langA['template_directory'] = 					'临时文件目录： ';
	$langA['database_entries'] = 					'还有全部的数据库入口：页面，页面履历，评论等。';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'删除数据库入口。';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>警告:</b>不能删除数据库入口。';
	
	$langA['DELETED_USERFILES'] = 					'删除用户文件目录。';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>警告:</b>不能删除用户文件目录。';
	
	$langA['DELETED_TEMPLATES'] = 					'删除临时文件目录。';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>警告:</b>不能删除临时文件目录。';
	
	$langA['USER_DELETED'] = 						'%s 已經被完整的刪除了. ';
	$langA['USER_NOT_DELETED'] = 					'%s 並沒有被完整的刪除 ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activate';
	$langA['lost_page'] = 							'丢失页面';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'禁止';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'無法刪除Error日誌';
	$langA['ERROR_LOG_DELETED'] = 					'Error日誌已被刪除';
	$langA['ERROR_LOG_MAXED'] = 						'错误日志文件已经达到最大尺寸，请清空该文件以继续纪录错误。%s';


	$langA['select'] = 								'選擇';
	$langA['description'] = 						'描述';


//	adminPlugins
	$langA['data_types'] = 							'数据格式'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'现存格式';
	$langA['available_plugins'] = 					'可用插件';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Check All / Uncheck All';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'線上';
	$langA['wbConfig']['online']['desc'] = 			'本安装连接到因特网吗？';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Flood间隔';
	$langA['wbConfig']['floodInterval']['desc'] = 	'前后编辑之间禁止用户的秒数。';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'使用 HTML Tidy 更正可能的用户输入错误。';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'完整功能';
	$langA['wbConfig']['allUsers']['desc'] = 		'允许所有注册的用户拥有自己的blog';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

