<?php

//	toolOptions.php
$langA['properties'] = 'Ιδιότητες';
$langA['file_name'] = 'Όνομα Αρχείου';
$langA['update_from'] = 'Αναβάθμιση Απο';
$langA['COPY_SYSTEM_FILES'] = 'Copy the most recent system help files from %s.';

$langA['EDITING_OPTIONS'] = 'Control who is allowed to edit this file.';
$langA['registered_users'] = 'Εγγεγραμένοι Χρήστες';
$langA['restricted_to'] = 'Restricted To ';
$langA['admin_only'] = 'Μόνο Διαχειριστής';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Μόνο ο Ιδιοκτήτης';
$langA['use_captcha'] = 'Χρήση Captcha';
		

$langA['visibility'] = 'Ορατότητα';
$langA['VISIBILITY_OPTIONS'] = 'Hide this file if you\'re not ready to show it to the world.';
$langA['visible'] = 'Ορατά';

$langA['COMMENT_OPTIONS'] = 'Απενεργοποίηση σχολιασμών για αυτό το αρχείο';
$langA['enabled'] = 'Ενεργοποίηση';
$langA['disabled'] = 'Απενεργοποίηση';
$langA['RECENT_COMMENTS'] = 'Προβολή πρόσφατων σχολίων.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = 'Διάφορα';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Remove From Blog';
$langA['repost'] = 'Αναφορά';
$langA['copy_to'] = 'Αντιγραφή στο.....';
$langA['send_to_trash'] = 'Αποστολή στα σκουπίδια';
$langA['default_options'] = 'Προκαθορισμένες Επιλογές';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = 'Set %s for this file type.'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'This file was reposted.';
$langA['NOT_REPOSTED'] = '<b>Error:</b> Could not repost this file.';
$langA['OPTIONS_NOT_CHANGED'] = 'Οι επιλογές του αρχείου έχουν τροποποιηθεί';
$langA['OPTIONS_UPDATED'] = 'Οι επιλογές του αρχείου αναβαθμίστηκαν επιτυχώς';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not updated.';

$langA['redirect'] = 'Ανακατεύθυνση';
$langA['REMOVE_REDIRECT'] = 'If you no longer want this file to redirect, you can either delete or edit it. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'User&nbsp;Permissions';
