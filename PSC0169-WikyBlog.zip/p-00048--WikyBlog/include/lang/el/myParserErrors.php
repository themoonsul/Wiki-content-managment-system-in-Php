<?php

$langA['end_of_document'] = ' --Τέλος Εγγράφου-- ';
$langA['syntax_warning'] = ' Έλεγχος Σύνταξης ';

$langA['XML_ERROR_INVALID_TOKEN'] = 'The error was detected on line %s at position %s but could have been caused by previous lines.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>random &lt;text</tt> instead of <tt>random &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> instead of <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> instead of <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = 'Closing HTML tags are needed to make this document complete: "<em>%s</em>".';

$langA['unnecessary_closing_tag'] = 'Unnecessary closing tag.';
$langA['should_be'] = ' should simply be ';

$langA['CLOSING_AN_UNOPENED_TAG'] = 'Closing an unopened tag.<br /> There was not an opening tag for the closing tag <tt>&lt;/%s&gt;</tt>.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>&lt;/tag&gt;</tt> without <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> instead of <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Missing closing tag. <br /> The <tt>&lt;%s&gt;</tt> tag must be closed using <tt>%s</tt> ';
$langA['MISSING_CLOSING_TAG2'] = ' before the closing tag <tt>&lt;/%s&gt;</tt>.';

$langA['AUTOMATED_SYNTAX_ERROR'] = 'Αυτοματοποιημένο Σφάλμα Σύνταξης';
$langA['AUTOMATED_SYNTAX_ERROR2'] = '(%s) at line %s (of %s lines) at position %s ';
$langA['last_open_tag'] = '<br />Last Open Tag ';
