<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Αρχείο';
$langA['edit'] = 'Αλλαγή';
$langA['edits'] = 'Edits';
$langA['view_source'] = 'Πηγαίος κώδικας';
$langA['talk'] = 'Ομιλία';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Ιστορία';
$langA['diff'] = 'Διαφορά';
$langA['watch'] = 'Παρακολούθηση';
$langA['unwatch'] = 'Παύση παρακολούθησης';
$langA['options'] = 'Επιλογές';


$langA['messages'] = 'Μηνύματα';
$langA['current'] = 'Πρόσφατο/α';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Possible';

$langA['DEFAULT_CONTENT'] = 'This is a new file, would you like to [[%s?cmd=edit|create it]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Νέο Αρείο. Για την δημιουργία αυτούν του αρχείου πρέπει να εισέλθεται στην υπηρεσία με τα απαιτούμενα δικαιώματα.';

$langA['NOT_OWNER'] = 'Δέν έετε επαρκή διακιώματα για αυτό το χαρακτηριστικό';
$langA['LONG_PATH'] = 'The title for this file was too long and has been truncated.';
$langA['EMPTY_CONTENT'] = 'Το Περιεχόμενο είναι υποχρεωτικό πεδίο';
$langA['INCOMPLETE_PATH'] = 'The supplied path is incomplete.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Sorry, the website administrator has disabled user blogging. To create a bliki with the same features found here, visit <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = 'Αυτο το αρχείο είναι "κρυμμένο". ';
$langA['DELETED_FILE'] = 'This file is currently in the "trash". If you are the owner of this account, you can restore this file via your control panel.';
$langA['PROTECTED_FILE'] = 'Προστατευμένο Αρχείο. Όποιες αλλαγές έγιναν στο αρχείο δέν αποθηκέυτηκαν.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Link Text';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'Αυτή η σελίδα ανακατευθείνει στο %s.';

//	Data Types
$langA['all'] = 'Ολα';
$langA['page'] = 'Σελίδα';
$langA['comment'] = 'Σχόλιο';
$langA['map'] = 'Χάρτης';
$langA['template'] = 'Προφόρμα';
$langA['help'] = 'Βοήθεια';
$langA['skeleton'] = 'Σκελετός';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Σχόλια';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Σελίδες';
$langA['CLASScomment'] = 'Σχόλια';
$langA['CLASSmap'] = 'Χάρτες';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'Βοήθεια';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' δευτερόλεπτα';
$langA['queries'] = ' εντολές στη βάση δεδομένων';

$langA['QUERY_TIME'] = ' για εντολές στη βάση δεδομένων';
$langA['INVALID_PATH'] = 'Η τοποθεσία του αρχείου είναι λανθασμένη: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Invalid Request.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = 'Create a new help file';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Περιήγηση';
$langA['change_log'] = 'Change Log';
$langA['control_panel'] = 'Κέντρο Ελέγχου';
$langA['administration'] = 'Δοιήκηση';
$langA['preferences'] = 'Επιλογές';
$langA['watchlist'] = 'Λίστα παρακολούθησης';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'Αναζήτηση';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'External Links';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'More Recent Posts.';
$langA['NEED_INTERNET'] = 'This feature is only available for systems connected to the internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Warning:</b> Cookies are required to continue. Refresh this page if you have cookies enabled.';
$langA['LOGIN_REQUIRED'] = 'You must be signed in to use this feature.';

$langA['ENTER_USERNAME'] = 'Please enter your Username.';
$langA['ENTER_PASSWORD'] = 'Please enter your Password.';
$langA['LOGGED_OUT'] = 'You have successfully logged out.';
$langA['AUTO_LOGOUT'] = 'Your session has expired.';

$langA['LOGIN_FAILED'] = 'Log in failed: Incorrect Password.<ul><li>Is Caps Lock on?<li> Have you %sforgotten your password%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'The maximum number of %s login attempts has been exceeded. You will not be allowed to login for the next %s minutes.';
						
$langA['create_new'] = 'Create&nbsp;New ';
$langA['remember_me'] = 'Διατήρηση του κωδικού πρόσβασης σε αυτόν τον υπολογιστή';
$langA['log_out'] = 'Έξοδος χρήστη';
$langA['log_in'] = 'Είσοδος';

//	SAVING 
$langA['syntax_error'] = 'Σφάλμα Σύνταξης';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Syntax Error:</b> Unable to Save/Display the most recent changes to this file due to an incompatible syntax.';
$langA['SYNTAX_FIXED'] = 'Το Σφάλμα σύνταξης διορθώθηκε';


$langA['NO_CHANGES'] = 'Καμμία μεταβολή πραγματοποιήθηκε στο αρχείο';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Μη αποθήκευση Αρχείου';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Οι Αλλαγές του Αρχείου αποθυκεύτηκαν';
$langA['HIDDEN_FILE3'] = '<b>Note:</b> This is a hidden file, therefore tags for this file will not be included in the user menu totals.';

$langA['VERSION_CONFLICT'] = 'Προειδοποίηση: Δεν μπορειτε να αποθηκεύσετε τις αλλαγές λόγω προβληματικής έκδοσης';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Editing has been limited to one file every %s seconds. Please try again in %s seconds.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Αποθήκευση αλλαγών';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = 'Διαφορά(ές)';
$langA['line_num'] = 'Γραμμή';


//	toolHistory1.php
$langA['revision'] = 'Επαναλήψη ';
$langA['revision_as_of'] = 'Επαναληψη ';
$langA['revision_num_as_of'] = 'Επανάληψη όπως'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Τροποποίηση Επανάληψης';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Reverted to revision #';
$langA['SET_USER_PERMISSIONS'] = 'Δηλώστε δικαιώματα γι΄αυτον τον χρήστη '; 
$langA['compare_with_prev'] = '← Compare with Previous Revision';
$langA['current_revision'] = 'Τρέχουσα αναθεώρηση';
$langA['compare_with_next'] = 'Compare with Next Revision →';
$langA['lines'] = 'Γραμμές';
$langA['text'] = 'Κείμενο';
$langA['vs'] = ' vs ';
$langA['content'] = 'Περιεχόμενο';
$langA['your_text'] = 'Το Κείμενο σας';
$langA['show_prev_revision'] = '← Revision %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revision %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Warning:</b> You are not editing the most recent version of this page.<br /> Saving will replace the newest version with this out-of-date version.';
$langA['SELECT_TWO_VERSIONS'] = 'Παρακαλώ Επιλέξτε δύο διαφορετικές εκδόσεις για σύγκριση';
$langA['NO_UNIQUE_REVISION'] = 'Could not find a unique revision for this request.';
$langA['INVALID_REVISION'] = '<b>Error:</b> Invalid Revision Number.';
$langA['NO_DIFFERENCES'] = 'The two revisions being compared are identical.';
$langA['NO_REVISIONS'] = 'There must be two distinct revisions before a comparison can be made.';
$langA['NON_EXISTANT'] = 'This file does not exist yet.';

//	toolEditPage.php
$langA['bold_text'] = 'Έντονο κείμενο';
$langA['italic_text'] = 'Κείμενο με πλάγιους χαρακτήρες';
$langA['headline_text'] = 'Insert Heading';
$langA['title'] = 'Τίτλος';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = 'Εσωτερικός σύνδεσμος';
$langA['link'] = 'Σύνδεσμος';
$langA['external_link'] = 'Εξωτερικός Σύνδεσμος';
$langA['embed_image'] = 'Ενσωμάτωση Εικόνας';
$langA['find_images'] = 'Find Images';
$langA['image'] = 'Εικόνα';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'Εισάγετε εδώ το μη μορφοποιημένο κείμενο.';
$langA['signature'] = 'Signature';
$langA['SIGNATURE_TEXT'] = 'Insert your Signature';
$langA['preview'] = 'Προεπισκόπηση';
$langA['PREVIEW_TEXT'] = 'Preview your changes [%s-p]';
$langA['PREVIEW_WARN'] = 'This is only a preview. Your changes have not been saved yet!';
$langA['SAVE_TEXT'] = 'Αποθήκευση αλλαγών [%s-s]';
$langA['reset'] = 'Επαναφορά προτιμήσεων';
$langA['RESET_TEXT'] = 'Reset this form to it\'s original state [%s-c]';
$langA['changes'] = 'αλλαγές';
$langA['CHANGES_TEXT'] = 'Show the changes you\'ve made to this file. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organize your posts with comma separated keywords'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Tags';
$langA['edit_summary'] = 'Edit Summary';
$langA['syntax_warning'] = 'Syntax Warning';
$langA['NO_IMAGES'] = 'Δέν βρέθηκαν εικόνες';
$langA['insert_emoticons'] = 'Εσαγωγή εικονιδίων συναισθημάτων';
$langA['upload'] = 'Ανέβασμα';



//searchHistory
$langA['show'] = 'Παρουσίαση';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Σύγκριση';
$langA['timeline'] = 'Χρονικό Περιθώριο';
$langA['summary'] = 'Περίληψη';
$langA['COMPARE_REVISONS'] = 'Σύγκριση με την επιλεχθείσα έκδοση';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Λανθασμένος τύπος αρχείου';


//	SEARCH
$langA['next'] = 'Επόμενο';
$langA['previous'] = 'Προηγούμενο';
$langA['order_by'] = 'Παραγγελία ανα:';
$langA['ascending'] = 'Άνοδος';
$langA['descending'] = 'Κάθοδος';
$langA['search_from'] = 'Αναζήτηση Απο: ';
$langA['all_users'] = 'Όλοι οι χρήστες';
$langA['user'] = 'Χρήστης';
$langA['from_file_type'] = 'Search From File Type: ';
$langA['read_more'] = 'Διαβάστε περισσότερα';
$langA['words'] = ' Λέξεις';

$langA['RESULTS'] = 'Results %s to %s of %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Δεν βρέθηκαν αποτελέσματα με τα δεδομένα κριτήρια';

//searchTalk
$langA['add_comment'] = 'Προσθέστε Νέο θέμα';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Could not include warning. Poorly formatted data for duplicate entry.';
$langA['duplicate_entry'] = 'Διπλότυπη Εισαγωγή';
$langA['DUPLICATE_ENTRY'] = 'This is a duplicate entry for the page found at %s. <br/>Any non redundant information found here should be transfered to the original before this page is deleted.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Δεν Βρέθηκε '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Error:</b><br /> An error occurred while executing this script.<br /> Please check your request and we will attempt to debug the script with the error log. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Cannot delete the default template.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'The specified theme was invalid.';

//
//	CLASSmap
//
$langA['new_marker']='Νέα Επισήμανση';
$langA['new_route']='Νέα Διαδρομή';
$langA['SAVE_HEADER']='Πρίν την Αποθήκευση Θυμηθείτε';
$langA['save_map']='Αποθήκευση Χάρτη';
$langA['continue_editing']='Συνέχεια Τροποποίησης';
$langA['miles/km'] = 'Μίλια/Χιλιόμετρα';
$langA['MAP_DEFAULT_CONTENT'] = '<b>This is a new map.</b><br/> To create/edit this map, click "Edit" above.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Δυστηχώς δεν έχετε επαρκή δικαιώματα για την τροποποίηση του χάρτη.';
$langA['play'] = 'Εκκίνηση';
$langA['stop'] = 'Σταμάτημα';
$langA['import'] = 'Εισαγωγή';
$langA['export'] = 'Εξαγωγή';
$langA['gpx_data'] = 'Δεδομένα GPX';
$langA['gpx_exchange_format'] = 'GPX Exchange Format';
$langA['CLICK_EDIT'] = 'Για την τροποποίηση του χάρτη πατήστε \'\'edit\'\'';


//	smileys
$langA['smiles'][':D'] = 'Αρκετά Χαρούμενος';
$langA['smiles'][':)'] = 'Χαμόγελο';
$langA['smiles'][':('] = 'Λυπηρό';
$langA['smiles'][':o'] = 'Έκπληκτος';
$langA['smiles'][':shock:'] = 'Σοκαρισμένος';
$langA['smiles'][':?'] = 'Μπερδεμένος';
$langA['smiles']['8)'] = 'Αραχτός';
$langA['smiles'][':lol:'] = 'Γελαστός';
$langA['smiles'][':x'] = 'Τρελός';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Ντροπαλός';
$langA['smiles'][':cry:'] = 'Κλαμμένος ή πολύ λυπημένος';
$langA['smiles'][':evil:'] = 'Διαβολικός ή πολύ θυμωμένος';
$langA['smiles'][':twisted:'] = 'Twisted Evil';
$langA['smiles'][':roll:'] = 'Rolling Eyes';
$langA['smiles'][':wink:'] = 'Wink';
$langA['smiles'][':!:'] = 'Exclamation';
$langA['smiles'][':?:'] = 'Ερώτηση';
$langA['smiles'][':idea:'] = 'Ιδέα';
$langA['smiles'][':arrow:'] = 'Τόξο';
$langA['smiles'][':|'] = 'Ουδέτερο';
$langA['smiles'][':mrgreen:'] = 'Mr. Green';

//
//	General Language
//
$langA['or'] = 'ή';
$langA['username'] = 'Όνομα Χρήστη';
$langA['password'] = 'κωδικός';
$langA['email'] = 'Ηλεκτρονικό Ταχυδρομείο';
$langA['register'] = 'Εγγραφή';
$langA['cancel'] = 'Άκυρο';
$langA['language'] = 'Γλώσσα';
$langA['use'] = 'Use';
$langA['copy'] = 'Copy';
$langA['rename'] = 'Rename';

$langA['on'] = 'Ανοιχτο';
$langA['partial'] = 'Μερικώς';
$langA['off'] = 'Κλειστό';
$langA['save'] = 'Αποθήκευση';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Δεν έχει καθοριστεί';
$langA['homepage'] = 'Αρχική Σείδα';
$langA['home'] = 'Αρική';
$langA['go'] = 'Μετάβαση';
$langA['user_menu'] = 'Μενού Χρήστη';

$langA['last_modified'] = 'Πρόσφατα Τροποποιημένο';
$langA['LAST_MODIFIED'] = 'Πρόσφατα Τροποποιημένο Απο';//%s replaced with date and username
$langA['accessed_times'] = 'Accessed %s times';// %s replaced with a number
$langA['modified'] = 'Τροποποίηση';
$langA['posted'] = 'Δημοσιευμένο';
$langA['created'] = 'Δημιουργήθηκε';
$langA['hidden'] = 'Κρυμμένα';
$langA['what_links_here'] = 'Αναφορές στη σελίδα';
$langA['share'] = 'Share';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'The file must be saved before you can perform this operation.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Μέγεθος ';
$langA['bytes'] = 'bytes';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'αναβάθμιση';
$langA['editing'] = 'Τροποίηση';
$langA['workgroup'] = 'Ομάδα εργασίας';
$langA['BROWSE_HIDDEN'] = 'Αναζήτηση κρυμένων αρχείων';

$langA['delete'] = 'Διαγραφή';
$langA['confirm_delete'] = 'Επιβεβαίωση Διαγραφής';
$langA['continue'] = 'Συνέχεια';
$langA['back'] = 'Πίσω';
$langA['close'] = 'Close';
$langA['view'] = 'Προβολή';
$langA['empty'] = '-Άδειο-';
$langA['none'] = 'Κανένα';
$langA['total'] = 'Σύνολο ';
$langA['files'] = 'Αρχεία';
$langA['other'] = 'Διάφορα';
$langA['trash'] = 'Σκουπίδια';
$langA['flagged'] = 'Flagged';

$langA['today'] = 'Σήμερα';
$langA['yesterday'] = 'Χθές';
$langA['days_ago'] = ' Μέρες Πρίν';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'More';
$langA['download'] = 'Λήψη αρχείων';


//Date
$langA['date_l'][0] = 'Κυριακή';
$langA['date_l'][1] = 'Δευτέρα';
$langA['date_l'][2] = 'Τρίτη';
$langA['date_l'][3] = 'Τετάρτη';
$langA['date_l'][4] = 'Πέμπτη';
$langA['date_l'][5] = 'Παρασκευή';
$langA['date_l'][6] = 'Σαββάτο';

$langA['date_D'][0] = 'Sun';
$langA['date_D'][1] = 'Mon';
$langA['date_D'][2] = 'Tue';
$langA['date_D'][3] = 'Wed';
$langA['date_D'][4] = 'Thu';
$langA['date_D'][5] = 'Fri';
$langA['date_D'][6] = 'Sat';


$langA['date_F'][1] = 'Ιανουαρίου';
$langA['date_F'][2] = 'Φεβρουαρίου';
$langA['date_F'][3] = 'Μαρτίου';
$langA['date_F'][4] = 'Απριλίου';
$langA['date_F'][5] = 'Μαΐου';
$langA['date_F'][6] = 'Ιουνίου';
$langA['date_F'][7] = 'Ιουλίου';
$langA['date_F'][8] = 'Αυγούστου';
$langA['date_F'][9] = 'Σεπτεμβρίου';
$langA['date_F'][10] = 'Οκτωβρίου';
$langA['date_F'][11] = 'Νοεμβρίου';
$langA['date_F'][12] = 'Δεκεμβρίου';

$langA['date_M'][1] = 'Ιαν';
$langA['date_M'][2] = 'Φεβρ';
$langA['date_M'][3] = 'Μαρτ';
$langA['date_M'][4] = 'Απρ';
$langA['date_M'][5] = 'Μαΐου';
$langA['date_M'][6] = 'Ιουν';
$langA['date_M'][7] = 'Ιουλ';
$langA['date_M'][8] = 'Αυγ';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'Οκτ';
$langA['date_M'][11] = 'Νοε';
$langA['date_M'][12] = 'Δεκ';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabic (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'German (de)';
$langA['lang']['el'] = 'Ελληνικά (el)';
$langA['lang']['en'] = 'English (en)';
$langA['lang']['es'] = 'Spanish (es)';
$langA['lang']['fr'] = 'French (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italian (it)';
$langA['lang']['ja'] = 'Japanese (ja)';
$langA['lang']['ko'] = 'Korean (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Dutch (nl)';
$langA['lang']['pl'] = 'Polish (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Russian (ru)';
$langA['lang']['tr'] = 'Τουρκικά (tr)';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'Chinese (zh)';
$langA['lang']['zh-cn'] = 'Chinese Simplified (zh-cn)';



