 <?php

$langA['CHANGE_PASS_INTRO'] = 'To change your password, we first need to send you a "Permission Key" so that you may access this restricted feature. Once you have received the key, return to this page and enter the information below. Please note, your "Permission Key" will only work for your Username.';

$langA['next_step'] = 'Επόμενο';

$langA['PASS_EMAIL_SUBJECT'] = 'Permission Key for %s.';
$langA['PASS_EMAIL_TEXT'] ='Your permission key for %s is %s.';

$langA['get_your_key'] = 'Παραλαβή κλειδιού έγκρισης';
$langA['GET_YOUR_KEY'] = 'Το κλειδί θα σας αποσταλεί στην ηλεκτρονική διεύθυνση που δηλώσατε κατα την εγγραφή σας';

$langA['send_key'] = 'Αποστολή κλειδιού έγκρισης';

$langA['change_password'] = 'Αλλαγή κωδικού';
$langA['permission_key'] = 'Κλειδί έγκρισης';
$langA['new_password'] = 'Νέος κωδικός';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = 'Αποτυχία αλλαγής Κώδικού: Λάθος κλειδί έγκρισης ή Λάθος όνομα χρήστη.';
$langA['PASSWORD_CHANGED'] = 'Password updated successfully for <tt>%s</tt>.';
$langA['PROVIDE_PASSWORD'] = 'Πρέπει να δώσετε καινούργιο κωδικό';
$langA['PROVIDE_PERMISSION_KEY'] = 'Πρέπει να δώσετε το Εγκριτικό κλειδί για να αλλάξετε τον κωδικό σας';
$langA['PERMISSION_KEY_SENT'] = 'Το Εγκριτικό κλειδί στάλθεικε επιτυχώς. Πάρτε το κλειδί απο το email σας και χρησιμοποιήστε το για την αλλαγή του κωδικού';
$langA['PERMISSION_KEY_NOT_SENT'] = 'Failed to send Permission Key to the provided email address, please contact the website administrator for additional help.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = 'An email address was not provided for this account. Please contact the website administrator for additional help.';

