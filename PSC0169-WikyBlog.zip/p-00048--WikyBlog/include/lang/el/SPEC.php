<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Δικαιώματα';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'This special page has not been defined yet: <tt>%s</tt>';

//	control panel
$langA['general'] = 'Γενικά';
$langA['attachments'] = 'Attachments';
$langA['account_info'] = 'Account Info';
$langA['error_log'] = 'Καταγραφή σφάλματος';
$langA['advanced_search'] = 'Advanced&nbsp;Search';
$langA['configuration'] = 'Ρυθμίσεις';
$langA['search_options'] = 'Επιλογές έρευνας';
$langA['data_types'] = 'Τυποι δεδομένων';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Tabs';
$langA['account_display'] = 'Προβολή Λογαριασμού';
$langA['links'] = 'Σύνδεσμοι εικόνων';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = 'Στατιστικά στοιχεία χρηστών';
$langA['database_info'] = 'Database&nbsp;Information';
$langA['user_preferences'] = 'Επιλογές χρήστη';
$langA['content_license'] = 'Content&nbsp;License';
$langA['user_permissions'] = 'User Permissions';
$langA['default_page_options'] = 'Default&nbsp;Page&nbsp;Options';
$langA['account_details'] = 'Account&nbsp;Details';
$langA['manage_images'] = 'Manage&nbsp;Images';
$langA['manage_files'] = 'Manage&nbsp;Files';
$langA['upload_files'] = 'Upload Files';
$langA['public_templates'] = 'Public&nbsp;Templates';
$langA['feeds'] = 'Syndication / Feeds';
$langA['recently_modified'] = 'Recently Modified';
$langA['recently_posted'] = 'Recently Posted';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = 'Αυτό είναι το  κέντρο ελέγχου για το <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Would you like to see your %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'The Package Templates directory is unavailable.';
$langA['themes']['default'] = 'Προκαθορισμένο';
$langA['themes']['simple'] = 'Simple';
$langA['themes']['three_columns'] = 'Three Columns';
$langA['themes']['floating'] = 'Floating';
$langA['themes']['graphic'] = 'Graphic';

$langA['colors']['colors'] = 'Colors';
$langA['colors']['black'] = 'Black';
$langA['colors']['blue'] = 'Blue';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Green';
$langA['colors']['light_blue'] = 'Light Blue';
$langA['colors']['green'] = 'Green';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Red';
$langA['colors']['orange'] = 'Orange';
$langA['colors']['gray'] = 'Gray';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = 'Browse Hidden';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = 'Δικαιώματα αναβάθμισης';
$langA['username_or_ip'] = 'κωδικός χρήστη ή IP';
$langA['status'] = 'Κατάσταση';
$langA['workgroup'] = 'Ομάδα εργασίας';
$langA['admin'] = 'Διαχειρηστής';
$langA['full_owner'] = 'Full / Owner';
$langA['ban'] = 'Αποβολή';
$langA['banned'] = 'Αποβεβλημένος';

//	friends.php
$langA['friends'] = 'Friends';
$langA['my_status'] = 'My Status';


$langA['EX_USERNAMES'] = 'ex: <a>BillyJoe</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'You have not specefied any permissions.';
$langA['view_users'] = 'View This User\'s...';
$langA['change'] = 'Αλλαγή';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = 'User <tt>%s</tt> was removed from this workgroup.';
$langA['USER_NOT_REMOVED'] = 'User <tt>%s</tt> was not successfully removed from this workgroup. ';
$langA['ADDED_PERMISSIONS'] = 'Added permissions for <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Updated permissions for <tt>%s</tt>.';
$langA['NOT_A_USER'] = 'Username <tt>%s</tt> was not found.';
$langA['IP_NOT_ADDED'] = 'Could not add/update permissions for <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>Warning:</b> User <tt>%s</tt> is already the owner of this account.';
$langA['IP_WRONG_LEVEL'] = '<b>Warning:</b> IP addresses cannot be given privileges higher than "workgroup".';
$langA['SET_PERMISSIONS'] = 'To set permissions for "%s", select the desired status then click "Update Permissions".';


//	specLostPass
$langA['lost_password'] = 'Χαμένος Κωδικός';



//	specFileManager
$langA['file_manager'] = 'Διαχειριστής Αρχείου';
$langA['image_manager'] = 'Διαχειριστής Εικόνων';
$langA['CONFIRM_FILE_DELETE'] = 'Σίγουρα θέλεις να διαγράψεις το/τα<b>%s</b>;';
$langA['IMAGE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these images in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['FILE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these files in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['file_name'] = 'Όνομα Αρχείου';
$langA['available_space'] = 'Ελέυθερος Χώρος';
$langA['UPLOAD_INTRO'] = 'Upload file attachments and images for inclusion in your pages.';
$langA['file_upload'] = 'Ανέβασμα Αρχείου';
$langA['file_info'] = 'Πληροφορίες Αρχείου';
$langA['width'] = 'Πλάτος';
$langA['height'] = 'Ύψος';
$langA['file_location'] = 'Τοποθεσία Αρχείου';
$langA['wiki_syntax'] = 'Σύνταξη Wiki';
$langA['html_syntax'] = 'Σύνταξη HTML';
$langA['append_to'] = 'append to';
$langA['count'] = 'Count';
$langA['total_size'] = 'Συνολικό Μέγεθος';
$langA['images'] = 'Εικόνες';
$langA['overwrite_existing'] = 'Overwrite Existing';
$langA['compression'] = 'Compression';

$langA['NOT_AN_IMAGE'] = 'The file does not appear to be an image. Please check the file then try again. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'Could not delete the file <tt>%s</i>.';
$langA['UPLOADED'] = 'File <tt>%s</tt> uploaded successfully.';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = 'Το αρχείο μετονομάστηκε επιτυχώς';
$langA['UPLOAD_FAILED'] = 'Failed to copy file: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Επιλέψτε Τύπο Αρχείου';
$langA['default_options'] = 'Προκαθορισμένες Επιλογές';
$langA['UNKNOWN_FILE_TYPE'] = 'Unknown Page Type: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Λογαριασμός';
$langA['entries'] = 'Εισαγωγές';
$langA['average'] = 'Μέσος';
$langA['uploaded_files'] = 'Ανεβασμένα Αρχεία';


//	searchTrash
$langA['deleted'] = 'Διαγραφή';
$langA['restore'] = 'Επαναφορά';
$langA['empty_trash'] = 'Empty Trash';
$langA['CONFIRM_EMPTY_TRASH'] = 'Are you sure you want to empty your trash?';

$langA['DELETED_AFTER_30'] = 'Τα Αρχεία θα διαγραφούν Αυτόματα μετά απο 30 ημέρες';
$langA['check_uncheck'] = 'Επιλογή όλων / Αποεπιλογη όλων';
$langA['DELETED_FILES'] = 'Τα επιλεγμένα αρχεία διαγραφηκαν επιτυχώς';
$langA['NOTHING_DELETED'] = 'Τίποτα δεν διαγράφηκε';
$langA['DELETE_FILES'] = 'Παρακαλω επιλέξατε αρχεία προς διαγραφή';
$langA['MAP_INVALID_PT'] = 'Λανθασμένα δεδομένα χάρτη: Λανθασμένη διαμόρφωση σημείου';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'The search feature for this site does not appear to be enabled. Site administrators can enable this feature via Search Options in the Control Panel.';
$langA['search:'] = 'Αναζήτηση ';
$langA['search_for'] = 'Αναζήτηση για: ';
$langA['registered'] = 'Εγγεγραμένος';
$langA['restricted'] = 'Απαγορευμένη';
$langA['locked'] = 'Κλειδωμένο';
$langA['disabled'] = 'Απενεργοποίηση';
$langA['editing_option'] = 'Επιλογή τροποποίησης';
$langA['comments_option'] = 'Επιλογές Σχολιασμών';
$langA['visibility_option'] = 'Visibility Option';
$langA['normal'] = 'Κανονικό';
$langA['advanced'] = 'Για προχωρημένους';
$langA['relevance'] = 'Σχετικό';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'Για όλες τις λέξεις';
$langA['SEARCH_EXACT'] = 'Για την ακριβής φράση';
$langA['SEARCH_WITHOUT'] = 'Without the words';
$langA['SEARCH_BEGIN'] = 'For words beginning with';


//	searchKeywords
$langA['keyword_search'] = 'Αναζήτηση Λέξεων-κλειδίων';
$langA['non_tagged_files'] = 'Non-Tagged Files';

//	searchChangeLog
$langA['new'] = 								'Νέο';
$langA['DIFF_TITLE'] = 							'Compare differences with most recent revision';
$langA['indicates_syntax_error'] = 				'Indicates a syntax error.';
$langA['indicates_unchecked'] = 				'Indicates an unchecked file.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Επιλογη Άδειας';
$langA['SELECT_LICENSE_DESC'] = 'Opens a Creative Commons webpage in a popup window.';
$langA['DELETE_LICENSE_DESC'] = 'This will remove your current content license.';
$langA['LICENSE_UPDATED'] = 'Your content license has been updated successfully.';
$langA['LICENSE_DELETED'] = 'License was deleted';
$langA['LICENSE_DELETED2'] = 'License has already been deleted.';
$langA['customize_license'] = 'Τροποποιείστε την άδεια σας';

$langA['text_before'] = 'Text Before Link';
$langA['text_after'] = 'Text After Link';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Except where expressly noted, this work is licensed under a ';
$langA['LICENSE_TEXT_LINK'] = 'Creative Commons Άδεια ';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganize';
$langA['from'] = 'Αποστολέας';
$langA['to'] = 'Προς';
$langA['KEYWORDS_UPDATED'] = 'Your keywords have been updated.';
$langA['KEYWORDS_EMPTY'] = 'You have not created any files with keywords yet.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = 'Περιγραφή';
$langA['add_link'] = 'Add Link';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Group';
$langA['name'] = 'Όνομα';
$langA['add_group'] = 'Προσθήκη ομάδας';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Limit';
$langA['random'] = 'Random';
$langA['order'] = 'Order';
$langA['LEAVE_EMPTY'] = 'Leave empty for no limit';
$langA['unlimited'] = 'Unlimited';
$langA['type'] = 'Type';
$langA['auto_detect'] = 'Auto Detect';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'Move Up';
$langA['move_down'] = 'Move Down';
$langA['redirect'] = 'Ανακατεύθυνση';
$langA['content_template'] = 'Content Template';

