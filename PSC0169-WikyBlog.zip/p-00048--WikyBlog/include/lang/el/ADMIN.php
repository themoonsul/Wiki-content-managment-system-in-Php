<?php

	$langA['googleMapKeys'] =						'Google Maps API Key';


	$langA['ADMIN_ONLY'] =							'Πρέπει να είστε ο διαχειριστής αυτού του συστήματος για να προσπελάσεται αυτή τη σελίδα.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Αυτή η σελίδα διαχείρισης του συστήματος δέν έχει δημιουργηθεί ακόμα.';
	
	$langA['CONFIRM_PASSWORD'] =						'Παρακαλούμε επιβεβαιώστε τον κωδικό πρόσβασης σας προτού συνεχίσεται.';
	$langA['confirm_password'] =						'Επιβεβαιώστε τον κωδικό πρόσβασης σας';
	$langA['confirmation_failed'] =					'Η επιβεβαιώστε του κωδικού πρόσβασης σας απέτυχε. Παρακαλούμε δοκιμάστε ξανά.';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Επιλογές έρευνας';
	$langA['search_status'] =						'Κατάσταση έρευνας';
	$langA['search_enabled'] =						'Έρευνα ενεργοποιημένη';
	$langA['SEARCH_ENABLED'] =						'Απενεργοποιώντας την δυνατότητα έρευνας θα αδειάσει το `all_search` table στη βάση δεδομένων. Αργότερα, εάν αποφασίσεται να ενεργοποιήσεται την δυνατότητα έρευνας το `all_search` table θα πρέπει να επαναγραφτεί.';
	$langA['disable'] =								'Επενεργοποίηση';
	
	$langA['search_disabled'] =						'Έρευνα απενεργοποιημένη';
	$langA['SEARCH_DISABLED'] =						'Η δυνατότητα ερεύνας είναι απενεργοποιημένη. Ενεργοποιώντας την δυνατότητα έρευνας θα γεμίσει το all_search` table στη βάση δεδομένων με αναφορές απο όλα τα αρχεία στην βάση δεδομένων. Αυτή η διαδικασία μπορεί να πάρει αρκετό χρόνο ειδικά για μεγάλες βάσε';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'Ενεργοποίηση';
	
	$langA['FINISHED_ENTRIES'] =						'%s καταχωρήσεις έτοιμες, %s ακόμα καταχωρήσεις να ετοιμαστούν.';
	$langA['SEARCH_IS_ENABLED'] =					'Η δυνατότητα έρευνας ενεργοποιήθηκε';


//
// adminConfig.php
//
	$langA['configuration'] =						'Ρυθμίσεις';
	$langA['confighistory'] =						'Ιστορία ρυθμίσεων';
	$langA['CONFIG_SAVING'] =						'Καινούργιες ρυθμίσεις σώζονται χωρίς να διαγράφουν τις ισχύουσες τιμές, έτσι μπορείτε να ανακαλέσεται τις αλλαγές ρυθμίσεων εάν χρειαστεί...';
	$langA['CONFIG_STAT'] =							'Εχουν γίνει %s αλλαγές στις ρυθμίσεις';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Εαν είστε σίγουρος οτι θέλεται να ανακαλέσεται τον αύξοντα αριθμό εγγραφής πατήστε <tt>Save</tt> για να συνεχίσεται.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Κάτι που μπορεί να χρησιμοποιηθεί σε μια πρόταση όπως¨"Καλωσήρθατε στο Ονομα_Συστήματος".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'Μέγιστο μέγεθος αρχείου που μπορεί να ανεβαστεί.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Μέγιστο μέγεθος αρχείου ιστορίας λαθών. 10,000 bytes εξορισμού.';
	$langA['errorEmail']['desc'] = 					'Παρακαλούμε δώστε την διεύθυνση του ηλεκτρονικού σας ταχυδρομίου. ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Γενικές ρυθμίσεις';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'Αναγνώσιμο όνομα server';
	$langA['serverName2']['alias'] = 				'Όνομα server';
	$langA['serverName3']['alias'] = 				'Πλήρες Server URL';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Μέγιστο ανέβασμα';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Γλώσσα';
	$langA['reservedWords']['alias'] = 				'Ειδικές λέξεις';
	
	$langA['developer_aids'] = 						'Βοηθήματα για προγραμματιστές';
	$langA['maxErrorFileSize']['alias'] = 			'Μέγεθος αρχείου λαθών';
	$langA['errorEmail']['alias'] = 					'Διεύθυνση ηλεκτρονικού ταχυδρομείου για λάθη';
	$langA['include']['alias'] = 					'Συμπεριλάμβανε PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Εξορισμού ρυθμίσεις χρηστών';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Τίτλος αρχικής σελίδας';
	$langA['defaultUser:homeTitle']['desc'] =		'Χρησιμοποιείται ώς ο τίτλος της αρχικής σελίδας.';
	
	$langA['defaultUser:template']['alias'] =		'Προφόρμα χρηστών';
	$langA['defaultUser:template']['desc'] =		'Main/Home is the default wikyblog template.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Ύψος περιοχής εισαγωγής κειμένου';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Αρχική σελίδα για το blog';
	$langA['defaultUser:isBlog']['desc'] =			'Ελέγχει την εμφάνιση της σελίδας ως στύλ blog ή όχι.';
	
	$langA['defaultUser:timezone']['alias'] =		'Ζώνη ώρας (Timezone)';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Μέγιστος αριθμός σειρών ιστορίας';
	$langA['defaultUser:maxHistory']['desc'] =		'Εξορισμού μέγιστος αριθμός γραμμών ιστορίας.';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Προσθήκη ομάδας';
	$langA['unlimited'] = 'Unlimited';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Χρήση Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Στατιστικά στοιχεία χρηστών';
	$langA['user_stats'] =							'Στατιστική χρηστών';
	$langA['user_account'] =							'Λογαριασμός χρήσης';
	$langA['entries'] =								'Εισαγωγές';
	$langA['history Rows'] =							'Γραμμές ιστορίας';
	$langA['last_visit'] = 							'Τελευταία επίσκεψη';
	
	$langA['users_found'] =							'Χρήστες που βρέθηκαν';
	$langA['showing_of_found'] =						'Δείχνονται %s απο %s';
	$langA['cpanel'] =								'Σύστημα διαχείρησης (CPanel)';
	$langA['details'] =								'Λεπτομέρειες';
	
	$langA['within_the_hour'] =						' < απο μια ώρα';
	$langA['hours'] =								'ώρες';
	$langA['days'] =									'ημέρες';
	$langA['months'] =								'μήνες';
	$langA['years'] = 								'χρόνια';
	$langA['ago'] = 									'εδώ και';
	
	$langA['TIMEOUT'] = 								'<b>Λάθος διακοπής επικοινωνίας:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'Σίγουρα θέλεις να διαγράψεις το/τα<b>%s</b>;';
	$langA['CONFIRM_DELETE_USER2'] = 				'Η διαδικασία διαγραφής θα <i>σβήσει τελείως</i> όλα τα αρχεία απο αυτό τον λογαριασμό συμπεριλαμβανομένων και τον ακόλουθων:';
	$langA['userfiles_directory'] = 					'Directory αρχείων χρηστών: ';
	$langA['template_directory'] = 					'Directory αρχείων template: ';
	$langA['database_entries'] = 					'Και όλες τις εισαγωγές απο την βάση δεδομένων: σελίδες, ιστορία σελίδων, σχόλια κτλ.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Εισαγωγές που έχουν διαγραφεί απο την βάση δεδομένων.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Προσοχή:</b> Δεν μπόρεσα να σβήσω τις εισαγωγές απο την βάση δεδομένων.';
	
	$langA['DELETED_USERFILES'] = 					'Διεγραμένος κατάλογος αρχείων χρηστών.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Προσοχή:</b> Δεν μπόρεσα να σβήσω τον κατάλογο αρχείων χρηστών.';
	
	$langA['DELETED_TEMPLATES'] = 					'Διεγραμένος κατάλογος αρχείων templates.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Προσοχή:</b> Δεν μπόρεσα να σβήσω τον κατάλογο templates.';
	
	$langA['USER_DELETED'] = 						'%s διεγράφησαν εντελώς: ';
	$langA['USER_NOT_DELETED'] = 					'%s ΔΕΝ διεγράφησαν εντελώς: ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activate';
	$langA['lost_page'] = 							'Αρχείο εγγραφών';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'Απενεργοποίηση';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Δεν μπορεσα να διαγράψω το αρχείο λαθών.';
	$langA['ERROR_LOG_DELETED'] = 					'Το αρχείο λαθών διεγράφη.';
	$langA['ERROR_LOG_MAXED'] = 						'Το αρχείο λαθών έχει γεμίσει. Αδειάστε το ώστε το πρόγραμμα μπορεί να συνεχίσει να γράφει στο αρχείο λαθών. %s';


	$langA['select'] = 								'Επιλέξτε';
	$langA['description'] = 						'Περιγραφή';


//	adminPlugins
	$langA['data_types'] = 							'Τυποι δεδομένων'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Υπάρχοντες τύποι';
	$langA['available_plugins'] = 					'Διαθέσιμες επεκτάσεις';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Επιλογή όλων / Αποεπιλογη όλων';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Online';
	$langA['wbConfig']['online']['desc'] = 			'Είναι αυτή η εγκατάσταση συνδεδεμένη στο Ιντερνετ;';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Διάρχεια υπερχείλησης';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Τα δευτερόλεπτα που πρέπει να περιμένει μεταξεί αλλαγών ένας χρήστης χωρίς προνόμια στο σύστημα.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'Διόρθωση HTML (HTML Tidy)';
	$langA['wbConfig']['tidy']['desc'] =				'Χρησιμοποιήση του HTML Tidy για την διόρθωση τυχόν λαθών στην εισαγωγή δεδομένων απο τον χρήστη.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Πλήρες δυνατοτήτων.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Επέτρεψε σε όλους τους εγγεγραμμένους χρήστες να έχουν το δικό τους blog.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

