<?php

	$langA['googleMapKeys'] =						'Google Maps API Key';


	$langA['ADMIN_ONLY'] =							'Csak adminisztrátorok számára elérhető oldal.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Ez az admin lap még nincs definiálva: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Adja meg újra jelszavát.';
	$langA['confirm_password'] =						'Jelszó megerősítése';
	$langA['confirmation_failed'] =					'A jelszó megerősítése nem sikerült. Próbálja újra.';
	
	$langA['run_scheduled_tasks'] =					'Ütemezett feladatok indítása';
	$langA['FAILED'] = 								'A kívánt folyamat megszakadt. Kérjük próbálja újra.';
	$langA['SUCCESS'] = 								'A kívánt folyamat sikeresen befejeződött.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Keresési beállítások';
	$langA['search_status'] =						'Keresés állapot';
	$langA['search_enabled'] =						'Keresés engedélyezve';
	$langA['SEARCH_ENABLED'] =						'Disabling the search feature will empty the `all_search` database table. Later, if you would like to enable search again, the `all_search` table will have to be re-populated.';
	$langA['disable'] =								'Letiltás';
	
	$langA['search_disabled'] =						'Keresés letiltva';
	$langA['SEARCH_DISABLED'] =						'A keresés nem lehetséges. A kereséshez szükséges egy olyan folyamat, amely az \'all_search\' adatbázist feltölti az összes adatbázisbeli adattal. Ez az adatbázis hosszáttól függően hosszabb időt is igénybe vehet. ';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'Engedélyezés';
	
	$langA['FINISHED_ENTRIES'] =						'%s bejegyzés kész, %s van hátra.';
	$langA['SEARCH_IS_ENABLED'] =					'A keresés tulajdonság engedélyezve.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Beállítások';
	$langA['confighistory'] =						'Beállítások történet';
	$langA['CONFIG_SAVING'] =						'Az új beálításokat elmentettük, anélkül, hogy a meglévő adatokat fölülírtuk volna. Így szükség esetén a beállítások visszacsinálhatók. ';
	$langA['CONFIG_STAT'] =							'%s darab módosítást végeztünk a programban.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Biztosan vissza szeretne térni a %s. módosításhoz?  A folytatáshoz klikk a <tt>Mentés</tt> gombra.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Something that can be used with a sentence like: "Welcome to serverName1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'Maximum mérete egy feltöltött fájlnak';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Maximum file size to be allowed for the Error Log. Defaults to 10,000 bytes.';
	$langA['errorEmail']['desc'] = 					'e-mail cím megadása ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Álatlános Beállítások';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'Csinos szerver név';
	$langA['serverName2']['alias'] = 				'szerver név';
	$langA['serverName3']['alias'] = 				'Full Server Url';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Maximum feltöltés';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Language';
	$langA['reservedWords']['alias'] = 				'Reserved Words';
	
	$langA['developer_aids'] = 						'Developer Aids';
	$langA['maxErrorFileSize']['alias'] = 			'Error Log Size';
	$langA['errorEmail']['alias'] = 					'Error Email';
	$langA['include']['alias'] = 					'Include PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Általános Felhasználói Beállítások';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Home Title';
	$langA['defaultUser:homeTitle']['desc'] =		'Ez lesz a kezdőlap címe.';
	
	$langA['defaultUser:template']['alias'] =		'User Template';
	$langA['defaultUser:template']['desc'] =		'Main/Home is the default wikyblog template.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Textarea Height';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Blog főoldal';
	$langA['defaultUser:isBlog']['desc'] =			'Blogszerű honlap ki- és bekapcsolása.';
	
	$langA['defaultUser:timezone']['alias'] =		'Időzóna';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Max History Rows';
	$langA['defaultUser:maxHistory']['desc'] =		'Default maximum for history rows.';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Add Group';
	$langA['unlimited'] = 'határtalan';
	$langA['group'] = 'csoport';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'User statisztika';
	$langA['user_stats'] =							'User Stats';
	$langA['user_account'] =							'Felhasználói fiók';
	$langA['entries'] =								'Entries';
	$langA['history Rows'] =							'History Rows';
	$langA['last_visit'] = 							'Last Visit';
	
	$langA['users_found'] =							'Users Found';
	$langA['showing_of_found'] =						'Showing %s through %s';
	$langA['cpanel'] =								'CPanel';
	$langA['details'] =								'Részletek';
	
	$langA['within_the_hour'] =						' < 1 órával ezelött';
	$langA['hours'] =								'óra';
	$langA['days'] =									'nap';
	$langA['months'] =								'hónap';
	$langA['years'] = 								'év';
	$langA['ago'] = 									'ezelött';
	
	$langA['TIMEOUT'] = 								'<b>Timeout error:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'Biztos benne hogy törli <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Deleting will <i>completely erase</i> all files for the account including:';
	$langA['userfiles_directory'] = 					'Userfiles directory: ';
	$langA['template_directory'] = 					'Template directory: ';
	$langA['database_entries'] = 					'And all database entries: pages, pagehistory, comments etc.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Deleted database entries.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Warning:</b> Could not delete the database entries.';
	
	$langA['DELETED_USERFILES'] = 					'Deleted Userfiles Directory.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Warning:</b> Could not delete the Userfiles Directory.';
	
	$langA['DELETED_TEMPLATES'] = 					'Deleted Tempalate Directory.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Warning:</b> Could not delete the Template Directory.';
	
	$langA['USER_DELETED'] = 						'%s was completely deleted: ';
	$langA['USER_NOT_DELETED'] = 					'%s was NOT completely deleted: ';
	$langA['DELETE_ACCOUNT'] = 						'Törölje teljesen ezt a felhasználót. ';
	$langA['DISABLE_ACCOUNT'] = 					'A fálj módosításának tiltása.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'frissítve';
	$langA['suspend'] = 							'kiterjesztés';
	$langA['activate'] = 							'aktiválva';
	$langA['lost_page'] = 							'Elveszett lap';
	$langA['suspended'] =							'kiterjesztve';
	$langA['disabled'] =							'Tiltás';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Could not delete the error log.';
	$langA['ERROR_LOG_DELETED'] = 					'The Error Log was deleted.';
	$langA['ERROR_LOG_MAXED'] = 						'The Error Log file has reached is maximum size, please empty the file so the script can continue to log errors. %s';


	$langA['select'] = 								'Választ';
	$langA['description'] = 						'Description';


//	adminPlugins
	$langA['data_types'] = 							'Adattípusok'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Létező típusok';
	$langA['available_plugins'] = 					'Elérhető pluginok';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Check All / Uncheck All';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Bejelentkezve';
	$langA['wbConfig']['online']['desc'] = 			'Ez egy megvalósitott kapcsolódás az internethez?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Flood Interval';
	$langA['wbConfig']['floodInterval']['desc'] = 	'The number of seconds a user without permissions will have to wait between edits.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Use HTML Tidy to correct possible user input errors.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Full Featured.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Engedi az összes regisztrált felhasználónak hogy saját blogjuk legyen.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Default User.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

