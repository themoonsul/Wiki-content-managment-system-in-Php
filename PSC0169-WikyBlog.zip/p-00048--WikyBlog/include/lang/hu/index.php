<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Fájl';
$langA['edit'] = 'Szerkesztés';
$langA['edits'] = 'beállítások';
$langA['view_source'] = 'Forrás megtekintése';
$langA['talk'] = 'Beszélgetés';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Történet';
$langA['diff'] = 'Eltérés';
$langA['watch'] = 'Watch';
$langA['unwatch'] = 'Unwatch';
$langA['options'] = 'beállítások';


$langA['messages'] = 'Üzenetek';
$langA['current'] = 'Aktuális';
$langA['blog'] = 'Blog';
$langA['possible'] = 'lehetséges';

$langA['DEFAULT_CONTENT'] = 'Ez egy új fájl. Szeretné  [[%s?cmd=edit|létrehozni]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'This is a new file. To create this file, you need to be logged in with appropriate privileges.';

$langA['NOT_OWNER'] = 'You do not have the appropriate privileges for this feature.';
$langA['LONG_PATH'] = 'The title for this file was too long and has been truncated.';
$langA['EMPTY_CONTENT'] = 'Content is a required field';
$langA['INCOMPLETE_PATH'] = 'The supplied path is incomplete.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Sorry, the website administrator has disabled user blogging. To create a bliki with the same features found here, visit <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'A fájl hozzáférését a tulajdonosa megtiltotta. A megtekintéséhez megfelelő engedélyre van szükség';
$langA['HIDDEN_FILE2'] = 'This file is "hidden". ';
$langA['DELETED_FILE'] = 'This file is currently in the "trash". If you are the owner of this account, you can restore this file via your control panel.';
$langA['PROTECTED_FILE'] = 'Ez a fájl védett. Semmilyen változtatás nem lesz mentve a fájlon.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Link Text';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Visszautasítva a %s helyről.';
$langA['REDIRECT_TO'] = 'This page redirects to %s.';

//	Data Types
$langA['all'] = 'Mind';
$langA['page'] = 'Oldal';
$langA['comment'] = 'Komment';
$langA['map'] = 'Térkép';
$langA['template'] = 'Template';
$langA['help'] = 'Segítség';
$langA['skeleton'] = 'Skeleton';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Kommentek';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'oldalak';
$langA['CLASScomment'] = 'Kommentek';
$langA['CLASSmap'] = 'Térképek';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'Segítség';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' secs';
$langA['queries'] = ' queries';

$langA['QUERY_TIME'] = ' for queries';
$langA['INVALID_PATH'] = 'Invalid file path supplied: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Érvénytelen kérés.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = 'Create a new help file';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Böngészés';
$langA['change_log'] = 'Change Log';
$langA['control_panel'] = 'Beállítási panel';
$langA['administration'] = 'Administration';
$langA['preferences'] = 'Beállítások';
$langA['watchlist'] = 'figyelőlista';
$langA['wanted_files'] = 'Wanted Files';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'Keresés';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'External Links';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'More Recent Posts.';
$langA['NEED_INTERNET'] = 'Ez a funkció csak internet kapcsolattal rendelkező rendszerrel működik.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Warning:</b> Cookies are required to continue. Refresh this page if you have cookies enabled.';
$langA['LOGIN_REQUIRED'] = 'Be kell jelentkeznie hogy használhassa ezt a funkciót.';

$langA['ENTER_USERNAME'] = 'Kérem adja meg a felhasználónevét.';
$langA['ENTER_PASSWORD'] = 'Kérem írja be a jelszavát.';
$langA['LOGGED_OUT'] = 'Sikeresen belépett.';
$langA['AUTO_LOGOUT'] = 'Your session has expired.';

$langA['LOGIN_FAILED'] = 'Log in failed: Incorrect Password.<ul><li>Is Caps Lock on?<li> Have you %sforgotten your password%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'The maximum number of %s login attempts has been exceeded. You will not be allowed to login for the next %s minutes.';
						
$langA['create_new'] = 'Create&nbsp;New ';
$langA['remember_me'] = 'Jelszó megjegyzése a használatok között.';
$langA['log_out'] = 'Kilépés';
$langA['log_in'] = 'Belépés';

//	SAVING 
$langA['syntax_error'] = 'formai hiba';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Syntax Error:</b> Unable to Save/Display the most recent changes to this file due to an incompatible syntax.';
$langA['SYNTAX_FIXED'] = 'A syntax hiba kijavítva.';


$langA['NO_CHANGES'] = 'Ez a fájl nem lett módosítva (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Ezt a fájlt nem lehetett menteni. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'E fájl változásait mentettük.';
$langA['HIDDEN_FILE3'] = '<b>Note:</b> This is a hidden file, therefore tags for this file will not be included in the user menu totals.';

$langA['VERSION_CONFLICT'] = 'Warning: We could not save your changes because we detected a version conflict.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Másol &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/> Klikkelj a "Mentés"re, hogy befejezzük a mentést.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Editing has been limited to one file every %s seconds. Please try again in %s seconds.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Beállítások mentése';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = 'különbség(ek)';
$langA['line_num'] = 'Line #';


//	toolHistory1.php
$langA['revision'] = 'Revision ';
$langA['revision_as_of'] = 'Revision as of ';
$langA['revision_num_as_of'] = 'Revision %s as of %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Edit Revision';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Reverted to revision #';
$langA['SET_USER_PERMISSIONS'] = 'Set your permissions for this user: '; 
$langA['compare_with_prev'] = '← Compare with Previous Revision';
$langA['current_revision'] = 'Aktuális változat';
$langA['compare_with_next'] = 'Compare with Next Revision →';
$langA['lines'] = 'Lines';
$langA['text'] = 'szöveg';
$langA['vs'] = ' vs ';
$langA['content'] = 'Content';
$langA['your_text'] = 'A te szöveged';
$langA['show_prev_revision'] = '← Revision %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revision %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Warning:</b> You are not editing the most recent version of this page.<br /> Saving will replace the newest version with this out-of-date version.';
$langA['SELECT_TWO_VERSIONS'] = 'Please select two distinct versions to compare.';
$langA['NO_UNIQUE_REVISION'] = 'Could not find a unique revision for this request.';
$langA['INVALID_REVISION'] = '<b>Error:</b> Invalid Revision Number.';
$langA['NO_DIFFERENCES'] = 'The two revisions being compared are identical.';
$langA['NO_REVISIONS'] = 'There must be two distinct revisions before a comparison can be made.';
$langA['NON_EXISTANT'] = 'Ez a fájl még nem létezik.';

//	toolEditPage.php
$langA['bold_text'] = 'Bold text';
$langA['italic_text'] = 'Italic text';
$langA['headline_text'] = 'Insert Heading';
$langA['title'] = 'Cím';
$langA['unordered_list'] = 'Unordered List';
$langA['ordered_list'] = 'Ordered List';


$langA['internal_link'] = 'Internal Link';
$langA['link'] = 'Hivatkozás';
$langA['external_link'] = 'External Link';
$langA['embed_image'] = 'Embed Image';
$langA['find_images'] = 'Find Images';
$langA['image'] = 'Image';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'Nem formázott szöveget szúrjon ide.';
$langA['signature'] = 'Signature';
$langA['SIGNATURE_TEXT'] = 'Insert your Signature';
$langA['preview'] = 'Előnézet';
$langA['PREVIEW_TEXT'] = 'Preview your changes [%s-p]';
$langA['PREVIEW_WARN'] = 'Ez csak egy bemutató. A változások még nem lettek elmentve!';
$langA['SAVE_TEXT'] = 'Save your changes [%s-s]';
$langA['reset'] = 'Beállítások törlése';
$langA['RESET_TEXT'] = 'Reset this form to it\'s original state [%s-c]';
$langA['changes'] = 'változtatás';
$langA['CHANGES_TEXT'] = 'Show the changes you\'ve made to this file. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organize your posts with comma separated keywords'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Tags';
$langA['edit_summary'] = 'Edit Summary';
$langA['syntax_warning'] = 'Syntax Warning';
$langA['NO_IMAGES'] = 'Kép nem tallható';
$langA['insert_emoticons'] = 'Insert Emoticons';
$langA['upload'] = 'Upload';



//searchHistory
$langA['show'] = 'mutat';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Compare';
$langA['timeline'] = 'Timeline';
$langA['summary'] = 'Összefoglaló';
$langA['COMPARE_REVISONS'] = 'Compare with the selected version.';
$langA['unchecked'] = 'nem ellenőrzött';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Invalid File Type supplied.';


//	SEARCH
$langA['next'] = 'köv';
$langA['previous'] = 'Vissza';
$langA['order_by'] = 'Order by:';
$langA['ascending'] = 'Ascending';
$langA['descending'] = 'Descending';
$langA['search_from'] = 'Search From: ';
$langA['all_users'] = 'All Users';
$langA['user'] = 'User';
$langA['from_file_type'] = 'Search From File Type: ';
$langA['read_more'] = 'Olvasson többet';
$langA['words'] = ' szavak';

$langA['RESULTS'] = 'Results %s to %s of %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'No entries found for the search criteria.';

//searchTalk
$langA['add_comment'] = 'Új téma hozzáadása';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Could not include warning. Poorly formatted data for duplicate entry.';
$langA['duplicate_entry'] = 'Duplicate Entry';
$langA['DUPLICATE_ENTRY'] = 'This is a duplicate entry for the page found at %s. <br/>Any non redundant information found here should be transfered to the original before this page is deleted.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Nem található: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Error:</b><br /> An error occurred while executing this script.<br /> Please check your request and we will attempt to debug the script with the error log. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Cannot delete the default template.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'The specified theme was invalid.';

//
//	CLASSmap
//
$langA['new_marker']='New Marker';
$langA['new_route']='New Route';
$langA['SAVE_HEADER']='Mielött mentené emlékezzen';
$langA['save_map']='Térkép mentése';
$langA['continue_editing']='Szerkesztés folytatása';
$langA['miles/km'] = 'mérföld/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>This is a new map.</b><br/> To create/edit this map, click "Edit" above.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Sorry, you don\'t have sufficient privileges to edit this map.';
$langA['play'] = 'játék';
$langA['stop'] = 'leállítás';
$langA['import'] = 'importálás';
$langA['export'] = 'exportálás';
$langA['gpx_data'] = 'GPX adat';
$langA['gpx_exchange_format'] = 'GPX Exchange Format';
$langA['CLICK_EDIT'] = 'To edit the map, click "edit" above';


//	smileys
$langA['smiles'][':D'] = 'Nagyon boldog';
$langA['smiles'][':)'] = 'mosoly';
$langA['smiles'][':('] = 'Szomorú';
$langA['smiles'][':o'] = 'Meglepett';
$langA['smiles'][':shock:'] = 'Ilyedt';
$langA['smiles'][':?'] = 'Confused';
$langA['smiles']['8)'] = 'Cool';
$langA['smiles'][':lol:'] = 'Nevető';
$langA['smiles'][':x'] = 'Mad';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Embarassed';
$langA['smiles'][':cry:'] = 'Crying or Very sad';
$langA['smiles'][':evil:'] = 'Evil or Very Mad';
$langA['smiles'][':twisted:'] = 'Twisted Evil';
$langA['smiles'][':roll:'] = 'Rolling Eyes';
$langA['smiles'][':wink:'] = 'Wink';
$langA['smiles'][':!:'] = 'Exclamation';
$langA['smiles'][':?:'] = 'Kérdés';
$langA['smiles'][':idea:'] = 'Ötlet';
$langA['smiles'][':arrow:'] = 'Arrow';
$langA['smiles'][':|'] = 'Neutral';
$langA['smiles'][':mrgreen:'] = 'Mr. Green';

//
//	General Language
//
$langA['or'] = 'vagy';
$langA['username'] = 'A felhasználói neved';
$langA['password'] = 'Jelszavad';
$langA['email'] = 'E-mail';
$langA['register'] = 'Register';
$langA['cancel'] = 'Vissza';
$langA['language'] = 'Language';
$langA['use'] = 'Use';
$langA['copy'] = 'Copy';
$langA['rename'] = 'Rename';

$langA['on'] = 'On';
$langA['partial'] = 'Partial';
$langA['off'] = 'Ki';
$langA['save'] = 'Beállítások mentése';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Undefined';
$langA['homepage'] = 'Címlap';
$langA['home'] = 'Főoldal';
$langA['go'] = 'Menj';
$langA['user_menu'] = 'felhasznállói menü';

$langA['last_modified'] = 'Last Modified';
$langA['LAST_MODIFIED'] = 'Last modified %s by %s.';//%s replaced with date and username
$langA['accessed_times'] = 'Accessed %s times';// %s replaced with a number
$langA['modified'] = 'Modified';
$langA['posted'] = 'Elküldve';
$langA['created'] = 'Created';
$langA['hidden'] = 'Hidden';
$langA['what_links_here'] = 'Mi hivatkozik erre';
$langA['share'] = 'Share';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'The file must be saved before you can perform this operation.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Size ';
$langA['bytes'] = 'bytes';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Feltöltés';
$langA['editing'] = 'Szövegdoboz méretei';
$langA['workgroup'] = 'Munkacsoport';
$langA['BROWSE_HIDDEN'] = 'Rejtett fájlok keresése';

$langA['delete'] = 'Törlés';
$langA['confirm_delete'] = 'Confirm Delete';
$langA['continue'] = 'Folytatás';
$langA['back'] = 'Vissza';
$langA['close'] = 'kilépés';
$langA['view'] = 'View';
$langA['empty'] = 'üres';
$langA['none'] = 'None';
$langA['total'] = 'Total ';
$langA['files'] = 'Fájlok';
$langA['other'] = 'Másik';
$langA['trash'] = 'Trash';
$langA['flagged'] = 'Flagged';

$langA['today'] = 'Ma';
$langA['yesterday'] = 'Tegnap';
$langA['days_ago'] = ' nappal korábban';
$langA['page_contents'] = 'tartalomjegyzék';
$langA['more'] = 'több';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'vasárnap';
$langA['date_l'][1] = 'hétfő';
$langA['date_l'][2] = 'kedd';
$langA['date_l'][3] = 'szerda';
$langA['date_l'][4] = 'csütörtök';
$langA['date_l'][5] = 'péntek';
$langA['date_l'][6] = 'szombat';

$langA['date_D'][0] = 'Sun';
$langA['date_D'][1] = 'Mon';
$langA['date_D'][2] = 'Tue';
$langA['date_D'][3] = 'Wed';
$langA['date_D'][4] = 'Thu';
$langA['date_D'][5] = 'Fri';
$langA['date_D'][6] = 'Sat';


$langA['date_F'][1] = 'január';
$langA['date_F'][2] = 'február';
$langA['date_F'][3] = 'március';
$langA['date_F'][4] = 'április';
$langA['date_F'][5] = 'Máj';
$langA['date_F'][6] = 'június';
$langA['date_F'][7] = 'július';
$langA['date_F'][8] = 'augusztus';
$langA['date_F'][9] = 'szeptember';
$langA['date_F'][10] = 'október';
$langA['date_F'][11] = 'november';
$langA['date_F'][12] = 'december';

$langA['date_M'][1] = 'Jan';
$langA['date_M'][2] = 'Feb';
$langA['date_M'][3] = 'Már';
$langA['date_M'][4] = 'Ápr';
$langA['date_M'][5] = 'Máj';
$langA['date_M'][6] = 'Jún';
$langA['date_M'][7] = 'Júl';
$langA['date_M'][8] = 'Aug';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'Okt';
$langA['date_M'][11] = 'Nov';
$langA['date_M'][12] = 'Dec';

$langA['date_a']['am'] = 'délelőtt';
$langA['date_a']['pm'] = 'délután';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'arab(ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'German (de)';
$langA['lang']['el'] = 'görög (el)';
$langA['lang']['en'] = 'angol (en)';
$langA['lang']['es'] = 'spanyol (es)';
$langA['lang']['fr'] = 'French (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'olasz(it)';
$langA['lang']['ja'] = 'Japanese (ja)';
$langA['lang']['ko'] = 'kóreai (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'holland (nl)';
$langA['lang']['pl'] = 'Polish (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Orosz(ru)';
$langA['lang']['tr'] = 'török (tr)';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'kíbai(zh)';
$langA['lang']['zh-cn'] = 'kínai-egyszerű (zh-cn)';



