<?php

//	toolOptions.php
$langA['properties'] = 'Properties';
$langA['file_name'] = 'File Name';
$langA['update_from'] = 'Update from';
$langA['COPY_SYSTEM_FILES'] = 'Copy the most recent system help files from %s.';

$langA['EDITING_OPTIONS'] = 'Control who is allowed to edit this file.';
$langA['registered_users'] = 'Regisztrált felhasználók';
$langA['restricted_to'] = 'Restricted To ';
$langA['admin_only'] = 'Csak adminisztrátor';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'csak a tulajdonosnak';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = 'Visibility';
$langA['VISIBILITY_OPTIONS'] = 'Rejtse el ezt a fájlt, ha nem kész a világnak megmutatni.';
$langA['visible'] = 'Visible';

$langA['COMMENT_OPTIONS'] = 'Ennek a fájl kommentjének tiltása.';
$langA['enabled'] = 'Engedélyezés';
$langA['disabled'] = 'Tiltás';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = 'Másik';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Remove From Blog';
$langA['repost'] = 'Repost';
$langA['copy_to'] = 'Másolás ide:';
$langA['send_to_trash'] = 'Send to Trash';
$langA['default_options'] = 'Alap beállítások';
$langA['restore_defaults'] = 'kijelöltek visszaállítása';
$langA['SET_DEFAULT_OPTIONS'] = 'Set %s for this file type.'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'This file was reposted.';
$langA['NOT_REPOSTED'] = '<b>Error:</b> Could not repost this file.';
$langA['OPTIONS_NOT_CHANGED'] = 'The file options were not changed.';
$langA['OPTIONS_UPDATED'] = 'The file options were updated successfully.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Warning:</b> File Options were not updated.';

$langA['redirect'] = 'Redirect';
$langA['REMOVE_REDIRECT'] = 'If you no longer want this file to redirect, you can either delete or edit it. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'fájl ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'User&nbsp;Permissions';
