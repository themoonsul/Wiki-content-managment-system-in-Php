<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Rechten';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'Deze speciale pagina is nog niet gedefinieerd: <tt>%s</tt>';

//	control panel
$langA['general'] = 'Algemeen';
$langA['attachments'] = 'Attachments';
$langA['account_info'] = 'Account Info';
$langA['error_log'] = 'Error Log';
$langA['advanced_search'] = 'Geavanceerd&nbsp;Zoeken';
$langA['configuration'] = 'Configuratie';
$langA['search_options'] = 'Zoek Opties';
$langA['data_types'] = 'Data Types';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Tabs';
$langA['account_display'] = 'Account Display';
$langA['links'] = 'Links';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = 'Gebruikers Statistieken';
$langA['database_info'] = 'Datavase&nbsp;Informatie';
$langA['user_preferences'] = 'Gebruikers Instellingen';
$langA['content_license'] = 'Content&nbsp;License';
$langA['user_permissions'] = 'Gebruikers Rechten';
$langA['default_page_options'] = 'Stamdaard&nbsp;Pagina&nbsp;Opties';
$langA['account_details'] = 'Account&nbsp;Details';
$langA['manage_images'] = 'Beheer&nbsp;Plaatjes';
$langA['manage_files'] = 'Beheer&nbsp;Bestanden';
$langA['upload_files'] = 'Upload Bestanden';
$langA['public_templates'] = 'Publieke&nbsp;Templates';
$langA['feeds'] = 'Syndication / Feeds';
$langA['recently_modified'] = 'Recent Aangepast';
$langA['recently_posted'] = 'Recent Gepost';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = 'Dit is het controle paneel voor <tt>%s</tt>/';
$langA['CONTROL_PANEL_2'] = 'Wil je je %s zien.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'De Pakket Templates map is niet beschikbaar.';
$langA['themes']['default'] = 'Standaard';
$langA['themes']['simple'] = 'Simpel';
$langA['themes']['three_columns'] = 'Drie kolommen';
$langA['themes']['floating'] = 'Drijvende';
$langA['themes']['graphic'] = 'Grafiek';

$langA['colors']['colors'] = 'Kleuren';
$langA['colors']['black'] = 'Zwart';
$langA['colors']['blue'] = 'Blauw';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Groen';
$langA['colors']['light_blue'] = 'Licht Blauw';
$langA['colors']['green'] = 'Groen';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Rood';
$langA['colors']['orange'] = 'Oranje';
$langA['colors']['gray'] = 'Grijs';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = 'Verken Verborgen';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = 'Update Rechten';
$langA['username_or_ip'] = 'Gebruikersnaam of IP';
$langA['status'] = 'Status';
$langA['workgroup'] = 'Werkgroep';
$langA['admin'] = 'Beheer';
$langA['full_owner'] = 'Volledig / Eigenaar';
$langA['ban'] = 'Verbod';
$langA['banned'] = 'Verboden';

//	friends.php
$langA['friends'] = 'Vrienden';
$langA['my_status'] = 'Mijn Status';


$langA['EX_USERNAMES'] = 'vb: <a>BillyJoe</a>,<a>127.0.0.1</a>,<a>255,0</a>';
$langA['EMPTY_PERMISSIONS'] = 'Je hebt geen rechten opgegeven.';
$langA['view_users'] = 'Bekijk Deze Gebruiker z\'n...';
$langA['change'] = 'Wijzig';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = 'Gebruiker <tt>%s</tt> is verwijderd uit deze werkgroep.';
$langA['USER_NOT_REMOVED'] = 'Gebruiker <tt>%s</tt> is niet succesvol verwijderd uit deze werkgroep. ';
$langA['ADDED_PERMISSIONS'] = 'Toegevoegde rechten voor <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Geupdate rechten voor <tt>%s</tt>.';
$langA['NOT_A_USER'] = 'Gebruikersnaam <tt>%s</tt> is niet gevonden.';
$langA['IP_NOT_ADDED'] = 'Kan niet toevoegen/updaten rechten van <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>Waarschuwing:</b> Gebruikers <tt>%s</tt> is al de eigenaar van dit account.';
$langA['IP_WRONG_LEVEL'] = '<b>Warning:</b> IP addresses cannot be given privileges higher than "workgroup".';
$langA['SET_PERMISSIONS'] = 'To set permissions for "%s", select the desired status then click "Update Permissions".';


//	specLostPass
$langA['lost_password'] = 'Wachtwoord Kwijt';



//	specFileManager
$langA['file_manager'] = 'Bestandsbeheer';
$langA['image_manager'] = 'Plaatjes Beheerder';
$langA['CONFIRM_FILE_DELETE'] = 'Weet je zeker dat je <b>%s</b> wilt verwijderen?';
$langA['IMAGE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these images in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['FILE_MANAGER_INTRO'] = 'You may use wiki syntax or html to include these files in  your pages. For certain file types (templates, maps..) we recommend using html syntax.';
$langA['file_name'] = 'Bestandsnaam';
$langA['available_space'] = 'Beschikbare Ruimte';
$langA['UPLOAD_INTRO'] = 'Upload file attachments and images for inclusion in your pages.';
$langA['file_upload'] = 'Bestand Upload';
$langA['file_info'] = 'Bestands Info';
$langA['width'] = 'Breedte';
$langA['height'] = 'Hoogte';
$langA['file_location'] = 'Bestandslocatie';
$langA['wiki_syntax'] = 'Wiki Syntaxis';
$langA['html_syntax'] = 'HTML Syntaxis';
$langA['append_to'] = 'toevoegen aan';
$langA['count'] = 'Tellen';
$langA['total_size'] = 'Totale grootte';
$langA['images'] = 'Afbeeldingen';
$langA['overwrite_existing'] = 'Overwrite Existing';
$langA['compression'] = 'Compressie';

$langA['NOT_AN_IMAGE'] = 'The file does not appear to be an image. Please check the file then try again. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'Kan het bestand <tt>%s</i> niet verwijderen.';
$langA['UPLOADED'] = 'Bestand <tt>%s</tt> succesvol geupload.';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = 'Dit bestand is succesvol hernoemd.';
$langA['UPLOAD_FAILED'] = 'Niet gelukt om bestand te kopieeren: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Selecteer een Bestandstype:';
$langA['default_options'] = 'Standaard Instellingen';
$langA['UNKNOWN_FILE_TYPE'] = 'Onbekend Pagina Type: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Account';
$langA['entries'] = 'Toevoegingen';
$langA['average'] = 'Gemiddelde';
$langA['uploaded_files'] = 'Geuploade';


//	searchTrash
$langA['deleted'] = 'Verwijderde';
$langA['restore'] = 'Hestel';
$langA['empty_trash'] = 'Leeg Vuilnisbak';
$langA['CONFIRM_EMPTY_TRASH'] = 'Weet je zeker dat je je vuilnisbak wilt legen?';

$langA['DELETED_AFTER_30'] = 'Bestanden worden na 30 dagen automatisch verwijderd.';
$langA['check_uncheck'] = 'Check All / Uncheck All';
$langA['DELETED_FILES'] = 'De geselecteerde bestanden zijn succesvol verwijderd.';
$langA['NOTHING_DELETED'] = 'Niets was verwijderd.';
$langA['DELETE_FILES'] = 'Selecteer alsjeblieft de bestanden om te verwijderen.';
$langA['MAP_INVALID_PT'] = 'Ongeldige Map Data: Ongeldige Punt Formaat';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'The search feature for this site does not appear to be enabled. Site administrators can enable this feature via Search Options in the Control Panel.';
$langA['search:'] = 'Zoek: ';
$langA['search_for'] = 'Zoek naar: ';
$langA['registered'] = 'Geregistreerd';
$langA['restricted'] = 'Beperkt';
$langA['locked'] = 'Vergrendeld';
$langA['disabled'] = 'Uitgezet';
$langA['editing_option'] = 'Wijzigingen Optie';
$langA['comments_option'] = 'Commentaar Optie ';
$langA['visibility_option'] = 'Zichtbaarheids Optie';
$langA['normal'] = 'Normaal';
$langA['advanced'] = 'Geavanceerd';
$langA['relevance'] = 'Relevantie';
$langA['SEARCH_ONE'] = 'Voor tenminste een van de woorden';
$langA['SEARCH_ALL'] = 'Voor al de woorden';
$langA['SEARCH_EXACT'] = 'Voor de exacte zin';
$langA['SEARCH_WITHOUT'] = 'Zonder de woorden';
$langA['SEARCH_BEGIN'] = 'Voor woorden beginnend met';


//	searchKeywords
$langA['keyword_search'] = 'Sleutelwoord Zoeken';
$langA['non_tagged_files'] = 'Niet-Gemarkeerde Bestanden';

//	searchChangeLog
$langA['new'] = 								'Nieuw';
$langA['DIFF_TITLE'] = 							'Vergelijk verschillen met de meest recente versie';
$langA['indicates_syntax_error'] = 				'Wijst op een syntaxfout.';
$langA['indicates_unchecked'] = 				'Wijst op een ongecontroleerd bestand.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Selecteer een Licentie';
$langA['SELECT_LICENSE_DESC'] = 'Opens a Creative Commons webpage in a popup window.';
$langA['DELETE_LICENSE_DESC'] = 'This will remove your current content license.';
$langA['LICENSE_UPDATED'] = 'Your content license has been updated successfully.';
$langA['LICENSE_DELETED'] = 'Licentie was verwijderd.';
$langA['LICENSE_DELETED2'] = 'Licentie is al verwijderd.';
$langA['customize_license'] = 'Customize Your License';

$langA['text_before'] = 'Text Before Link';
$langA['text_after'] = 'Text After Link';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Except where expressly noted, this work is licensed under a ';
$langA['LICENSE_TEXT_LINK'] = 'Creative Commons License';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganiseer';
$langA['from'] = 'Van';
$langA['to'] = 'Aan';
$langA['KEYWORDS_UPDATED'] = 'Je sleutelwoorden zijn geupdate.';
$langA['KEYWORDS_EMPTY'] = 'Je hebt nog geen bestanden met sleutelwoorden gecreeerd.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = 'Omschrijving';
$langA['add_link'] = 'Add Link';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Groep';
$langA['name'] = 'Naam';
$langA['add_group'] = 'Voeg een groep toe';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Limiet';
$langA['random'] = 'Random';
$langA['order'] = 'Order';
$langA['LEAVE_EMPTY'] = 'Leave empty for no limit';
$langA['unlimited'] = 'Ongelimiteerd';
$langA['type'] = 'Type';
$langA['auto_detect'] = 'Automatisch Detecteren';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'Beweeg naar boven';
$langA['move_down'] = 'Beweeg naar beneden';
$langA['redirect'] = 'Richt opnieuw';
$langA['content_template'] = 'Content Template';

