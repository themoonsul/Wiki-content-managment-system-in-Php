<?php
$langA['ILLEGAL_USERNAME'] = 'The Username cannot include the following characters: %s';
$langA['LONG_USERNAME'] = 'Deze gebruikersnaam is te lang';	
$langA['SHORT_USERNAME'] = 'Deze gebruikersnaam is te kort';
$langA['USER_TAKEN'] = 'Kies een andere gebruikersnaam. <tt>%s</tt> is al in gebruik. ';
$langA['USERNAME_ALL_DIGITS'] = 'De Gebruikersnaam kan niet alleen uit cijfers bestaan.';
$langA['PASSWORDS_DIFFERENT'] = 'Wachtwoorden komen niet overeen.';
$langA['SHORT_PASSWORD'] = 'Passwoord was te kort.';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = 'Registreer';
$langA['welcome_to'] = 'Welkom bij ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = 'Moet minimaal 5 karakters bevatten';
$langA['confirm_password'] = 'Bevestig Wachtwoord';
$langA['REG_CONFIRM_PASS'] = 'Hetzelfde als bovenstaande.';
$langA['REG_EMAIL'] = 'Optioneel maar handig als je je wachtwoord vergeet.';
$langA['REQUIRED_FIELD'] = 'Indicates a required field.';

$langA['REGISTRATION_TEXT'] = 'Registratie is snel, gratis en heeft veel voordelen...';
$langA['REG_A_USER_PAGE'] = '/Gebruikersnaam/Jouw_Pagina\'s';
$langA['REG_A_MAP_PAGE'] = '/Map/Gebruikersnaam/Jouw_Maps';

//login
$langA['LOGGED_IN'] = 'Je bent ingelogt als <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'De opgegeven gebruikersnaam bestaat niet. Wil je registreren %s.';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Activate your account now.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Your account has been activated.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
