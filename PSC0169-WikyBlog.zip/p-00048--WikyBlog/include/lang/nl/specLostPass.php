 <?php

$langA['CHANGE_PASS_INTRO'] = 'To change your password, we first need to send you a "Permission Key" so that you may access this restricted feature. Once you have received the key, return to this page and enter the information below. Please note, your "Permission Key" will only work for your Username.';

$langA['next_step'] = 'Volgende Stap';

$langA['PASS_EMAIL_SUBJECT'] = 'Permission Key for %s.';
$langA['PASS_EMAIL_TEXT'] ='Your permission key for %s is %s.';

$langA['get_your_key'] = 'Krijg je Toestemmings Sleutel';
$langA['GET_YOUR_KEY'] = 'Je sleutel zal naar het e-mailadres toegestuurd worden dat je gebruikt hebt bij het registreren.';

$langA['send_key'] = 'Stuur Toestemmings Sleutel';

$langA['change_password'] = 'Wijzig je wachtwoord';
$langA['permission_key'] = 'Toestemmings Sleutel';
$langA['new_password'] = 'Nieuw wachtwoord';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = 'Wachtwoord Verandering mislukt: Niet correcte Permissie Sleutel of Gebruikersnaam';
$langA['PASSWORD_CHANGED'] = 'Wachtwoord succesvol geupdate voor <tt>%s</tt>.';
$langA['PROVIDE_PASSWORD'] = 'Je moet een nieuw wachtwoord ingeven';
$langA['PROVIDE_PERMISSION_KEY'] = 'Je moet een Permissie Sleutel verstrekken om je wachtwoord te veranderen ';
$langA['PERMISSION_KEY_SENT'] = 'Permission Key sent successfully. Retrieve the key form your email and use it to change your password using the form below.';
$langA['PERMISSION_KEY_NOT_SENT'] = 'Failed to send Permission Key to the provided email address, please contact the website administrator for additional help.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = 'An email address was not provided for this account. Please contact the website administrator for additional help.';

