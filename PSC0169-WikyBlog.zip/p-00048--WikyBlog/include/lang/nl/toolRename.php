<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'De bestandsnaam is niet veranderd.';
$langA['NOT_RENAMED'] = 'Dit bestand kan niet hernoemd worden naar <tt>%s</tt>. Weet zeker dat het bestand niet al bestaat.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'Kan dit bestand niet hernoemen.';
$langA['redirected_to'] = 'Redirected to';
$langA['RENAMED'] = 'Dit bestand is succesvol hernoemd.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b.%s</b> is teruggezet. ';
$langA['ERROR_RESTORING'] = '<b>Error:</b> Could not restore the file at <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = 'Dit bestand is al teruggezet.';
$langA['WAS_DELETED'] = '<b>%s</b> was verwijderd. Dit bestand wordt opgeslagen in de %s voor 30 dagen.';
$langA['ERROR_DELETING'] = '<b>Fout:</b> Kan het bestand niet verwijderen bij <tt>%s</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> was verwijdered';
