<?php

	$langA['googleMapKeys'] =						'Google Maps API Sleutel';


	$langA['ADMIN_ONLY'] =							'Je moet een beheerder zijn om deze pagina te kunnen zien.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'De beheerder pagina is nog niet gedefinieerd: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Gelieve uw wachtwoord te bevestigen om verder te gaan.';
	$langA['confirm_password'] =						'Bevestig Wachtwoord';
	$langA['confirmation_failed'] =					'Wachtwoord bevestiging mislukt. Gelieve opnieuw proberen.';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Zoek Opties';
	$langA['search_status'] =						'Zoek Status';
	$langA['search_enabled'] =						'Zoeken Ingeschakeld';
	$langA['SEARCH_ENABLED'] =						'Uitschakelen van de zoekfunctie leegt de database tabel \'all_search\'. Later, als de zoekfunctie weer geactiveerd wordt, zal de database tabel \'all_search\' opnieuw bijgewerkt worden.';
	$langA['disable'] =								'Uitschakelen';
	
	$langA['search_disabled'] =						'Zoeken Uitgeschakeld';
	$langA['SEARCH_DISABLED'] =						'Zoeken is op dit moment niet actief. Zoeken activeren vereist een proces waarbij de database tabel \'all_search\' gevuld wordt met alle bestanden in de database. Dit proces kan veel tijd in beslag nemen bij grote databases.';
	$langA['SEARCH_IS_DISABLED'] =					'Search disabled and search table truncated.';
	$langA['enable'] =								'Inschakelen';
	
	$langA['FINISHED_ENTRIES'] =						'%s velden gereed, nog %s te gaan.';
	$langA['SEARCH_IS_ENABLED'] =					'De zoek functie is nu aangezet.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Configuratie';
	$langA['confighistory'] =						'Configuratie Historie';
	$langA['CONFIG_SAVING'] =						'De nieuwe configuraties worden bewaard zonder de huidige waarden te overschrijven, mogelijke veranderingen kunnen indien noodzakelijk ongedaan gemaakt worden...';
	$langA['CONFIG_STAT'] =							'Er zijn %s revisies gemaakt aan de configuratie.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Weet u zeker dat u revisie nummer %s wilt herstellen? Klik <tt>Opslaan</tt> om door te gaan.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Iets dat kan gebruikt worden met een zin als: "Welkom bij serverNaam1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverNaam2';

//default user

	$langA['max_upload']['desc'] = 					'Maximum grootte van een geupload bestand.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Maximaal toegestane bestandsgrootte voor het Fouten Logboek. Standaard 10,000 bytes.';
	$langA['errorEmail']['desc'] = 					'Verstrek een e-mailadres ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Algemene Instellingen';
	$langA['performance'] = 							'Prestaties';
	
	$langA['serverName1']['alias'] = 				'Leuke Server Naam';
	$langA['serverName2']['alias'] = 				'Server Naam';
	$langA['serverName3']['alias'] = 				'Volledige URL van de Server';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Max Upload';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Taal';
	$langA['reservedWords']['alias'] = 				'Gereserveerde Woorden';
	
	$langA['developer_aids'] = 						'Ontwikkelaar Hulp';
	$langA['maxErrorFileSize']['alias'] = 			'Fout Logboek Grootte ';
	$langA['errorEmail']['alias'] = 					'Email Fout';
	$langA['include']['alias'] = 					'Bevat PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Standaard Gebruikers Instellingen';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Start Titel';
	$langA['defaultUser:homeTitle']['desc'] =		'Weergeven als de titel van de start pagina.';
	
	$langA['defaultUser:template']['alias'] =		'Gebruikersprofiel';
	$langA['defaultUser:template']['desc'] =		'Main/Home is het standaard wikyblog sjabloon.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Tekstblok Hoogte';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Blog Start Pagina';
	$langA['defaultUser:isBlog']['desc'] =			'Zet blog gestileerde startpagina aan en uit.';
	
	$langA['defaultUser:timezone']['alias'] =		'Tijdzone';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Max Rijen Geschiedenis';
	$langA['defaultUser:maxHistory']['desc'] =		'Standaard maximum voor historie rijen.';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Voeg een groep toe';
	$langA['unlimited'] = 'Ongelimiteerd';
	$langA['group'] = 'Groep';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Gebruikers Statistieken';
	$langA['user_stats'] =							'Gebruikers Stats';
	$langA['user_account'] =							'Gebruikers Account';
	$langA['entries'] =								'Toevoegingen';
	$langA['history Rows'] =							'Historie Rijen';
	$langA['last_visit'] = 							'Laatst Bezocht';
	
	$langA['users_found'] =							'Gebruikers Gevonden';
	$langA['showing_of_found'] =						'Laat zien %s tot %s';
	$langA['cpanel'] =								'Cpaneel';
	$langA['details'] =								'Details';
	
	$langA['within_the_hour'] =						' < 1 uur geleden';
	$langA['hours'] =								'uren';
	$langA['days'] =									'dagen';
	$langA['months'] =								'maanden';
	$langA['years'] = 								'jaren';
	$langA['ago'] = 									'geleden';
	
	$langA['TIMEOUT'] = 								'<b>Onderbrekings fout:/b> %s';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'Weet je zeker dat je <b>%s</b> wilt verwijderen?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Verwijderen zal <i>volledig wissen</i> alle bestanden voor het account inclusief:';
	$langA['userfiles_directory'] = 					'Gebruikers bestanden map ';
	$langA['template_directory'] = 					'Sjablonen map: ';
	$langA['database_entries'] = 					'En alle database toevoegingen: pagina\'s, pagina historie, commentaar etc.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Verwijderde database toevoegingen.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Waarschuwing:</b> Kan de database toevoegingen niet verwijderen.';
	
	$langA['DELETED_USERFILES'] = 					'Gebruiker Bestandenmap Verwijderd.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Let Op:</b> De Gebruikers bestandenmap kon niet worden verwijderd.';
	
	$langA['DELETED_TEMPLATES'] = 					'Sjablonenmap Verwijderd.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Let Op:</b> De Sjablonenmap kon niet worden verwijderd.';
	
	$langA['USER_DELETED'] = 						'%s is volledig verwijderd: ';
	$langA['USER_NOT_DELETED'] = 					'%s is NIET volledig verwijderd: ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Updated';
	$langA['suspend'] = 							'Suspend';
	$langA['activate'] = 							'Activeer';
	$langA['lost_page'] = 							'Verdwenen Pagina';
	$langA['suspended'] =							'Suspended';
	$langA['disabled'] =							'Uitgezet';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Kan het fouten logboek niet verwijderen.';
	$langA['ERROR_LOG_DELETED'] = 					'Het Fouten Logboek was verwijderd.';
	$langA['ERROR_LOG_MAXED'] = 						'Het fouten logboek heeft z\'n maximum grootte bereikt, leeg alsjeblieft het bestand zodat het script door kan gaan met het loggen van fouten. %s';


	$langA['select'] = 								'Selecteer';
	$langA['description'] = 						'Omschrijving';


//	adminPlugins
	$langA['data_types'] = 							'Data Types'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Bestaande Types';
	$langA['available_plugins'] = 					'Beschikbare Plugins';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Check All / Uncheck All';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Online';
	$langA['wbConfig']['online']['desc'] = 			'Wordt deze implementatie verbonden met het internet?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Vloed Interval';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Het aantal seconden dat een gebruiker zonder rechten moet wachten tussen wijzigingen.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Gebruik HTML Tidy om mogelijke gebruikers input fouten te verbeteren.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Gekenmerkt Hoogtepunt.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Geef toestemming aan alle geregistreerde gebruikers om een eigen blog te beheren.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Standaard Gebruiker.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Sessie Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

