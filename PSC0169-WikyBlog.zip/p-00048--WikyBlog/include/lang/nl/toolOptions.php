<?php

//	toolOptions.php
$langA['properties'] = 'Eigenschappen';
$langA['file_name'] = 'Bestandsnaam';
$langA['update_from'] = 'Update van';
$langA['COPY_SYSTEM_FILES'] = 'Kopieer de meest recente systeem help bestanden van %s.';

$langA['EDITING_OPTIONS'] = 'Controle op degene die is toegestaan om dit bestand te wijzigen.';
$langA['registered_users'] = 'Geregistreerde Gebruikers';
$langA['restricted_to'] = 'Beperkt Tot ';
$langA['admin_only'] = 'Alleen Beheerder';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Alleen Eigenaar';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = 'Zichtbaarheid';
$langA['VISIBILITY_OPTIONS'] = 'Verberg dit bestand als je er nog niet klaar voor bent om het aan de wereld te laten zien.';
$langA['visible'] = 'Zichtbaar';

$langA['COMMENT_OPTIONS'] = 'Disable comments for this file.';
$langA['enabled'] = 'Aangezet';
$langA['disabled'] = 'Uitgezet';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = 'Andere';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Verwijder Van Blog';
$langA['repost'] = 'Opnieuw gepost';
$langA['copy_to'] = 'Kopieer Naar...';
$langA['send_to_trash'] = 'Verzend naar Afval';
$langA['default_options'] = 'Standaard Instellingen';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = 'Zet %s voor dit bestandstype.'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'Dit bestand is opnieuw gepost.';
$langA['NOT_REPOSTED'] = '<b>Fout:</b> Kan dit bestand niet opnieuw posten.';
$langA['OPTIONS_NOT_CHANGED'] = 'De bestandsinstellingen zijn niet aangepast.';
$langA['OPTIONS_UPDATED'] = 'De bestandsinstellingen zijn bijgewerkt.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Waarschuwing:</b> Bestandsopties zijn niet geupdate.';

$langA['redirect'] = 'Richt opnieuw';
$langA['REMOVE_REDIRECT'] = 'Als je niet langer wilt dat dit bestand opnieuw richt, kun je het verwijderen of wijzigen. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'Bestands ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'Gebruikers&nbsp;Rechten';
