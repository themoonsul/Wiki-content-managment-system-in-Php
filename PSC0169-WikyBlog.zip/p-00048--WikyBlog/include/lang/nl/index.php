<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Bestand';
$langA['edit'] = 'Bewerk';
$langA['edits'] = 'Edits';
$langA['view_source'] = 'Bekijk Bron';
$langA['talk'] = 'Praat';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Geschiedenis';
$langA['diff'] = 'Verschil';
$langA['watch'] = 'Watch';
$langA['unwatch'] = 'Unwatch';
$langA['options'] = 'Opties';


$langA['messages'] = 'Berichten';
$langA['current'] = 'Huidig';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Mogelijk';

$langA['DEFAULT_CONTENT'] = 'Dit is een nieuw bestand, wil je het [[%s?cmd=wijzigen|creeeren]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Dit is een nieuw bestand. Om dit bestand te creeeren, moet je ingelogd zijn met de juiste rechten.';

$langA['NOT_OWNER'] = 'Je hebt niet de juiste rechten voor deze eigenschap.';
$langA['LONG_PATH'] = 'De naam voor dit bestand was the lang en is ingekort.';
$langA['EMPTY_CONTENT'] = 'Inhoud is een vereist veld';
$langA['INCOMPLETE_PATH'] = 'Het opgegeven pad is niet compleet.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Sorry, the website administrator has disabled user blogging. To create a bliki with the same features found here, visit <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'Deze titel bestaat al, selecteer alsjeblieft een andere en bewaar opnieuw.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = 'Dit is een "verborgen" bestand. ';
$langA['DELETED_FILE'] = 'This file is currently in the "trash". If you are the owner of this account, you can restore this file via your control panel.';
$langA['PROTECTED_FILE'] = 'Dit bestand is beveiligd. Wijzigigen in dit bestand worden niet opgeslagen.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Link Text';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'Deze pagina verwijst naar %s.';

//	Data Types
$langA['all'] = 'Alle';
$langA['page'] = 'Pagina';
$langA['comment'] = 'Commentaar';
$langA['map'] = 'Map';
$langA['template'] = 'Sjabloon';
$langA['help'] = 'Help';
$langA['skeleton'] = 'Skelet';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Commentaren';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Pagina\'s';
$langA['CLASScomment'] = 'Commentaren';
$langA['CLASSmap'] = 'Mappen';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'Help';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' seconden';
$langA['queries'] = ' vragen';

$langA['QUERY_TIME'] = ' voor vragen';
$langA['INVALID_PATH'] = 'Niet geldig bestands pad opgegeven: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Invalid Request.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = 'Maak een nieuw help bestand';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Blader';
$langA['change_log'] = 'Wijzigingen Logboek';
$langA['control_panel'] = 'Configuratiescherm';
$langA['administration'] = 'Beheer';
$langA['preferences'] = 'Voorkeuren';
$langA['watchlist'] = 'Watchlist';
$langA['wanted_files'] = 'Gewilde Bestanden';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'Zoeken';
$langA['orphaned_files'] = 'Orphaned Files';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'Externe Verbindingen';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'Recentere Posts';
$langA['NEED_INTERNET'] = 'Deze toepassing is alleen beschikbaar voor systemen die verbonden zijn met het internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Waarschuwing:</b> Uw webbrowser moet cookies accepteren om verder te gaan. Ververs deze pagina als u cookies heeft ingeschakeld.';
$langA['LOGIN_REQUIRED'] = 'U moet aangemeld zijn om gebruik te kunnen maken van deze toepassing.';

$langA['ENTER_USERNAME'] = 'Voer je gebruikersnaam in AUB';
$langA['ENTER_PASSWORD'] = 'Voer je wachtwoord in AUB';
$langA['LOGGED_OUT'] = 'U bent nu afgemeld.';
$langA['AUTO_LOGOUT'] = 'Uw sessie is verlopen.';

$langA['LOGIN_FAILED'] = 'Aanmeldfout: Het ingegeven wachtwoord is niet juist.<ul><li>Het wachtwoord is hoofdlettergevoelig<li> Heeft u %suw wachtwoord vergeten%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'Het maximum aantal van %s login pogingen is overschreden. Je zult niet toegestaan worden om in te loggen voor de volgende $s minuten.';
						
$langA['create_new'] = 'Maak&nbsp;Nieuw ';
$langA['remember_me'] = 'Gegevens Onthouden';
$langA['log_out'] = 'Log Uit';
$langA['log_in'] = 'Log In';

//	SAVING 
$langA['syntax_error'] = 'syntax fout';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Syntaxis Fout:</b> Niet mogelijk om de meest recente veranderingen aan dit bestand weg te schrijven/tonen door een onverenigbare syntaxis.';
$langA['SYNTAX_FIXED'] = 'De syntax fout is gerepareerd.';


$langA['NO_CHANGES'] = 'Geen wijzigingen gemaakt aan dit bestand. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Niet mogelijk om dit Bestand weg te schrijven.(%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Wijzigingen aan dit bestand zijn weggeschreven.';
$langA['HIDDEN_FILE3'] = '<b>Nota:</b> Dit is een verborgen bestand, daarom zullen de markeringen voor dit bestand niet toegevoegd worden in het gebruikers menu totalen.';

$langA['VERSION_CONFLICT'] = 'Waarschuwing: We konden je wijzigingen niet wegschruiven omdat er een versie conflict gedetecteerd is.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Wijzigen is gelimiteerd tot 1 bestand elke %s seconden. Probeer alsjeblieft opnieuw in %s seconden.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Bewaar Opties';
$langA['blog_this'] = 'Blog Dit';



//	toolHistory2.php
$langA['differences'] = 'Verschil(len)';
$langA['line_num'] = 'Regel #';


//	toolHistory1.php
$langA['revision'] = 'Versie ';
$langA['revision_as_of'] = 'Versie van ';
$langA['revision_num_as_of'] = 'Revision %s van %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Wijzig versie';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Teruggekeerd naar versie #';
$langA['SET_USER_PERMISSIONS'] = 'Stel de rechten in voor deze gebruiker: '; 
$langA['compare_with_prev'] = '← Vergelijk met vorige versie';
$langA['current_revision'] = 'Huidige versie';
$langA['compare_with_next'] = 'Vergelijk met volgende versie →';
$langA['lines'] = 'Regels';
$langA['text'] = 'Tekst';
$langA['vs'] = ' to ';
$langA['content'] = 'Inhoud';
$langA['your_text'] = 'Uw Tekst';
$langA['show_prev_revision'] = '← Versie %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Versie %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Warning:</b> You are not editing the most recent version of this page.<br /> Saving will replace the newest version with this out-of-date version.';
$langA['SELECT_TWO_VERSIONS'] = 'Selecteer alsjeblieft twee verschillende versies om te vergelijken.';
$langA['NO_UNIQUE_REVISION'] = 'Kan geen unique versie vinden voor deze aanvraag.';
$langA['INVALID_REVISION'] = '<b>Fout:</b> Niet geldig Revisie Nummer.';
$langA['NO_DIFFERENCES'] = 'De twee versies ter vergelijking zijn identiek.';
$langA['NO_REVISIONS'] = 'Er moeten twee verschillende versies zijn voordat een vergelijking gemaakt kan worden.';
$langA['NON_EXISTANT'] = 'Dit bestand bestaat nog niet.';

//	toolEditPage.php
$langA['bold_text'] = 'Vette tekst';
$langA['italic_text'] = 'Cursieve tekst';
$langA['headline_text'] = 'Voeg Rubriek tussen';
$langA['title'] = 'Titel';
$langA['unordered_list'] = 'Ongeordende Lijst';
$langA['ordered_list'] = 'Geordende Lijst';


$langA['internal_link'] = 'Interne Link';
$langA['link'] = 'Link';
$langA['external_link'] = 'Externe Verwijzing';
$langA['embed_image'] = 'Bed Beeld in';
$langA['find_images'] = 'Find Images';
$langA['image'] = 'Plaatje';
$langA['nowiki'] = 'geenwiki';
$langA['NOWIKI_TEXT'] = 'Voeg hier niet-geformateerde tekst tussen ';
$langA['signature'] = 'Handtekening';
$langA['SIGNATURE_TEXT'] = 'Voeg je Handtekening toe';
$langA['preview'] = 'Nakijken';
$langA['PREVIEW_TEXT'] = 'Preview your changes [%s-p]';
$langA['PREVIEW_WARN'] = 'Dit is alleen een voorproef. Je wijzigingen zijn nog niet opgeslagen!';
$langA['SAVE_TEXT'] = 'Sla uw wijzigigen op [%s-s]';
$langA['reset'] = 'Herstel';
$langA['RESET_TEXT'] = 'Reset this form to it\'s original state [%s-c]';
$langA['changes'] = 'wijzigingen';
$langA['CHANGES_TEXT'] = 'Laat de wijzigingen zien die u gemaakt heeft in dit bestand.[%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organiseer je posts met komma gesepareerde kernwoorden'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Markeringen';
$langA['edit_summary'] = 'Wijzigingen Samenvatting';
$langA['syntax_warning'] = 'Syntaxis Waarschuwing';
$langA['NO_IMAGES'] = 'Geen Plaatjes Gevonden';
$langA['insert_emoticons'] = 'Voeg Emoticons toe';
$langA['upload'] = 'Upload';



//searchHistory
$langA['show'] = 'toon';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Vergelijk';
$langA['timeline'] = 'Tijdslijn';
$langA['summary'] = 'Beschrijving';
$langA['COMPARE_REVISONS'] = 'Vergelijk met de geselecteerde versie.';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Niet geldig bestandstype opgegeven.';


//	SEARCH
$langA['next'] = 'Volgende';
$langA['previous'] = 'Vorige';
$langA['order_by'] = 'Sorteer op:';
$langA['ascending'] = 'Oplopend';
$langA['descending'] = 'Aflopend';
$langA['search_from'] = 'Zoek Pagina ';
$langA['all_users'] = 'Alle Gebruikers';
$langA['user'] = 'Gebruiker';
$langA['from_file_type'] = 'Zoeken Van Bestandstype: ';
$langA['read_more'] = 'Lees Meer';
$langA['words'] = ' woorden';

$langA['RESULTS'] = 'Resultaten %s van %s voor %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Uw zoekbewerking heeft geen overeenkomstige resultaten opgeleverd.';

//searchTalk
$langA['add_comment'] = 'Toevoegen Nieuw Onderwerp';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Kan geen waarschuwing invoegen. Slecht geformateerde gegevens voor dubbele ingang.';
$langA['duplicate_entry'] = 'Dubbele Ingang';
$langA['DUPLICATE_ENTRY'] = 'Dit is een dubbele ingang voor de pagina gevonden bij %s. <br/>Om het even welke niet overtollige hier gevonden informatie zou naar het origineel moeten worden overgebracht voordat deze pagina wordt verwijderd.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Niet gevonden: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Error:</b><br /> An error occurred while executing this script.<br /> Please check your request and we will attempt to debug the script with the error log. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Kan de standaard template niet verwijderen.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'Het opgegeven thema is niet geldig.';

//
//	CLASSmap
//
$langA['new_marker']='Nieuwe Markering';
$langA['new_route']='Nieuwe Route';
$langA['SAVE_HEADER']='Voor het opslaan onthoudt';
$langA['save_map']='Map opslaan';
$langA['continue_editing']='Ga door met wijzigen';
$langA['miles/km'] = 'mijlen/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>Dit is een nieuwe map.</b><br/>Om deze map te creeeren/wijzigen, click "Wijzig" hierboven.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Sorry, je hebt niet genoeg rechten om deze map te wijzigen.';
$langA['play'] = 'Start';
$langA['stop'] = 'Stop';
$langA['import'] = 'Importeer';
$langA['export'] = 'Exporteer';
$langA['gpx_data'] = 'GPX Data';
$langA['gpx_exchange_format'] = 'GPX Uitwisselings Formaat';
$langA['CLICK_EDIT'] = 'Om de map te wijzigen, klik "wijzig" hierboven';


//	smileys
$langA['smiles'][':D'] = 'Heel Blij';
$langA['smiles'][':)'] = 'Blij';
$langA['smiles'][':('] = 'Bedroefd';
$langA['smiles'][':o'] = 'Verast';
$langA['smiles'][':shock:'] = 'Geschokt';
$langA['smiles'][':?'] = 'In de war';
$langA['smiles']['8)'] = 'Cool';
$langA['smiles'][':lol:'] = 'Lachend';
$langA['smiles'][':x'] = 'Boos';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Embarassed';
$langA['smiles'][':cry:'] = 'Diep bedroefd';
$langA['smiles'][':evil:'] = 'Kwaad';
$langA['smiles'][':twisted:'] = 'Verdraaid Kwaad';
$langA['smiles'][':roll:'] = 'Rollende Ogen';
$langA['smiles'][':wink:'] = 'Knipoog';
$langA['smiles'][':!:'] = 'Uitroepteken';
$langA['smiles'][':?:'] = 'Vraag';
$langA['smiles'][':idea:'] = 'Idee';
$langA['smiles'][':arrow:'] = 'Pijl';
$langA['smiles'][':|'] = 'Neutraal';
$langA['smiles'][':mrgreen:'] = 'Meneer Groen';

//
//	General Language
//
$langA['or'] = 'of';
$langA['username'] = 'Gebruikersnaam';
$langA['password'] = 'Wachtwoord';
$langA['email'] = 'E-mail';
$langA['register'] = 'Registreer';
$langA['cancel'] = 'Annuleer';
$langA['language'] = 'Taal';
$langA['use'] = 'Gebruik';
$langA['copy'] = 'Kopieer';
$langA['rename'] = 'Hernoem';

$langA['on'] = 'Aan';
$langA['partial'] = 'Gedeeltelijk';
$langA['off'] = 'Uit';
$langA['save'] = 'Opslaan';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Ongedefinieerd';
$langA['homepage'] = 'Homepage';
$langA['home'] = 'Home';
$langA['go'] = 'OK';
$langA['user_menu'] = 'Gebruikers Menu';

$langA['last_modified'] = 'Laatst Gewijzigd';
$langA['LAST_MODIFIED'] = 'Laatst gewijzigd %s door %s.';//%s replaced with date and username
$langA['accessed_times'] = 'Accessed %s times';// %s replaced with a number
$langA['modified'] = 'Gewijzigd';
$langA['posted'] = 'Gepost';
$langA['created'] = 'Gemaakt';
$langA['hidden'] = 'Verborgen';
$langA['what_links_here'] = 'Referenties';
$langA['share'] = 'Deel';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'Het bestand moet opgeslagen worden voordat je deze operatie kan uitvoeren.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Grootte ';
$langA['bytes'] = 'bytes';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Update';
$langA['editing'] = 'Bijwerken';
$langA['workgroup'] = 'Werkgroep';
$langA['BROWSE_HIDDEN'] = 'Verborgen bestanden vinden';

$langA['delete'] = 'Verwijder';
$langA['confirm_delete'] = 'Bevestig verwijdering';
$langA['continue'] = 'Ga Verder';
$langA['back'] = 'Terug';
$langA['close'] = 'Sluiten';
$langA['view'] = 'Tonen';
$langA['empty'] = '-leeg-';
$langA['none'] = 'Geen';
$langA['total'] = 'Totaal ';
$langA['files'] = 'bestanden';
$langA['other'] = 'Andere';
$langA['trash'] = 'Vuilnis';
$langA['flagged'] = 'Gemarkeerd';

$langA['today'] = 'Vandaag';
$langA['yesterday'] = 'Gisteren';
$langA['days_ago'] = ' dagen geleden';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'Meer';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'zondag';
$langA['date_l'][1] = 'maandag';
$langA['date_l'][2] = 'dinsdag';
$langA['date_l'][3] = 'woensdag';
$langA['date_l'][4] = 'donderdag';
$langA['date_l'][5] = 'vrijdag';
$langA['date_l'][6] = 'zaterdag';

$langA['date_D'][0] = 'Zon';
$langA['date_D'][1] = 'Maa';
$langA['date_D'][2] = 'Din';
$langA['date_D'][3] = 'Woe';
$langA['date_D'][4] = 'Don';
$langA['date_D'][5] = 'Vri';
$langA['date_D'][6] = 'Zat';


$langA['date_F'][1] = 'januari';
$langA['date_F'][2] = 'februari';
$langA['date_F'][3] = 'maart';
$langA['date_F'][4] = 'april';
$langA['date_F'][5] = 'mei';
$langA['date_F'][6] = 'juni';
$langA['date_F'][7] = 'juli';
$langA['date_F'][8] = 'augustus';
$langA['date_F'][9] = 'september';
$langA['date_F'][10] = 'oktober';
$langA['date_F'][11] = 'november';
$langA['date_F'][12] = 'december';

$langA['date_M'][1] = 'jan';
$langA['date_M'][2] = 'feb';
$langA['date_M'][3] = 'mrt';
$langA['date_M'][4] = 'apr';
$langA['date_M'][5] = 'mei';
$langA['date_M'][6] = 'jun';
$langA['date_M'][7] = 'jul';
$langA['date_M'][8] = 'aug';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'okt';
$langA['date_M'][11] = 'nov';
$langA['date_M'][12] = 'dec';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabisch (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'Duits (de)';
$langA['lang']['el'] = 'Grieks (el)';
$langA['lang']['en'] = 'Engels (en)';
$langA['lang']['es'] = 'Spaans (es)';
$langA['lang']['fr'] = 'Frans (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italiaans (it)';
$langA['lang']['ja'] = 'Japans (ja)';
$langA['lang']['ko'] = 'Koreaans (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Nederlands (nl)';
$langA['lang']['pl'] = 'Pools (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Russisch (ru)';
$langA['lang']['tr'] = 'Turks (tr)';
$langA['lang']['vi'] = 'Vietnamees (vi)';
$langA['lang']['zh'] = 'Chinees (zh)';
$langA['lang']['zh-cn'] = 'Chinees Versimpeld (zh-cn)';



