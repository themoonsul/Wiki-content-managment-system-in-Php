<?php

	$langA['googleMapKeys'] =						'Cheia API pentru Google Maps';


	$langA['ADMIN_ONLY'] =							'Trebuie să fii administrator pentru a accesa această pagină.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Această pagină de administrare nu a fost definită încă: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Vă rugăm confirmă-ţi parola pentru a continua.';
	$langA['confirm_password'] =						'Confirmă parola';
	$langA['confirmation_failed'] =					'Confirmare parolă eşuată. Vă rugăm încercaţi din nou.';
	
	$langA['run_scheduled_tasks'] =					'Executarea Activităţilor programate';
	$langA['FAILED'] = 								'Ne pare rău, acţiunea dorită a eşuat. Vă rugăm încercaţi din nou.';
	$langA['SUCCESS'] = 								'Acţiunea dorită s-a teminat cu succes.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Opţiuni căutare';
	$langA['search_status'] =						'Status căutare';
	$langA['search_enabled'] =						'Căutare activată';
	$langA['SEARCH_ENABLED'] =						'Dezactivarea căutarii va goli tabelul `all_search` din baza de date. Ulterior, dacă vrei să reactivezi căutarea, `all_search` va trebui repopulată.';
	$langA['disable'] =								'Dezactivează';
	
	$langA['search_disabled'] =						'Căutarea este dezactivată';
	$langA['SEARCH_DISABLED'] =						'Căutarea este momentan dezactivată. Activarea sa are nevoie de un proces ce va popula tabelul `all_search` din baza de date cu intrări pentru toate fişierele din baza de date. Acest proces ar putea avea nevoie de un timp notabil de rulare pentru baze de date mari.';
	$langA['SEARCH_IS_DISABLED'] =					'Cauta dezactivare şi tabelul de căutare trunchiate.';
	$langA['enable'] =								'Activează';
	
	$langA['FINISHED_ENTRIES'] =						'%s intrări procesate, %s rămase.';
	$langA['SEARCH_IS_ENABLED'] =					'Opţiunea de cautare este acum activată.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Configuraţie';
	$langA['confighistory'] =						'Istoria configuraţiei';
	$langA['CONFIG_SAVING'] =						'Noile configurări sunt salvate fără a suprascrie valorile curente, lasându-te să poţi restaura modificările.';
	$langA['CONFIG_STAT'] =							'Au fost făcute %s revizii configuraţiei.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Sunteţi sigur că doriţi să restauraţi revizia cu numărul %s? Clichează <tt>Salvează</tt> pentru a continua.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Nu e disponibil';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Ceva ce poate fi folosit într-o propoziţie ca "Bine aţi venit pe serverName1"';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://serverName2';

//default user

	$langA['max_upload']['desc'] = 					'Dimensiunea maximă a fişierelor uploadate.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Utilizatorilor nu li se va permite să se înregistreze folosind aceste siruri de caractere separate prin virgulă ca nume de utilizator.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Dimensiunea maximă a log-ului cu erori. Valoarea standard este 10 000 octeţi.';
	$langA['errorEmail']['desc'] = 					'Furnizează o adresă de e-mail  ';
	
	
	$langA['include']['desc'] = 						'Automat includ un file php. Numele fisierelor pot fi date separate prin virgulă și sa fie relative la rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Setări generale';
	$langA['performance'] = 							'Performanță';
	
	$langA['serverName1']['alias'] = 				'Numele prietenos al serverului';
	$langA['serverName2']['alias'] = 				'Numele serverului';
	$langA['serverName3']['alias'] = 				'URL-ul complet al serverului';
	
	
	$langA['total_usage'] = 						'Utilizarea totală';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Uploadul maxim';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Limba';
	$langA['reservedWords']['alias'] = 				'Cuvinte rezervate';
	
	$langA['developer_aids'] = 						'Suport pentru programatori';
	$langA['maxErrorFileSize']['alias'] = 			'Dimensiunea log-ului de erori';
	$langA['errorEmail']['alias'] = 					'Adresa de e-mail pentru erori';
	$langA['include']['alias'] = 					'Include PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Setările standard ale utilizatorilor';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Titlul paginii de start';
	$langA['defaultUser:homeTitle']['desc'] =		'Afişat ca titlul paginii de start.';
	
	$langA['defaultUser:template']['alias'] =		'Şabloanele utilizatorilor';
	$langA['defaultUser:template']['desc'] =		'Main/Home este şablonul wikyblog standard.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Înălţimea câmpului de introducere a datelor';
	$langA['defaultUser:textareaY']['desc'] =		'Inălțimea predefinită pentru textarea.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Pagina de start a blogului';
	$langA['defaultUser:isBlog']['desc'] =			'Activează sau dezactivează pagina de start ca blog.';
	
	$langA['defaultUser:timezone']['alias'] =		'Fusul orar';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Numărul maxim în istoria editărilor';
	$langA['defaultUser:maxHistory']['desc'] =		'Maximul standard pentru numărul de intrări în istorie.';

	$langA['defaultUser:pTemplate']['alias'] =		'Temă predefinită';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'Grupul Utilizatorului';
	$langA['add_group'] = 'Toate Grupile';
	$langA['unlimited'] = 'Nelimitat';
	$langA['group'] = 'Grup';
	$langA['related_links'] = 'Legături corespunzătoare';
	
//
//	registration
//	
	$langA['registration'] = 						'Înregistrare';
	$langA['register:reqemail']['alias'] = 				'Cere adresa de email';
	$langA['register:register']['alias'] =				'Registrează titlul de display';
	$langA['register:registered']['alias'] =				'Titlul de display registrat';
	$langA['register:captcha']['alias'] =				'Folosiţi Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Statistici utilizatorilor';
	$langA['user_stats'] =							'Statusuri utilizatorilor';
	$langA['user_account'] =							'Contul utilizatorului';
	$langA['entries'] =								'Intrări';
	$langA['history Rows'] =							'Liniile în istorie';
	$langA['last_visit'] = 							'Ultima vizită';
	
	$langA['users_found'] =							'Utilizatori găsiţi';
	$langA['showing_of_found'] =						'AAfişez de la %s până la %s';
	$langA['cpanel'] =								'Panoul de control';
	$langA['details'] =								'Detalii';
	
	$langA['within_the_hour'] =						' < acum o oră';
	$langA['hours'] =								'ore';
	$langA['days'] =									'zile';
	$langA['months'] =								'luni';
	$langA['years'] = 								'ani';
	$langA['ago'] = 									'acum';
	
	$langA['TIMEOUT'] = 								'<b>Eroare expirare:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Atenție</b> Contul MAIN nu poate fi eliminat.';
	$langA['CONFIRM_DELETE_USER'] = 					'Sunteţi sigur că doriţi să ştergeţi <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Ştergând contul veţi <i>elimina complet</i> toate fişierele contului, inclusiv:';
	$langA['userfiles_directory'] = 					'Directorul de fişiere al utilizatorului: ';
	$langA['template_directory'] = 					'Directorul de şabloane al utilizatorului: ';
	$langA['database_entries'] = 					'Toate intrările în baza de date: pagini, istoria editărilor, comentarii, ş.a.m.d.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Intrările din baza de date şterse.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Avertizare:</b> Nu am putut şterge intrările din baza de date.';
	
	$langA['DELETED_USERFILES'] = 					'Directorul de fişiere al utilizatorului şters.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Avertizare:</b> Nu am putut şterge directorul cu fişierele utilizatorului.';
	
	$langA['DELETED_TEMPLATES'] = 					'Directorul cu şabloane şters.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Avertizare:</b> Nu am putut şterge directorul cu şabloane.';
	
	$langA['USER_DELETED'] = 						'%s a fost şters complet: ';
	$langA['USER_NOT_DELETED'] = 					'%s NU a fost şters complet: ';
	$langA['DELETE_ACCOUNT'] = 						'Elimină complet acest cont';
	$langA['DISABLE_ACCOUNT'] = 					'Dezactivează editarea fișierului.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspende toate utilizările.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Adăugaţi "neurmărit" tuturor link-uri externe.';
	$langA['updated'] = 							'Actualizat';
	$langA['suspend'] = 							'Suspendează';
	$langA['activate'] = 							'Activează';
	$langA['lost_page'] = 							'Pagină pierdută';
	$langA['suspended'] =							'Suspendat';
	$langA['disabled'] =							'Dezactivat';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Nu am putut şterge logul cu erori.';
	$langA['ERROR_LOG_DELETED'] = 					'Logul cu erori a fost şters.';
	$langA['ERROR_LOG_MAXED'] = 						'Logul cu erori a atins dimensiunea maximă, vă rog goliţi fişierul astfel încât scriptul să poată salva erori în continuare. %s';


	$langA['select'] = 								'Selectează';
	$langA['description'] = 						'Descriere';


//	adminPlugins
	$langA['data_types'] = 							'Tipuri de date'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Tipuri existente';
	$langA['available_plugins'] = 					'Extensii disponibile';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Selecționeaza/Deselecționeaza tot';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Online';
	$langA['wbConfig']['online']['desc'] = 			'Este această implementaţie conectată la internet?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Intervalul de flood';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Numărul de secunde pe careva un utilizator fără permisiuni va trebui să aştepte între editări.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determină nivelul de sporire JavaScript pentru utilizatorii anonimi.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Foloseşte HTML Tidy pentru a corecta eventuale erori în input.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Cu toate opţiunile';
	$langA['wbConfig']['allUsers']['desc'] = 		'Permite tuturor utilizatorilor înregistraţi să aibe propriul blog.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Selectaţi contul de utilizator care va fi afişat dacă nu este un dat de vizitator.';
	$langA['wbConfig']['pUser']['alias'] = 			'Utilizatorul predefinit.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determină cât de mult din IP-ul utilizatorului să fie folosit atunci când vor fi verificate de validare sesiuni.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Nivelul Sesiunii';

	$langA['wbConfig']['thumbs']['desc'] = 		'Creaţi icoane pentru imaginile încărcate.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Icoanele imaginilor';

