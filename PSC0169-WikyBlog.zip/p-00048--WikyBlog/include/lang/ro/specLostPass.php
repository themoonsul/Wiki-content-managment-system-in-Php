 <?php

$langA['CHANGE_PASS_INTRO'] = 'Pentru a schimba parola, va trebui mai întâi să vă trimitem o "cheie-de-permisiune", astfel încât să puteți accesa această facilitate restricţionată. După veţi primi cheia, reveniţi la această pagină şi introduceţi informaţiile de mai jos. Vă rugăm să luaţi notă, "cheie-de-permisiune" va funcţiona doar pentru numele dvs. de utilizator.';

$langA['next_step'] = 'Următorul Pas';

$langA['PASS_EMAIL_SUBJECT'] = 'Permisiunea cheie pentru %s.';
$langA['PASS_EMAIL_TEXT'] ='Permisiunea vostră cheie pentru %s este %s.';

$langA['get_your_key'] = 'Obţineţi cheia pentru permisiunile dvs.';
$langA['GET_YOUR_KEY'] = 'Cheia dvs. va fi trimisă la adresa de e-mail pe care aţi furnizato la înregistrare.';

$langA['send_key'] = 'Trimite cheia pentru permisiunile dvs.';

$langA['change_password'] = 'Schimbă parola';
$langA['permission_key'] = 'cheia pentru permisiuni';
$langA['new_password'] = 'Parolă nouă';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = 'Modificarea parolei a eşuat: Cheie de permis sau nume de utilizator incorecte';
$langA['PASSWORD_CHANGED'] = 'Parola schimbată cu succes pentru <tt>%s</tt>.';
$langA['PROVIDE_PASSWORD'] = 'Trebuie să furnizaţi o parolă nouă.';
$langA['PROVIDE_PERMISSION_KEY'] = 'Trebuie să furnizaţi o cheie de permisiune pentru a schimba parola';
$langA['PERMISSION_KEY_SENT'] = 'Cheia de Permisiune trimisă cu succes. Recuperaţi-cheia dvs. din e-mail şi utilizaţio pentru a vă schimba parola, folosind formularul de mai jos.';
$langA['PERMISSION_KEY_NOT_SENT'] = 'Eşuare în a trimite Cheia de Permisiunea la adresa de e-mail oferită, vă rugăm să contactaţi pe administratorul site-ului pentru ajutor suplimentar.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = 'Nici o adresă de e-mail nu a fost prevăzută pentru acest cont. Vă rugăm să contactaţi pe administratorul site-ului pentru ajutor suplimentar.';

