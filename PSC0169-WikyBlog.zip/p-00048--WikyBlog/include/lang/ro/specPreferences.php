<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'Preferinţele dvs. nu s-au schimbat de la valorile avute în precedență.';
$langA['INVALID_PREFS'] = '<b>Atenție:</b> Nu am putut salva preferinţele dumneavoastră cu valorile furnizate.';

$langA['EMAIL_PREFS'] = 'Utile în cazul în care uitaţi parola.';

$langA['LANG_PREFS'] = 'Alege limba:';

$langA['javascript_preferences'] = 'Preferințe JavaScript';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Activează/Dezactivează facilitățile JavaScript. Unele caracteristici nu vor funcționa fară JavaScript activat.';

$langA['time_zone'] = 'Fîșia timpului:';
$langA['TIME_ZONE_PREFS'] = 'Diferenţa între timpul local și timpul serverului: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'Timpul serverului este %s <br/> Timpul dvs. ajustat este %s.';

$langA['sig'] = 'Semnătură';
$langA['SIGNATURE'] = 'Personalizați semnătura dvs. cu ajutorul sintaxei Wiky.';


$langA['home_title'] = 'Titlul paginii de start';
$langA['HOME_TITLE_PREFS'] = 'Titlul de afişat pe pagina dvs. de pornire.';

$langA['blog_styled_frontpage'] = 'Stilul primei pagine';
$langA['BLOG_PREFS'] = 'Arată pagina dvs. de pornire ca un blog.';

$langA['blogT'] = 'Tipul blogului';
$langA['BLOG_TYPE'] = 'Selectaţi între tipuri de date disponibile pe acest blog.';

$langA['selective_blogging'] = 'Bloging selectiv';
$langA['SELECTIVE_BLOGGING'] = 'Blogingul selectiv vă permite să blogaţi numai acele pagini care sunt afişate pe prima pagină.';

$langA['blog_count'] = 'Contatorul Blogului';
$langA['BLOG_COUNT'] = 'Numărul de intrări pentru a apărea pe blog-ul dvs.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'Afişeayă legaturile de "Partajare" în partea de jos a fiecărui fişier.';

$langA['ihelp'] = 'Legături pentru ajutor';
$langA['IHELP'] = 'Arată legăturile pentru ajutor';

$langA['uServices'] = 'Servicii de actualizare';
$langA['UPDATE_SERVICES'] = 'Când publicaţi un nou articol, următoarele servicii de actualizare va for notificate în mod automat. Separaţi mai multe servicii de URI-uri în semne de pauză (line breaks).';
$langA['BAD_UPDATE_SERVICES'] = 'URI(uri) nu valide pentru serviciul de update.';


$langA['VIEW_THEME'] = '<a %s>Editează sau copie</a> această temă.';

$langA['quick_comment'] = 'Coment rapid';
$langA['QUICK_COMMENT'] = 'Dacă activ, un formular va fi afişat în partea de sus a pagini pentru a scri mai repede comentarea.';

$langA['textarea rows'] = 'Rînduri in textarea';
$langA['TEXTAREA_ROWS_PREFS'] = 'Determină înălţimea spațiului de editare.';

$langA['history_rows'] = 'Numărul maxim de rînduri pentru istorie';
$langA['HISTORY_ROWS_PREFS'] = 'Limitează numărul de rânduri de istorie stocate pe server pentru fiecare fişier.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Maxim %s';

$langA['tab_limit'] = 'Limită pentru Tab';
$langA['TAB_LIMIT'] = 'JavaScript va închide în mod automat filele în momentul în care numărul de file deschise va trece de această limită. Valoarea prestabilită este 7. Setaţi la 1000 sau mai mult, dacă nu doriţi ca JavaScript vă administreze filele.';

$langA['EXTERNAL_LINKS'] = 'Legăturile externe vor fi deschise în ferestre externe cînd e activ.';

$langA['SCROLL_CONTENT'] = 'Defilaţi numai în zona de conţinut a paginii şi nu pe întreaga pagină.<br/><span class="sm">(Tema are nevoie de un div WB_SCROLLAREA)</span>';

$langA['shortK'] = 'Scurtături tastatură';
$langA['SHORTK_CONTENT'] = 'Particularizaţi secvenţa de escape pentru comenzile rapide de tastatură. (Necesită reîncărcare)';


$langA['save_preferences'] = 'Salvează preferințe';

$langA['CONFIRM_CHANGE'] = 'Ești sigur că vrei să schimbați preferinţele dumneavoastră?';
$langA['preference'] = 'Preferințe';
$langA['old_value'] = 'Valoarea veche';
$langA['new_value'] = 'Valoarea noua';

$langA['changes'] = 'Schimbări';
$langA['PREFS_CHANGED'] = 'Preferințele dvs. au fost actualizate cu succes. <br/> Mai jos este un rezumat al valorilor care s-au schimbat.';


//check edit
$langA['anonymous'] = 'Anonim';
$langA['fEdits'] = 'Editarea bandierei';
$langA['FLAG_EDITS'] = 'Editări făcute de către utilizatorii cu statutul sau de la statutul de mai jos selectat va fi marcat ca "neverificată" până când va fi examinată de proprietar.';

//save all edits
$langA['saveAll'] = 'Scrie in log toate editarile';
$langA['SAVEALL'] = '"Activat" va salva toate modificările în revizuirea istoriei. <br/> "Dezactivat" va înregistra revizii bazate pe sesiuni de editare.';
