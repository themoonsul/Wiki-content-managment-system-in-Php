<?php

//	toolOptions.php
$langA['properties'] = 'Proprietăţi';
$langA['file_name'] = 'Numele fileului';
$langA['update_from'] = 'Sincronizează de la ';
$langA['COPY_SYSTEM_FILES'] = 'Copiază cele mai recente file de ajutor de la %s.';

$langA['EDITING_OPTIONS'] = 'Verifică cine are dreptul sa editeze acest file.';
$langA['registered_users'] = 'Utilizatori înregistraţi';
$langA['restricted_to'] = 'Limitat la ';
$langA['admin_only'] = 'Doar Administratorul';
$langA['editor_visible'] = 'Viyibil pentru editori';
$langA['owner_only'] = 'Doar Stăpînul';
$langA['use_captcha'] = 'Folosiţi Captcha';
		

$langA['visibility'] = 'Vizibilitate';
$langA['VISIBILITY_OPTIONS'] = 'Ascunde acest fişier dacă nu sunteţi gata să-l arătați lumii.';
$langA['visible'] = 'Vizibil';

$langA['COMMENT_OPTIONS'] = 'Dizactivează comentariile pentru acest file';
$langA['enabled'] = 'Activat';
$langA['disabled'] = 'Dezactivat';
$langA['RECENT_COMMENTS'] = 'Arată comentăriile recente';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Neurmarit';

$langA['other'] = 'Altul';
$langA['related_links'] = 'Legături corespunzătoare';
$langA['unblog'] = 'Elimină din Blog';
$langA['repost'] = 'Publică';
$langA['copy_to'] = 'Copiază la...';
$langA['send_to_trash'] = 'Trimite la gunoi';
$langA['default_options'] = 'Preferințe predefinite';
$langA['restore_defaults'] = 'Restaurează setările standard';
$langA['SET_DEFAULT_OPTIONS'] = 'Setează %s pentru acest tip de file.'; //replaced with link
$langA['add_to_tabs'] = 'Adaugă la etichete';
$langA['add_to_links'] = 'Adaugă la legaturi';

$langA['REPOSTED'] = 'Acest file a fost publicat din nou.';
$langA['NOT_REPOSTED'] = '<b>Eroare:</b> Nu pot publica din nou acest file.';
$langA['OPTIONS_NOT_CHANGED'] = 'Opțiunile pentru acest file nu pot fi schimbate.';
$langA['OPTIONS_UPDATED'] = 'Preferințele pentru acest file au fost salvate cu succes.';
$langA['OPTIONS_NOT_UPDATED'] = '<b> Atenţie: </b> Opţiuni de fişier nu au fost actualizate.';

$langA['redirect'] = 'Redirecție';
$langA['REMOVE_REDIRECT'] = 'Dacă nu mai doriţi să redirecţionați acest fişier, puteţi fie să-l editaţi sau să-l ştergeţi. ';


$langA['UNCHECKED_REMOVED'] = 'Bandiera ”Neselectat” a fost eliminată pentru acest fişier';

$langA['NO_KEYWORDS'] = 'Nu exista nici un set de cuvinte cheie pentru acest fişier. Doriţi să <a %s>adăugaţi cuvînt cheie</a> sau <a %s>sa blogaţi acum</a>?';

$langA['file_id'] = 'ID-ul fișierului';

//watch
$langA['WATCH_UPDATED'] = '<a %s>Lista voastră de urmărire</a> a fost actualizată.';


$langA['user_permissions'] = 'Permisiunile Utilizatorului';
