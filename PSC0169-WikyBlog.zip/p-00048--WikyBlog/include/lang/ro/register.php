<?php
$langA['ILLEGAL_USERNAME'] = 'Numele de utilizator nu pot include următoarele caractere: %s';
$langA['LONG_USERNAME'] = 'Nume Utilizator prea lung';	
$langA['SHORT_USERNAME'] = 'Nume Utilizator prea scurt';
$langA['USER_TAKEN'] = 'Vă rugam sa alegeți alt Nume Utilizator. <tt>%s</tt> este ocupat. ';
$langA['USERNAME_ALL_DIGITS'] = 'Numele Utilizator nu poate conține cifre.';
$langA['PASSWORDS_DIFFERENT'] = 'Password-urile nu coincid';
$langA['SHORT_PASSWORD'] = 'Password prea scurt';
$langA['EMAIL_REQUIRED'] = 'Vă rugăm să furnizaţi o adresă de email validă.';


$langA['register'] = 'Registreazăte';
$langA['welcome_to'] = 'Bine Ați Venit În ';
$langA['REG_USERNAME'] = 'Un ID unic de 3-20 caractere';
$langA['REG_PASSWORD'] = 'Trebuie să aibă cel puțin 5 caractere.';
$langA['confirm_password'] = 'Confirmă parola';
$langA['REG_CONFIRM_PASS'] = 'La fel ca si cele de mai sus.';
$langA['REG_EMAIL'] = 'Opţional, dar util în cazul în care uitaţi parola.';
$langA['REQUIRED_FIELD'] = 'Indică un câmp obligatoriu.';

$langA['REGISTRATION_TEXT'] = 'Inregistrarea este rapidă, gratuită si are multe beneficii...';
$langA['REG_A_USER_PAGE'] = '/NumeUtilizator/Pagina_Voasră';
$langA['REG_A_MAP_PAGE'] = '/Mapa/NumeUtilizator/Mapa_Voasră';

//login
$langA['LOGGED_IN'] = 'Sunteți logat ca <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'Numele de utilizator furnizat nu există. Doriţi să înregistraţi %s?';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Succes! Faceţi clic pe link-ul de activare din e-mailul trimis la %s pentru a vă activa contul.';
$langA['ACTIVATE_ACCOUNT'] = 'Activează contul meu acum.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Contul dvs. a fost activat cu succes.';
$langA['INVALID_CODE'] = 'Codul de confirmare furnizat nu mai este valabil.';
