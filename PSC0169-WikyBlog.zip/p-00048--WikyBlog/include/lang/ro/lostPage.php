<?php

$langA['lost_page'] = 'Pagină pierdută';
$langA['PAGE_NOT_FOUND'] = 'Pagina dorită <tt>%s</tt> nu a putut fi gasita.';
$langA['REGISER_AS_USER'] = 'Se pare contul de utilizator <tt>%s </tt> nu a fost creat. Doriţi să %s cu acest nume de utilizator?';
$langA['LINK_TYPO'] = ' Verificaţi tipul link-ului pentru pagina de trimitere: ';
$langA['REGISTER_TO_CREATE'] = 'Crează această pagină de prima înregistrare cu nume de utilizator <tt>%s </tt>.';