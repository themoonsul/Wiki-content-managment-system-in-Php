<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'Numele fișierului nu a fost schimbat.';
$langA['NOT_RENAMED'] = 'Acest fişier nu a putut fi redenumit în <tt>%s </tt>. Vă rugăm să vă asiguraţi că acest fişier nu există deja.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'Nu e posibil de redenumit acest fișier.';
$langA['redirected_to'] = 'Redirecționat la';
$langA['RENAMED'] = 'Fișierul a fost redenumit cu succes.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b> a fost restaurat. ';
$langA['ERROR_RESTORING'] = '<b>Eroar:</b> Nu e posibilă restabilirea fișierului <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = 'File-ul a fost restaurat.';
$langA['WAS_DELETED'] = '<b>%s</b> a fost eliminat. El v-a fi păstrat in %s timp de 30 de zile.';
$langA['ERROR_DELETING'] = '<b>Eroare:</b> Nu pot elimina fileul ca <tt>%s.</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> a fost eliminat.';
