<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Fişier';
$langA['edit'] = 'Editează';
$langA['edits'] = 'Editări';
$langA['view_source'] = 'Vizualizează sursa';
$langA['talk'] = 'Discuţie';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Istoric';
$langA['diff'] = 'Diferenţe';
$langA['watch'] = 'Privește';
$langA['unwatch'] = 'Nu privi';
$langA['options'] = 'Opţiuni';


$langA['messages'] = 'Mesaje';
$langA['current'] = 'Actual';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Posibil';

$langA['DEFAULT_CONTENT'] = 'Acesta este un fişier nou, doriţi să-l [[%s?cmd=edit|creaţi]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Acesta este un fişier nou. Pentru a crea acest fişier trebuie să vă autentificaţi cu privilegiile corespunzătoare.';

$langA['NOT_OWNER'] = 'Nu aveţi drepturile corespunzătoare pentru această opţiune.';
$langA['LONG_PATH'] = 'Titlul acestui fişier a fost prea lung şi a fost trunchiat.';
$langA['EMPTY_CONTENT'] = 'Conţinutul este un câmp necesar';
$langA['INCOMPLETE_PATH'] = 'Calea introdusă este incompletă.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Ne pare rău, administratorul website-ului a dezactivat blogul utilizatorilor. Pentru a crea o bliki cu aceleaşi capabilităţi, vizitaţi <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'Titlul dorit există deja, vă rugam sa alegeţi altul şi să salvaţi din nou.';

$langA['HIDDEN_FILE'] = 'Accesul la acest fisier a fost restricţionat de către proprietarul său. Pentru a vizualiza acest fişier, aveţi nevoie de privilegiile corespunzătoare.';
$langA['HIDDEN_FILE2'] = 'Fişierul este "ascuns". ';
$langA['DELETED_FILE'] = 'Fişierul este momentan în "coşul de gunoi". Dacă sunteţi deţinătorul acestui cont, puteţi restaura fişierul din panoul de control.';
$langA['PROTECTED_FILE'] = 'Fişierul este protejat. Orice modificări făcute acestui fişier nu au fost salvate.';
$langA['INVALID_THEME'] = 'Nume de temă nevalabil definit în preferinţe. Utilizez tema predefinită.';
$langA['link_text'] = 'Textul legăturii';
$langA['SURPASSED_MAX'] = '<b> Atenţie: </b> Utilizarea discului a depășit limita alocată. Orice modificări aduse la acest dosar nu au fost salvate.';


$langA['REDIRECTED'] = 'Redirecţionează de la %s';
$langA['REDIRECT_TO'] = 'Această pagină redirecţionează către %s.';

//	Data Types
$langA['all'] = 'Toate';
$langA['page'] = 'Pagină';
$langA['comment'] = 'Comentariu';
$langA['map'] = 'Hartă';
$langA['template'] = 'Şablon';
$langA['help'] = 'Ajutor';
$langA['skeleton'] = 'Schelet';
$langA['attach'] = 'Atașament';

$langA['theme'] = 'Temă';

$langA['comments'] = 'Comentarii';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Pagini';
$langA['CLASScomment'] = 'Comentarii';
$langA['CLASSmap'] = 'Hărţi';
$langA['CLASStemplate'] = 'Teme';
$langA['CLASShelp'] = 'Ajutor';
$langA['IS_CONTENT_TEMPLATE'] = 'Acest fişier este un şablon şi nu va fi afişat în blog-ul.';


$langA['seconds'] = ' secunde';
$langA['queries'] = ' cereri';

$langA['QUERY_TIME'] = ' pentru cereri';
$langA['INVALID_PATH'] = 'Calea fişierului invalidă: <tt>%s</tt>';							//replaced with path
$langA['INVALID_REQUEST'] = 'Cerere formulată greșit';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'Aceasta este o nouă temă. Editaţi această temă, făcând clic pe "Editare", link-ul de mai sus. <br/> Când creaţi teme să vă amintiţi să includeţi toate variabilele necesare:';
$langA['your_theme'] = 'Tema voastră';
$langA['CURRENT_THEME'] = 'În prezent folosiți tema <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Folosește acestă temă.';
$langA['using_this_theme'] = 'Folosiți deja această temă.';
$langA['MAKE_THEME'] = 'Faceţi o tema personalizată folosind o copie a prezentei teme o ca punct de start.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editarea</h2> Când editați teme, modificările nu vor fi vizibile imediat.<br />Va trebui sa reîmprospatați sau sa reîncărcați pagina ca să vedeți schimbările.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'Ca parte integrată a produsului software, acest ajutor este stocat pe un server central. <br/> Puteţi edita conţinutul %s, lui %s şi altor fişiere de la%s.';

$langA['NEW_HELP'] = 'Creaţi un nou fişier de ajutor';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Răsfoiţi';
$langA['change_log'] = 'Istoric';
$langA['control_panel'] = 'Panoul de control';
$langA['administration'] = 'Administrare';
$langA['preferences'] = 'Preferințe';
$langA['watchlist'] = 'Listă de urmărire';
$langA['wanted_files'] = 'Fișierele solicitate';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'Caută';
$langA['orphaned_files'] = 'Fișiere abandonate';
$langA['most_linked'] = 'Cele mai căutate fişiere';
$langA['scrl'] = 'Ameliorați defilarea';
$langA['nWin'] = 'Lincuri externe';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'Posturi mai recente';
$langA['NEED_INTERNET'] = 'Această opţiune este disponibilă doar pentru sisteme conectate la Internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Avertizare:</b>Cookie sunt necesare pentru a continua. Reactualizaţi această pagină dacă aveţi cookie activate.';
$langA['LOGIN_REQUIRED'] = 'Trebuie să vă autentificaţi pentru a folosi această opţiune.';

$langA['ENTER_USERNAME'] = 'Vă rugăm introduceţi ID-ul.';
$langA['ENTER_PASSWORD'] = 'Vă rugăm introduceţi Parola.';
$langA['LOGGED_OUT'] = 'V-aţi dezautentificat cu succes.';
$langA['AUTO_LOGOUT'] = 'Sesiunea dvs. a expirat.';

$langA['LOGIN_FAILED'] = 'Logare eșuată: Password greșită.<ul><li>Aveți activ CAPS LOCK?<li> Ați  %suitat password-ul%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'Numărul maxim de %s tentative pentru a va loga a fost depășit. Nu mai puteți incerca pentru următoarele %s minute.';
						
$langA['create_new'] = 'Crează&nbsp;Nou ';
$langA['remember_me'] = 'Ţine-mă minte';
$langA['log_out'] = 'Dezautentificare';
$langA['log_in'] = 'Autentificare';

//	SAVING 
$langA['syntax_error'] = 'eroare de sintaxă';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'O eroare de <a %s>syntaxă</a> a fost detectată în acest fişier şi poate duce la formatare nedorită.';

$langA['OTHER_ACCOUNT'] = 'Ați vrea să vreați fișiere pentru %s în loc de %s.';
$langA['MAKE_ADMIN'] = 'Setează <a %s>opțiunile fișierului</a> la "<tt>DOAR ADMINISTRATORUL</tt>" ca să evitați verificarea sintaxei.';


$langA['THEME_SYNTAX_WARN'] = '<b>Syntax Error:</b> Nu reușesc sa Salvez/Arăt ultimele schimbari facute la acest file, sintaxă incompatibilă.';
$langA['SYNTAX_FIXED'] = 'Eroarea de sintaxă a fost reparată.';


$langA['NO_CHANGES'] = 'Nicio schimbare nu a fost făcută acestui fişier. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Nu pot să salvez file-ul. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Schimbările la acest file au fost salvate cu succes.';
$langA['HIDDEN_FILE3'] = '<b>Notează:</b> Acesta este un file ascuns, deci tagul pentru acest file nu va fi inclus totalurile userilor.';

$langA['VERSION_CONFLICT'] = 'PERICOL: Nu veți putea salva schimbările la acest file deoarece au fost identificate conflicte intre versiuni.';
$langA['VERSION_CONFLICT_2'] = 	'Atenţie: Nu am putut salva modificările, deoarece am descoperit o versiune de conflict. Următoarele evenimente ar putea să fi dus la această discrepanţă. <ul> <li> S-ar putea să ca dvs. sa suprascrieți un fişier existent. </li> <li> Sesiunea dvs. poate fi expirată. </li> <li> posibil ca altcineva să fi salvat modificările în acest fişier. </li> </ul>';

$langA['COPY_TO'] = 'Copie&nbsp;<b>%s</b>&nbsp;la&nbsp;<b>%s</b>. <br/> Faceţi clic pe "Salvare" pentru a finaliza copierea.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Editarea a fost limitată la un file fiecare %s secunde. Vă invitam să încercați peste %s secunde.';
$langA['INCORRECT_CAPTCHA'] = 'Imaginea CAPTCHA nu sa potrivit cu textul dvs., vă rugăm să încercaţi din nou.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Salveaza Opțiunile';
$langA['blog_this'] = 'Pune in Blog';



//	toolHistory2.php
$langA['differences'] = 'diferența (e)';
$langA['line_num'] = 'Rindul nr.';


//	toolHistory1.php
$langA['revision'] = 'Revizia ';
$langA['revision_as_of'] = 'Reviziat ca ';
$langA['revision_num_as_of'] = 'Reviziat %sca%s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Editează revizia';
$langA['revert_to_revision'] = 'Întoarcete la această revizie';
$langA['reverted_to_rev'] = 'Întoarce la revizia nr.';
$langA['SET_USER_PERMISSIONS'] = 'Setează permisiunile tale acestui utilizator: '; 
$langA['compare_with_prev'] = '← Compară cu revizia precedentă';
$langA['current_revision'] = 'Revizia curentă';
$langA['compare_with_next'] = 'Compară cu urmatoarea revizie →';
$langA['lines'] = 'Linii';
$langA['text'] = 'Text';
$langA['vs'] = ' vs ';
$langA['content'] = 'Conținut';
$langA['your_text'] = 'Textul D-voastră';
$langA['show_prev_revision'] = '← Revizia %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revizia %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Atenție:</b> Editați o versie mai veche al acestui file.<br /> Cînd veți salva versia nouă va fi înlocuită cu acesta veche.';
$langA['SELECT_TWO_VERSIONS'] = 'Alegeți două versii diferite ca sa le comparați.';
$langA['NO_UNIQUE_REVISION'] = 'Nu a fost gasita nici o revizie pentru cererea D-voastră.';
$langA['INVALID_REVISION'] = '<b>Eroare:</b> Numar de Revizie Greșit.';
$langA['NO_DIFFERENCES'] = 'Reviziile de comparat sunt identice.';
$langA['NO_REVISIONS'] = 'Trebuie sa alegeti doua revizii diverite pentru a putea fi comparate.';
$langA['NON_EXISTANT'] = 'Acest fișier nu există încă.';

//	toolEditPage.php
$langA['bold_text'] = 'Text GROS';
$langA['italic_text'] = 'Text înclinat';
$langA['headline_text'] = 'Introdu Heading';
$langA['title'] = 'Titol';
$langA['unordered_list'] = 'Lista neordonată';
$langA['ordered_list'] = 'Lista ordonată';


$langA['internal_link'] = 'Legătură internă';
$langA['link'] = 'Legătură';
$langA['external_link'] = 'Legătură externă';
$langA['embed_image'] = 'Imaginea emblemă';
$langA['find_images'] = 'Caută imagini';
$langA['image'] = 'Imagine';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'Intruduceți textul simplu, nu formatat.';
$langA['signature'] = 'Semnătură';
$langA['SIGNATURE_TEXT'] = 'Introduceți semnătura voastră';
$langA['preview'] = 'Previzualizare';
$langA['PREVIEW_TEXT'] = 'Vedeţi schimbările dvs. [%s-p]';
$langA['PREVIEW_WARN'] = 'Aceasta este doar o previzualizare. Modificările nu au fost încă salvate!';
$langA['SAVE_TEXT'] = 'Salvați schimbările dvs. [%s-s]';
$langA['reset'] = 'Reset';
$langA['RESET_TEXT'] = 'Resetează acest formular [%s-c]';
$langA['changes'] = 'Schimbări';
$langA['CHANGES_TEXT'] = 'Arată schimbările farute de mine la acest fişier. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organizaţi-vă posturi-le cu cuvinte cheie separate prin virgulă'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Taguri';
$langA['edit_summary'] = 'Sumarul editării';
$langA['syntax_warning'] = 'Pericol de sintaxă.';
$langA['NO_IMAGES'] = 'Nici o imagine găsită.';
$langA['insert_emoticons'] = 'Introdu emoticons.';
$langA['upload'] = 'Încarcă';



//searchHistory
$langA['show'] = 'Arată';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Compară';
$langA['timeline'] = 'Linia timpului';
$langA['summary'] = 'Rezumat';
$langA['COMPARE_REVISONS'] = 'Comparaţi cu versiunea selectată.';
$langA['unchecked'] = 'Nonselecționat';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Tipul de fişier introdus este invalid.';


//	SEARCH
$langA['next'] = 'Înainte';
$langA['previous'] = 'Înapoi';
$langA['order_by'] = 'Sortează după:';
$langA['ascending'] = 'Ascendent';
$langA['descending'] = 'Descendent';
$langA['search_from'] = 'Caută prin: ';
$langA['all_users'] = 'Toţi utilizatorii';
$langA['user'] = 'Utilizator';
$langA['from_file_type'] = 'Caută tipul de fişiere: ';
$langA['read_more'] = 'Citeşte mai mult';
$langA['words'] = ' cuvinte';

$langA['RESULTS'] = 'Rezultatele %s-%s din %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Nici un rezultat găsit pentru criteriile dvs.';

//searchTalk
$langA['add_comment'] = 'Adaugă un nou subiect';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Nu se poate include avertizarea. Prost formatat pentru datele de intrari duplicate.';
$langA['duplicate_entry'] = 'Intrare duplicată';
$langA['DUPLICATE_ENTRY'] = 'Acesta este un duplicat al paginii %s. <br/>Orice informaţii neredundante ar trebui transcrise în original înainte de a şterge această pagină.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Nu am găsit: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Eroare:</b><br /> A apărut o eroare în timpul executării acestui script.<br /> Vă rugăm să verificaţi cererea dumneavoastră ! %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Şablonul standard nu poate fi şters.';
$langA['THEME_MISSING_VARS'] = 'Lipsesc variabilele necesare: <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'Tema specificată nu este validă.';

//
//	CLASSmap
//
$langA['new_marker']='Marker Nou';
$langA['new_route']='Rută nouă';
$langA['SAVE_HEADER']='Înainte de a salva ține minte.';
$langA['save_map']='Salvează harta';
$langA['continue_editing']='Continuă editarea';
$langA['miles/km'] = 'mile/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>Aceasta este o nouă hartă.</b><br/>Pentru a crea/edita această hartă, clicaţi "Editează" de mai sus.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Ne pare rău, nu aveţi privilegii suficiente pentru a edita această hartă.';
$langA['play'] = 'Play';
$langA['stop'] = 'Stop';
$langA['import'] = 'Importă';
$langA['export'] = 'Exportă';
$langA['gpx_data'] = 'Date GPX';
$langA['gpx_exchange_format'] = 'Formatul GPX';
$langA['CLICK_EDIT'] = 'Pentru a edita această hartă, clicaţi "Editează" de mai sus';


//	smileys
$langA['smiles'][':D'] = 'Foarte fericit';
$langA['smiles'][':)'] = 'Zîmbet';
$langA['smiles'][':('] = 'Trist';
$langA['smiles'][':o'] = 'surprins';
$langA['smiles'][':shock:'] = 'Şocat';
$langA['smiles'][':?'] = 'Confuz';
$langA['smiles']['8)'] = 'Mișto';
$langA['smiles'][':lol:'] = 'Rîde';
$langA['smiles'][':x'] = 'Supărat';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Amețit';
$langA['smiles'][':cry:'] = 'Strigă sau foarte rau';
$langA['smiles'][':evil:'] = 'Drăcușor';
$langA['smiles'][':twisted:'] = 'Dracușor șueră';
$langA['smiles'][':roll:'] = 'Rotește ochii';
$langA['smiles'][':wink:'] = 'Clipoci';
$langA['smiles'][':!:'] = 'Exclamare';
$langA['smiles'][':?:'] = 'Întrebare';
$langA['smiles'][':idea:'] = 'Idee';
$langA['smiles'][':arrow:'] = 'Săgeată';
$langA['smiles'][':|'] = 'Neutru';
$langA['smiles'][':mrgreen:'] = 'D-nul Verde';

//
//	General Language
//
$langA['or'] = 'sau';
$langA['username'] = 'Nume Utilizator';
$langA['password'] = 'Parolă';
$langA['email'] = 'E-mail';
$langA['register'] = 'Registreazăte';
$langA['cancel'] = 'Anulează';
$langA['language'] = 'Limba';
$langA['use'] = 'Folosește';
$langA['copy'] = 'Copiază';
$langA['rename'] = 'Redenumește';

$langA['on'] = 'Aprins';
$langA['partial'] = 'Parţial';
$langA['off'] = 'Stins';
$langA['save'] = 'Salvează';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Nedefinit';
$langA['homepage'] = 'Pagina de start';
$langA['home'] = 'Acasă';
$langA['go'] = 'Dute';
$langA['user_menu'] = 'Menu-ul utilizatorului';

$langA['last_modified'] = 'Ultimul modificat';
$langA['LAST_MODIFIED'] = 'Ultima modifica %s de către %s';//%s replaced with date and username
$langA['accessed_times'] = 'Accesat %s time';// %s replaced with a number
$langA['modified'] = 'Modificat';
$langA['posted'] = 'Scris';
$langA['created'] = 'Creat';
$langA['hidden'] = 'Ascuns';
$langA['what_links_here'] = 'Ce se leagă aici';
$langA['share'] = 'Împărtăşește';
$langA['INVALID_LINK'] = 'Numele paginii solicitate este formulat greşit. Posibil să conţină caractere care nu pot fi folosite în titluri. Vă rugam să verificaţi.';
$langA['FILE_MUST_EXIST'] = 'Acest file trebuie salvat inainte de a putea face acțiunea dorită';

$langA['OOPS'] = 'Hopa, că nu funcţionează, vă rugăm să încercaţi din nou.';


$langA['size'] = 'Mărime ';
$langA['bytes'] = 'bytes';
$langA['kb'] = 'Ko';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Actualizează';
$langA['editing'] = 'Redactare';
$langA['workgroup'] = 'Grup de lucru';
$langA['BROWSE_HIDDEN'] = 'Caută fişiere ascunse';

$langA['delete'] = 'Elimina';
$langA['confirm_delete'] = 'Confirmă eliminarea';
$langA['continue'] = 'Continuă';
$langA['back'] = 'Înapoi';
$langA['close'] = 'Închide';
$langA['view'] = 'Privește';
$langA['empty'] = '-gol-';
$langA['none'] = 'Nimic';
$langA['total'] = 'Total ';
$langA['files'] = 'Fişiere';
$langA['other'] = 'Altul';
$langA['trash'] = 'Coş';
$langA['flagged'] = 'Marcat';

$langA['today'] = 'Azi';
$langA['yesterday'] = 'Ieri';
$langA['days_ago'] = ' acum câteva zile';
$langA['page_contents'] = 'Conţinutul paginii';
$langA['more'] = 'Mai mult';
$langA['download'] = 'Descarcă';


//Date
$langA['date_l'][0] = 'Dominică';
$langA['date_l'][1] = 'Luni';
$langA['date_l'][2] = 'Marți';
$langA['date_l'][3] = 'Miercuri';
$langA['date_l'][4] = 'Joi';
$langA['date_l'][5] = 'Vineri';
$langA['date_l'][6] = 'Sîmbăta';

$langA['date_D'][0] = 'Dum';
$langA['date_D'][1] = 'Lun';
$langA['date_D'][2] = 'Mar';
$langA['date_D'][3] = 'Mie';
$langA['date_D'][4] = 'Joi';
$langA['date_D'][5] = 'Vin';
$langA['date_D'][6] = 'Sim';


$langA['date_F'][1] = 'Ianuarie';
$langA['date_F'][2] = 'Februarie';
$langA['date_F'][3] = 'Martie';
$langA['date_F'][4] = 'Aprilie';
$langA['date_F'][5] = 'Mai';
$langA['date_F'][6] = 'Iunie';
$langA['date_F'][7] = 'Iulie';
$langA['date_F'][8] = 'August';
$langA['date_F'][9] = 'Septembrie';
$langA['date_F'][10] = 'Octombrie';
$langA['date_F'][11] = 'Noiembrie';
$langA['date_F'][12] = 'Decembrie';

$langA['date_M'][1] = 'Ian';
$langA['date_M'][2] = 'Feb';
$langA['date_M'][3] = 'Mar';
$langA['date_M'][4] = 'Apr';
$langA['date_M'][5] = 'Mai';
$langA['date_M'][6] = 'Iun';
$langA['date_M'][7] = 'Iul';
$langA['date_M'][8] = 'Aug';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'Oct';
$langA['date_M'][11] = 'Nov';
$langA['date_M'][12] = 'Dec';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabă (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'Germana (de)';
$langA['lang']['el'] = 'Greacă (el)';
$langA['lang']['en'] = 'Engleză (en)';
$langA['lang']['es'] = 'Spaniolă(es)';
$langA['lang']['fr'] = 'Franceza (fr)';
$langA['lang']['hu'] = 'Maghiară (hu)';
$langA['lang']['it'] = 'Italiană (it)';
$langA['lang']['ja'] = 'Japoneza (jp)';
$langA['lang']['ko'] = 'Coreană(ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Olandeză (nl)';
$langA['lang']['pl'] = 'Poloneză(pl)';
$langA['lang']['ro'] = 'Română (ro)';
$langA['lang']['ru'] = 'Rusă (ru)';
$langA['lang']['tr'] = 'Turca (tr)';
$langA['lang']['vi'] = 'Vietramează (vi)';
$langA['lang']['zh'] = 'Chineză(zh)';
$langA['lang']['zh-cn'] = 'Chineza simplificată(zh/cn)';



