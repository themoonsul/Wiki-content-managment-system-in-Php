<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Permisiuni';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'Această pagină specială nu a fost încă definită: <tt>%s</tt>';

//	control panel
$langA['general'] = 'General';
$langA['attachments'] = 'Ataşamente';
$langA['account_info'] = 'Info despre cont';
$langA['error_log'] = 'Log erori';
$langA['advanced_search'] = 'Căutare&nbsp;Avansată';
$langA['configuration'] = 'Configuraţie';
$langA['search_options'] = 'Opţiuni căutare';
$langA['data_types'] = 'Tipuri de date';
$langA['plugins'] = 'Pluginuri';
$langA['dynamic_content'] = 'Conținut dinamic';

$langA['tabs'] = 'File';
$langA['account_display'] = 'Panoul contului';
$langA['links'] = 'Legaturi';
$langA['go_to'] = 'Dute la %s';


$langA['user_statistics'] = 'Statistici utilizatorilor';
$langA['database_info'] = 'Informație despre databază';
$langA['user_preferences'] = 'Preferințele Utilizatorului';
$langA['content_license'] = 'Conținutul licenței';
$langA['user_permissions'] = 'Permisiunile Utilizatorilor';
$langA['default_page_options'] = 'Opțiunile de bază a paginii';
$langA['account_details'] = 'Detalii despre cont';
$langA['manage_images'] = 'Administrează imaginile';
$langA['manage_files'] = 'Gestionarea&nbsp;fişierelor';
$langA['upload_files'] = 'Incarcă fileurile';
$langA['public_templates'] = 'Șabloanele publice';
$langA['feeds'] = 'Sindacatul - Feeds';
$langA['recently_modified'] = 'Modificate recent';
$langA['recently_posted'] = 'Publicate recent';
$langA['user_edits'] = 'Editările utilizatorului';

$langA['CONTROL_PANEL_1'] = 'Acesta este panoul de control pentru <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Ați vrea sa vedeți %s vostru.';

//specTemplates
$langA['pTemplate'] = 'Pachetul cu teme';
$langA['custom_theme'] = 'O temă la întîmplare';
$langA['current_theme'] = 'Tema curentă';
$langA['TEMPLATES_UNAVAILABLE'] = 'Directorul cu pachetele Șabloanelor nu este disponibil.';
$langA['themes']['default'] = 'Predefinit';
$langA['themes']['simple'] = 'Simplu';
$langA['themes']['three_columns'] = 'Trei Coloane';
$langA['themes']['floating'] = 'Fluturător';
$langA['themes']['graphic'] = 'Grafică';

$langA['colors']['colors'] = 'Culori';
$langA['colors']['black'] = 'Inapoi';
$langA['colors']['blue'] = 'Albastru';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Maro';
$langA['colors']['green'] = 'Verde';
$langA['colors']['light_blue'] = 'Albastru deschis';
$langA['colors']['green'] = 'Verde';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Roșu';
$langA['colors']['orange'] = 'Oranj';
$langA['colors']['gray'] = 'Sur';


$langA['customize_this_theme'] = 'Personalizează această temă';



//searchHidden.php
$langA['browse_hidden'] = 'Parcurge ce-i ascuns';
$langA['editor_visible'] = 'Viyibil pentru editori';


//	WorkGroup.php
$langA['update_permissions'] = 'Actualizează permisiunile';
$langA['username_or_ip'] = 'Numele utilizatorului sau IP';
$langA['status'] = 'Statutul';
$langA['workgroup'] = 'Grup de lucru';
$langA['admin'] = 'Administratorul';
$langA['full_owner'] = 'Plin / Stapîn';
$langA['ban'] = 'Banează';
$langA['banned'] = 'Banat';

//	friends.php
$langA['friends'] = 'Prieteni';
$langA['my_status'] = 'Statutul meu';


$langA['EX_USERNAMES'] = 'exemplu: <a>Den_X</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'Nu ați specificat nici o permisiune';
$langA['view_users'] = 'Vezi acest utilizator...';
$langA['change'] = 'Schimbă';
$langA['users'] = 'Utilizatori';

$langA['USER_REMOVED'] = 'Utilizatorul <tt>%s</tt> a fost eliminat din acest GrupDeLucru';
$langA['USER_NOT_REMOVED'] = 'Utilizatorul <tt>%s</tt> nu a fost eliminat din acest GrupDeLucru ';
$langA['ADDED_PERMISSIONS'] = 'Au fost adaugate permisii pentru <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Actualizează permisiunile pentru <tt>%s</tt>.';
$langA['NOT_A_USER'] = 'Utilizatorul <tt>%s</tt>. nu poate fi găsit.';
$langA['IP_NOT_ADDED'] = 'Nu pot sa adaug/modific permisiunile pentru <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>Pericol:</b> Utilizatorul <tt>%s</tt> este deja stapînul acestui cont.';
$langA['IP_WRONG_LEVEL'] = '<b>Pericol:</b> Unei adrese IP nu poate fi acordat privilegii mai mari decât "GrupulDeLucru".';
$langA['SET_PERMISSIONS'] = 'Pentru a seta permisiuni pentru " %s ", selectaţi stare dorită, apoi faceţi clic pe "Actualizare de permisiuni".';


//	specLostPass
$langA['lost_password'] = 'Parolă pierdută';



//	specFileManager
$langA['file_manager'] = 'Manager de fişiere';
$langA['image_manager'] = 'Gestionarea Imaginilor';
$langA['CONFIRM_FILE_DELETE'] = 'Sunteţi sigur că doriţi să ştergeţi <b>%s</b>?';
$langA['IMAGE_MANAGER_INTRO'] = 'Aveţi dreptul să utilizaţi sintaxa wiki sau html pentru a include aceste imagini în paginile dumneavoastră. Pentru anumite tipuri de fişiere (template-uri, hărți ..) vă recomandăm să folosiţi sintaxa html.';
$langA['FILE_MANAGER_INTRO'] = 'Aveţi dreptul să utilizaţi sintaxa wiki sau html pentru a include aceste imagini în paginile dumneavoastră. Pentru anumite tipuri de fişiere (template-uri, harti ..) vă recomandăm să folosiţi sintaxa html.';
$langA['file_name'] = 'Numele fileului';
$langA['available_space'] = 'Spațiul disponibil';
$langA['UPLOAD_INTRO'] = 'Încarcă ataşamentele şi imaginile pentru a fi incluse în paginile dumneavoastră.';
$langA['file_upload'] = 'Încarcă File';
$langA['file_info'] = 'Info despre file';
$langA['width'] = 'Lățimea';
$langA['height'] = 'Înalțimea';
$langA['file_location'] = 'Locația fișierului';
$langA['wiki_syntax'] = 'Sintaxa Wiky';
$langA['html_syntax'] = 'Sintaxa HTML';
$langA['append_to'] = 'agață la';
$langA['count'] = 'Numara';
$langA['total_size'] = 'Marimea totală';
$langA['images'] = 'Imagini';
$langA['overwrite_existing'] = 'Suprascrie cel existent';
$langA['compression'] = 'Compresie';

$langA['NOT_AN_IMAGE'] = 'Fişierul nu pare să fie o imagine. Vă rugăm să verificaţi fişierul, apoi încercaţi din nou. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'Nu pot sa elimin fileul <tt>%s</i>.';
$langA['UPLOADED'] = 'Fileul <tt>%s</tt> a fost încărcat cu succes.';
$langA['UPLOADED_RENAMED'] = 'Fişierul <tt>%s</tt> a fost încărcat ca <tt>%s</tt>. Îl puteţi <a %s>redenumi în %s</a>.';
$langA['RENAMED'] = 'Fișierul a fost redenumit cu succes.';
$langA['UPLOAD_FAILED'] = 'Eroare in timpul copierii fileului: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Nu pot încărca acest fişier <tt>%s</tt>. <br/>Fişierul trebuie să aibă mai puţin decît <tt>%s</tt> byte.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> a fost doar parţial încărcat. Vă rugăm să încercaţi din nou.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Selecționeaza tipul de file:';
$langA['default_options'] = 'Preferințe predefinite';
$langA['UNKNOWN_FILE_TYPE'] = 'Tip de file necunoscut: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Cont';
$langA['entries'] = 'Intrări';
$langA['average'] = 'Mediu';
$langA['uploaded_files'] = 'Au fost încarcate fileurile';


//	searchTrash
$langA['deleted'] = 'Eliminat';
$langA['restore'] = 'Restabilește';
$langA['empty_trash'] = 'Cutia de gunoi goală';
$langA['CONFIRM_EMPTY_TRASH'] = 'Sunteți sigur ca vreți sa goliți cutia de gunoi?';

$langA['DELETED_AFTER_30'] = 'Fișierele vor fi eliminate automat după 30 zile.';
$langA['check_uncheck'] = 'Selecționeaza/Deselecționeaza tot';
$langA['DELETED_FILES'] = 'Fișierele selecționate au fost eliminate cu succes.';
$langA['NOTHING_DELETED'] = 'Nu a fost eliminat nimic.';
$langA['DELETE_FILES'] = 'Alegeți fileul de eliminat.';
$langA['MAP_INVALID_PT'] = 'Harta incorectă a datelor: Invalid Point Format';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'Caracteristica de căutare pentru acest site nu pare să fie activată. Administratorii site-ului pot activa această facilitate prin intermediul Opţiuni de căutare în panoul de control.';
$langA['search:'] = 'Cauta: ';
$langA['search_for'] = 'Cauta după: ';
$langA['registered'] = 'Registrat';
$langA['restricted'] = 'Restricţionat';
$langA['locked'] = 'Încuiat';
$langA['disabled'] = 'Dezactivat';
$langA['editing_option'] = 'Opțiuni de editare';
$langA['comments_option'] = 'Opțiuni pentru comentarii';
$langA['visibility_option'] = 'Opțiuni pentru Vizibilitate';
$langA['normal'] = 'Normal';
$langA['advanced'] = 'Avansat';
$langA['relevance'] = 'Relevantă';
$langA['SEARCH_ONE'] = 'Pentru cel puţin unul dintre cuvinte';
$langA['SEARCH_ALL'] = 'Pentru toate cuvintele';
$langA['SEARCH_EXACT'] = 'Pentru frază';
$langA['SEARCH_WITHOUT'] = 'Fară cuvinte';
$langA['SEARCH_BEGIN'] = 'Pentru cuvintele care încep cu';


//	searchKeywords
$langA['keyword_search'] = 'Căutare dupa cuvinte cheie';
$langA['non_tagged_files'] = 'File non taggat';

//	searchChangeLog
$langA['new'] = 								'Nou';
$langA['DIFF_TITLE'] = 							'Compara diferenţele cu cea mai recente revizie';
$langA['indicates_syntax_error'] = 				'Indică o eroare de sintaxă.';
$langA['indicates_unchecked'] = 				'Indică un fişier neselectat.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Selecționează Licența';
$langA['SELECT_LICENSE_DESC'] = 'Creative Commons deschide o pagină Web într-o fereastră pop-up.';
$langA['DELETE_LICENSE_DESC'] = 'Acest lucru va elimina conţinutul licenţei dvs. curentă.';
$langA['LICENSE_UPDATED'] = 'Conţinut Licenței Dumneavoastră a fost actualizat cu succes.';
$langA['LICENSE_DELETED'] = 'Licența a fost eliminată';
$langA['LICENSE_DELETED2'] = 'Licenta a fost ştearsă.';
$langA['customize_license'] = 'Personalizați Licența D-voastră';

$langA['text_before'] = 'Text înaintea legăturii';
$langA['text_after'] = 'Text după legătură';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Cu excepţia cazului în care se menţionează în mod expres, acest lucru este licentiata sub o ';
$langA['LICENSE_TEXT_LINK'] = 'Licență Creative Commons';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'Editările mele';

//reorganize
$langA['reorganize'] = 'Reoranizează';
$langA['from'] = 'De la';
$langA['to'] = 'La';
$langA['KEYWORDS_UPDATED'] = 'Cuvintele cheie au fost actualizate.';
$langA['KEYWORDS_EMPTY'] = 'Nu aţi creat încă nici un fisier cu cuvinte cheie.';
$langA['REORGANIZE'] = 'Aici, puteți restructura fișierele redenumind cuvintele cheie pe care le-ati folosit.';

//watch
$langA['WATCH_UPDATED'] = '<a %s>Lista voastră de urmărire</a> a fost actualizată.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Etichetă';
$langA['description'] = 'Descriere';
$langA['add_link'] = 'Adaugă legătură';
$langA['link_groups'] = 'Grupuri de legături';
$langA['group'] = 'Grup';
$langA['name'] = 'Nume';
$langA['add_group'] = 'Toate Grupile';
$langA['add_page'] = 'Adaugă pagină';

$langA['limit'] = 'Limita';
$langA['random'] = 'Aleator';
$langA['order'] = 'Aranjează';
$langA['LEAVE_EMPTY'] = 'Lăsaţi gol pentru nici o limită';
$langA['unlimited'] = 'Nelimitat';
$langA['type'] = 'Tip';
$langA['auto_detect'] = 'Auto detecţie';
$langA['bookmarklet'] = 'Bookmarklet(semn de carte)';
$langA['move_up'] = 'Mișcă sus';
$langA['move_down'] = 'Mișcă jos';
$langA['redirect'] = 'Redirecție';
$langA['content_template'] = 'Şablon conţinut';

