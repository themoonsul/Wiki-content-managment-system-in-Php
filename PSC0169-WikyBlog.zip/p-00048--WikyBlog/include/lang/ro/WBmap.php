<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'Încarc mapa...';
$langA['MAP_DEBUG_O'] = 'A apărut o eroare în timpul încărcării aceastei pagini şi harta pe care aţi solicitat-o nu a putut fi afişată. <p> </p> Un log de eroare a fost creat şi administratorii site-ului ar trebui să rezolve problema în curând.';
$langA['MAP_DEBUG_1'] = 'Google Maps API, nu pare a fi compatibil cu browserul dumneavoastră. <p> Dacă ştiţi că browser-ul dvs. este compatibil, asiguraţi-vă că cheia folosita de Harta este corectă şi că sunteţi conectat la Internet. </p> <p> Puteţi <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top"> obţine mai multe informaţii </a> despre browser-ul de sprijin de la google.com. </p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>Atenție:</b> Mapele necesită de JavaScript pentru a funcționa.</p><p> Se pare că JavaScript nu a fost activat în browser-ul dumneavoastră. Pentru a vedea această hartă, vă rugăm să activaţi JavaScript în browserul dvs., apoi împrospătați/reîncărcaţi această pagină. </p>';