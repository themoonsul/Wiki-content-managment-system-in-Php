<?php

$langA['end_of_document'] = ' --- Sfîrsitul Documentului -- ';
$langA['syntax_warning'] = ' Atenție la sintaxă: ';

$langA['XML_ERROR_INVALID_TOKEN'] = 'Eroarea a fost detectată pe rîndul %s la poziţia %s dar ar putea să fi fost cauzate de liniile anterioare.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Posibile cauze pentru acest avertisment, includ: </strong><br />* <tt>aleator &lt;text</tt> în loc de <tt>aleator &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> în loc de <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> în loc de <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = 'Este necesară închiderea tagurilor HTML ca să fie completat acest ducument: "<em>%s</em>".';

$langA['unnecessary_closing_tag'] = 'Nu e necesară eticheta de închidere.';
$langA['should_be'] = ' ar trebui sa fie ';

$langA['CLOSING_AN_UNOPENED_TAG'] = 'Închiderea unei etichete nedeschisă. <br /> Nu exitsă tag-ul de deschidere pentru <tt> eticheta de închidere %s</tt>.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Posibile cauze de acest avertisment, includ: </strong><br />* <tt>&lt;/tag&gt;</tt> fără <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> în loc de <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Imposibil să închid eticheta.<br /> Eticheta <tt>&lt;%s&gt;</tt> trebuie să fie închisă folosind <tt>%s</tt> ';
$langA['MISSING_CLOSING_TAG2'] = ' înaintea închiderii filei <tt>&lt;/%s&gt;</tt>.';

$langA['AUTOMATED_SYNTAX_ERROR'] = 'Verifică sintaxa automat';
$langA['AUTOMATED_SYNTAX_ERROR2'] = '(%s) pe rîndul %s (din %s rînduri) pe poziția %s ';
$langA['last_open_tag'] = '<br />Ultima Etichetă Deschisă ';
