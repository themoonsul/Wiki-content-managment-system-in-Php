<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Permisos';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'Esta página especial no ha sido definida todavía: <tt>%s</tt>';

//	control panel
$langA['general'] = 'General';
$langA['attachments'] = 'Adjuntos';
$langA['account_info'] = 'Información de la Cuenta';
$langA['error_log'] = 'Log de errores';
$langA['advanced_search'] = 'Busqueda&nbsp;Avanzada';
$langA['configuration'] = 'Configuración';
$langA['search_options'] = 'Opciones de Búsqueda';
$langA['data_types'] = 'Tipos de datos';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Pestañas';
$langA['account_display'] = 'Mostrar Cuenta';
$langA['links'] = 'Enlaces';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = 'Estadística del Usuario';
$langA['database_info'] = 'Base de Datos&nbsp;Información';
$langA['user_preferences'] = 'Preferencias de usuario';
$langA['content_license'] = 'Contenido&nbsp;Licencia';
$langA['user_permissions'] = 'Usuario Permisos';
$langA['default_page_options'] = 'PorDefecto&nbsp;Página&nbsp;Opciones';
$langA['account_details'] = 'Cuenta&nbsp;Detalles';
$langA['manage_images'] = 'Administrar&nbsp;Imágenes';
$langA['manage_files'] = 'Administrar&nbsp;Archivos';
$langA['upload_files'] = 'Subir Ficheros';
$langA['public_templates'] = 'Publicar&nbsp;Plantillas';
$langA['feeds'] = 'Sindicación / Feeds';
$langA['recently_modified'] = 'Recientemente Modificado';
$langA['recently_posted'] = 'Recientemente Publicados';
$langA['user_edits'] = 'Ediciones de usuario';

$langA['CONTROL_PANEL_1'] = 'Este es el Panel de Control para <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Le gustaria ver su %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'El directorio de Paquete de Plantillas no esta disponible.';
$langA['themes']['default'] = 'por defecto';
$langA['themes']['simple'] = 'Simple';
$langA['themes']['three_columns'] = 'Tres Columnas';
$langA['themes']['floating'] = 'Flotando';
$langA['themes']['graphic'] = 'Gráfico';

$langA['colors']['colors'] = 'Colores';
$langA['colors']['black'] = 'Negro';
$langA['colors']['blue'] = 'Azul';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Verde';
$langA['colors']['light_blue'] = 'Celeste';
$langA['colors']['green'] = 'Verde';
$langA['colors']['tan'] = 'Bronceado';
$langA['colors']['red'] = 'Rojo';
$langA['colors']['orange'] = 'Naranja';
$langA['colors']['gray'] = 'Gris';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = 'Navegar Ocultos';
$langA['editor_visible'] = 'Editores visibles';


//	WorkGroup.php
$langA['update_permissions'] = 'Permisos de actualización';
$langA['username_or_ip'] = 'Nombre de usuario o IP';
$langA['status'] = 'Estado';
$langA['workgroup'] = 'Grupo de trabajo';
$langA['admin'] = 'Admin';
$langA['full_owner'] = 'Completo / Dueño';
$langA['ban'] = 'Amonestar';
$langA['banned'] = 'Amonestado';

//	friends.php
$langA['friends'] = 'Amigos';
$langA['my_status'] = 'Mi Estado';


$langA['EX_USERNAMES'] = 'ej: <a>Jose</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'No especifíco ningún permiso.';
$langA['view_users'] = 'Ver de este Usuario...';
$langA['change'] = 'Cambiar';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = 'El Usuario <tt>%s</tt> fue removido de este grupo de trabajo.';
$langA['USER_NOT_REMOVED'] = 'El Usuario <tt>%s</tt> no pudo ser removido con éxito de este grupo de trabajo. ';
$langA['ADDED_PERMISSIONS'] = 'Permisos agregados para <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Permisos actualizados para <tt>%s</tt>.';
$langA['NOT_A_USER'] = 'El nombre de usuario <tt>%s</tt> no fue encontrado.';
$langA['IP_NOT_ADDED'] = 'No se pudo agregar/actualizar permisos para <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>Advertencia:</b> El Usuario <tt>%s</tt> ya es el dueño de esta cuenta.';
$langA['IP_WRONG_LEVEL'] = '<b>Advertencia:</b> Direcciones IP no pueden tener privilegios mayores que "grupo de trabajo".';
$langA['SET_PERMISSIONS'] = 'Para colocar permisos para "%s", elija el estado deseado y luego presione en "Actualizar Permisos".	';


//	specLostPass
$langA['lost_password'] = 'Clave perdida';



//	specFileManager
$langA['file_manager'] = 'Gestor de archivos';
$langA['image_manager'] = 'Gestor de imagen';
$langA['CONFIRM_FILE_DELETE'] = 'Esta seguro que quiere borrar<b>%s</b>?';
$langA['IMAGE_MANAGER_INTRO'] = 'Puede usar sintaxis wiki o html para incluir estas imágenes en sus páginas. Para ciertos tipos de archivos (plantillas, mapas..) recomendamos utilizar sintaxis html.';
$langA['FILE_MANAGER_INTRO'] = 'Puede usar sintaxis wiki o html para incluir en sus páginas. Para ciertos tipos de archivo (plantillas, mapas..) recomendamos utilizar sintaxis html.';
$langA['file_name'] = 'Nombre de archivo';
$langA['available_space'] = 'Espacio disponible';
$langA['UPLOAD_INTRO'] = 'Subir archivos adjuntos e imágenes para su inclusión en mis páginas.';
$langA['file_upload'] = 'Subir Archivo';
$langA['file_info'] = 'Información de fichero';
$langA['width'] = 'Ancho';
$langA['height'] = 'Largo';
$langA['file_location'] = 'Ubicación Archivo';
$langA['wiki_syntax'] = 'Sintaxis Wiki';
$langA['html_syntax'] = 'Sintaxis HTML';
$langA['append_to'] = 'añadir a';
$langA['count'] = 'Cuenta';
$langA['total_size'] = 'Tamaño Total';
$langA['images'] = 'Imagenes';
$langA['overwrite_existing'] = 'Sobreescribir Existente';
$langA['compression'] = 'Compresión';

$langA['NOT_AN_IMAGE'] = 'El archivo no parece ser una imágen. Por favor revise el archivo y luego intente otra vez. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'No se puede borrar el archivo <tt>%s</i>.';
$langA['UPLOADED'] = 'Archivo <tt>%s</tt> subido con éxito.';
$langA['UPLOADED_RENAMED'] = 'El Archivo <tt>%s</tt> fue subido como <tt>%s</tt>. Puede <a %s>renombrarlo a %s</a>.';
$langA['RENAMED'] = 'El fichero fue renombrado satisfactoriamente.';
$langA['UPLOAD_FAILED'] = 'No se pudo copiar el archivo: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'No se puede subir el archivo <tt>%s</tt>. <br/>Los archivos deben ser menores a <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Seleccione un tipo de archivo';
$langA['default_options'] = 'Opciones por defecto';
$langA['UNKNOWN_FILE_TYPE'] = 'Tipo de Página Desconocido: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Cuenta';
$langA['entries'] = 'Entradas';
$langA['average'] = 'Media';
$langA['uploaded_files'] = 'Ficheros subidos';


//	searchTrash
$langA['deleted'] = 'Borrado';
$langA['restore'] = 'Restaurar';
$langA['empty_trash'] = 'Vaciar Basura';
$langA['CONFIRM_EMPTY_TRASH'] = '¿Seguro que desea vaciar su basura?';

$langA['DELETED_AFTER_30'] = 'Los archivos serán borrados automáticamente luego de 30 días.';
$langA['check_uncheck'] = 'Marcar todos / Desmarcar todos';
$langA['DELETED_FILES'] = 'Los archivos seleccionados fueron borrados con éxito.';
$langA['NOTHING_DELETED'] = 'No se borró nada.';
$langA['DELETE_FILES'] = 'Por favor seleccione los archivos a borrar.';
$langA['MAP_INVALID_PT'] = 'Datos de Mapa No Válidos: Formato de Puntero No Válido';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'La característica de búsqueda para este sitio parece estar deshabilitada. Administradores de Sitios pueden habilitar esta característica via Opciones de Búsqueda en el Panel de Control.';
$langA['search:'] = 'Buscar: ';
$langA['search_for'] = 'Buscar por: ';
$langA['registered'] = 'Registrado';
$langA['restricted'] = 'Restringido';
$langA['locked'] = 'Bloqueado';
$langA['disabled'] = 'Deshabilitado';
$langA['editing_option'] = 'Opciones de edición';
$langA['comments_option'] = 'Opciones de Comentarios';
$langA['visibility_option'] = 'Opciones de visualización';
$langA['normal'] = 'Normal';
$langA['advanced'] = 'Avanzado';
$langA['relevance'] = 'Relevancia';
$langA['SEARCH_ONE'] = 'Por lo menos una de las palabras';
$langA['SEARCH_ALL'] = 'Para todas las palabras';
$langA['SEARCH_EXACT'] = 'Para la frase exacta';
$langA['SEARCH_WITHOUT'] = 'Sin las palabras';
$langA['SEARCH_BEGIN'] = 'Para palabras que comiencen con';


//	searchKeywords
$langA['keyword_search'] = 'Buscar Palabras Clave';
$langA['non_tagged_files'] = 'Archivos No-Etiquetados';

//	searchChangeLog
$langA['new'] = 								'Nuevo';
$langA['DIFF_TITLE'] = 							'Compara diferencias con la revisión mas reciente';
$langA['indicates_syntax_error'] = 				'Indica un error sintáctico';
$langA['indicates_unchecked'] = 				'Indica un archivo no revisado.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Seleccione una licencia';
$langA['SELECT_LICENSE_DESC'] = 'Abre una página Creative Commons en una ventana popup.';
$langA['DELETE_LICENSE_DESC'] = 'Esto removera su licencia actual de contenido.';
$langA['LICENSE_UPDATED'] = 'Su licencia de contenido ha sido actualizada con éxito.';
$langA['LICENSE_DELETED'] = 'La licencia fue borrada';
$langA['LICENSE_DELETED2'] = 'La Licencia ya ha sido borrada.';
$langA['customize_license'] = 'Personalize Su Licencia';

$langA['text_before'] = 'Texto antes del enlace';
$langA['text_after'] = 'Texto despues del enlace';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Excepto donde se hace notar expresamente, este trabajo esta bajo licencia ';
$langA['LICENSE_TEXT_LINK'] = 'Licencia Creative Commons';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganizar';
$langA['from'] = 'De';
$langA['to'] = 'Para';
$langA['KEYWORDS_UPDATED'] = 'Sus palabras clave han sido actualizadas.';
$langA['KEYWORDS_EMPTY'] = 'No ha creado ningún archivo con palabras clave todavía.';
$langA['REORGANIZE'] = 'Aquí, puede reestructurar sus archivos renombrando las palabras claves que usó.';

//watch
$langA['WATCH_UPDATED'] = 'Su <a %s>lista de observados</a> ha sido actualizada.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Etiqueta';
$langA['description'] = 'Descripción';
$langA['add_link'] = 'Agregar Enlace';
$langA['link_groups'] = 'Enlazar Grupos';
$langA['group'] = 'Grupo';
$langA['name'] = 'Nombre';
$langA['add_group'] = 'Agregar Grupo';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Límite';
$langA['random'] = 'Aleatorio';
$langA['order'] = 'Orden';
$langA['LEAVE_EMPTY'] = 'Dejar vacio para sin límite';
$langA['unlimited'] = 'Ilimitado';
$langA['type'] = 'Tipo';
$langA['auto_detect'] = 'AutoDetectar';
$langA['bookmarklet'] = 'Dejar Señalador';
$langA['move_up'] = 'Mover Arriba';
$langA['move_down'] = 'Mover Abajo';
$langA['redirect'] = 'Redirigir';
$langA['content_template'] = 'Plantilla de contenido';

