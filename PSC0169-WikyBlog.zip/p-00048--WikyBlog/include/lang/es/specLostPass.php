 <?php

$langA['CHANGE_PASS_INTRO'] = 'Para cambiar su contraseña, primero debemos enviarle una "Llave de permiso" para que pueda acceder a esta propiedad restringida. Una vez que ha recibido la llave, vuelva a esta página e ingrese la información abajo. Porfavor note, su "Llave de permiso" sólo funcionará para su Nombre de Usuario.';

$langA['next_step'] = 'Proximo paso';

$langA['PASS_EMAIL_SUBJECT'] = 'Clave de Permiso para %s.';
$langA['PASS_EMAIL_TEXT'] ='Su clave de permiso para %s es %s.';

$langA['get_your_key'] = 'Obtener Su Clave de Permiso';
$langA['GET_YOUR_KEY'] = 'Su clave será enviada a la dirección de email provista cuando se registró.';

$langA['send_key'] = 'Enviar Clave de Permiso';

$langA['change_password'] = 'Cambiar su clave';
$langA['permission_key'] = 'Clave de Permiso';
$langA['new_password'] = 'Nueva clave';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = 'No se pudo efectuar el cambio de Contraseña: Clave de Permiso o Nombre de Usuario incorrecto';
$langA['PASSWORD_CHANGED'] = 'Contraseña actualizada con éxito para <tt>%s</tt>.';
$langA['PROVIDE_PASSWORD'] = 'Debe introducir una nueva clave';
$langA['PROVIDE_PERMISSION_KEY'] = 'Debe proporcionar una Clave de Permiso para modificar su contraseña';
$langA['PERMISSION_KEY_SENT'] = 'Clave de Permiso enviada con éxito. Recupere su Clave desde su email y úsela para cambiar su contraseña usando el formulario de abajo.';
$langA['PERMISSION_KEY_NOT_SENT'] = 'No se pudo enviar la Clave de Permiso a la dirección de email provista, por favor contacte al administrador del sitio para ayuda adicional.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = 'No se ingreso una dirección de email para esta cuenta. Por favor contacte al administrador del sitio para ayuda adicional.';

