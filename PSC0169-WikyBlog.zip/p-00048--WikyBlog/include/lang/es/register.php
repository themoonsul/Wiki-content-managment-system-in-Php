<?php
$langA['ILLEGAL_USERNAME'] = 'The Username cannot include the following characters: %s';
$langA['LONG_USERNAME'] = 'El nombre de usuario es demasiado largo.';	
$langA['SHORT_USERNAME'] = 'El nombre de usuario es demasiado corto.';
$langA['USER_TAKEN'] = 'Por favor seleccione un Nombre de Usuario diferente.<tt>%s</tt> ya existe. ';
$langA['USERNAME_ALL_DIGITS'] = 'El nombre de usuario no puede ser todo dígitos.';
$langA['PASSWORDS_DIFFERENT'] = 'Las contraseñas no concuerdan.';
$langA['SHORT_PASSWORD'] = 'La contraseña es demasiado corta.';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = 'Registrar';
$langA['welcome_to'] = 'Bienvenido a ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = 'Debe ser de al menos 5 caracteres de largo.';
$langA['confirm_password'] = 'Confirmar Contraseña';
$langA['REG_CONFIRM_PASS'] = 'Lo mismo que arriba.';
$langA['REG_EMAIL'] = 'Opcional pero útil si olvida su contraseña.';
$langA['REQUIRED_FIELD'] = 'Indica un campo requerido.';

$langA['REGISTRATION_TEXT'] = 'La registración es rápida, gratuita y tiene sus beneficios...';
$langA['REG_A_USER_PAGE'] = '/NombreUsuario/Sus_Paginas';
$langA['REG_A_MAP_PAGE'] = '/Mapa/NombreUsuario/Sus_Mapas';

//login
$langA['LOGGED_IN'] = 'Ha entrado como <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'El nombre de usuario provisto no existe. Desea registrar %s.';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Activate your account now.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Your account has been activated.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
