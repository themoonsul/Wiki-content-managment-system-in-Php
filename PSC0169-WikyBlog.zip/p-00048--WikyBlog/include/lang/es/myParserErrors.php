<?php

$langA['end_of_document'] = ' --Fin del Documento-- ';
$langA['syntax_warning'] = ' Error Sintáctico: ';

$langA['XML_ERROR_INVALID_TOKEN'] = 'El error se detectó en la línea %s en la posición %s pero puede haber sido causado por líneas anteriores.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>random &lt;text</tt> instead of <tt>random &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> instead of <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> instead of <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = 'Las etiquetas de cierre HTML son necesarias para completar este documento: "<em>%s</em>".';

$langA['unnecessary_closing_tag'] = 'Etiqueta de cierre innecesaria.';
$langA['should_be'] = ' debería simplemente ser ';

$langA['CLOSING_AN_UNOPENED_TAG'] = 'Cerró una etiqueta no abierta.<br /> No hay ninguna etiqueta de apertura para esta etiqueta de cierre <tt>&lt;/%s&gt;</tt>.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>&lt;/tag&gt;</tt> without <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> instead of <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Missing closing tag. <br /> The <tt>&lt;%s&gt;</tt> tag must be closed using <tt>%s</tt> ';
$langA['MISSING_CLOSING_TAG2'] = ' antes de esta etiqueta de cierre <tt>&lt;/%s&gt;</tt>.';

$langA['AUTOMATED_SYNTAX_ERROR'] = 'Error Automatizado de Sintaxis:';
$langA['AUTOMATED_SYNTAX_ERROR2'] = '(%s) en linea %s (de %s lineas) en posición %s ';
$langA['last_open_tag'] = '<br />Ultima Etiqueta Abierta ';
