<?php

//	toolOptions.php
$langA['properties'] = 'Propiedades';
$langA['file_name'] = 'Nombre de archivo';
$langA['update_from'] = 'Actualizado desde';
$langA['COPY_SYSTEM_FILES'] = 'Copia los archivos del sistema de ayuda mas recientes de %s.';

$langA['EDITING_OPTIONS'] = 'Controla quien puede editar este archivo.';
$langA['registered_users'] = 'Usuarios registrados';
$langA['restricted_to'] = 'Restringido a ';
$langA['admin_only'] = 'Solo Admin';
$langA['editor_visible'] = 'Editores visibles';
$langA['owner_only'] = 'Sólo del dueño';
$langA['use_captcha'] = 'Usar prueba de turing pública y automática para diferenciar a máquinas y humanos.';
		

$langA['visibility'] = 'Visibilidad';
$langA['VISIBILITY_OPTIONS'] = 'Oculta este archivo si no esta listo para ser mostrado al mundo.';
$langA['visible'] = 'Visible';

$langA['COMMENT_OPTIONS'] = 'Deshabilitar comentarios para este archivo.';
$langA['enabled'] = 'Habilitado';
$langA['disabled'] = 'Deshabilitado';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = 'Otro';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Sacar del Blog';
$langA['repost'] = 'Repostear';
$langA['copy_to'] = 'Copiar a...';
$langA['send_to_trash'] = 'Enviar a la papelera';
$langA['default_options'] = 'Opciones por defecto';
$langA['restore_defaults'] = 'Restorar por defecto';
$langA['SET_DEFAULT_OPTIONS'] = 'Coloca %s para este tipo de archivo.'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'El archivo fue republicado.';
$langA['NOT_REPOSTED'] = '<b>Error:</b> No se pudo republicar este archivo.';
$langA['OPTIONS_NOT_CHANGED'] = 'Las opciones de este archivo no fueron modificadas.';
$langA['OPTIONS_UPDATED'] = 'Las opciones del archivo fueron actualizadas con éxito';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Advertencia:</b> Las opciones del archivo no fueron actualizadas.';

$langA['redirect'] = 'Redirigir';
$langA['REMOVE_REDIRECT'] = 'Si no desea que este archivo continue redirigiendo, lo puedo borrar o editar. ';


$langA['UNCHECKED_REMOVED'] = 'El indicador de "No Revisado" fue removido de este archivo.';

$langA['NO_KEYWORDS'] = 'No hay ninguna palabra clave para este archivo. Le gustaría <a %s>agregar palabras clave primero</a> o <a %s>bloggearlo ahora</a>?';

$langA['file_id'] = 'ID de Archivo';

//watch
$langA['WATCH_UPDATED'] = 'Su <a %s>lista de observados</a> ha sido actualizada.';


$langA['user_permissions'] = 'Usuario&nbsp;Permisos';
