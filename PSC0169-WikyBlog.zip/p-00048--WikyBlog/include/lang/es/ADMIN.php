<?php

	$langA['googleMapKeys'] =						'Clave de Google Maps API';


	$langA['ADMIN_ONLY'] =							'Debe ser administrador para acceder a esta página.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Esta página de administración no esta definida aun: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Por favor confirme su contraseña para continuar.';
	$langA['confirm_password'] =						'Confirmar Contraseña';
	$langA['confirmation_failed'] =					'Contraseña Incorrecta. Porfavor intentelo de nuevo.';
	
	$langA['run_scheduled_tasks'] =					'Correr Tareas Programadas';
	$langA['FAILED'] = 								'Lo sentimos, la acción solicitada ha fallado. Porfavor intente de nuevo.';
	$langA['SUCCESS'] = 								'La acción solicitada resultó exitosa. ';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Opciones de Búsqueda';
	$langA['search_status'] =						'Estado de Búsqueda';
	$langA['search_enabled'] =						'Búsqueda Habilitada';
	$langA['SEARCH_ENABLED'] =						'Deshabilitar la característica de buscar vaciara la table de la base de datos `all_search`. Mas tarde, si quiere habilitarla de nuevo, la tabla `all_search` tendrá que ser rellenada nuevamente.';
	$langA['disable'] =								'Deshabilitar';
	
	$langA['search_disabled'] =						'Búsqueda Deshabilitada';
	$langA['SEARCH_DISABLED'] =						'Buscar se encuentra deshabilitado. Habilitar la busqueda requiere un proceso que llenara la tabla de la base de datos `all_search` con entradas para todos los archivos en la base de datos. Este proceso puede tomar un tiempo en bases de datos grandes.';
	$langA['SEARCH_IS_DISABLED'] =					'Buscar deshabilitado y tabla de búsqueda truncada.';
	$langA['enable'] =								'Habilitar';
	
	$langA['FINISHED_ENTRIES'] =						'%s entradas, %s para finalizar.';
	$langA['SEARCH_IS_ENABLED'] =					'La herramienta de búsqueda está ahora habilitada';


//
// adminConfig.php
//
	$langA['configuration'] =						'Configuración';
	$langA['confighistory'] =						'Historial de Configuración';
	$langA['CONFIG_SAVING'] =						'Las nuevas configuraciones son guardadas sin sobreescribir los valores actuales, permitiendote deshacer los cambios si lo deseas...';
	$langA['CONFIG_STAT'] =							'Se han hecho %s revisiones a la configuración';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Estas seguro que deseas revertir la configuración número %s. Haz click en <tt>Guardar</tt> para continuar.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Algo que pueda ser usado con una sentencia como: "Bienvenido a Nombreservidor1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://nombredelservidor2';

//default user

	$langA['max_upload']['desc'] = 					'Tamaño maximo de fichero para subida.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Los usuarios no tienen permitido registrarse usando cadenas separadas por coma como nombres de usuario.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Tamaño máximo de archivo permitido para la bitácora de Errores(Error Log). El valor por defecto es 10,000 bytes.';
	$langA['errorEmail']['desc'] = 					'De una dirección de correo electrónico. ';
	
	
	$langA['include']['desc'] = 						'Hacer que el software incluya un archivo php automáticamente con cada petición. Se pueden dar nombres de archivos separados por coma y relativos a su directorio raíz.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Configuración general.';
	$langA['performance'] = 							'Rendimiento';
	
	$langA['serverName1']['alias'] = 				'Nombre bonito del servidor.';
	$langA['serverName2']['alias'] = 				'Nombre del Servidor';
	$langA['serverName3']['alias'] = 				'Direccion completa del servidor (URL)';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Maxima subida';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Idioma';
	$langA['reservedWords']['alias'] = 				'Palabras reservadas';
	
	$langA['developer_aids'] = 						'Ayudas al Desarrollador';
	$langA['maxErrorFileSize']['alias'] = 			'Tamaño de el archivo de errores';
	$langA['errorEmail']['alias'] = 					'Email de Error';
	$langA['include']['alias'] = 					'Incluir PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Configuración de usuario por defecto';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Titulo de inicio';
	$langA['defaultUser:homeTitle']['desc'] =		'Mostrar como el título de la página principal.';
	
	$langA['defaultUser:template']['alias'] =		'Plantilla de usuario';
	$langA['defaultUser:template']['desc'] =		'Main/Home es el template de wikyblog por defecto.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Altura del area de texto';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Pagina principal del Blog';
	$langA['defaultUser:isBlog']['desc'] =			'Habilita o deshabilita los estilos en la pagina de inicio del blog.';
	
	$langA['defaultUser:timezone']['alias'] =		'Zona horaria';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Maximas entradas del historial';
	$langA['defaultUser:maxHistory']['desc'] =		'Maximo por defecto para la cantidad de filas del historial';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Agregar Grupo';
	$langA['unlimited'] = 'Ilimitado';
	$langA['group'] = 'Grupo';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Usar prueba de turing pública y automática para diferenciar a máquinas y humanos.';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Estadística del Usuario';
	$langA['user_stats'] =							'Estados de usuario';
	$langA['user_account'] =							'Cuenta de usuario';
	$langA['entries'] =								'Entradas';
	$langA['history Rows'] =							'Filas del Historial';
	$langA['last_visit'] = 							'Ultima visita';
	
	$langA['users_found'] =							'Usuarios encontrados';
	$langA['showing_of_found'] =						'Mostrando %s hasta %s';
	$langA['cpanel'] =								'CPanel';
	$langA['details'] =								'Detalles';
	
	$langA['within_the_hour'] =						' hace menos de 1h';
	$langA['hours'] =								'horas';
	$langA['days'] =									'dias';
	$langA['months'] =								'meses';
	$langA['years'] = 								'años';
	$langA['ago'] = 									'hace';
	
	$langA['TIMEOUT'] = 								'<b>error Tiempo exedido:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Precaución</b> No se puede eliminar la cuenta "Principal"';
	$langA['CONFIRM_DELETE_USER'] = 					'Esta seguro que quiere borrar<b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'La eliminación <i>borrará por completo</i> todos los archivos de la cuenta incluyendo:';
	$langA['userfiles_directory'] = 					'Directorio de archivos de usuario: ';
	$langA['template_directory'] = 					'Directorio de plantilla: ';
	$langA['database_entries'] = 					'Y todas las entradas de la base de datos: páginas, historial de páginas, comentarios, etc.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Entradas de la base de datos borradas.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Atención:</b> No se han podido borrar las entradas de la base de datos.';
	
	$langA['DELETED_USERFILES'] = 					'Directorio de ficheros de usuario borrado.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Advertencia:</b> No se pudo borrar el Directorio de Archivos del Usuario (Userfiles).';
	
	$langA['DELETED_TEMPLATES'] = 					'Directorio de plantilla borrado.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Advertencia:</b> No se pudo borrar el directorio de Plantillas.';
	
	$langA['USER_DELETED'] = 						'%s fue completamente borrado: ';
	$langA['USER_NOT_DELETED'] = 					'%s NO fue completamente borrado: ';
	$langA['DELETE_ACCOUNT'] = 						'Eliminar esta cuenta completamente.';
	$langA['DISABLE_ACCOUNT'] = 					'Deshabilitar edición de archivos.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Actualizado';
	$langA['suspend'] = 							'Suspender';
	$langA['activate'] = 							'Activar';
	$langA['lost_page'] = 							'Página perdida';
	$langA['suspended'] =							'Suspendido';
	$langA['disabled'] =							'Deshabilitado';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'No se puede borrar el log de errores.';
	$langA['ERROR_LOG_DELETED'] = 					'EL Log de errores fue borrado.';
	$langA['ERROR_LOG_MAXED'] = 						'El archivo Error.log a alcanzado su tamaño máximo, por favor vacie el archivo asi es script puede continuar registrando los errores. %s';


	$langA['select'] = 								'Seleccionar';
	$langA['description'] = 						'Descripción';


//	adminPlugins
	$langA['data_types'] = 							'Tipos de datos'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Tipos existentes';
	$langA['available_plugins'] = 					'Plugins disponibles';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Marcar todos / Desmarcar todos';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Conectado';
	$langA['wbConfig']['online']['desc'] = 			'¿Está esta implementacion conectada a internet?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Intervalo de tiempo entre mensajes';
	$langA['wbConfig']['floodInterval']['desc'] = 	'El número de segundos que un usuario sin permisos tendrá que esperar entre ediciones.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Usar HTML Tidy para corregir posibles errores en entradas de usuario.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Completo.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Permitir a todos los usuarios registrados tener su propio blog.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Elija la cuenta de usuario que será mostrada si ningúna es provista por el visitante.';
	$langA['wbConfig']['pUser']['alias'] = 			'Usuario por Defecto.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determina cuanto del IP del usuario será revisado al validar las sesiones.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Nivel de Sesión';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

