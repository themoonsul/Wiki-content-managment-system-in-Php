<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'Cargando Mapa...';
$langA['MAP_DEBUG_O'] = 'Ocurrió un error mientras se cargaba esta página y el mapa que solicito puede que no se muestre<p> </p>Una bitácora de error fue creada y los administradores del sitio deben poder resolver este problema pronto.';
$langA['MAP_DEBUG_1'] = 'The Google Maps API does not appear to be compatible with your browser.<p>If you know your browser is compatible, make sure the correct map key is being used and that you are connected to the internet.</p><p>You can <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">get more information</a> about browser support from google.com.</p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>Advertencia:</b> Los Mapas requiren JavaScript para funcionar.</p><p> Parece que JavaScript no esta habilitado en su navegador. Para ver este mapa, por favor habilite JavaScript en su navegador y luego refresque/recargue esta página. </p>';