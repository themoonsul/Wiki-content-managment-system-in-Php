<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'Sus preferencias no cambiaron de los valores ya guardados.';
$langA['INVALID_PREFS'] = '<b>Advertencia:</b> No se pudo guardar sus preferencias con los valores provistos.';

$langA['EMAIL_PREFS'] = 'Util si pierde su clave.';

$langA['LANG_PREFS'] = 'Seleccione un idioma.';

$langA['javascript_preferences'] = 'JavaScript Preferences';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Cambie a activado/desactivado ';

$langA['time_zone'] = 'Zona horaria';
$langA['TIME_ZONE_PREFS'] = 'Diferencia de tiempo entre su hora local y la del servidor: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'La hora del servidor es ahora %s. <br/>Su hora ajustada es %s.';

$langA['sig'] = 'Firma';
$langA['SIGNATURE'] = 'Personalize su firma con sintaxis wiki.';


$langA['home_title'] = 'Titulo de inicio';
$langA['HOME_TITLE_PREFS'] = 'El título a ser mostrado en su página de inicio.';

$langA['blog_styled_frontpage'] = 'Portada Estilo Blog';
$langA['BLOG_PREFS'] = 'Mostrar la página de inicio como un blog.';

$langA['blogT'] = 'Tipo de Blog';
$langA['BLOG_TYPE'] = 'Elija entre los tipos de datos disponibles para blog.';

$langA['selective_blogging'] = 'Bloggeo Selectivo';
$langA['SELECTIVE_BLOGGING'] = 'Bloggeo Selectivo le permite bloggear solo las páginas que quiere mostrar en la portada.';

$langA['blog_count'] = 'Blog Count';
$langA['BLOG_COUNT'] = 'The number of entries to show on your blog.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'Mostrar el enlace "Compartir" en la parte inferior de cada archivo.';

$langA['ihelp'] = 'Help Links';
$langA['IHELP'] = 'Show help links.';

$langA['uServices'] = 'Actualizar Servicios';
$langA['UPDATE_SERVICES'] = 'Cuando publique un nuevo anuncio, los siguientes servicios de actualización serán automáticamente notificados. Separe múltiples URIs de servicio con saltos de línea.';
$langA['BAD_UPDATE_SERVICES'] = 'Las Uri(s) provistas para los Servicios de Actualización no son válidas.';


$langA['VIEW_THEME'] = '<a %s>Edit or copy</a> this theme.';

$langA['quick_comment'] = 'Comentario rápido';
$langA['QUICK_COMMENT'] = 'Cuando se activa, un formulario se muestra arriba de las páginas de conversación para el comentado mas rápido. ';

$langA['textarea rows'] = 'Filas del Area de Texto';
$langA['TEXTAREA_ROWS_PREFS'] = 'Determina la altura de las áreas de edición.';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'Limita el número de filas de historial almacenadas en el servidor para cada archivo.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Maximum %s.';

$langA['tab_limit'] = 'Límite de Pestañas';
$langA['TAB_LIMIT'] = 'JavaScript will automatically close tabs once the number of opened tabs has reached this limit. Defaults to 7. Set to 1000 or more if you don\'t want JavaScript to manage your tabs.';

$langA['EXTERNAL_LINKS'] = 'Enlaces externos serán abiertos en una nueva ventana cuando esta en "Prendido".';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'Atajos de teclado';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = 'Guardar preferencias';

$langA['CONFIRM_CHANGE'] = '¿Esta seguro que quiere cambiar sus preferencias?';
$langA['preference'] = 'Preferencia';
$langA['old_value'] = 'Valor Antiguo';
$langA['new_value'] = 'Valor Nuevo';

$langA['changes'] = 'Cambios';
$langA['PREFS_CHANGED'] = 'Sus preferencias han sido actualizadas.<br/> Abajo hay un sumario de los valores que han cambiado.';


//check edit
$langA['anonymous'] = 'Anónimo';
$langA['fEdits'] = 'Editar Banderas';
$langA['FLAG_EDITS'] = 'Las ediciones hechas por usuarios con estado igual o menor al estado seleccionado tendrán la bandera de "No Verificados" hasta que sean revisados por el dueño de la cuenta.';

//save all edits
$langA['saveAll'] = 'Log All Edits';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
