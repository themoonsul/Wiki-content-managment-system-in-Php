<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Fichero';
$langA['edit'] = 'Editar';
$langA['edits'] = 'Ediciones';
$langA['view_source'] = 'Ver codigo';
$langA['talk'] = 'Hablar';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Historial';
$langA['diff'] = 'Diferencia';
$langA['watch'] = 'Observar';
$langA['unwatch'] = 'Desobservar';
$langA['options'] = 'Opciones';


$langA['messages'] = 'Mensajes';
$langA['current'] = 'Actual';
$langA['blog'] = 'Blog';
$langA['possible'] = 'Posible';

$langA['DEFAULT_CONTENT'] = 'Este es un fichero nuevo, quiere[[%s?cmd=edit|crearlo]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Esto es un archivo nuevo. Para crear este archivo, usted necesita ser entrado con privilegios apropiados.';

$langA['NOT_OWNER'] = 'No tiene los apropiados privilegios para esta opción.';
$langA['LONG_PATH'] = 'El título para este fichero es demasiado lago, ha sido truncado.';
$langA['EMPTY_CONTENT'] = 'Contenido es un campo requerido';
$langA['INCOMPLETE_PATH'] = 'La dirección escrita es incompleta';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Disculpe, el administrador del sitio ha deshabilitado el bloggeo de usuario. Para crear un bliki con las mismas características encontradas aquí, visite<a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'Este título ya existe, por favor elija uno diferente y luego guarde otra vez.';

$langA['HIDDEN_FILE'] = 'El acceso a este archivo ha sido restringido por su dueño. Para ver este archivo, necesita los privilegios apropiados.';
$langA['HIDDEN_FILE2'] = 'El archivo esta "oculto". ';
$langA['DELETED_FILE'] = 'El archvio se encuentra en la "basura". Si Ud. es el dueño de esta cuenta, puede restaurar el archivo via su panel de control.';
$langA['PROTECTED_FILE'] = 'Este archivo esta protegido. Alguno cambios hechos a este archivo no serán guardados.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Texto de enlace';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redireccionado desde %s.';
$langA['REDIRECT_TO'] = 'Esta página redirije a %s.';

//	Data Types
$langA['all'] = 'Todo';
$langA['page'] = 'Página';
$langA['comment'] = 'Comentario';
$langA['map'] = 'Mapa';
$langA['template'] = 'Plantilla';
$langA['help'] = 'Ayuda';
$langA['skeleton'] = 'Esqueleto';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Comentarios';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Páginas';
$langA['CLASScomment'] = 'Comentarios';
$langA['CLASSmap'] = 'Mapas';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'Ayuda';
$langA['IS_CONTENT_TEMPLATE'] = 'Este archivo es una plantilla de contenido y no será mostrada en su blog.';


$langA['seconds'] = ' segundos';
$langA['queries'] = ' consultas';

$langA['QUERY_TIME'] = ' por consultas';
$langA['INVALID_PATH'] = 'Ruta de archivo provista no válida: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Petición No Válida.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'Como parte integrada de este software, este archivo de ayuda esta almacenado en un servidor central<br/> Puede editar los contenidos de %sthis%s y otros archivos de ayuda en %s.';

$langA['NEW_HELP'] = 'Crear un nuevo archivo de ayuda';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Examinar';
$langA['change_log'] = 'Log de Cambios';
$langA['control_panel'] = 'Panel de control';
$langA['administration'] = 'Administración';
$langA['preferences'] = 'Preferencias';
$langA['watchlist'] = 'Lista de Observados';
$langA['wanted_files'] = 'Archivos Queridos';
$langA['dead_end'] = 'Archivos Sin-Salida';
$langA['search'] = 'Buscar';
$langA['orphaned_files'] = 'Archivos Huerfanos';
$langA['most_linked'] = 'Más Enlazados A Archivos';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'Enlaces Externos';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'Posts mas recientes.';
$langA['NEED_INTERNET'] = 'Esta opción esta solo disponible en sistemas conectados a internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Atención:</b> Cookies requeridas para continuar. Actualice esta página si las cookies estan habilitadas.';
$langA['LOGIN_REQUIRED'] = 'Debe ingresar al sistema para utilizar esta característica.';

$langA['ENTER_USERNAME'] = 'Porfavor introduzca su nombre de usuario.';
$langA['ENTER_PASSWORD'] = 'Porfavor introduzca su clave.';
$langA['LOGGED_OUT'] = 'Ud. a salido del sistema con éxito.';
$langA['AUTO_LOGOUT'] = 'Su sesión a expirado.';

$langA['LOGIN_FAILED'] = 'No se pudo Ingresar al sistema: Contraseña Incorrecta.<ul><li>¿Tiene el boton de Mayusculas(Caps Lock) activado?<li> Have you %sforgotten your password%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'El número máximo de intentos de %s de ingreso ha sido excedido. No le será permitido ingresar por los próximos %s minutos.';
						
$langA['create_new'] = 'Crear&nbsp;Nuevo ';
$langA['remember_me'] = 'Recuerdeme';
$langA['log_out'] = 'Salir';
$langA['log_in'] = 'Entrar';

//	SAVING 
$langA['syntax_error'] = 'error de sintaxis';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Error Sintáctico:</b> Incapaz de Guardar/Mostrar los cambios mas recientes a este archivo debido a una sintaxis incompatible.';
$langA['SYNTAX_FIXED'] = 'El error de sintaxis fue arreglado.';


$langA['NO_CHANGES'] = 'No se han hecho cambios a este archivo. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'No es posible guardar este archivo. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Los cambios a este fichero fueron grabados.';
$langA['HIDDEN_FILE3'] = '<b>Nota:</b> Este es un archivo oculto, por lo que las etiquetas de este archivo no serán incluídas en los totales del menú usuario.';

$langA['VERSION_CONFLICT'] = 'Advertencia: No se pueden guardar los cambios porque se detectó un conflicto de versión.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Editar ha sido limitado a uno cada %s segundos. Por favor intente otra vez luego de %s segundos.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Guardar Opciones';
$langA['blog_this'] = 'Bloguee Esto';



//	toolHistory2.php
$langA['differences'] = 'diferencia(s)';
$langA['line_num'] = 'Linea #';


//	toolHistory1.php
$langA['revision'] = 'Revisión ';
$langA['revision_as_of'] = 'Revisión en cuanto a ';
$langA['revision_num_as_of'] = 'Revisión %s en cuanto a %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Editar revisión';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Revertido a revisión #';
$langA['SET_USER_PERMISSIONS'] = 'Coloque los permisos para este usuario: '; 
$langA['compare_with_prev'] = '← Compare con la revisión anterior';
$langA['current_revision'] = 'Revision actual';
$langA['compare_with_next'] = 'Compare con la revisión siguiente →';
$langA['lines'] = 'Lineas';
$langA['text'] = 'Texto';
$langA['vs'] = ' vs ';
$langA['content'] = 'Contenido';
$langA['your_text'] = 'Su texto';
$langA['show_prev_revision'] = '← Revisión %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Revisión %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Advertencia:</b> Ud. no esta utilizando la versión mas reciente de esta página.<br /> Si elije Guardar estará reemplazando la versión mas nueva con esta versión desactualizada.';
$langA['SELECT_TWO_VERSIONS'] = 'Por favor seleccione dos versiones distintas para comparar.';
$langA['NO_UNIQUE_REVISION'] = 'No se pudo encontrar una revisión única para esta petición.';
$langA['INVALID_REVISION'] = '<b>Error:</b> Número Inválido De Revisión.';
$langA['NO_DIFFERENCES'] = 'Las dos revisiones siendo comparadas son idénticas.';
$langA['NO_REVISIONS'] = 'Debe haber dos revisiones distintas antes de que una comparación pueda ser hecha.';
$langA['NON_EXISTANT'] = 'Este archivo no existe aun.';

//	toolEditPage.php
$langA['bold_text'] = 'Negrita';
$langA['italic_text'] = 'Cursiva';
$langA['headline_text'] = 'Inserte El Título';
$langA['title'] = 'Título';
$langA['unordered_list'] = 'Lista Desordenada';
$langA['ordered_list'] = 'Lista Ordenada';


$langA['internal_link'] = 'Enlace interno';
$langA['link'] = 'Enlace';
$langA['external_link'] = 'Enlace externo';
$langA['embed_image'] = 'imagen embebida';
$langA['find_images'] = 'Find Images';
$langA['image'] = 'Imagen';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'Aquí inserta texto sin formato';
$langA['signature'] = 'Firma';
$langA['SIGNATURE_TEXT'] = 'Inserte su Firma';
$langA['preview'] = 'Previsualizar';
$langA['PREVIEW_TEXT'] = 'Previsualizar sus cambios [%s-p]';
$langA['PREVIEW_WARN'] = 'Esto es una previsualización. Sus cambios no han sido grabados!';
$langA['SAVE_TEXT'] = 'Guardar cambios [%s-s]';
$langA['reset'] = 'Resetear';
$langA['RESET_TEXT'] = 'Resetear este formulario a su estado original [%s-c]';
$langA['changes'] = 'Cambios';
$langA['CHANGES_TEXT'] = 'Demuestre los cambios que usted ha realizado a este archivo. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organise sus anuncios con palabras clave separadas por coma'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Etiquetas';
$langA['edit_summary'] = 'Editar Resumen';
$langA['syntax_warning'] = 'Advertencia de Sintáxis';
$langA['NO_IMAGES'] = 'Ninguna imagen encontrada';
$langA['insert_emoticons'] = 'Insertar emoticonos';
$langA['upload'] = 'Subir';



//searchHistory
$langA['show'] = 'Mostrar';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Comparar';
$langA['timeline'] = 'Linea de Tiempo';
$langA['summary'] = 'Sumario';
$langA['COMPARE_REVISONS'] = 'Comparar con la versión seleccionada.';
$langA['unchecked'] = 'No chequeado';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Tipo de Archivo Provisto No válido.';


//	SEARCH
$langA['next'] = 'Siguiente';
$langA['previous'] = 'Anterior';
$langA['order_by'] = 'Ordenar por:';
$langA['ascending'] = 'Ascendente';
$langA['descending'] = 'Descendente';
$langA['search_from'] = 'Buscar por: ';
$langA['all_users'] = 'Todos los usuarios';
$langA['user'] = 'Usuario';
$langA['from_file_type'] = 'Buscar por tipo de archivo: ';
$langA['read_more'] = 'Leer más';
$langA['words'] = ' palabras';

$langA['RESULTS'] = 'Resultados %s a %s de %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Ninguna entrada encontrada con los criterios de busqueda introducidos.';

//searchTalk
$langA['add_comment'] = 'Agregue un Nuevo Asunto';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'No se pudo incluir la advertencia. Datos pobremente formateados para entrada duplicada.';
$langA['duplicate_entry'] = 'Entrada duplicada';
$langA['DUPLICATE_ENTRY'] = 'Esta es una entrada duplicada para la página encontrada en %s. <br/>Cualquier información no redundante encontrada aquí debe ser transferida al original antes de borrar esta página.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'No encontrado: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Error:</b><br /> Ocurrió un error mientras se ejecutaba este script.<br /> Por favor verifique su petición y nosotros intentaremos depurar el script con la bitácora de errores (error.log). %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'No se puede borrar la plantilla por defecto.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'El tema especificado es invalido.';

//
//	CLASSmap
//
$langA['new_marker']='Marcador Nuevo';
$langA['new_route']='Rute Nueva';
$langA['SAVE_HEADER']='Recuerde Antes de Guardar';
$langA['save_map']='Guardar mapa';
$langA['continue_editing']='Continuar editando';
$langA['miles/km'] = 'millas/Km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>Este es un nuevo mapa.</b><br/> Para crear/editar este mapa, haga click en "Editar".';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Disculpe, pero Ud. no tiene suficientes privilegios para editar este mapa.';
$langA['play'] = 'Play';
$langA['stop'] = 'Parar';
$langA['import'] = 'Importar';
$langA['export'] = 'Exportar';
$langA['gpx_data'] = 'Datos GPX';
$langA['gpx_exchange_format'] = 'Formato de Intercambio GPX';
$langA['CLICK_EDIT'] = 'Para editar el mapa, pulse "editar", arriba';


//	smileys
$langA['smiles'][':D'] = 'Muy feliz';
$langA['smiles'][':)'] = 'Sonrisa';
$langA['smiles'][':('] = 'Triste';
$langA['smiles'][':o'] = 'Sorprendido';
$langA['smiles'][':shock:'] = 'Impactado';
$langA['smiles'][':?'] = 'Confundido';
$langA['smiles']['8)'] = 'Canchero';
$langA['smiles'][':lol:'] = 'Riendo';
$langA['smiles'][':x'] = 'Enojado/a';
$langA['smiles'][':P'] = 'Burlón';
$langA['smiles'][':oops:'] = 'Avergonzado';
$langA['smiles'][':cry:'] = 'Llorando o Muy triste';
$langA['smiles'][':evil:'] = 'Perverso o Muy Loco';
$langA['smiles'][':twisted:'] = 'Retorcido y Perverso';
$langA['smiles'][':roll:'] = 'Girando los Ojos';
$langA['smiles'][':wink:'] = 'Parpadeando';
$langA['smiles'][':!:'] = 'Exclamación';
$langA['smiles'][':?:'] = 'Pregunta';
$langA['smiles'][':idea:'] = 'Idea';
$langA['smiles'][':arrow:'] = 'Flecha';
$langA['smiles'][':|'] = 'Neutral';
$langA['smiles'][':mrgreen:'] = 'Sr. Verde';

//
//	General Language
//
$langA['or'] = 'o';
$langA['username'] = 'Nombre de usuario';
$langA['password'] = 'Clave';
$langA['email'] = 'E-mail';
$langA['register'] = 'Registrar';
$langA['cancel'] = 'Cancelar';
$langA['language'] = 'Idioma';
$langA['use'] = 'Usar';
$langA['copy'] = 'Copiar';
$langA['rename'] = 'Renombrar';

$langA['on'] = 'Encendido';
$langA['partial'] = 'Parcial';
$langA['off'] = 'Apagado';
$langA['save'] = 'Guardar';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Indefinido';
$langA['homepage'] = 'Página de inicio';
$langA['home'] = 'Inicio';
$langA['go'] = 'Mostrar';
$langA['user_menu'] = 'Menú de usuario';

$langA['last_modified'] = 'Ultima modificación';
$langA['LAST_MODIFIED'] = 'Ultima modificación %s por %s.';//%s replaced with date and username
$langA['accessed_times'] = 'Accedido %s veces';// %s replaced with a number
$langA['modified'] = 'Modificado';
$langA['posted'] = 'Publicado';
$langA['created'] = 'Creado';
$langA['hidden'] = 'Oculto';
$langA['what_links_here'] = 'Lo que enlaza aquí';
$langA['share'] = 'Compartir';
$langA['INVALID_LINK'] = 'El título de la página solicitada no es válido. Puede contener uno o mas caracteres que no pueden ser usados en títulos.';
$langA['FILE_MUST_EXIST'] = 'El archivo debe ser guardado antes de que pueda efectuar esta operación.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Tamaño ';
$langA['bytes'] = 'bytes';
$langA['kb'] = 'KB';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Actualizar';
$langA['editing'] = 'Edición';
$langA['workgroup'] = 'Grupo de trabajo';
$langA['BROWSE_HIDDEN'] = 'Encontrar archivos ocultos';

$langA['delete'] = 'Borrar';
$langA['confirm_delete'] = 'Confirmar borrado';
$langA['continue'] = 'Continuar';
$langA['back'] = 'Atras';
$langA['close'] = 'Cerrar';
$langA['view'] = 'Ver';
$langA['empty'] = '-vacio-';
$langA['none'] = 'Ninguna';
$langA['total'] = 'Total ';
$langA['files'] = 'Archivos';
$langA['other'] = 'Otro';
$langA['trash'] = 'Papelera';
$langA['flagged'] = 'Con Bandera';

$langA['today'] = 'Hoy';
$langA['yesterday'] = 'Ayer';
$langA['days_ago'] = ' dias atras';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'Más';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'Domingo';
$langA['date_l'][1] = 'Lunes';
$langA['date_l'][2] = 'Martes';
$langA['date_l'][3] = 'Miércoles';
$langA['date_l'][4] = 'Jueves';
$langA['date_l'][5] = 'Viernes';
$langA['date_l'][6] = 'Sábado';

$langA['date_D'][0] = 'Do';
$langA['date_D'][1] = 'Lu';
$langA['date_D'][2] = 'Ma';
$langA['date_D'][3] = 'Mi';
$langA['date_D'][4] = 'Ju';
$langA['date_D'][5] = 'Vi';
$langA['date_D'][6] = 'Sa';


$langA['date_F'][1] = 'enero';
$langA['date_F'][2] = 'febrero';
$langA['date_F'][3] = 'marzo';
$langA['date_F'][4] = 'abril';
$langA['date_F'][5] = 'may';
$langA['date_F'][6] = 'junio';
$langA['date_F'][7] = 'julio';
$langA['date_F'][8] = 'agosto';
$langA['date_F'][9] = 'septiembre';
$langA['date_F'][10] = 'octubre';
$langA['date_F'][11] = 'noviembre';
$langA['date_F'][12] = 'diciembre';

$langA['date_M'][1] = 'ene';
$langA['date_M'][2] = 'feb';
$langA['date_M'][3] = 'mar';
$langA['date_M'][4] = 'abr';
$langA['date_M'][5] = 'may';
$langA['date_M'][6] = 'jun';
$langA['date_M'][7] = 'jul';
$langA['date_M'][8] = 'ago';
$langA['date_M'][9] = 'Sept';
$langA['date_M'][10] = 'oct';
$langA['date_M'][11] = 'nov';
$langA['date_M'][12] = 'dic';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabic (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'Aleman(de)';
$langA['lang']['el'] = 'Griego (el)';
$langA['lang']['en'] = 'Inglés(en)';
$langA['lang']['es'] = 'Español (es)';
$langA['lang']['fr'] = 'Francés(fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italian (it)';
$langA['lang']['ja'] = 'Japones(ja)';
$langA['lang']['ko'] = 'Koreano (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Holandes (nl)';
$langA['lang']['pl'] = 'Polaco (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Ruso (ru)';
$langA['lang']['tr'] = 'Turco(tr)';
$langA['lang']['vi'] = 'Vietnamita (vi)';
$langA['lang']['zh'] = 'Chino (zh)';
$langA['lang']['zh-cn'] = 'Chino Simplificado (zh-cn)';



