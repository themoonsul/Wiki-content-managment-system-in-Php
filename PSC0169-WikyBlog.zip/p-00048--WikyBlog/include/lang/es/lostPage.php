<?php

$langA['lost_page'] = 'Página perdida';
$langA['PAGE_NOT_FOUND'] = 'La página solicitada <tt>%s</tt> no se encontró.';
$langA['REGISER_AS_USER'] = 'Parece que la cuenta de usuario <tt>%s</tt> no ha sido creada. ¿Le gustaría %s con este nombre de usuario?';
$langA['LINK_TYPO'] = ' Verifíque por un error de tipeo en el link de la página referente: ';
$langA['REGISTER_TO_CREATE'] = 'Cree esta página al registrarla primero con el nombre de usuario <tt>%s</tt>.';