<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'Le nom de fichier n\'a pas été changé.';
$langA['NOT_RENAMED'] = 'Ce fichier n\'a pu être renommé en tant que <tt>%s</tt>. Veuillez vous assurer que ce fichier n\'existe pas.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'Ne peut renommer ce fichier.';
$langA['redirected_to'] = 'Redirected to';
$langA['RENAMED'] = 'Ce fichier fut renommé avec succès.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b> à été restoré. ';
$langA['ERROR_RESTORING'] = '<b>Error:</b> Could not restore the file at <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = 'Le fichier a déjà été restoré.';
$langA['WAS_DELETED'] = '<b>%s</b> a été supprimé. Ce fichier sera stocké dans %s pour 30 jours.';
$langA['ERROR_DELETING'] = '<br>Erreur:</b>Ne peut supprimer le fichier emplacement <tt>%s.</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> fut détruit.';
