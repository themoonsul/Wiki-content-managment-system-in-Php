<?php
$langA['ILLEGAL_USERNAME'] = 'The Username cannot include the following characters: %s';
$langA['LONG_USERNAME'] = 'Le nom d\'utilisateur est trop long.';	
$langA['SHORT_USERNAME'] = 'Le nom d\'utilisateur est trop court.';
$langA['USER_TAKEN'] = 'Veuillez choisir un nom d\'utilisateur différent.<tt>%s</tt> est déjà pris. ';
$langA['USERNAME_ALL_DIGITS'] = 'Le nom d\'utilisateur ne peut être que des chiffres.';
$langA['PASSWORDS_DIFFERENT'] = 'Les mots de passes ne sont pas pareil.';
$langA['SHORT_PASSWORD'] = 'Le mot de passe est trop court.';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = 'Enregistrer';
$langA['welcome_to'] = 'Bienvenue sur ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = 'Doit avoir au moins 5 caractères.';
$langA['confirm_password'] = 'Confirmez le mot de passe.';
$langA['REG_CONFIRM_PASS'] = 'La même chose qu\'en haut.';
$langA['REG_EMAIL'] = 'Facultatif mais utile si vous avez oublié votre mot de passe.';
$langA['REQUIRED_FIELD'] = 'Indique un champ requis.';

$langA['REGISTRATION_TEXT'] = 'L\'enregistrement est rapide, gratuit et offre plusieurs bénéfices...';
$langA['REG_A_USER_PAGE'] = '/NomUtilisateur/Vos_Pages';
$langA['REG_A_MAP_PAGE'] = '/Carte/NomUtilisateur/Vos_Cartes';

//login
$langA['LOGGED_IN'] = 'Vous êtes enregistré en tant que <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'Le nom d\'utilisateur n\'existe pas. Voulez-vous vous enregistrer %s.';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Activate your account now.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Your account has been activated.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
