<?php

$langA['end_of_document'] = ' --Fin du document-- ';
$langA['syntax_warning'] = ' Avertissement syntaxe ';

$langA['XML_ERROR_INVALID_TOKEN'] = 'L\'erreur fut détecté sur la ligne %s à la position %s mais peut avoir été causée par les lignes précédentes.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>random &lt;text</tt> instead of <tt>random &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> instead of <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> instead of <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = 'Closing HTML tags are needed to make this document complete: "<em>%s</em>".';

$langA['unnecessary_closing_tag'] = 'Fermeture de bornes non-nécessaire.';
$langA['should_be'] = ' pourrait simplement être ';

$langA['CLOSING_AN_UNOPENED_TAG'] = 'Fermeture d\'une borne qui n\'est pas ouverte.<br/>Il n\'y avait pas de borne ouverte pour la borne fermée.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>&lt;/tag&gt;</tt> without <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> instead of <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Missing closing tag. <br /> The <tt>&lt;%s&gt;</tt> tag must be closed using <tt>%s</tt> ';
$langA['MISSING_CLOSING_TAG2'] = ' avant la fermeture de la borne <tt>&lt;/%s&gt;</tt>.';

$langA['AUTOMATED_SYNTAX_ERROR'] = 'Erreur de syntaxe automatique';
$langA['AUTOMATED_SYNTAX_ERROR2'] = '(%s) ligne %s (de %s lignes) position %s ';
$langA['last_open_tag'] = '<br/>Dernière borne ouverte ';
