<?php

$langA['lost_page'] = 'Page perdue';
$langA['PAGE_NOT_FOUND'] = 'La page demandé <tt>%s</tt> n\'a pu être trouvé.';
$langA['REGISER_AS_USER'] = 'Il semble que le compte utilisateur <tt>%s</tt> n\'a pas encore été crée. Voulez-vous vous %s avec ce nom d\'utilisateur?';
$langA['LINK_TYPO'] = ' Regardez pour un lien typo sur la page référente: ';
$langA['REGISTER_TO_CREATE'] = 'Nom d\'utilisateur <tt>%s</tt>.';