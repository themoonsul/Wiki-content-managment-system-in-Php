<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Permissions';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'Cette page spéciale n\'a pas encore été définit: <tt>%s</tt>';

//	control panel
$langA['general'] = 'Général';
$langA['attachments'] = 'Attachments';
$langA['account_info'] = 'Information du Compte';
$langA['error_log'] = 'Journal d\'erreurs';
$langA['advanced_search'] = 'Recherche&nbsp;avancée';
$langA['configuration'] = 'Configuration';
$langA['search_options'] = 'Options de recherche';
$langA['data_types'] = 'Types de données';
$langA['plugins'] = 'Plugins';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Tabs';
$langA['account_display'] = 'Afficher compte';
$langA['links'] = 'Liens vers l\'image';
$langA['go_to'] = 'Go to %s.';


$langA['user_statistics'] = 'Statistiques utilisateur';
$langA['database_info'] = 'Information&nbsp;base de donnée';
$langA['user_preferences'] = 'Préférences utilisateur';
$langA['content_license'] = 'Contenu&nbsp;License';
$langA['user_permissions'] = 'Permissions utilisateur';
$langA['default_page_options'] = 'Option&nbsp;page&nbsp;par&nbsp;défaut';
$langA['account_details'] = 'Détails&nbsp;compte';
$langA['manage_images'] = 'Gérer&nbsp;Images';
$langA['manage_files'] = 'Gérer&nbsp;Fichiers';
$langA['upload_files'] = 'Envoyer fichiers';
$langA['public_templates'] = 'Gabarits&nbsppublics';
$langA['feeds'] = 'Syndication / Flux RSS';
$langA['recently_modified'] = 'Modifié récemment';
$langA['recently_posted'] = 'Posté récemment';
$langA['user_edits'] = 'User Edits';

$langA['CONTROL_PANEL_1'] = 'Voici le Panneau de Contrôle pour <tt>%s</tt>';
$langA['CONTROL_PANEL_2'] = 'Voulez-vous voir votre %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Current Theme';
$langA['TEMPLATES_UNAVAILABLE'] = 'Le répertoire de paquetages Thèmes n\'est pas disponible.';
$langA['themes']['default'] = 'Défaut';
$langA['themes']['simple'] = 'Simple';
$langA['themes']['three_columns'] = 'Trois colonnes';
$langA['themes']['floating'] = 'Floating';
$langA['themes']['graphic'] = 'Graphic';

$langA['colors']['colors'] = 'Couleurs';
$langA['colors']['black'] = 'Black';
$langA['colors']['blue'] = 'Bleu';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Vert';
$langA['colors']['light_blue'] = 'Light Blue';
$langA['colors']['green'] = 'Vert';
$langA['colors']['tan'] = 'Tan';
$langA['colors']['red'] = 'Rouge';
$langA['colors']['orange'] = 'Orange';
$langA['colors']['gray'] = 'Gray';


$langA['customize_this_theme'] = 'Customize This Theme';



//searchHidden.php
$langA['browse_hidden'] = 'Naviguation cachée';
$langA['editor_visible'] = 'Visible to Editors';


//	WorkGroup.php
$langA['update_permissions'] = 'Mettre à jour permissions';
$langA['username_or_ip'] = 'Nom d\'utilisateur ou IP';
$langA['status'] = 'Status';
$langA['workgroup'] = 'Groupe de travail';
$langA['admin'] = 'Administrateur';
$langA['full_owner'] = 'Plein/Propriétaire';
$langA['ban'] = 'Bannir';
$langA['banned'] = 'Banni';

//	friends.php
$langA['friends'] = 'Amis';
$langA['my_status'] = 'Mon état';


$langA['EX_USERNAMES'] = 'ex: <a>JeanJacques</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'Vous n\'avez pas spécifié de permissions.';
$langA['view_users'] = 'Voir cet utilisateur...';
$langA['change'] = 'Changer';
$langA['users'] = 'Users';

$langA['USER_REMOVED'] = 'Utilisateur <tt>%s</tt> a été enlevé de ce groupe de travail.';
$langA['USER_NOT_REMOVED'] = 'Utilisateur <tt>%s</tt> n\'a pas été enlevé de ce groupe de travail avec succès. ';
$langA['ADDED_PERMISSIONS'] = 'Pemissions ajoutées pour <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Permissions mise à jour pour <tt>%s</tt>.';
$langA['NOT_A_USER'] = 'Nom d\'utilisateur <tt>%s</tt> introuvable.';
$langA['IP_NOT_ADDED'] = 'Ne peut ajouter/mettre à jour les permissions pour <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>Attention:</b> Utilisateur <tt>%s</tt>. est déjà le propriétaire ce compte.';
$langA['IP_WRONG_LEVEL'] = '<b>Attention:</b> Les adresses IP ne pouvaient avoir de privilèges plus haut que "workgroup".';
$langA['SET_PERMISSIONS'] = 'Pour configurer les permissions pour "%s", selectionnez le status désiré et puis cliquez sur "Mettre à jour les permissions".';


//	specLostPass
$langA['lost_password'] = 'Mot de passe perdu';



//	specFileManager
$langA['file_manager'] = 'Explorateur de fichiers';
$langA['image_manager'] = 'Gérer images';
$langA['CONFIRM_FILE_DELETE'] = 'Êtes-vous sûr de vouloir supprimer <b>%s</b>?';
$langA['IMAGE_MANAGER_INTRO'] = 'Vous pouvez utiliser la syntaxe wiki ou html pour inclure ces images dans vos pages. Pour certains types de fichiers(thèmes, cartes), utilisez la syntaxe html.';
$langA['FILE_MANAGER_INTRO'] = 'Vous pouvez utiliser la syntaxe wiki ou html pour inclure ces fichiers dans vos pages. Pour certain types de fichiers (gabarits, cartes..) nous vous recommendons d\'utiliser la syntaxe html.';
$langA['file_name'] = 'Nom de fichier';
$langA['available_space'] = 'Espace disponible';
$langA['UPLOAD_INTRO'] = 'Envoyer attachements fichiers et images pour les inclures dans vos pages.';
$langA['file_upload'] = 'Envoie fichier';
$langA['file_info'] = 'Information fichier';
$langA['width'] = 'Largeur';
$langA['height'] = 'Hauteur';
$langA['file_location'] = 'Localisation du fichier';
$langA['wiki_syntax'] = 'Syntaxe Wiki';
$langA['html_syntax'] = 'Syntaxe HTML';
$langA['append_to'] = 'ajouter à';
$langA['count'] = 'Compter';
$langA['total_size'] = 'Grosseur totale';
$langA['images'] = 'Images';
$langA['overwrite_existing'] = 'Overwrite Existing';
$langA['compression'] = 'Compression';

$langA['NOT_AN_IMAGE'] = 'Le fichier ne semble pas être une image. Veuillez vérifier le fichier et réessayer encore. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'Ne peut détruire <tt>%s</i>.';
$langA['UPLOADED'] = 'Fichier <tt>%s</i> envoyé avec succès.';
$langA['UPLOADED_RENAMED'] = 'File <tt>%s</tt> was uploaded as <tt>%s</tt>. You may <a %s>rename it to %s</a>.';
$langA['RENAMED'] = 'Ce fichier fut renommé avec succès.';
$langA['UPLOAD_FAILED'] = 'Impossible de copier ce fichier:<tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Cannot upload file <tt>%s</tt>. <br/>Files must be smaller than <tt>%s</tt> bytes.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Sélectionnez un type de fichier:';
$langA['default_options'] = 'Options par défaut';
$langA['UNKNOWN_FILE_TYPE'] = 'Type de page inconnu: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Compte';
$langA['entries'] = 'Entrées';
$langA['average'] = 'Moyenne';
$langA['uploaded_files'] = 'Fichiers envoyés';


//	searchTrash
$langA['deleted'] = 'Effacé';
$langA['restore'] = 'Restorer';
$langA['empty_trash'] = 'Vider la corbeille';
$langA['CONFIRM_EMPTY_TRASH'] = 'Are you sure you want to empty your trash?';

$langA['DELETED_AFTER_30'] = 'Les fichiers seront automatiquement détruits après 30 jours.';
$langA['check_uncheck'] = 'Cocher tous / Décocher tous';
$langA['DELETED_FILES'] = 'Les fichiers sélectionnés furent détruits avec succès.';
$langA['NOTHING_DELETED'] = 'Rien ne fut détruit.';
$langA['DELETE_FILES'] = 'Veuillez choisir un fichier à détruir.';
$langA['MAP_INVALID_PT'] = 'Donnée carte invalide: Format de point invalide.';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'La fonction de recherche pour ce site ne semble pas être activée. Les administrateurs peuvent activer cette fonction grâce au panneau de contrôle.';
$langA['search:'] = 'Recherche ';
$langA['search_for'] = 'Rechercher ';
$langA['registered'] = 'Enregistré';
$langA['restricted'] = 'Réservé';
$langA['locked'] = 'Barré';
$langA['disabled'] = 'Désactivé';
$langA['editing_option'] = 'Option de modifications';
$langA['comments_option'] = 'Option de commentaires';
$langA['visibility_option'] = 'Option de visibilité';
$langA['normal'] = 'Normal';
$langA['advanced'] = 'Avancé';
$langA['relevance'] = 'Rapport';
$langA['SEARCH_ONE'] = 'For at least one of the words';
$langA['SEARCH_ALL'] = 'For all of the words';
$langA['SEARCH_EXACT'] = 'For the exact phrase';
$langA['SEARCH_WITHOUT'] = 'Without the words';
$langA['SEARCH_BEGIN'] = 'For words beginning with';


//	searchKeywords
$langA['keyword_search'] = 'Recherche mot-clef';
$langA['non_tagged_files'] = 'Fichiers sans-bornes';

//	searchChangeLog
$langA['new'] = 								'Nouveau';
$langA['DIFF_TITLE'] = 							'Comparer différences avec la révision la plus récente';
$langA['indicates_syntax_error'] = 				'Erreur de syntaxe';
$langA['indicates_unchecked'] = 				'Indicates an unchecked file.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Sélectionnez une license';
$langA['SELECT_LICENSE_DESC'] = 'Ouvre une page web créations communes dans une fenêtre.';
$langA['DELETE_LICENSE_DESC'] = 'Ceci enlevera votre license de contenu courante.';
$langA['LICENSE_UPDATED'] = 'Votre license de contenu a été mise à jour avec succès.';
$langA['LICENSE_DELETED'] = 'La license fut détruite';
$langA['LICENSE_DELETED2'] = 'La license à déjà été détruite.';
$langA['customize_license'] = 'Modifier votre license';

$langA['text_before'] = 'Texte avant le lien';
$langA['text_after'] = 'Texte après le lien';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'Excepté où expressément noté, ce travail est licencié sous un ';
$langA['LICENSE_TEXT_LINK'] = 'License de créations communes';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Reorganize';
$langA['from'] = 'Expéditeur';
$langA['to'] = 'Destinataire';
$langA['KEYWORDS_UPDATED'] = 'Your keywords have been updated.';
$langA['KEYWORDS_EMPTY'] = 'You have not created any files with keywords yet.';
$langA['REORGANIZE'] = 'Here, you can restructure your files by renaming the keywords you\'ve used.';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';

//links
$langA['uri'] = 'URI';
$langA['label'] = 'Label';
$langA['description'] = 'Description';
$langA['add_link'] = 'Add Link';
$langA['link_groups'] = 'Link Groups';
$langA['group'] = 'Group';
$langA['name'] = 'Nom';
$langA['add_group'] = 'Ajouter un groupe';
$langA['add_page'] = 'Add Page';

$langA['limit'] = 'Limit';
$langA['random'] = 'Random';
$langA['order'] = 'Order';
$langA['LEAVE_EMPTY'] = 'Leave empty for no limit';
$langA['unlimited'] = 'Illimité';
$langA['type'] = 'Type';
$langA['auto_detect'] = 'Auto Detect';
$langA['bookmarklet'] = 'Bookmarklet';
$langA['move_up'] = 'Move Up';
$langA['move_down'] = 'Move Down';
$langA['redirect'] = 'Redirection';
$langA['content_template'] = 'Content Template';

