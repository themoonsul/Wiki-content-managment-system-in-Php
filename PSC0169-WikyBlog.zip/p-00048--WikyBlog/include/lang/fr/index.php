<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'l,_F_j,_Y'; //format to be used with php's date() function

$langA['file'] = 'Fichier';
$langA['edit'] = 'Modifier';
$langA['edits'] = 'Edits';
$langA['view_source'] = 'Voir source';
$langA['talk'] = 'Parler';
//$langA['reply'] = 'Reply';
$langA['history'] = 'Historique';
$langA['diff'] = 'Diff';
$langA['watch'] = 'Suivre';
$langA['unwatch'] = 'Ne plus suivre';
$langA['options'] = 'Options';


$langA['messages'] = 'Messages';
$langA['current'] = 'Courrant';
$langA['blog'] = 'Blogue';
$langA['possible'] = 'Possible';

$langA['DEFAULT_CONTENT'] = 'Ceci est un nouveau fichier, voulez-vous [[%s?cmd=edit|create it]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Ceci est un nouveau fichier. Pour créer ce fichier, vous devez être enregistré avec les privilèges requis.';

$langA['NOT_OWNER'] = 'Vous n\'avez pas les privilèges requis pour cette fonction.';
$langA['LONG_PATH'] = 'Le titre de ce fichier était trop long et à été tronqué.';
$langA['EMPTY_CONTENT'] = 'Contenu est un champ requis';
$langA['INCOMPLETE_PATH'] = 'Le chemin donné est incomplet.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Désoler, l\'administrateur du site web a désactivé le blogging utilisateur. Pour créer un bliki avec les mêmes fonctions qu\'ici, visitez <a href="http://www.wikyblog.com">WikyBlog.com</a>.	';
$langA['TITLE_EXISTS'] = 'This title already exists, please select a different one then save again.';

$langA['HIDDEN_FILE'] = 'Access to this file has been restricted by it\'s owner. To view this file, you need the appropriate privileges.';
$langA['HIDDEN_FILE2'] = 'Ce fichier est "caché". ';
$langA['DELETED_FILE'] = 'Ce fichier est présentement dans la "corbeille". Si vous êtes le propriétaire de ce compte, vous pouvez restorer ce fichier grâce au panneau de contrôle.';
$langA['PROTECTED_FILE'] = 'Ce fichier est protégé. Tout changements fait à ce fichier n\'ont pas été enregistrés.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Lier texte';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Redirected from %s.';
$langA['REDIRECT_TO'] = 'Cette page vous redirige vers %s.';

//	Data Types
$langA['all'] = 'Tout';
$langA['page'] = 'Page';
$langA['comment'] = 'Comment';
$langA['map'] = 'Carte';
$langA['template'] = 'Thème';
$langA['help'] = 'Aide';
$langA['skeleton'] = 'Squelette';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Commentaires';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Pages';
$langA['CLASScomment'] = 'Commentaires';
$langA['CLASSmap'] = 'Cartes';
$langA['CLASStemplate'] = 'Themes';
$langA['CLASShelp'] = 'Aide';
$langA['IS_CONTENT_TEMPLATE'] = 'This file is a content template and won\'t be shown on your blog.';


$langA['seconds'] = ' secondes';
$langA['queries'] = ' demandes';

$langA['QUERY_TIME'] = ' en demande';
$langA['INVALID_PATH'] = 'Mauvais chemin spécifié: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'Invalid Request.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Your Theme';
$langA['CURRENT_THEME'] = 'You are currently using theme <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Use this theme instead';
$langA['using_this_theme'] = 'You are currently using this theme.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'As an integrated part of the software, this help file is stored on a central server.<br/> You can edit the contents of %sthis%s and other help files at %s.';

$langA['NEW_HELP'] = 'Créer un nouveau fichier aide';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Naviguer';
$langA['change_log'] = 'Changer de journal';
$langA['control_panel'] = 'Panneau de Contrôle';
$langA['administration'] = 'Administration';
$langA['preferences'] = 'Préférences';
$langA['watchlist'] = 'Watchlist';
$langA['wanted_files'] = 'Pages les plus demandées';
$langA['dead_end'] = 'Dead-End Files';
$langA['search'] = 'Recherche';
$langA['orphaned_files'] = 'Pages orphelines';
$langA['most_linked'] = 'Most Linked To Files';
$langA['scrl'] = 'Enhanced Scroll';
$langA['nWin'] = 'Lien Externe';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'Messages les plus récents.';
$langA['NEED_INTERNET'] = 'Cette fonction est disponible seulement pour les systèmes connectés à Internet.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Attention:</b> Les cookies sont nécessaires pour continuer. Veuillez actualiser la page si les cookies sont activés.';
$langA['LOGIN_REQUIRED'] = 'Vous devez être enregistré pour utiliser cette fonctionnalité.';

$langA['ENTER_USERNAME'] = 'Veuillez entrer votre nom d\'utilisateur.';
$langA['ENTER_PASSWORD'] = 'Veuillez entrer votre mot de passe.';
$langA['LOGGED_OUT'] = 'Vous vous êtes déconnecté avec succès.';
$langA['AUTO_LOGOUT'] = 'Votre session est expirée.';

$langA['LOGIN_FAILED'] = 'Impossible de se connecter: Mot de passe invalide.<ul><li>ls Majuscules activées?<li>Avez-vous %soublié votre mot de passe%s?</li></ul>'; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'Le nombre maximal de connexions permises à été excédé. Vous ne pouvez pas vous connecter pour les prochaines %s minutes.';
						
$langA['create_new'] = 'Créer&nbsp;Nouveau ';
$langA['remember_me'] = 'Se souvenir de moi';
$langA['log_out'] = 'Déconnexion';
$langA['log_in'] = 'Se connecter';

//	SAVING 
$langA['syntax_error'] = 'erreur de syntaxe';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Erreur de syntaxe:</b> Impossible d\'enregistrer les modifications les plus récentes de ce fichier à cause de la syntaxe incompatible.';
$langA['SYNTAX_FIXED'] = 'L\'erreur de syntaxe a été corrigé.';


$langA['NO_CHANGES'] = 'Aucun changement apporté à ce fichier.(%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Impossible d\'enregistrer ce fichier. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Les changements apportés à ce fichier ont été enregistrés.';
$langA['HIDDEN_FILE3'] = '<b>Note:</b> Ceci est un fichier caché, donc les bornes de ce fichier ne seront pas incluses les totals du menu utilisateur.';

$langA['VERSION_CONFLICT'] = 'Attention: Nous ne pouvions pas enregistrer vos modifications car nous avons détecter un conflit de versions.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.'; //replaced with paths

$langA['FLOOD_WARN'] = 'La modification a été limité à un fichier tout les %s secondes. Veuillez réessayer dans %s secondes.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Enregistrer options';
$langA['blog_this'] = 'Blog This';



//	toolHistory2.php
$langA['differences'] = 'différence(s)';
$langA['line_num'] = 'Lignes';


//	toolHistory1.php
$langA['revision'] = 'Révision ';
$langA['revision_as_of'] = 'Révision à partir de ';
$langA['revision_num_as_of'] = 'Révision %s à partir de %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Modifier révision';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Retourné à la révision #';
$langA['SET_USER_PERMISSIONS'] = 'Configurez vos permmissions pour cet utilisateur: '; 
$langA['compare_with_prev'] = 'Comparer avec dernière révision';
$langA['current_revision'] = 'Révision courante';
$langA['compare_with_next'] = 'Comparer avec la prochaine révision →';
$langA['lines'] = 'Lignes';
$langA['text'] = 'Textes';
$langA['vs'] = ' vs ';
$langA['content'] = 'Contenu';
$langA['your_text'] = 'Votre texte';
$langA['show_prev_revision'] = '← Révision %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Révision %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Attention:</b> Vous nêtes pas entrain de modifier la version la plus récente de cette page.<br/>L\'enregistrement remplacera la version la plus récente avec cette version obsolète.';
$langA['SELECT_TWO_VERSIONS'] = 'Prière de choisir deux versions distinctes afin de comparer.';
$langA['NO_UNIQUE_REVISION'] = 'N\'a pu trouver une révision unique pour cette demande.';
$langA['INVALID_REVISION'] = '<b>Erreur:</b> Numéro de révision invalide.';
$langA['NO_DIFFERENCES'] = 'Les deux révisions en comparaison sont identiques.';
$langA['NO_REVISIONS'] = 'Il doit y avoir deux versions distinctes avant qu\'une comparaison puisse être fait.';
$langA['NON_EXISTANT'] = 'Ce fichier n\'existe pas encore.';

//	toolEditPage.php
$langA['bold_text'] = 'Texte en gras';
$langA['italic_text'] = 'Texte en italique';
$langA['headline_text'] = 'Inserer un en-tête';
$langA['title'] = 'Titre';
$langA['unordered_list'] = 'Liste';
$langA['ordered_list'] = 'Enumération';


$langA['internal_link'] = 'Lien interne';
$langA['link'] = 'Lien';
$langA['external_link'] = 'Lien externe';
$langA['embed_image'] = 'Image intégré';
$langA['find_images'] = 'Find Images';
$langA['image'] = 'Image';
$langA['nowiki'] = 'nowiki';
$langA['NOWIKI_TEXT'] = 'Inserez du texte non-formatté ici.';
$langA['signature'] = 'Signature';
$langA['SIGNATURE_TEXT'] = 'Inserer votre signature';
$langA['preview'] = 'Pré-visualiser';
$langA['PREVIEW_TEXT'] = 'Pré-visualiser les modifications [%s-p]';
$langA['PREVIEW_WARN'] = 'Ceci est seulement une pré-visualisation. Vos modifications n\\\'ont pas encore été enregistrées.';
$langA['SAVE_TEXT'] = 'Enregistrer vos modifications [%s-s]';
$langA['reset'] = 'Remettre à zéro';
$langA['RESET_TEXT'] = 'Remmettre ce formulaire à son état initial [%s-c]';
$langA['changes'] = 'Modifications';
$langA['CHANGES_TEXT'] = 'Montrer les modifications apportées à ce fichier. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Organiser vos messages avec des mots sépararés par des virgules'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Bornes';
$langA['edit_summary'] = 'Modifier sommaire';
$langA['syntax_warning'] = 'Alerte syntaxe';
$langA['NO_IMAGES'] = 'Aucune image trouvée';
$langA['insert_emoticons'] = 'Inserer emoticônes';
$langA['upload'] = 'Envoie';



//searchHistory
$langA['show'] = 'Montrer';
$langA['hide'] = 'Hide';
$langA['compare'] = 'Comparer';
$langA['timeline'] = 'Ligne du temps';
$langA['summary'] = 'Sommaire';
$langA['COMPARE_REVISONS'] = 'Comparere avec la version sélectionné.';
$langA['unchecked'] = 'Unchecked';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Type de fichier invalide.';


//	SEARCH
$langA['next'] = 'Suivant';
$langA['previous'] = 'Précédent';
$langA['order_by'] = 'Ordre par:';
$langA['ascending'] = 'Acendant';
$langA['descending'] = 'Descendant';
$langA['search_from'] = 'Rechercher à partir de: ';
$langA['all_users'] = 'Tout les utilisateurs';
$langA['user'] = 'Utilisateur';
$langA['from_file_type'] = 'Rechercher à partir du type de fichier: ';
$langA['read_more'] = 'Lire plus';
$langA['words'] = ' mots';

$langA['RESULTS'] = 'Résultats %s à %s de %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'Aucun résulat pour le critère de recherche.';

//searchTalk
$langA['add_comment'] = 'Ajouter un nouveau sujet';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Ne peut inclure un avertissement. Mauvais format de données pour la duplication de l\'entrée.';
$langA['duplicate_entry'] = 'Dupliquer entrée';
$langA['DUPLICATE_ENTRY'] = 'Ceci est une copie de l\'entrée trouvée sur %s. <br/>Toute information non-redondante devrait être transférée à l\'original avant que cette page soit supprimée.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Introuvable: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Erreur:</b><br />Une erreur s\'est produite durant l\'éxécution du script.<br> Veuillez vérifier votre demande et nous essayerons de déboguer le script avec le journal d\'erreurs. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Ne peut supprimer le thème par défaut.';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'Le thème spécifié est invalide.';

//
//	CLASSmap
//
$langA['new_marker']='Nouveau marqueur';
$langA['new_route']='Nouvelle route';
$langA['SAVE_HEADER']='Avant d\'enregistrer, souvenez-vous';
$langA['save_map']='Enregistrer carte';
$langA['continue_editing']='Continuer modification';
$langA['miles/km'] = 'miles/km';
$langA['MAP_DEFAULT_CONTENT'] = '<b>Ceci est une nouvelle carte.</b><br/>Pour créer/modifier cette carte, cliquez sur "Éditer" ci-haut.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Désoler, vous n\'avez pas les privilèges nécessaires pour modifier cette carteé';
$langA['play'] = 'Jouer';
$langA['stop'] = 'Arrêter';
$langA['import'] = 'Importer';
$langA['export'] = 'Exporter';
$langA['gpx_data'] = 'Données GPX';
$langA['gpx_exchange_format'] = 'Format d\'échange GPX';
$langA['CLICK_EDIT'] = 'Pour modifier cette carte, cliquez sur "éditer" ci-haut.';


//	smileys
$langA['smiles'][':D'] = 'Très heureux';
$langA['smiles'][':)'] = 'Sourire';
$langA['smiles'][':('] = 'Triste';
$langA['smiles'][':o'] = 'Étonné';
$langA['smiles'][':shock:'] = 'Choqué';
$langA['smiles'][':?'] = 'Confus';
$langA['smiles']['8)'] = 'Cool';
$langA['smiles'][':lol:'] = 'Rire';
$langA['smiles'][':x'] = 'Fou';
$langA['smiles'][':P'] = 'Razz';
$langA['smiles'][':oops:'] = 'Embarrassé';
$langA['smiles'][':cry:'] = 'En train de pleurer ou très triste';
$langA['smiles'][':evil:'] = 'Méchant ou vraiment enragé';
$langA['smiles'][':twisted:'] = 'Méchant';
$langA['smiles'][':roll:'] = 'Yeux qui roulent';
$langA['smiles'][':wink:'] = 'Clin d\'œil';
$langA['smiles'][':!:'] = 'Exclamation';
$langA['smiles'][':?:'] = 'Question';
$langA['smiles'][':idea:'] = 'Idée';
$langA['smiles'][':arrow:'] = 'Flèche';
$langA['smiles'][':|'] = 'Neutre';
$langA['smiles'][':mrgreen:'] = 'Mr. Vert';

//
//	General Language
//
$langA['or'] = 'ou';
$langA['username'] = 'Utilisateur';
$langA['password'] = 'Mot de passe';
$langA['email'] = 'Courriel';
$langA['register'] = 'Enregistrer';
$langA['cancel'] = 'Annuler';
$langA['language'] = 'Langue';
$langA['use'] = 'Utiliser';
$langA['copy'] = 'Copier';
$langA['rename'] = 'Renommer';

$langA['on'] = 'Ouvert';
$langA['partial'] = 'Partiel';
$langA['off'] = 'Fermé';
$langA['save'] = 'Enregistrer';
$langA['save_now'] = 'Save Now';
$langA['undefined'] = 'Indéfinit';
$langA['homepage'] = 'Page d\'accueil';
$langA['home'] = 'Accueil';
$langA['go'] = 'Valider';
$langA['user_menu'] = 'Menu utilisateur';

$langA['last_modified'] = 'Dernière modification';
$langA['LAST_MODIFIED'] = 'Dernière modification %s par %s';//%s replaced with date and username
$langA['accessed_times'] = 'Accédé %s fois.';// %s replaced with a number
$langA['modified'] = 'Modifié';
$langA['posted'] = 'Posté';
$langA['created'] = 'Créé';
$langA['hidden'] = 'Caché';
$langA['what_links_here'] = 'Pages liées';
$langA['share'] = 'Partager';
$langA['INVALID_LINK'] = 'The requested page title was invalid. It may contain one more characters which cannot be used in titles.';
$langA['FILE_MUST_EXIST'] = 'Ce fichier doit être enregistrer avant que vous ne puissiez performer cetter opération.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Grosseur ';
$langA['bytes'] = 'octets';
$langA['kb'] = 'KO';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Mise à jour';
$langA['editing'] = 'Édition';
$langA['workgroup'] = 'Groupe de travail';
$langA['BROWSE_HIDDEN'] = 'Trouver fichiers cachés';

$langA['delete'] = 'Supprimer';
$langA['confirm_delete'] = 'Confirmer la suppression';
$langA['continue'] = 'Continuer';
$langA['back'] = 'Retour';
$langA['close'] = 'Close';
$langA['view'] = 'Voir';
$langA['empty'] = '-vide-';
$langA['none'] = 'Aucune';
$langA['total'] = 'Total ';
$langA['files'] = 'Fichiers';
$langA['other'] = 'Autre';
$langA['trash'] = 'Corbeille';
$langA['flagged'] = 'Flagged';

$langA['today'] = 'Aujourd\'hui';
$langA['yesterday'] = 'Hier';
$langA['days_ago'] = ' jours passés';
$langA['page_contents'] = 'Page Contents';
$langA['more'] = 'Plus';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'dimanche';
$langA['date_l'][1] = 'lundi';
$langA['date_l'][2] = 'mardi';
$langA['date_l'][3] = 'mercredi';
$langA['date_l'][4] = 'jeudi';
$langA['date_l'][5] = 'vendredi';
$langA['date_l'][6] = 'samedi';

$langA['date_D'][0] = 'Dimanche';
$langA['date_D'][1] = 'Lundi';
$langA['date_D'][2] = 'Mardi';
$langA['date_D'][3] = 'Mercredi';
$langA['date_D'][4] = 'Jeudi';
$langA['date_D'][5] = 'VEndredi';
$langA['date_D'][6] = 'Samedi';


$langA['date_F'][1] = 'janvier';
$langA['date_F'][2] = 'février';
$langA['date_F'][3] = 'mars';
$langA['date_F'][4] = 'avril';
$langA['date_F'][5] = 'mai';
$langA['date_F'][6] = 'juin';
$langA['date_F'][7] = 'juillet';
$langA['date_F'][8] = 'août';
$langA['date_F'][9] = 'septembre';
$langA['date_F'][10] = 'octobre';
$langA['date_F'][11] = 'novembre';
$langA['date_F'][12] = 'décembre';

$langA['date_M'][1] = 'jan';
$langA['date_M'][2] = 'fév';
$langA['date_M'][3] = 'mar';
$langA['date_M'][4] = 'avr';
$langA['date_M'][5] = 'mai';
$langA['date_M'][6] = 'jun';
$langA['date_M'][7] = 'jul';
$langA['date_M'][8] = 'aoû';
$langA['date_M'][9] = 'Septembre';
$langA['date_M'][10] = 'oct';
$langA['date_M'][11] = 'nov';
$langA['date_M'][12] = 'déc';

$langA['date_a']['am'] = 'am';
$langA['date_a']['pm'] = 'pm';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Arabe (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'Allemand (de)';
$langA['lang']['el'] = 'Greek (el)';
$langA['lang']['en'] = 'Anglais (en)';
$langA['lang']['es'] = 'Espagniol (es)';
$langA['lang']['fr'] = 'Français (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Italien (it)';
$langA['lang']['ja'] = 'Japonais (ja)';
$langA['lang']['ko'] = 'Korean (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Dutch (nl)';
$langA['lang']['pl'] = 'Polish (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Russe (ru)';
$langA['lang']['tr'] = 'Turc (tr)';
$langA['lang']['vi'] = 'Vietnamese (vi)';
$langA['lang']['zh'] = 'Chinois (zh)';
$langA['lang']['zh-cn'] = 'Chinese Simplified (zh-cn)';



