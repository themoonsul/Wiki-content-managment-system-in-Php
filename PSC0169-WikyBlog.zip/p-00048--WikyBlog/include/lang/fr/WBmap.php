<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'Chargement de la carte';
$langA['MAP_DEBUG_O'] = 'Une erreur s\'est produite durant le chargement ce cette page et la carte demandée ne peut être montée.<p></p>Un journal de l\'erreur a été crée et l\'administrateur du site devrait réparer l\'erreur d\'ici peu.';
$langA['MAP_DEBUG_1'] = 'The Google Maps API does not appear to be compatible with your browser.<p>If you know your browser is compatible, make sure the correct map key is being used and that you are connected to the internet.</p><p>You can <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">get more information</a> about browser support from google.com.</p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>Attention</b>Les cartes nécessitent javascript.</p><p>Il semble que javascript n\'a pas été activé dans votre navigateur web. Pour voir cette carte, veuillez activer javascript dans votre navigateur et actualisez la page.</p>';