<?php

	$langA['googleMapKeys'] =						'Clef API Google Maps';


	$langA['ADMIN_ONLY'] =							'Vous devez être un administrateur pour accéder cette page.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Cette page admin n\'a pas encore été définit: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Veuillez confirmer votre mot de passe pour continuer.';
	$langA['confirm_password'] =						'Confirmez le mot de passe.';
	$langA['confirmation_failed'] =					'Confirmation du mot de passe échouée. Essayez encore.';
	
	$langA['run_scheduled_tasks'] =					'Run Scheduled Tasks';
	$langA['FAILED'] = 								'Sorry, the desired action failed. Please try again.';
	$langA['SUCCESS'] = 								'The desired action was successful.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Options de recherche';
	$langA['search_status'] =						'Statut de la recherche';
	$langA['search_enabled'] =						'Recherche Activée';
	$langA['SEARCH_ENABLED'] =						'Désactiver l\'option de recherche videra la table de la base de données \'all_search\'. Plus tard, si vous voulez réactiver l\'option de recherche, la table \'all_search\' devra être remplie de nouveau.';
	$langA['disable'] =								'Désactiver';
	
	$langA['search_disabled'] =						'Recherche Désactivée';
	$langA['SEARCH_DISABLED'] =						'La recherche est présentement désactivée. L\'activation nécessite que la table \'all_search\' de la base de données soit remplit avec les entrées de tout les fichiers de la base de données. Ceci peut prendre un moment.';
	$langA['SEARCH_IS_DISABLED'] =					'Recherche désactivée and table de recherche tronquée.';
	$langA['enable'] =								'Activer';
	
	$langA['FINISHED_ENTRIES'] =						'%s entrées fait, %s restantes.';
	$langA['SEARCH_IS_ENABLED'] =					'Cette fonction de recherche est maintenant activée.';


//
// adminConfig.php
//
	$langA['configuration'] =						'Configuration';
	$langA['confighistory'] =						'Historique de la configuration';
	$langA['CONFIG_SAVING'] =						'Les nouvelles configurations sont enregistrées de façon à ne pas détruire les valeurs courantes, vous offrant la possibilité de revenir en arrière.';
	$langA['CONFIG_STAT'] =							'Il y a eu %s révisions de la configuration fait jusqu\'à présent.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Êtes-vous sûre de vouloir retourner à la révision numéro %s. Cliquez <tt>Enregistrer</tt> pour continuer.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Une phrase qui peut être utilisée avec quelque chose comme: "Bienvenue sur nomServeur1"';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://nomDeServeur2';

//default user

	$langA['max_upload']['desc'] = 					'Grosseur max d\'un fichier envoyé.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Users won\'t be allowed to register using these comma separated strings as usernames.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Grosseur max pour le journal d\'erreurs. 10, 000 octets par défaut.';
	$langA['errorEmail']['desc'] = 					'Donnez une adresse courriel. ';
	
	
	$langA['include']['desc'] = 						'Automatically have the software include a php file with each request. Filenames can be given comma separated and relative to your rootDir.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Options générales';
	$langA['performance'] = 							'Performance';
	
	$langA['serverName1']['alias'] = 				'Nom de serveur personnalisé';
	$langA['serverName2']['alias'] = 				'Nom du serveur';
	$langA['serverName3']['alias'] = 				'Adresse URL complète du serveur';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Max envoie';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Langue';
	$langA['reservedWords']['alias'] = 				'Mots réservés';
	
	$langA['developer_aids'] = 						'Aides au développeur';
	$langA['maxErrorFileSize']['alias'] = 			'Grosseur du journal d\'erreurs';
	$langA['errorEmail']['alias'] = 					'Erreur courriel';
	$langA['include']['alias'] = 					'Inclure PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Options par défaut de l\'utilisateur';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Titre de la page d\'accueil';
	$langA['defaultUser:homeTitle']['desc'] =		'Affiché en tant que titre de la page d\'accueil.';
	
	$langA['defaultUser:template']['alias'] =		'Thème de l\'utilisateur';
	$langA['defaultUser:template']['desc'] =		'Main/Home est le thème de wikyblog par défaut.';
	
	$langA['defaultUser:textareaY']['alias'] =		'Hauteur de la zone de texte';
	$langA['defaultUser:textareaY']['desc'] =		'Default textarea height.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Page d\'accueil du blogue';
	$langA['defaultUser:isBlog']['desc'] =			'Activer/Désactiver page d\'accueil du blogue avec style.';
	
	$langA['defaultUser:timezone']['alias'] =		'Fuseau horaire';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Lignes max pour l\'historique';
	$langA['defaultUser:maxHistory']['desc'] =		'Lignes max pour l\'historique par défaut.';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Ajouter un groupe';
	$langA['unlimited'] = 'Illimité';
	$langA['group'] = 'Group';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Registration';
	$langA['register:reqemail']['alias'] = 				'Require Email Address';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Use Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Statistiques utilisateur';
	$langA['user_stats'] =							'Statistiques utilisateur';
	$langA['user_account'] =							'Compte utilisateur';
	$langA['entries'] =								'Entrées';
	$langA['history Rows'] =							'Lignes de l\'historique';
	$langA['last_visit'] = 							'Dernière visite';
	
	$langA['users_found'] =							'Utilisateurs trouvés';
	$langA['showing_of_found'] =						'Montrer %s jusqu\'à %s';
	$langA['cpanel'] =								'CPanel';
	$langA['details'] =								'Détails';
	
	$langA['within_the_hour'] =						' < 1 heure passée';
	$langA['hours'] =								'heures';
	$langA['days'] =									'jours';
	$langA['months'] =								'mois';
	$langA['years'] = 								'années';
	$langA['ago'] = 									'depuis';
	
	$langA['TIMEOUT'] = 								'<b>Erreur de délais:</b> %s.';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Warning</b> Cannot delete the "Main" account';
	$langA['CONFIRM_DELETE_USER'] = 					'Êtes-vous sûr de vouloir supprimer <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'La supression effacera <i>complètement</i> tous les fichiers de ce compte incluant:';
	$langA['userfiles_directory'] = 					'Répertoire pour les fichiers utilisateurs: ';
	$langA['template_directory'] = 					'Répertoire pour les thèmes: ';
	$langA['database_entries'] = 					'Toutes les entrées de la base de données: pages, historique des pages, commentaires etc.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Entrées de la base de données supprimées.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Attention:</b>Ne peut supprimer les entrées de la  base de données.';
	
	$langA['DELETED_USERFILES'] = 					'Répertoire pour les fichiers utilisateur supprimé.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Attention:</b>Ne peut supprimer le répertoire des fichiers utilisateurs.';
	
	$langA['DELETED_TEMPLATES'] = 					'Répertoire Thèmes supprimé.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Attention:</b>Ne peut supprimer le répertoire Thèmes.';
	
	$langA['USER_DELETED'] = 						'%s fut complètement supprimé: ';
	$langA['USER_NOT_DELETED'] = 					'%s n\'a pas complètement été supprimé. ';
	$langA['DELETE_ACCOUNT'] = 						'Delete this account entirely.';
	$langA['DISABLE_ACCOUNT'] = 					'Disable file editing.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Add "nofollow" to all external links.';
	$langA['updated'] = 							'Mis à jour';
	$langA['suspend'] = 							'Suspendre';
	$langA['activate'] = 							'Activer';
	$langA['lost_page'] = 							'Page perdue';
	$langA['suspended'] =							'Suspendu';
	$langA['disabled'] =							'Désactivé';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Ne peut supprimer le journal d\'erreurs.';
	$langA['ERROR_LOG_DELETED'] = 					'Le journal d\'erreurs fut supprimé.';
	$langA['ERROR_LOG_MAXED'] = 						'Le journal d\'erreurs a atteint la limite maximal, veuillez vider le fichier de façon que le programme puisse continuer la journalisation des erreurs. %s';


	$langA['select'] = 								'Sélectionner';
	$langA['description'] = 						'Description';


//	adminPlugins
	$langA['data_types'] = 							'Types de données'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Types existants';
	$langA['available_plugins'] = 					'Plugiciels disponibles';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Cocher tous / Décocher tous';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Connecté';
	$langA['wbConfig']['online']['desc'] = 			'Est-ce que cette implémentation est connectée à Internet ?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Intervalle flood';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Le nombre de secondes qu\'un utilisateur devra attendre entre deux modifications.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Determines the level of JavaScript enhancement for the anonymous users.';
	
	$langA['wbConfig']['tidy']['alias'] =			'HTML Tidy';
	$langA['wbConfig']['tidy']['desc'] =				'Utiliser HTML Tidy pour corriger les erreurs d\'entrées possibles.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Toutes les fonctionnalités.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Donner la permission aux utilisateurs d\'avoir leur propre blogue.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Select the user account that will be displayed if one isn\'t given by the visitor.';
	$langA['wbConfig']['pUser']['alias'] = 			'Utilisateur par défaut.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Determines how much of the user\'s IP will be checked when validating sessions.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Session Level';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

