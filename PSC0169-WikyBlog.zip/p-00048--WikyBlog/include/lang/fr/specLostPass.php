 <?php

$langA['CHANGE_PASS_INTRO'] = 'To change your password, we first need to send you a "Permission Key" so that you may access this restricted feature. Once you have received the key, return to this page and enter the information below. Please note, your "Permission Key" will only work for your Username.';

$langA['next_step'] = 'Prochaine étape';

$langA['PASS_EMAIL_SUBJECT'] = 'Clef de permission pour %s';
$langA['PASS_EMAIL_TEXT'] ='Votre clef de permission pour %s est %s';

$langA['get_your_key'] = 'Obtenir votre clef de permission';
$langA['GET_YOUR_KEY'] = 'Votre clef sera envoyé à l\'adresse courrielle que vous avez fournit durant l\'enregistrement.';

$langA['send_key'] = 'Envoyer clef de permission';

$langA['change_password'] = 'Changer votre mot de passe';
$langA['permission_key'] = 'Clef de persmission';
$langA['new_password'] = 'Nouveau mot de passe';

//messages
$langA['PASSWORD_CHANGE_FAILED'] = 'Échech du changement du mot de passe: Clef de permission ou nom d\'utilisateur incorrect';
$langA['PASSWORD_CHANGED'] = 'Mot de passe mis à jour avec succès pour <tt>%s</tt>.';
$langA['PROVIDE_PASSWORD'] = 'Vous devez fournir un nouveau mot de passe.';
$langA['PROVIDE_PERMISSION_KEY'] = 'Vous devez fournir une clef de permission pour changer votre mot de passe';
$langA['PERMISSION_KEY_SENT'] = 'Clef de permission envoyé avec succès. Retrouvez la clef à partir de votre courriel et utilisez-la pour changer votre mot de passe en utilisant le questionnaire ci-bas.';
$langA['PERMISSION_KEY_NOT_SENT'] = 'Échec de l\'envoie de la clef de permission à l\'adresse de courriel fournit, veuillez contacter l\'administrateur pour de l\'aide.';
$langA['NO_EMAIL_FOR_ACCOUNT'] = 'Une adresse de courriel n\'a pas été fournit pour ce compte. Veuillez contacter l\'administrateur pour de l\'aide.';

