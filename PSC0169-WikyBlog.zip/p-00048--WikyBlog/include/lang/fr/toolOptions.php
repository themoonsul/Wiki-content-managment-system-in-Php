<?php

//	toolOptions.php
$langA['properties'] = 'Propriétés';
$langA['file_name'] = 'Nom de fichier';
$langA['update_from'] = 'Mise à jour à partir de';
$langA['COPY_SYSTEM_FILES'] = 'Copier les fichiers d\'aides les plus récents à partir de %s.';

$langA['EDITING_OPTIONS'] = 'Contrôler ceux qui peuvent modifier ce fichier.';
$langA['registered_users'] = 'Utilisateurs enregistrés';
$langA['restricted_to'] = 'Restraint à ';
$langA['admin_only'] = 'Administrateur seulement';
$langA['editor_visible'] = 'Visible to Editors';
$langA['owner_only'] = 'Owner Only';
$langA['use_captcha'] = 'Use Captcha';
		

$langA['visibility'] = 'Visibilité';
$langA['VISIBILITY_OPTIONS'] = 'Cacher ce fichier si vous n\'êtes pas prêt à l\'afficher au monde entier.';
$langA['visible'] = 'Visible';

$langA['COMMENT_OPTIONS'] = 'Désactiver les commentaires pour ce fichier.';
$langA['enabled'] = 'Activé';
$langA['disabled'] = 'Désactivé';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Anti Spam';
$langA['nofollow'] = 'Nofollow';

$langA['other'] = 'Autre';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Retirer du blogue';
$langA['repost'] = 'Reposter';
$langA['copy_to'] = 'Copier vers...';
$langA['send_to_trash'] = 'Envoyer à la corbeille';
$langA['default_options'] = 'Options par défaut';
$langA['restore_defaults'] = 'Restore Defaults';
$langA['SET_DEFAULT_OPTIONS'] = 'Configurer %s pour ce type de fichier.'; //replaced with link
$langA['add_to_tabs'] = 'Add To Tabs';
$langA['add_to_links'] = 'Add To Links';

$langA['REPOSTED'] = 'Ce fichier fut reposté';
$langA['NOT_REPOSTED'] = '<b>Erreur:</b> Impossible de reposter ce fichier.';
$langA['OPTIONS_NOT_CHANGED'] = 'Les options de fichier ne furent pas changées.';
$langA['OPTIONS_UPDATED'] = 'Les options de fichier furent changé avec succès.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Attention:</b> Les options de fichier ne furent pas mise à jour.';

$langA['redirect'] = 'Redirection';
$langA['REMOVE_REDIRECT'] = 'Si vous ne voulez plus que ce fichier redirige, vous pouvez soit le supprimer ou le modifier. ';


$langA['UNCHECKED_REMOVED'] = 'The "Unchecked" flag has been removed from this file.';

$langA['NO_KEYWORDS'] = 'There aren\'t any keywords set for this file. Would you like to <a %s>add keywords first</a> or <a %s>blog it now</a>?';

$langA['file_id'] = 'File ID';

//watch
$langA['WATCH_UPDATED'] = 'Your <a %s>watchlist</a> was updated.';


$langA['user_permissions'] = 'Permissions&nbsp;utilisateur';
