<?php
//	Some Standards for creating new entries
// 
//		UPPER CASE keys should be used when the text is a phrase
//			$langA['UPPER_CASE'] = 'This is an UPPER_CASE entry in $langA';
//			$langA['COPY_TO'] = 'Copy  &nbsp; <b>%s</b> &nbsp; to &nbsp; <b>%s</b>.<br/>Click "Save" to finalize the copy.';
//
//		lower case keys should be used for more simple word for word tanslations
//			$langA['lower_case'] = 'lower case';
//			$langA['copy_to'] = 'Copy To...';
//
//		Use _ (uderscore) for spaces in keys
//			$langA['A_SPACE']  .. instead of $langA['A SPACE']
//
//		Prefer <tt> to <i>


//
//	wiki2.php
//

$langA['NEW_PAGE_FORMAT'] = 'j_F_Y_г.,_l'; //format to be used with php's date() function

$langA['file'] = 'Файл';
$langA['edit'] = 'Редактировать';
$langA['edits'] = 'Поля редактирования';
$langA['view_source'] = 'Просмотр исходного кода';
$langA['talk'] = 'Комментировать';
//$langA['reply'] = 'Reply';
$langA['history'] = 'История';
$langA['diff'] = 'Сравнить';
$langA['watch'] = 'Наблюдать';
$langA['unwatch'] = 'Снять наблюдение';
$langA['options'] = 'Параметры';


$langA['messages'] = 'Сообщения';
$langA['current'] = 'Текущий';
$langA['blog'] = 'Блог';
$langA['possible'] = 'Возможно';

$langA['DEFAULT_CONTENT'] = 'Это новый файл, хотите ли Вы [[%s?cmd=редактировать|созать его]]?'; //replaced with url to current page
$langA['DEFAULT_CONTENT_PROTECTED'] = 'Это новый файл. Для создания этого файла Вам потребуется войти в систему с соответствующими полномочиями.';

$langA['NOT_OWNER'] = 'У Вас отсутствуют соответствующие полномочия для этой операции.';
$langA['LONG_PATH'] = 'Заголовок этого файла имеет слишком большую длинну и будет обрезан.';
$langA['EMPTY_CONTENT'] = 'Содержимое является обязательным полем';
$langA['INCOMPLETE_PATH'] = 'Приведенный путь не полон.';
$langA['ADMIN_DISABLED_ALL_USERS'] = 'Извините, но Администратор сайта запретил ведение блогов. Чтобы создать wiki блог (bliki) в такими же возможностями, как здесь, посетите <a href="http://www.wikyblog.com">WikyBlog.com</a>.';
$langA['TITLE_EXISTS'] = 'Страница с таким именем уже существует, выберите другое название и сохраните еще раз.';

$langA['HIDDEN_FILE'] = 'Доступ к этому файлу был ограничен его владельцем. Для его просмотра необходимы соответствующие права.';
$langA['HIDDEN_FILE2'] = 'Файл "скрыт". ';
$langA['DELETED_FILE'] = 'Этот файл  сейчас в "Мусорной корзине". Если Вы являетесь владельцем этой учетной записи, Вы можете восстановить его через Панель управления.';
$langA['PROTECTED_FILE'] = 'Файл защищен. Любые изменения этого файла сохраняться не будут.';
$langA['INVALID_THEME'] = 'Invalid theme name defined in preferences. Using default theme.';
$langA['link_text'] = 'Текст ссылки';
$langA['SURPASSED_MAX'] = '<b>Warning:</b> Disk usage has exceeded the allotted amount. Any changes made to this file were not saved.';


$langA['REDIRECTED'] = 'Перенаправлено с %s.';
$langA['REDIRECT_TO'] = 'Эта страница перенаправит на %s.';

//	Data Types
$langA['all'] = 'Вcе';
$langA['page'] = 'Страница';
$langA['comment'] = 'Комментарий';
$langA['map'] = 'Карта';
$langA['template'] = 'Шаблон';
$langA['help'] = 'Справка';
$langA['skeleton'] = 'Шаблон';
$langA['attach'] = 'Attachment';

$langA['theme'] = 'Theme';

$langA['comments'] = 'Комментарии';

//exceptions to our standards because we use the name of datatypes 
$langA['CLASSpage'] = 'Страницы';
$langA['CLASScomment'] = 'Комментарии';
$langA['CLASSmap'] = 'Карты';
$langA['CLASStemplate'] = 'Темы';
$langA['CLASShelp'] = 'Справка';
$langA['IS_CONTENT_TEMPLATE'] = 'Этот файл является шаблоном контента и не может быть показан в Вашем блоге.';


$langA['seconds'] = ' сек';
$langA['queries'] = ' запрос(ов)';

$langA['QUERY_TIME'] = ' для запросов';
$langA['INVALID_PATH'] = 'Неправильный путь к файлу: <tt>%s</tt>.';							//replaced with path
$langA['INVALID_REQUEST'] = 'неправильный запрос.';


//	CLASStemplate.php
$langA['THEME_DEFAULT_CONTENT'] = 'This is a new theme. Edit this theme by clicking the "Edit" link above.<br/>When creating themes remember to include all of the required content variables:';
$langA['your_theme'] = 'Ваша тема';
$langA['CURRENT_THEME'] = 'Вы используете тему <b>%s</b>.'; //replaced with template name

$langA['use_this_theme'] = 'Используйте эту тему вместо';
$langA['using_this_theme'] = 'Сейчас вы используете эту тему.';
$langA['MAKE_THEME'] = 'Make a personalized theme using a copy of this one as a starter.';
$langA['EDIT_THEME_TEXT'] = '<p><h2>Editing</h2> When editing themes, your changes will not be immediately visible.<br />You may have to use your browser\'s "refresh" button to review changes after saving.';

//	CLASShelp.php
$langA['HELP_FOOTER'] = 'Данный файл помощи является составной частью программного обеспечения и хранится на центральном сервере.<br/> Вы можете редактировать содержимое %sэтого%s и других файлов помощи в %s.';

$langA['NEW_HELP'] = 'Создать новый файл Помощи';



//	Special Files that need to be in with main lang file
$langA['browse'] = 'Просмотреть';
$langA['change_log'] = 'Протокол изменений';
$langA['control_panel'] = 'Панель управления';
$langA['administration'] = 'Администрирование';
$langA['preferences'] = 'Настройки';
$langA['watchlist'] = 'Список наблюдения';
$langA['wanted_files'] = 'Желаемые файлы';
$langA['dead_end'] = 'Файлы без ссылок';
$langA['search'] = 'Искать';
$langA['orphaned_files'] = 'Файлы без родителей';
$langA['most_linked'] = 'Файлы с наибольшим количеством ссылок';
$langA['scrl'] = 'Расширенные возможности прокрутки';
$langA['nWin'] = 'Внешние ссылки';
$langA['enhanced_tabs'] = 'AJAX Browsing';

$langA['MORE_RECENT_POST'] = 'Последние записи.';
$langA['NEED_INTERNET'] = 'Эта опция доступна только в системах, соединенных с Интернет.';


//	SESSION
$langA['COOKIES_REQUIRED'] = '<b>Предупреждение:</b> Для продолжения необходимы Cookies. Обновите эту страницу если у Вас разрешены Cookies.';
$langA['LOGIN_REQUIRED'] = 'Вы должны войти в систему для использования этой опции.';

$langA['ENTER_USERNAME'] = 'Введите Имя пользователя.';
$langA['ENTER_PASSWORD'] = 'Введите Пароль.';
$langA['LOGGED_OUT'] = 'Вы успешно вышли из системы.';
$langA['AUTO_LOGOUT'] = 'Время Вашей сессии закончилось.';

$langA['LOGIN_FAILED'] = 'Неудачный вход в систему: ошибочный пароль.<ul><li>Включен ли CapsLock?<li>Вы %sзабыли пароль%s?</li></ul> '; //replacements are for <a href=""> and </a>
$langA['LOGIN_BLOCK'] = 'Достигното максимальное количество попыток входа в систему. Вы не сможете войти в ближайшие %s минут(ы).';
						
$langA['create_new'] = 'Создать&nbsp;Новый ';
$langA['remember_me'] = 'Запоминать меня';
$langA['log_out'] = 'Завершение сеанса';
$langA['log_in'] = 'Вход в систему';

//	SAVING 
$langA['syntax_error'] = 'синтаксическая ошибка';
//$langA['SYNTAX_WARNING'] = 'A %s was detected within this file and may result in undesired formatting.'; //%s will be replaced with a link and $langA['syntax_error']
$langA['SYNTAX_WARNING'] = 'A <a %s>syntax error</a> was detected within this file and may result in undesired formatting.';

$langA['OTHER_ACCOUNT'] = 'Would you like to create files for %s instead of %s.';
$langA['MAKE_ADMIN'] = 'Set the <a %s>file options</a> to "<tt>Admin Only</tt>" to skip syntax checking.';


$langA['THEME_SYNTAX_WARN'] = '<b>Синтаксическая ошибка:</b> Не могу Сохранить/Показать последние изменения этого файла из-за несовместимого синтаксиса.';
$langA['SYNTAX_FIXED'] = 'Синтаксическая ошибка исправлена.';


$langA['NO_CHANGES'] = 'В этом файле не было изменений. (%s)';								//replaces with 1 or 2.. there are two checks for changes
$langA['UNABLE_TO_SAVE'] = 'Не могу сохранить этот файл. (%s)';									//replaces with 1,2,3 or 4..
$langA['SAVED_FILE'] = 'Изменения этого файла сохранены.';
$langA['HIDDEN_FILE3'] = '<b>Замечание:</b> Это скрытый файл, поэтому его теги не будут вкллючены в пользовательское меню.';

$langA['VERSION_CONFLICT'] = 'Предупреждение: Невозможно сохранить Ваши изменения поскольку обнаружен конфликт версий.';
$langA['VERSION_CONFLICT_2'] = 	'Warning: We could not save your changes because we detected a version conflict.
								The following events could have resulted in this discrepancy.
								<ul><li>You may be trying to overwrite an existing file.</li>
								<li>Your session may have expired.</li>
								<li>Someone else may have saved changes to this file.</li></ul>';

$langA['COPY_TO'] = 'Копировать&nbsp;<b>%s</b>&nbsp;в&nbsp;<b>%s</b>.<br/>Нажмите "Сохранить" для подтверждения.'; //replaced with paths

$langA['FLOOD_WARN'] = 'Редактирование ограничено до одного раза в %s секунд. попробуйте еще раз через %s секунд.';
$langA['INCORRECT_CAPTCHA'] = 'The CAPTCHA image did not match your text, please try again.';

//	toolOptions .. see /lang/../toolOptions.php
$langA['save_options'] = 'Параметры сохранения';
$langA['blog_this'] = 'Сделать блогом';



//	toolHistory2.php
$langA['differences'] = 'paзница';
$langA['line_num'] = 'Строка №';


//	toolHistory1.php
$langA['revision'] = 'Версия ';
$langA['revision_as_of'] = 'Версия от ';
$langA['revision_num_as_of'] = 'Версия %s от %s'; //replaced with revision num and timestamp
$langA['edit_revision'] = 'Редактировать версию';
$langA['revert_to_revision'] = 'Revert To This Revision';
$langA['reverted_to_rev'] = 'Вернуться к версии №';
$langA['SET_USER_PERMISSIONS'] = 'Установите Ваши разрешения пользователю: '; 
$langA['compare_with_prev'] = '← Сравните с предыдущей версией';
$langA['current_revision'] = 'Текущая версия';
$langA['compare_with_next'] = 'Сравните со следующей версией →';
$langA['lines'] = 'Строк';
$langA['text'] = 'Текст';
$langA['vs'] = ' VS ';
$langA['content'] = 'Содержимое';
$langA['your_text'] = 'Ваш текст';
$langA['show_prev_revision'] = '← Версия %s'; //%s replaced with a revision number
$langA['show_next_revision'] = 'Версия %s →'; //%s replaced with a revision number

$langA['EDITING_REVISION'] = '<b>Предупреждение:</b> Вы редактируете не самую последнюю версию этой страницы. Сохранение заменит последнюю версию этой устаревшей.';
$langA['SELECT_TWO_VERSIONS'] = 'Выберите две разне версии для сравнения.';
$langA['NO_UNIQUE_REVISION'] = 'Не могу найти уникальную версию для этого запроса.';
$langA['INVALID_REVISION'] = '<b>Ошибка:</b> Неверный номер версии.';
$langA['NO_DIFFERENCES'] = 'Две версии, которые сравнивались, идентичны.';
$langA['NO_REVISIONS'] = 'Должно существовать две разные версии, прежде чем можно что-то сравнивать.';
$langA['NON_EXISTANT'] = 'Этот файл еще не существует.';

//	toolEditPage.php
$langA['bold_text'] = 'Жирный шрифт';
$langA['italic_text'] = 'Курсивный текст';
$langA['headline_text'] = 'Вставить заголовок';
$langA['title'] = 'Заголовок';
$langA['unordered_list'] = 'Несортированный список';
$langA['ordered_list'] = 'Сортированный список';


$langA['internal_link'] = 'Внутренняя ссылка';
$langA['link'] = 'Ссылка';
$langA['external_link'] = 'Внешняя ссылка';
$langA['embed_image'] = 'Встроить картинку';
$langA['find_images'] = 'Найти изображения';
$langA['image'] = 'Картинка';
$langA['nowiki'] = 'без wiki';
$langA['NOWIKI_TEXT'] = 'Вставляйте сюда неформатированный текст.';
$langA['signature'] = 'Подпись';
$langA['SIGNATURE_TEXT'] = 'Вставьте Вашу подпись';
$langA['preview'] = 'Предварительный просмотр';
$langA['PREVIEW_TEXT'] = 'Предварительный просмотр изменений [%s-p]';
$langA['PREVIEW_WARN'] = 'Это только предварительный просмотр. Изменения еще не сохранены!';
$langA['SAVE_TEXT'] = 'Сохранить ваши изменения [%s-s]';
$langA['reset'] = 'Сбросить';
$langA['RESET_TEXT'] = 'Восстановить эту форму к исходному состоянию [%s-c]';
$langA['changes'] = 'Измeнения';
$langA['CHANGES_TEXT'] = 'Показать изменения, сделанные в этом файле. [%s-d]';

$langA['DEFAULT_KEYWORD_FIELD'] = 'Организовать Ваши записи с помощью ключевых слов, разделенных запятой'; //should not contain ( or )
$langA['keywords'] = $langA['tags'] = 'Ключевые слова';
$langA['edit_summary'] = 'Редактировать краткое описание';
$langA['syntax_warning'] = 'Предупреждение по синтаксису';
$langA['NO_IMAGES'] = 'Картинок не найдено';
$langA['insert_emoticons'] = 'Вставить пиктограммы-эмоции';
$langA['upload'] = 'Загрузить';



//searchHistory
$langA['show'] = 'Показать';
$langA['hide'] = 'Скрыть';
$langA['compare'] = 'Сравнить';
$langA['timeline'] = 'Линия времени';
$langA['summary'] = 'Краткое описание';
$langA['COMPARE_REVISONS'] = 'Сравнить с выбранной версией';
$langA['unchecked'] = 'Не помечено';



//
//	toolBatch
//
$langA['INVALID_FILE_TYPE'] = 'Неправленный тип файла.';


//	SEARCH
$langA['next'] = 'Вперед';
$langA['previous'] = 'Назад';
$langA['order_by'] = 'Сортировать по:';
$langA['ascending'] = 'Возрастанию';
$langA['descending'] = 'Убыванию';
$langA['search_from'] = 'Искать в: ';
$langA['all_users'] = 'Все пользователи';
$langA['user'] = 'Пользователь';
$langA['from_file_type'] = 'Искать в следующем типе файлов: ';
$langA['read_more'] = 'Читать дальше';
$langA['words'] = ' слов(а)';

$langA['RESULTS'] = 'Результаты %s до %s из %s'; //  Results 1 to 25 of 65 
$langA['EMPTY_SET'] = 'По данному запросу записей не найдено';

//searchTalk
$langA['add_comment'] = 'Добавить новую тему';



//	myParser
$langA['BAD_DUPLICATE_ENTRY'] = 'Не могу включить предупреждение. Плохо отформатированные данные для дублирующей записи.';
$langA['duplicate_entry'] = 'Запись-дубликат';
$langA['DUPLICATE_ENTRY'] = 'Это дублирующаяся запись для страницы, найденной в %s.<br/>Вся неизбыточная информация, найденная здесь, должна быть перенесена в оригинал прежде, чем страница будет удалена.'; //pages can be flagged as being a duplicate of another page, the text from this entry will shown to users when a page is flagged as a "duplicate entry"
$langA['not_found'] = 'Не найдено: '; //used for the alt attribute in an <img> tag when an image is not found

//	error
$langA['ERROR_OCCURED'] = '<b>Ошибка:</b><br /> При исполнении скрипта произошла ошибка.<br /> Проверьте Ваш запрос, а мы постараемся отладить скрипт с помощью протокола (лога) ошибок. %s'; //replaced with link to error log for admin

//	CLASStemplate
$langA['DELETE_DEFAULT_TEMPLATE'] = 'Не могу удалить шаблон по умолчанию';
$langA['THEME_MISSING_VARS'] = 'Missing required variable(s): <tt>%s</tt>.';
$langA['css1'] = 'CSS1';
$langA['css2'] = 'CSS2';
$langA['INVALID_THEME'] = 'Указанная тема неверна.';

//
//	CLASSmap
//
$langA['new_marker']='Новый Маркер';
$langA['new_route']='Новый Маршрут';
$langA['SAVE_HEADER']='Напоминание перед сохранением';
$langA['save_map']='Сохранить Карту';
$langA['continue_editing']='Продолжить редактирование';
$langA['miles/km'] = 'мили/км';
$langA['MAP_DEFAULT_CONTENT'] = '<b>Это новая карта.</b><br/> Для создания/редактирования этой карты, нажмите "Редактировать" вверху.';
$langA['MAP_DEFAULT_CONTENT_PROTECTED'] = 'Извините, но у Вас недостаточно полномочий для редактирования этой карты.';
$langA['play'] = 'Исполнить';
$langA['stop'] = 'Остановить';
$langA['import'] = 'Импортировать';
$langA['export'] = 'Экспортировать';
$langA['gpx_data'] = 'Данные GPX';
$langA['gpx_exchange_format'] = 'Формат обмена GPX';
$langA['CLICK_EDIT'] = 'Для редактирования карты нажмите "Редактироваь" вверху';


//	smileys
$langA['smiles'][':D'] = 'Очень cчастливый';
$langA['smiles'][':)'] = 'Улыбка';
$langA['smiles'][':('] = 'Грустный';
$langA['smiles'][':o'] = 'Удивленный';
$langA['smiles'][':shock:'] = 'Шокированный';
$langA['smiles'][':?'] = 'Смущенный';
$langA['smiles']['8)'] = 'Крутой';
$langA['smiles'][':lol:'] = 'Смеющийся';
$langA['smiles'][':x'] = 'Сумасшедший';
$langA['smiles'][':P'] = 'Шутливый';
$langA['smiles'][':oops:'] = 'Смущенный';
$langA['smiles'][':cry:'] = 'Плачущий или Очень грустный';
$langA['smiles'][':evil:'] = 'Злой или Безумный';
$langA['smiles'][':twisted:'] = 'Вдвойне злой';
$langA['smiles'][':roll:'] = 'Глаза на выкате';
$langA['smiles'][':wink:'] = 'Подмигивающий';
$langA['smiles'][':!:'] = 'Восклицающий';
$langA['smiles'][':?:'] = 'Спрашивающий';
$langA['smiles'][':idea:'] = 'Идея';
$langA['smiles'][':arrow:'] = 'Стрелка';
$langA['smiles'][':|'] = 'Нейтральный';
$langA['smiles'][':mrgreen:'] = 'Г-н зеленый';

//
//	General Language
//
$langA['or'] = 'или';
$langA['username'] = 'Имя пользователя';
$langA['password'] = 'Пароль';
$langA['email'] = 'Адрес электронной почты';
$langA['register'] = 'Регистрироваться';
$langA['cancel'] = 'Отменить';
$langA['language'] = 'Язык';
$langA['use'] = 'Использовать';
$langA['copy'] = 'Копировать';
$langA['rename'] = 'Переименовать';

$langA['on'] = 'Включить';
$langA['partial'] = 'Частичный';
$langA['off'] = 'Выключить';
$langA['save'] = 'Сохранить';
$langA['save_now'] = 'Сохранить сейчас';
$langA['undefined'] = 'Неопределённый';
$langA['homepage'] = 'Домашняя страничка';
$langA['home'] = 'Домой';
$langA['go'] = 'Выполнить';
$langA['user_menu'] = 'Пользовательское Меню';

$langA['last_modified'] = 'Последние изменения';
$langA['LAST_MODIFIED'] = 'Последние изменения %s выполнены %s';//%s replaced with date and username
$langA['accessed_times'] = '%s запрос(ов)';// %s replaced with a number
$langA['modified'] = 'Изменено';
$langA['posted'] = 'Отправлено';
$langA['created'] = 'Создано';
$langA['hidden'] = 'Скрыто';
$langA['what_links_here'] = 'Ссылки сюда';
$langA['share'] = 'Распространить';
$langA['INVALID_LINK'] = 'Запрошенный заголовок страницы неверен. Возможно, он содержит символы, которые не разрешается использовать в заголовках. ';
$langA['FILE_MUST_EXIST'] = 'Нужно сохранить файл прежде, чемы Вы сможете выполнить эту операцию.';

$langA['OOPS'] = 'Oops, that didn\'t work, please try again.';


$langA['size'] = 'Размер ';
$langA['bytes'] = 'байт(ов)';
$langA['kb'] = 'КБайт';
$langA['mb'] = 'MB';
$langA['gb'] = 'GB';
$langA['update'] = 'Обновить';
$langA['editing'] = 'Редактирование';
$langA['workgroup'] = 'Рабочая Группа';
$langA['BROWSE_HIDDEN'] = 'Найти скрытые файлы';

$langA['delete'] = 'Удалить';
$langA['confirm_delete'] = 'Подтвердить удаление';
$langA['continue'] = 'Продолжить';
$langA['back'] = 'Назад';
$langA['close'] = 'Закрыть';
$langA['view'] = 'Посмотреть';
$langA['empty'] = '-пусто-';
$langA['none'] = 'Нет';
$langA['total'] = 'Всего ';
$langA['files'] = 'Файлы';
$langA['other'] = 'Другой';
$langA['trash'] = 'Мусорная корзина';
$langA['flagged'] = 'Помечено флагом';

$langA['today'] = 'Сегодня';
$langA['yesterday'] = 'Вчера';
$langA['days_ago'] = ' дней назад';
$langA['page_contents'] = 'Содержание';
$langA['more'] = 'Еще';
$langA['download'] = 'Download';


//Date
$langA['date_l'][0] = 'Воскресенье';
$langA['date_l'][1] = 'Понедельник';
$langA['date_l'][2] = 'Вторник';
$langA['date_l'][3] = 'Среда';
$langA['date_l'][4] = 'Четверг';
$langA['date_l'][5] = 'Пятница';
$langA['date_l'][6] = 'Суббота';

$langA['date_D'][0] = 'Вск';
$langA['date_D'][1] = 'Пнд';
$langA['date_D'][2] = 'Втр';
$langA['date_D'][3] = 'Срд';
$langA['date_D'][4] = 'Чтв';
$langA['date_D'][5] = 'Птн';
$langA['date_D'][6] = 'Суб';


$langA['date_F'][1] = 'января';
$langA['date_F'][2] = 'февраля';
$langA['date_F'][3] = 'марта';
$langA['date_F'][4] = 'апреля';
$langA['date_F'][5] = 'мaя';
$langA['date_F'][6] = 'июня';
$langA['date_F'][7] = 'июля';
$langA['date_F'][8] = 'августа';
$langA['date_F'][9] = 'сентября';
$langA['date_F'][10] = 'октября';
$langA['date_F'][11] = 'ноября';
$langA['date_F'][12] = 'декабря';

$langA['date_M'][1] = 'янв';
$langA['date_M'][2] = 'фев';
$langA['date_M'][3] = 'мар';
$langA['date_M'][4] = 'апр';
$langA['date_M'][5] = 'мaя';
$langA['date_M'][6] = 'июн';
$langA['date_M'][7] = 'июл';
$langA['date_M'][8] = 'авг';
$langA['date_M'][9] = 'Сент';
$langA['date_M'][10] = 'окт';
$langA['date_M'][11] = 'ноя';
$langA['date_M'][12] = 'дек';

$langA['date_a']['am'] = 'до полудня';
$langA['date_a']['pm'] = 'после полудня';

$langA['date_A']['am'] = 'AM';
$langA['date_A']['pm'] = 'PM';

$langA['lang']['ar'] = 'Арабский (ar)';
$langA['lang']['bn'] = 'Bengali (bn)';
$langA['lang']['de'] = 'Немецкий (de)';
$langA['lang']['el'] = 'Греческий (el)';
$langA['lang']['en'] = 'Английский (en)';
$langA['lang']['es'] = 'Испанский (es)';
$langA['lang']['fr'] = 'Французский (fr)';
$langA['lang']['hu'] = 'Hungarian (hu)';
$langA['lang']['it'] = 'Итальянский (it)';
$langA['lang']['ja'] = 'Японский (ja)';
$langA['lang']['ko'] = 'Корейский (ko)';
$langA['lang']['ml'] = 'Malayalam (ml)';
$langA['lang']['nl'] = 'Голландский (nl)';
$langA['lang']['pl'] = 'польский (pl)';
$langA['lang']['ro'] = 'Romanian (ro)';
$langA['lang']['ru'] = 'Русский (ru)';
$langA['lang']['tr'] = 'Турецкий (tr)';
$langA['lang']['vi'] = 'Вьетнамский (vi)';
$langA['lang']['zh'] = 'Китайский (zh)';
$langA['lang']['zh-cn'] = 'Китайский Упрощенный (zh-cn)';



