<?php

//	toolRename.php
$langA['NAME_UNCHANGED'] = 'Имя файла не изменилось.';
$langA['NOT_RENAMED'] = 'Этот файл нельзя переименовать в <tt>%s</tt>. Проверьте, не существует ли уже файл с таким именем.';//%s replaced with the title of a file
$langA['COULDNT_RENAMED'] = 'Не могу переименовать этот файл.';
$langA['redirected_to'] = 'Перенаправлено на';
$langA['RENAMED'] = 'Файл успешно переименован.';


//	toolDelete
$langA['FILE_RESTORED'] = '<b>%s</b> был восстановлен. ';
$langA['ERROR_RESTORING'] = '<b>Ошибка:</b> Не могу восстановить файл в <tt>%s.</tt>';
$langA['ALREADY_RESTORED'] = 'Этот файл уже был восстановлен.';
$langA['WAS_DELETED'] = '<b>%s</b> был удален. Этот файл будет храниться в %s еще 30 дней.';
$langA['ERROR_DELETING'] = '<b>Ошибка:</b> Не могу удалить файл в <tt>%s.</tt>';
//$langA['ALREADY_DELTED'] = 'This file has already been deleted.';

//$langA['FILE_DELETED'] = 'The file does not appear to exist.';
$langA['FILE_DELETED'] = '<tt>%s</tt> удален.';
