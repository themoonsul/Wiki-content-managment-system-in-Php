<?php

//	specPreferences
$langA['PREFERENCES_UNCHANGED'] = 'Ваши параметры не изменились по сравнению с уже сохраненными значениями.';
$langA['INVALID_PREFS'] = '<b>Предупреждение:</b> Не могу сохранить Ваши параметры с указанными значениями.';

$langA['EMAIL_PREFS'] = 'Полезно, если вы забудете свой пароль.';

$langA['LANG_PREFS'] = 'Выберите язык.';

$langA['javascript_preferences'] = 'JavaScript Preferences';
$langA['javascript'] = 'JavaScript';
$langA['JAVASCRIPT_PREFS'] = 'Включить/выключить расширения JavaScript. Некоторые функции могут работать не полностью, если JavaScript отключен.';

$langA['time_zone'] = 'Часовой пояс';
$langA['TIME_ZONE_PREFS'] = 'Разница во времени между местным временем и временем сервера: <tt>hh:mm</tt>.';
$langA['TIME_ZONE_PREFS2'] = 'Сейчас время на сервере %s. <br/>Откорректированное время %s.';

$langA['sig'] = 'Подпись';
$langA['SIGNATURE'] = 'Настройте Вашу подпись в соответствии с синтаксисом Wiki.';


$langA['home_title'] = 'Заголовок домашней страницы';
$langA['HOME_TITLE_PREFS'] = 'Этот заголовок будет отображаться на Вашей домашней странице.';

$langA['blog_styled_frontpage'] = 'Стиль главной страницы: блог';
$langA['BLOG_PREFS'] = 'Показывать домашнюю страницу как блог.';

$langA['blogT'] = 'Тип блога';
$langA['BLOG_TYPE'] = 'Выберите между типами данных для блога.';

$langA['selective_blogging'] = 'Выборочная работа с блогами';
$langA['SELECTIVE_BLOGGING'] = 'Выборочная работа с блогами позволяет Вам работать только с той информацией, которую вы хотите показать на главной странице.';

$langA['blog_count'] = 'Blog Count';
$langA['BLOG_COUNT'] = 'The number of entries to show on your blog.';

$langA['blen'] = 'Content Length';
$langA['BLEN'] = 'Determines the approximate amount of content to be displayed from each blog post.';

$langA['SHARE'] = 'Показать ссылку "Распространить" в нижней части каждой страницы.';

$langA['ihelp'] = 'Help Links';
$langA['IHELP'] = 'Show help links.';

$langA['uServices'] = 'Сервисы обновления';
$langA['UPDATE_SERVICES'] = 'При публикации каждой записи будут уведомляться следующие сервисы обновления. Указывайте различные URI сервисов на отдельных строках.';
$langA['BAD_UPDATE_SERVICES'] = 'Указан неправильный URI для сервиса обновлений';


$langA['VIEW_THEME'] = '<a %s>Редактировать или копировать</a> эту тему.';

$langA['quick_comment'] = 'Быстрый комментарий';
$langA['QUICK_COMMENT'] = 'Когда включен, форма будет располагаться в верхней части страницы комментариев для более быстрого ввода.';

$langA['textarea rows'] = 'Столбцы зоны текста';
$langA['TEXTAREA_ROWS_PREFS'] = 'Определяет высоту зон редактирования.';

$langA['history_rows'] = 'Maximum History Rows';
$langA['HISTORY_ROWS_PREFS'] = 'Ограничивает количество строк истории, которые сохраняются на сервере для каждого файла.';
//$langA['HISTORY_ROWS_PREFS2'] = 'Defaults to %s.<br/>Maximum %s.';
$langA['HISTORY_ROWS_PREFS2'] = 'Максимум %s.';

$langA['tab_limit'] = 'Максимальное количество закладок';
$langA['TAB_LIMIT'] = 'JavaScript автоматически будт закрывать закладки, когда их количество достигнет этого предела. По умолчанию - 7. Установите 1000 или более, если Вы не хотите, чтобы JavaScript управлял закладками.';

$langA['EXTERNAL_LINKS'] = 'Внешние ссылки будут открываться в новом окне, если "Включено".';

$langA['SCROLL_CONTENT'] = 'Scroll only the content area of the page instead of the whole page. <br/><span class="sm">(Custom themes will need the WB_SCROLLAREA div)</span>';

$langA['shortK'] = 'Сокрашенные клавиатурные команды';
$langA['SHORTK_CONTENT'] = 'Customize the keyboard shortcut escape sequence. (Requires reload)';


$langA['save_preferences'] = 'Сохранить параметры';

$langA['CONFIRM_CHANGE'] = 'Вы уверены, что хотите изменить Ваши параметры?';
$langA['preference'] = 'Параметр';
$langA['old_value'] = 'Старое значение';
$langA['new_value'] = 'Новое значение';

$langA['changes'] = 'Измeнения';
$langA['PREFS_CHANGED'] = 'Параметры обновлены.<br/> Ниже смотри список значений, которые изменились.';


//check edit
$langA['anonymous'] = 'Анонимный';
$langA['fEdits'] = 'Флаги на редактируемых записях';
$langA['FLAG_EDITS'] = 'Записи, созданные пользователями со статусом на уровне или ниже указанного будут помечены флагом "Не проверено" до тех пор, пока их не просмотрит владелец учетной записи.';

//save all edits
$langA['saveAll'] = 'Log All Edits';
$langA['SAVEALL'] = '"On" will save all edits in the revision history.<br/> "Off" will record revisions based on editing sessions.';
