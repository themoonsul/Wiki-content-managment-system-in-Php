<?php
$langA['ILLEGAL_USERNAME'] = 'Имя пользователя не может включать в себя следующие символы: %s';
$langA['LONG_USERNAME'] = 'Имя пользователя слишком длинное.';	
$langA['SHORT_USERNAME'] = 'Имя пользователя слишком короткое.';
$langA['USER_TAKEN'] = 'Введите другое имя пользователя. <tt>%s</tt> уже занято. ';
$langA['USERNAME_ALL_DIGITS'] = 'Имя пользователя не может состоять только из цифр.';
$langA['PASSWORDS_DIFFERENT'] = 'Пароли не совпадают.';
$langA['SHORT_PASSWORD'] = 'Пароль слишком короткий.';
$langA['EMAIL_REQUIRED'] = 'Please provide a valid email address.';


$langA['register'] = 'Регистрироваться';
$langA['welcome_to'] = 'Добро пожаловать в ';
$langA['REG_USERNAME'] = 'A unique ID with 3-20 characters.';
$langA['REG_PASSWORD'] = 'Должно быть длиной как минимум 5 символов.';
$langA['confirm_password'] = 'Подтвердите пароль';
$langA['REG_CONFIRM_PASS'] = 'Такой же как выше.';
$langA['REG_EMAIL'] = 'Необязательно, но полезно, если Вы забудите свой пароль.';
$langA['REQUIRED_FIELD'] = 'Обозначает обязательное поле.';

$langA['REGISTRATION_TEXT'] = 'Регистрация бытрая, бесплатная и предоставляет различные привелегии...';
$langA['REG_A_USER_PAGE'] = '/ИмяПользователя/Ваши_Страницы';
$langA['REG_A_MAP_PAGE'] = '/Map/ИмяПользователя/Ваши_Карты';

//login
$langA['LOGGED_IN'] = 'Вы вошли в систему как <tt>%s</tt>.';
$langA['WRONG_USERNAME'] = 'Указанное имя пользователя не существует. Не могли бы Вы зарегистрировать %s.';

//email confirmation
//$langA['REGISTERED_&_SENT'] = 'To activate your account, click on the link';
//$langA['REGISTERED_&_SENT'] = 'Registration was successful! <br/> An email was sent to %s, please click on activation link';
$langA['REGISTERED_&_SENT'] = 'Success! Click on the activation link in the email sent to %s to activate your account.';
$langA['ACTIVATE_ACCOUNT'] = 'Активируйте свой аккаунт.';
$langA['ACTIVATED_FROM_EMAIL'] = 'Ваш аккаунт был активирован.';
$langA['INVALID_CODE'] = 'The supplied confirmation code is no longer valid.';
