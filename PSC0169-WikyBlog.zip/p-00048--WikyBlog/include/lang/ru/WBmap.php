<?php
//
//	WBmap.php
//
$langA['loading_map'] = 'Загружаем карту...';
$langA['MAP_DEBUG_O'] = 'Произошла ошибка при загрузке этой страницы, и запрошенная карта не может быть показана.<p> </p>Запись об этой ошибке занесена в протокол ошибок, и администраторы веб сайта исправят ее в ближайшее время.';
$langA['MAP_DEBUG_1'] = 'The Google Maps API does not appear to be compatible with your browser.<p>If you know your browser is compatible, make sure the correct map key is being used and that you are connected to the internet.</p><p>You can <a href="http://local.google.com/support/bin/answer.py?answer=16532&topic=1499" target="_top">get more information</a> about browser support from google.com.</p>';
$langA['MAP_NO_SCRIPT'] = '<p><b>Предупреждение</b> Карты требуют функций JavaScript.</p><p>Возможно, JavaScript не разрешен в конфигурации Вашего браузера. Для просмотра этой карты необходимо разрешить JavaScript в Вашем браузере, затем обновить/перезагрузить эту страницу.</p>';