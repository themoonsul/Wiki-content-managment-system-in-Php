<?php

//	toolOptions.php
$langA['properties'] = 'Свойства';
$langA['file_name'] = 'Имя файла';
$langA['update_from'] = 'Обновить из';
$langA['COPY_SYSTEM_FILES'] = 'Скопировать последний файл системной помощи из %s.';

$langA['EDITING_OPTIONS'] = 'Контролировать, кто имеет право редактировать этот файл.';
$langA['registered_users'] = 'Зарегистрированные пользователи';
$langA['restricted_to'] = 'Ограничено для ';
$langA['admin_only'] = 'Только Администратор';
$langA['editor_visible'] = 'Видно Редакторам';
$langA['owner_only'] = 'Только Владелец';
$langA['use_captcha'] = 'Использовать Captcha';
		

$langA['visibility'] = 'Видимость';
$langA['VISIBILITY_OPTIONS'] = 'Скрыть этот файл, если вы не готовы показать его миру.';
$langA['visible'] = 'Видимый';

$langA['COMMENT_OPTIONS'] = 'Запретить комментарии для этого файла.';
$langA['enabled'] = 'Разрешено';
$langA['disabled'] = 'Запрещено';
$langA['RECENT_COMMENTS'] = 'Show recent comments.';

$langA['anti_spam'] = 'Анти-СПАМ';
$langA['nofollow'] = 'Не Переходить';

$langA['other'] = 'Другой';
$langA['related_links'] = 'Related Links';
$langA['unblog'] = 'Удалить из блога';
$langA['repost'] = 'Отправить еще раз';
$langA['copy_to'] = 'Скопировать в...';
$langA['send_to_trash'] = 'Отправить в Мусорную корзину';
$langA['default_options'] = 'Параметры по умолчанию';
$langA['restore_defaults'] = 'Восстановить Исходную Конфигурацию';
$langA['SET_DEFAULT_OPTIONS'] = 'Установите %s для этого типа файла.'; //replaced with link
$langA['add_to_tabs'] = 'Добавить в закладки';
$langA['add_to_links'] = 'Добавить в ссылки';

$langA['REPOSTED'] = 'Файл опубликован повторно.';
$langA['NOT_REPOSTED'] = '<b>Ошибка:</b> Не могу повторно опубликовать этот файл.';
$langA['OPTIONS_NOT_CHANGED'] = 'Параметры файла не изменились.';
$langA['OPTIONS_UPDATED'] = 'Параметры файла успешно обновлены.';
$langA['OPTIONS_NOT_UPDATED'] = '<b>Предупреждение:</b> Параметры файла обновлены.';

$langA['redirect'] = 'Перенаправить';
$langA['REMOVE_REDIRECT'] = 'Если Вы больше не хотите перенаправлять этот файл, можно его удалить или редактировать. ';


$langA['UNCHECKED_REMOVED'] = 'Флаг "Не проверен" снят с этого файла.';

$langA['NO_KEYWORDS'] = 'Не установлены ключевые слова для этого файла. Хотите <a %s>сначала добавить ключевые слова</a> или <a %s>переместить его в блог сейчас</a>?';

$langA['file_id'] = 'Идентификатор Файла';

//watch
$langA['WATCH_UPDATED'] = 'Ваш <a %s>список наблюдения</a> обновлен.';


$langA['user_permissions'] = 'Разрешения&nbsp;Пользователя';
