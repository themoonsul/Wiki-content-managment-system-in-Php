<?php
//		language file for /Special/ files
//
//


$langA['permissions'] = 'Разрешения';
$langA['UNDEFINED_SPECIAL_PAGE'] = 'Эта специальная страница еще не определена: <tt>%s</tt>';

//	control panel
$langA['general'] = 'Общие';
$langA['attachments'] = 'Присоединенные файлы';
$langA['account_info'] = 'Информация об учетной записи';
$langA['error_log'] = 'Протокол ошибок';
$langA['advanced_search'] = 'Расширенный&nbsp;Поиск';
$langA['configuration'] = 'Настройки';
$langA['search_options'] = 'Параметры поиска';
$langA['data_types'] = 'Типы данных';
$langA['plugins'] = 'Плагины';
$langA['dynamic_content'] = 'Dynamic Content';

$langA['tabs'] = 'Закладки';
$langA['account_display'] = 'Показать учетную запись';
$langA['links'] = 'Ссылки';
$langA['go_to'] = 'Перейти к %s.';


$langA['user_statistics'] = 'Статистика пользователей';
$langA['database_info'] = 'Информация&nbsp;о&nbsp;Базе&nbsp;данных';
$langA['user_preferences'] = 'Параметры пользователя';
$langA['content_license'] = 'Лицензия&nbsp;на&nbsp;Содержание';
$langA['user_permissions'] = 'Разрешения Пользователя';
$langA['default_page_options'] = 'Параметры&nbsp;страницы&nbsp;по&nbsp;умолчанию';
$langA['account_details'] = 'Параметры&nbsp;Учетной&nbsp;записи';
$langA['manage_images'] = 'Управление&nbsp;Картинками';
$langA['manage_files'] = 'Управление&nbsp;Файлами';
$langA['upload_files'] = 'Загрузить файлы';
$langA['public_templates'] = 'Опубликовать&nbsp;Шаблоны';
$langA['feeds'] = 'Краткое изложение в RSS';
$langA['recently_modified'] = 'Hедавно модифицированные';
$langA['recently_posted'] = 'Недавно опубликованные';
$langA['user_edits'] = 'Пользовательские Поля Редактирования';

$langA['CONTROL_PANEL_1'] = 'Это панель управления для <tt>%s</tt>.';
$langA['CONTROL_PANEL_2'] = 'Вы хотите посмотреть %s.';

//specTemplates
$langA['pTemplate'] = 'Package Themes';
$langA['custom_theme'] = 'Custom Theme';
$langA['current_theme'] = 'Текущая тема';
$langA['TEMPLATES_UNAVAILABLE'] = 'Каталог Базовых шаблонов недоступен';
$langA['themes']['default'] = 'по умолчанию';
$langA['themes']['simple'] = 'Простой';
$langA['themes']['three_columns'] = 'Три колонки';
$langA['themes']['floating'] = 'Плавающий';
$langA['themes']['graphic'] = 'Графика';

$langA['colors']['colors'] = 'Цвета';
$langA['colors']['black'] = 'Черный';
$langA['colors']['blue'] = 'Синий';
$langA['colors']['blue-green'] = 'Teal';
$langA['colors']['brown'] = 'Brown';
$langA['colors']['green'] = 'Зеленый';
$langA['colors']['light_blue'] = 'Голубой';
$langA['colors']['green'] = 'Зеленый';
$langA['colors']['tan'] = 'Коричневый';
$langA['colors']['red'] = 'Красный';
$langA['colors']['orange'] = 'Оранжевый';
$langA['colors']['gray'] = 'Серый';


$langA['customize_this_theme'] = 'Настроить эту тему';



//searchHidden.php
$langA['browse_hidden'] = 'Просмотреть скрытые';
$langA['editor_visible'] = 'Видно Редакторам';


//	WorkGroup.php
$langA['update_permissions'] = 'Обновить разрешения';
$langA['username_or_ip'] = 'Имя пользователя или IP адрес';
$langA['status'] = 'Статус';
$langA['workgroup'] = 'Рабочая Группа';
$langA['admin'] = 'Администратор';
$langA['full_owner'] = 'Полный / Владелец';
$langA['ban'] = 'Запретить';
$langA['banned'] = 'Запрещены';

//	friends.php
$langA['friends'] = 'Друзья';
$langA['my_status'] = 'Мой статус';


$langA['EX_USERNAMES'] = 'например:<a>ВасяПупкинъ</a>, <a>127.0.0.1</a>, <a>255.0</a>';
$langA['EMPTY_PERMISSIONS'] = 'Вы не описали никаких разешений.';
$langA['view_users'] = 'Посмотреть данные пользователя...';
$langA['change'] = 'Изменить';
$langA['users'] = 'Пользователи';

$langA['USER_REMOVED'] = 'Пользователь <tt>%s</tt> удален из Рабочей группы.';
$langA['USER_NOT_REMOVED'] = 'Пользователя <tt>%s</tt> не удалось удалить из Рабочей группы. ';
$langA['ADDED_PERMISSIONS'] = 'Добавлены разрешения для <tt>%s</tt>.';
$langA['UPDATED_PERMISSIONS'] = 'Обновлены разрешения для <tt>%s</tt>.';
$langA['NOT_A_USER'] = 'Имя пользователя <tt>%s</tt> не найдено.';
$langA['IP_NOT_ADDED'] = 'Не удалось добавить/обновить разрешения для <tt>%s</tt>.';
$langA['ALREADY_OWNER'] = '<b>Предупреждение:</b> Пользователь <tt>%s</tt> уже владеет этой учетной записью.';
$langA['IP_WRONG_LEVEL'] = '<b>Предупреждение:</b> IP адрес не может получить привелегии выше, чем "Рабочая группа"';
$langA['SET_PERMISSIONS'] = 'Для установки разрешений для "%s", нежно выбрать желаемый статус и нажать "Обновить разрешения".';


//	specLostPass
$langA['lost_password'] = 'Потерянный пароль';



//	specFileManager
$langA['file_manager'] = 'Управление файлами';
$langA['image_manager'] = 'Управление картинками';
$langA['CONFIRM_FILE_DELETE'] = 'Вы уверены в том, что собираетесь удалить <b>%s</b>?';
$langA['IMAGE_MANAGER_INTRO'] = 'Можно использовать синтаксис wiki или html для включения картинок в Ваши страницы. Для некоторых типов файлов (шаблоны, карты...) мы рекомендуем использовать синтаксис html.';
$langA['FILE_MANAGER_INTRO'] = 'Можно использовать синтаксис wiki или html для включения картинок в Ваши страницы. Для некоторых типов файлов (шаблоны, карты...) мы рекомендуем использовать синтаксис html.';
$langA['file_name'] = 'Имя файла';
$langA['available_space'] = 'Доступное пространство';
$langA['UPLOAD_INTRO'] = 'Загрузить файлы и картинки для присоединения на Ваши страницы.';
$langA['file_upload'] = 'Загрузка файла';
$langA['file_info'] = 'Информация о файле';
$langA['width'] = 'Ширина';
$langA['height'] = 'Высота';
$langA['file_location'] = 'Расположение файла';
$langA['wiki_syntax'] = 'Синтаксис Wiki';
$langA['html_syntax'] = 'Синтаксис HTML';
$langA['append_to'] = 'дoбавить к';
$langA['count'] = 'Количество';
$langA['total_size'] = 'Общий размер';
$langA['images'] = 'Картинки';
$langA['overwrite_existing'] = 'Перезаписать существующий';
$langA['compression'] = 'Сжатие';

$langA['NOT_AN_IMAGE'] = 'Похоже, файл не является картинкой. Проверьте файл и попробуйте еще раз. (%s). ';
$langA['IMAGE_NOT_DELETED'] = 'Не могу удалить файл <tt>%s</tt>.';
$langA['UPLOADED'] = 'Файл <tt>%s</tt> успешно загружен.';
$langA['UPLOADED_RENAMED'] = 'Файл <tt>%s</tt> был загружен как <tt>%s</tt>. Можно его <a %s>переименовать в %s</a>.';
$langA['RENAMED'] = 'Файл успешно переименован.';
$langA['UPLOAD_FAILED'] = 'Ошибка копирования файла: <tt>%s</tt>.';

//$langA['CANNOT_UPLOAD_3'] = 'Cannot upload file <tt>%s</tt>. Disk usage exceeds allotted amount.<br/>Currently using <tt>%s</tt> bytes.';
$langA['CANNOT_UPLOAD_2'] = 'Не могу загрузить файл <tt>%s</tt>. .<br/>Файлы должны быть меньше <tt>%s</tt> байт.';
//$langA['CANNOT_UPLOAD_1'] = 'Cannot upload file <tt>%s</tt>. Only <tt>%s</tt> files are supported.';

$langA['UPLOAD_ERR_PARTIAL'] = 'Oops, <tt>%s</tt> was only partially uploaded. Please try again.';

//	specDefaultOptions
$langA['select_a_file_type'] = 'Выберите тип файла:';
$langA['default_options'] = 'Параметры по умолчанию';
$langA['UNKNOWN_FILE_TYPE'] = 'Неизвестный тип страницы: <tt>%s</tt>.';

//	specAccountDetails
$langA['account'] = 'Учетная запись';
$langA['entries'] = 'Записи';
$langA['average'] = 'Средний';
$langA['uploaded_files'] = 'Загруженые файлы';


//	searchTrash
$langA['deleted'] = 'Удалено';
$langA['restore'] = 'Восстановить';
$langA['empty_trash'] = 'Очистить мусорную корзину';
$langA['CONFIRM_EMPTY_TRASH'] = 'Вы уверены, что хотите очистить мусорную корзину?';

$langA['DELETED_AFTER_30'] = 'Файлы будут автоматически удаляться через 30 дней.';
$langA['check_uncheck'] = 'Выделить Все / Снять выделение';
$langA['DELETED_FILES'] = 'Выбранные файлы успешно удалены.';
$langA['NOTHING_DELETED'] = 'Ничего не удалено.';
$langA['DELETE_FILES'] = 'Выберите файлы для удаления.';
$langA['MAP_INVALID_PT'] = 'Ошибочный данные по Карте: Неверный формат указателя';

//	searchSearch.php
$langA['ENABLE_SEARCH'] = 'Похоже, возможность поиска на этом сайте не разрешена. Администраторы сайта могут разрешить эту возможность с помощью Параметров поиска в Панели управления.';
$langA['search:'] = 'Искать: ';
$langA['search_for'] = 'Искать по: ';
$langA['registered'] = 'Зарегистрировано';
$langA['restricted'] = 'Ограничено';
$langA['locked'] = 'Заперто';
$langA['disabled'] = 'Запрещено';
$langA['editing_option'] = 'Параметр редактирования';
$langA['comments_option'] = 'Параметр комментариев';
$langA['visibility_option'] = 'Параметр видимости';
$langA['normal'] = 'Нормальный';
$langA['advanced'] = 'Расширенный';
$langA['relevance'] = 'Важность';
$langA['SEARCH_ONE'] = 'Как минимум, для одного из слов';
$langA['SEARCH_ALL'] = 'Для всех слов';
$langA['SEARCH_EXACT'] = 'Для полной фразы';
$langA['SEARCH_WITHOUT'] = 'Не включая слова';
$langA['SEARCH_BEGIN'] = 'Для слов, начинающихся с';


//	searchKeywords
$langA['keyword_search'] = 'Поиск по ключевым словам';
$langA['non_tagged_files'] = 'Файлы без ключевых слов';

//	searchChangeLog
$langA['new'] = 								'Новый';
$langA['DIFF_TITLE'] = 							'Сравните различия между последними версиями';
$langA['indicates_syntax_error'] = 				'Обозначает синтаксмческую ошибку.';
$langA['indicates_unchecked'] = 				'Обозначает непроверенный файл.';


//	specLicenseCC.php ... values used for selecting and showing content licenses
$langA['select_license'] = 'Выберите лицензию';
$langA['SELECT_LICENSE_DESC'] = 'Выберите страницу с лицензией Creative Commons в всплывающем окне.';
$langA['DELETE_LICENSE_DESC'] = 'Эта операция удалит текущую лицензию на содержание.';
$langA['LICENSE_UPDATED'] = 'Ваша лицензия на содержание успешно обновлена.';
$langA['LICENSE_DELETED'] = 'Лицензия удалена';
$langA['LICENSE_DELETED2'] = 'Лицензия была удалена раньше.';
$langA['customize_license'] = 'Поправьте Вашу лицензию';

$langA['text_before'] = 'Текст перед ссылкой';
$langA['text_after'] = 'Текст после ссылки';


//these three values are used to create a phrase 'LICENSE_TEXT_BEFORE' + 'LICENSE_TEXT_LINK' + 'LICENSE_TEXT_AFTER' where 'LICENSE_TEXT_LINK' is in a link to creativecommons.
$langA['LICENSE_TEXT_BEFORE'] = 'За исключением случая, когда это специально указано, данная работа лицензирована на основе ';
$langA['LICENSE_TEXT_LINK'] = 'Лицензии Creative Commons';
$langA['LICENSE_TEXT_AFTER'] = '.';

$langA['my_edits'] = 'My Edits';

//reorganize
$langA['reorganize'] = 'Реорганизовать';
$langA['from'] = 'От кого';
$langA['to'] = 'Кому';
$langA['KEYWORDS_UPDATED'] = 'Ваши ключевые слова загружены.';
$langA['KEYWORDS_EMPTY'] = 'Вы еще не создали файлов с ключевыми словами.';
$langA['REORGANIZE'] = 'Здесь можно изменить структуру файлов, переименовав использованные ключевые слова';

//watch
$langA['WATCH_UPDATED'] = 'Ваш <a %s>список наблюдения</a> обновлен.';

//links
$langA['uri'] = 'Ссылка';
$langA['label'] = 'Метка';
$langA['description'] = 'Описание';
$langA['add_link'] = 'Добавить ссылку';
$langA['link_groups'] = 'Связать группы';
$langA['group'] = 'Группа';
$langA['name'] = 'Имя';
$langA['add_group'] = 'Добавить группу';
$langA['add_page'] = 'Добавить страницу';

$langA['limit'] = 'Ограничение';
$langA['random'] = 'Случайный';
$langA['order'] = 'Порядок';
$langA['LEAVE_EMPTY'] = 'Оставьте пустым, если не хотите ограничивать';
$langA['unlimited'] = 'Без ограничений';
$langA['type'] = 'Тип';
$langA['auto_detect'] = 'Авто-определение';
$langA['bookmarklet'] = 'Сервис закладок';
$langA['move_up'] = 'Переместить вверх';
$langA['move_down'] = 'Переместить вниз';
$langA['redirect'] = 'Перенаправить';
$langA['content_template'] = 'Шаблон Содержания';

