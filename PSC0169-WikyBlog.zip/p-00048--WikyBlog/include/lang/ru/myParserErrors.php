<?php

$langA['end_of_document'] = ' --- Конец документа --- ';
$langA['syntax_warning'] = ' Синтаксическое предупреждение: ';

$langA['XML_ERROR_INVALID_TOKEN'] = 'Обнаружена ошибка в строке %s позиции %s, возможно влияние предыдущих строк.';
$langA['XML_ERROR_INVALID_TOKEN2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>random &lt;text</tt> instead of <tt>random &amp;lt;text</tt>.<br />* <tt>&lt;a href=foo&gt;</tt> instead of <tt>&lt;a href="foo"&gt;</tt><br />* <tt>&lt;ta g&gt;</tt> instead of <tt>&lt;tag&gt;</tt>';

$langA['XML_ERROR_TAG_MISMATCH1'] = 'Чтобы завершить этот документ необходимо закрыть HTML теги: "<em>%s</em>".';

$langA['unnecessary_closing_tag'] = 'Лишний закрывающий тег.';
$langA['should_be'] = ' просто должно быть ';

$langA['CLOSING_AN_UNOPENED_TAG'] = 'Закрываем неоткрытый тег. <br />Не существует открывающего тега для закрывающего <tt>&lt;/%s&gt;</tt>.';
$langA['CLOSING_AN_UNOPENED_TAG2'] = '<br /> <strong>Possible causes of this warning include: </strong><br />* <tt>&lt;/tag&gt;</tt> without <tt>&lt;tag&gt;</tt>.<br />* <tt>&lt; tag&gt;</tt> instead of <tt>&lt;tag&gt;</tt>.';

$langA['MISSING_CLOSING_TAG'] = 'Missing closing tag. <br /> The <tt>&lt;%s&gt;</tt> tag must be closed using <tt>%s</tt> ';
$langA['MISSING_CLOSING_TAG2'] = ' перед закрывающим тегом <tt>&lt;/%s&gt;</tt>';

$langA['AUTOMATED_SYNTAX_ERROR'] = 'Автоматическая синтаксическая ошибка:';
$langA['AUTOMATED_SYNTAX_ERROR2'] = '(%s) в строке %s (из %s строк) столбце %s ';
$langA['last_open_tag'] = '<br />последний открытый тег ';
