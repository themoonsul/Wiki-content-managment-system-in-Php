<?php

	$langA['googleMapKeys'] =						'Ключ для работы с Google Maps API';


	$langA['ADMIN_ONLY'] =							'Вы должны быть администратором для доступа к этой странице.';
	$langA['UNDEFINED_ADMIN_PAGE'] =					'Данная административная страница ещё не определена: <tt>%s</tt>';
	
	$langA['CONFIRM_PASSWORD'] =						'Пожалуйста подтвердите пароль для продолжения.';
	$langA['confirm_password'] =						'Подтвердите пароль';
	$langA['confirmation_failed'] =					'Пароль не подверждён. Повоторите еще раз.';
	
	$langA['run_scheduled_tasks'] =					'Запустить Задания По Расписанию';
	$langA['FAILED'] = 								'Извините, не запрошенная операция прошла неудачно. Повторите еще раз.';
	$langA['SUCCESS'] = 								'Запрошенная операция прошла успешно.';


//
//	adminSearchOptions.php
//
	$langA['search_options'] =						'Параметры поиска';
	$langA['search_status'] =						'Статус поиска';
	$langA['search_enabled'] =						'Поиск разрешён';
	$langA['SEARCH_ENABLED'] =						'Отключение возможности поиска очистит таблицу БД \'all_search\'. Позже, если Вы захотите разрешить поиск, таблица \'all_search\' будет воссоздана.';
	$langA['disable'] =								'Отключить';
	
	$langA['search_disabled'] =						'Поиск отключён';
	$langA['SEARCH_DISABLED'] =						'На данный момент поиск отключен. Для включения необходима таблица `all_search` в базе данных с содержанием всех файлов баз. Этот процесс может занять продолжительное время для больших баз данных.';
	$langA['SEARCH_IS_DISABLED'] =					'Поиск запрещен, и таблица поиска сброшена.';
	$langA['enable'] =								'Включить';
	
	$langA['FINISHED_ENTRIES'] =						'%s записей пройдено, %s осталось.';
	$langA['SEARCH_IS_ENABLED'] =					'Возможность поиска теперь включена';


//
// adminConfig.php
//
	$langA['configuration'] =						'Настройки';
	$langA['confighistory'] =						'История настроек';
	$langA['CONFIG_SAVING'] =						'Новые настройки сохранены без перезаписи текущих знчений, позволяя Вам вернуть изменения если потребуется.';
	$langA['CONFIG_STAT'] =							'Было внесено %s версий настроек.';
	$langA['CONFIG_CONFIRM_REVERT'] =				'Вы уверены что хотите восстановить настройки версии %s ? Щёлкните на <tt>Сохранить</tt> для продолжения.';
	//$langA['FEATURE_NOT_AVAILABLE'] =				'This feature is not available with the current PHP/MySQL installation.';
	$langA['unavailable'] = 							'Unavailable';

//////////////////////////////
//	Descriptions
//
	$langA['serverName1']['desc'] =					'Нечто, что может быть использовано с предложением вида: "Добро пожаловать на ИмяСервера1".';
	$langA['serverName2']['desc'] =					'www.wikyblog.com';
	$langA['serverName3']['desc'] =					'http://ИмяСервера2';

//default user

	$langA['max_upload']['desc'] = 					'Максимальный размер загружаемого файла.';
	$langA['userLanguage']['desc'] = 				'';
	$langA['reservedWords']['desc'] = 				'Пользователи не могут использовать указанные имена в качестве учетных записей.';
	
	$langA['maxErrorFileSize']['desc'] = 			'Максимально разрешённый размер журнала ошибок. По умолчанию - 10 000 байт.';
	$langA['errorEmail']['desc'] = 					'Предоставьте адрес электронной почты ';
	
	
	$langA['include']['desc'] = 						'Автоматически производится включение php файла при каждом запросе. Имена файлов могут быть указаны через запятую, относительно корневого каталога.';


//////////////////////////////
//	Aliases
//
	$langA['general_config'] = 						'Общие настройки';
	$langA['performance'] = 							'Производительность';
	
	$langA['serverName1']['alias'] = 				'Приятное название сервера';
	$langA['serverName2']['alias'] = 				'Название сервера';
	$langA['serverName3']['alias'] = 				'Полная URL-ссылка на сервер';
	
	
	$langA['total_usage'] = 						'Total Usage';
	//$langA['disk_usage'] = 						'Disk Usage Settings';
	
	//$langA['maxUserDiskUsage']['alias'] = 			'User Allocation';
	//$langA['maxUserDiskUsage']['desc'] = 			'Amount of disk space alloted to each account for all files.';
	
	$langA['max_upload']['alias'] = 					'Максимум загружено';
	
	//$langA['maxHistory']['alias'] = 					'Max History Rows';
	//$langA['maxHistory']['desc'] = 					'Maximum number of history rows to be allowed per file for all users.';
	
	
	$langA['userLanguage']['alias'] = 				'Язык';
	$langA['reservedWords']['alias'] = 				'Зарезервированные слова';
	
	$langA['developer_aids'] = 						'Вспомогательные Средства разработчика';
	$langA['maxErrorFileSize']['alias'] = 			'Ошибочный размер протокола';
	$langA['errorEmail']['alias'] = 					'Ошибочный адрес электронной почты';
	$langA['include']['alias'] = 					'Включить PHP';

//
//	default user
//
	$langA['default_user_vars'] = 				'Настройки пользователя по умолчанию';
	
	$langA['defaultUser:homeTitle']['alias'] =		'Заголовок домашней страницы';
	$langA['defaultUser:homeTitle']['desc'] =		'Отображается как заголовок домашней страницы.';
	
	$langA['defaultUser:template']['alias'] =		'Пользовательский шаблон';
	$langA['defaultUser:template']['desc'] =		'Main/Home является основным шаблоном WikiBlog';
	
	$langA['defaultUser:textareaY']['alias'] =		'Высота текстовой области';
	$langA['defaultUser:textareaY']['desc'] =		'Высота текстовой области по умолчанию.';
	
	$langA['defaultUser:isBlog']['alias'] =			'Домашняя страница блога';
	$langA['defaultUser:isBlog']['desc'] =			'Включить или выключить стилизированую под блог домашнюю страницу.';
	
	$langA['defaultUser:timezone']['alias'] =		'Временная зона';
	$langA['defaultUser:timezone']['desc'] =		'';
	
	$langA['defaultUser:ajax']['alias'] =			'JavaScript';
	$langA['defaultUser:ajax']['desc'] =			'';
	
	$langA['defaultUser:maxHistory']['alias'] =		'Максимальное число записей в Истории';
	$langA['defaultUser:maxHistory']['desc'] =		'Максимум строк истории по умолчанию';

	$langA['defaultUser:pTemplate']['alias'] =		'Default Theme';
	$langA['defaultUser:pTemplate']['desc'] =		'';
	
//
//	User Groups
//	
	$langA['user_group'] = 'User Group';
	$langA['add_group'] = 'Добавить группу';
	$langA['unlimited'] = 'Без ограничений';
	$langA['group'] = 'Группа';
	$langA['related_links'] = 'Related Links';
	
//
//	registration
//	
	$langA['registration'] = 						'Регистрация';
	$langA['register:reqemail']['alias'] = 				'Необходим адрес электронной почты';
	$langA['register:register']['alias'] =				'Register Display Title';
	$langA['register:registered']['alias'] =				'Registered Display Title';
	$langA['register:captcha']['alias'] =				'Использовать Captcha';
	
	
	
	
//	adminUsers
	$langA['user_statistics'] =						'Статистика пользователей';
	$langA['user_stats'] =							'Статистика пользователей';
	$langA['user_account'] =							'Учетная запись пользователя';
	$langA['entries'] =								'Записи';
	$langA['history Rows'] =							'Записи в Истории';
	$langA['last_visit'] = 							'Последнее посещение';
	
	$langA['users_found'] =							'Найдено пользователей';
	$langA['showing_of_found'] =						'Показать %s до %s';
	$langA['cpanel'] =								'Панель управления';
	$langA['details'] =								'Детали';
	
	$langA['within_the_hour'] =						' < 1 часа назад';
	$langA['hours'] =								'часы';
	$langA['days'] =									'дни';
	$langA['months'] =								'месяцы';
	$langA['years'] = 								'годы';
	$langA['ago'] = 									'назад';
	
	$langA['TIMEOUT'] = 								'<b>Ошибка таймаута:</b> %s';
	$langA['NOT_MAIN_ACCT'] = 						'<b>Предупреждение</b>Не могу удалить учетную запись "Main"';
	$langA['CONFIRM_DELETE_USER'] = 					'Вы уверены в том, что собираетесь удалить <b>%s</b>?';
	$langA['CONFIRM_DELETE_USER2'] = 				'Удаление <i>полностью сотрет</i> все файлы этой учетной записи, включая:';
	$langA['userfiles_directory'] = 					'Каталог пользовательских файлов: ';
	$langA['template_directory'] = 					'Каталог шаблонов: ';
	$langA['database_entries'] = 					'И все записи в Базе Данных: страницы, историю страниц, комментарии и т.д.';
	
	$langA['DELETED_DATABASE_ENTRIES'] = 			'Удаленные записи в Базе Данных.';
	$langA['NOT_DELETED_DATABASE_ENTRIES'] = 		'<b>Предупреждение:</b> Не могу удалить записи в Базе Данных.';
	
	$langA['DELETED_USERFILES'] = 					'Удаленный Каталог Пользовательских Файлов.';
	$langA['NOT_DELETED_USERFILES'] = 				'<b>Предупреждение:</b> Не могу удалить Каталог Пользовательских Файлов.';
	
	$langA['DELETED_TEMPLATES'] = 					'Удаленный Каталог Шаблонов.';
	$langA['NOT_DELETED_TEMPLATES'] = 				'<b>Предупреждение:</b> Не могу удалить Каталог Шаблонов.';
	
	$langA['USER_DELETED'] = 						'%s был полностью удален: ';
	$langA['USER_NOT_DELETED'] = 					'%s НЕ был полностью удален: ';
	$langA['DELETE_ACCOUNT'] = 						'Полностью удалить эту учетную запись.';
	$langA['DISABLE_ACCOUNT'] = 					'Запретить для редактирования.';
	$langA['SUSPEND_ACCOUNT'] = 					'Suspend all usage.'; //'Suspend all usage of this account.';
	$langA['NOFOLLOW'] = 							'Добавить "не переходить" ко всем внешним ссылкам.';
	$langA['updated'] = 							'Обновлено';
	$langA['suspend'] = 							'Приостановить';
	$langA['activate'] = 							'Активировать';
	$langA['lost_page'] = 							'Потерянная страница';
	$langA['suspended'] =							'Приостановлено';
	$langA['disabled'] =							'Запрещено';



//	adminErrors
	$langA['ERROR_LOG_NOT_DELETED'] = 				'Не могу удалить протокол ошибок.';
	$langA['ERROR_LOG_DELETED'] = 					'Протокол ошибок удален.';
	$langA['ERROR_LOG_MAXED'] = 						'Протокол ошибок достиг максимально возможного размера, нужно очитить файл, чтобы скрипт мог бы продолжать протоколировать ошибки. %s';


	$langA['select'] = 								'Выберите';
	$langA['description'] = 						'Описание';


//	adminPlugins
	$langA['data_types'] = 							'Типы данных'; //duplicate of value in SPEC.php
	$langA['existing_types'] = 						'Существующие типы';
	$langA['available_plugins'] = 					'Доступные Модули';

//
//	adminPlugins
//
	$langA['check_uncheck'] = 						'Выделить Все / Снять выделение';



//////////////////////////////
//
//	wbConfig
//

	$langA['wbConfig']['online']['alias'] = 			'Подключен';
	$langA['wbConfig']['online']['desc'] = 			'Эта установка может соединиться с Интернет?';
	
	$langA['wbConfig']['floodInterval']['alias'] = 	'Интервал между сообщениями';
	$langA['wbConfig']['floodInterval']['desc'] = 	'Количество секунд, которое пользователь без соответствующих привелегий должен будет подождать между процедурами редактирования.';
	
	$langA['wbConfig']['ajax']['alias'] = 			'JavaScript';
	$langA['wbConfig']['ajax']['desc'] = 			'Определяет уровень использования JavaScript для анонимных пользователей.';
	
	$langA['wbConfig']['tidy']['alias'] =			'Аккуратный код HTML';
	$langA['wbConfig']['tidy']['desc'] =				'Использовать HTML Tidy для исправления возможных ошибок пользователя.';
	
	$langA['wbConfig']['allUsers']['alias'] = 		'Полные возможности.';
	$langA['wbConfig']['allUsers']['desc'] = 		'Разрешить всем зарегистрированным пользователям иметь свой блог.';
	
	$langA['wbConfig']['pUser']['desc'] = 			'Укажите учетную запись, которую надо показывать, если она не указана посетителем.';
	$langA['wbConfig']['pUser']['alias'] = 			'Пользователь по умолчанию.';

	$langA['wbConfig']['sesslevel']['desc'] = 		'Определите, какая часть пользовательского IP адреса будет проверяться для очета сессий.';
	$langA['wbConfig']['sesslevel']['alias'] = 		'Уровень сессии';

	$langA['wbConfig']['thumbs']['desc'] = 		'Create thumbnails for uploaded images.';
	$langA['wbConfig']['thumbs']['alias'] = 		'Image Thumbnails';

