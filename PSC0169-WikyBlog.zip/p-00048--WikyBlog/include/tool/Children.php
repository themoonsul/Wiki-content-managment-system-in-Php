<?php

defined('WikyBlog') or die("Not an entry point...");


class fileChildren{
	
	function fileChildren(){
		global $page, $dbObject;
		
		
		$contentUri = $page->regLink('Children', '/Edit'.$dbObject->uniqLink.'?cmd=children');
		$page->displayTitle .= ' > Children';
		$page->regLink('?','Children?en=Children');

		
		// if( $page->ajaxRequest && isset($_GET['offset']) ){
		// 	
		// 	
		// 	$addContent = new content();
		// 	$addContent->aa = 'append';
		// 	$addContent->bb = 'WB.CHILDREN.'.$dbObject->file_id;
		// 	
		// 	ob_start();
		// 	fileChildren::getChildren();
		// 	$addContent->cc = wb::get_clean();
		// 	
		// 	$page->contentClasses[] = $addContent;
		// 	return;
		// }
			
		
		ob_start();
		
		fileChildren::getChildren();
		
		$page->contentB[$contentUri] = wb::get_clean();
	}
	
	/* static */
	function includeChildren(){
		ob_start();
		
		fileChildren::getChildren();
		
		return wb::get_clean();
	}
	
	/* static */
	function getChildren(){
		global $page, $dbObject,$langA, $wbTables;
		
		$maxPerRequest = 20;
		
		$query = 'SELECT /* Children.php:getChildren() */ ';
		$query .= wbData::getDTitle($dbObject->objectType);
		$query .= ' ,'.wbData::dbInfo($dbObject->objectType,'uniqLink').' as uniqLink ';
		$query .= ' FROM '.$dbObject->dbInfo['dbTable'];
		$query .= ' JOIN '.$wbTables['all_files'].' USING(`file_id`) ';
		$query .= ' WHERE ';
		$query .= $wbTables['all_files'].'.`visible` = 1 ';
		$query .= ' AND ';
		$lastKey = end(array_flip($dbObject->dbInfo['keys']));

		
		$order = '';
		$queryA = array();
		foreach( $dbObject->dbInfo['keys'] as $key => $null ){
			if( $key == $lastKey ){
				$root = $dbObject->$key.'/';
				$queryA[] = '`'.$key.'` LIKE "'.wbDB::escape($root).'%" ';
				$order = ' ORDER BY `'.$key.'`';
			}else{
				$queryA[] = '`'.$key.'` = "'.wbDB::escape($dbObject->$key).'" ';
			}
			
		}
		$query .= implode(' AND ',$queryA);
		$query .= $order;
		
		if( !isset($_GET['offset']) ){
			$_GET['offset'] = 0;
		}
		$_GET['offset'] = (int)$_GET['offset'];
		$query .= ' LIMIT '.($maxPerRequest+1).' OFFSET  '.$_GET['offset'];
		
		$result = wbDB::runQuery($query);
		$num = mysql_num_rows($result);
		if( $num <= 0 ){
			echo $langA['EMPTY_SET'];
			return;
		}
		
		
		$rootLen = strlen($root);
		
		$i = 0;
		echo '<ul>';
		while($row= mysql_fetch_assoc($result) ){
			$i++;
			if( $i > $maxPerRequest ){
				break;
			}
			
			echo '<li>';
			// if( strpos($row['dTitle'],$root) !== false ){
			// 	$title = substr($row['dTitle'],$rootLen);
			// }else{
			// 	$title = $row['dTitle'];
			// }
			
			$pos = strrpos($row['dTitle'],'/');
			$title = substr($row['dTitle'],($pos+1));
			
			//$title = substr($row['dTitle'],$rootLen);
			echo wbLinks::local($row['uniqLink'], toDisplay($title));
			
			echo '</li>';
		}
		echo '</ul>';

		if( $_GET['offset'] > 0 ){
			$newOffset = $_GET['offset'] - $maxPerRequest;
			$newOffset = max(0,$newOffset);
			echo wbLinks::local('/Edit'.$dbObject->uniqLink.'?cmd=children&offset='.$newOffset,$langA['previous']);
			echo ' &nbsp; ';
		}
		
		if( $i > $maxPerRequest ){
			$newOffset = $_GET['offset'] + $maxPerRequest;
			echo wbLinks::local('/Edit'.$dbObject->uniqLink.'?cmd=children&offset='.$newOffset,$langA['next']);
		}
				
	}
	
}

global $initiateFileClass;
if( $initiateFileClass ){
	new fileChildren();
}
		