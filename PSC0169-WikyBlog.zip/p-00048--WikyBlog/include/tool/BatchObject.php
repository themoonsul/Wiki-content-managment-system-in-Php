<?php

defined('WikyBlog') or die("Not an entry point...");
message('deprecated');



//
//
//
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
//
//

// function batchSetObject($type){
// 	global $batchObject,$dbInfo;
// 	
// 	
// 	wbData::newObject($type,$batchObject,true);
// 	if( !$batchObject ){
// 		message('INVALID_FILE_TYPE');
// 		return false;
// 	}
// 	return true;
// }


// //////////////////////////////////////////////////////////////////////////////////////////
// //	
// //		batchSetCase
// //			- should maybe set an array of $queries.. do an implode('UNION',$queries) and go through the result 
// //				instead of one by one
// //				-	the thing about this is that all other values will also have to be stored untill the queries are run
// //					the memory usage could be worse than running a query for each file..
// //		
// //			- needs to call setFromDisk() which needs to have  setFileLocations() called before it..
// //				these functions are only called if the file exists!

// function batchSetCase(&$values,$arg=''){
// 	global $batchObject,$wbMessageBuffer;
// 	//global $batchQueries;

// 	$tempMessage = $wbMessageBuffer;
// 	$wbMessageBuffer = array();
// 	
// 	//////////////////////////////////////////////////////////////
// 	//
// 	//	Emulate $dbObject->getStep1();
// 	//
// 	//set the keys
// 	foreach($batchObject->dbInfo['keys'] as $key => $trash){
// 		$batchObject->$key = $values[$key];
// 	}
// 	$batchObject->setUniqLink();
// 	//get the object
// 	$batchObject->exists = false;
// 	$query = 'SELECT ';
// 	$query .= wbData::dbInfo($batchObject->objectType,'querySelect');
// 	$query .= ' FROM '.wbData::dbInfo($batchObject->objectType,'queryFrom');
// 	$query .= ' WHERE ';
// 	$query .= $batchObject->where($batchObject->dbInfo['dbTable']);
// 	$query .= ' LIMIT 1 OFFSET 0';
// 	//$batchQueries[] = '('.$query.')';
// 	$result = wbDB::runQuery($query);
// 	$num = mysql_num_rows($result);
// 	
// 	if( method_exists($batchObject,'setFileLocations')){
// 		$batchObject->setFileLocations();
// 	}
// 	
// 	$batchObject->setFromDisk();

// 	
// 	///	New Page
// 	if($num === 1){
// 		$row = mysql_fetch_object($result);
// 		$batchObject->setVariables($row);
// 		$batchObject->exists = true;
// 		//message('File exists.');
// 	}else{
// 		//message('File does not exist.');
// 	}
// 	
// 	switch($arg){
// 		case 'save':
// 			fileToDisk($batchObject,$values);
// 		break;
// 		default:
// 			message('Nothing done with the file.');
// 		break;
// 	}
// 	
// 	echo '<h4 class="heading">'.$batchObject->uniqLink.'</h4>';
// 	echo returnMessages(false);
// 	
// 	
// 	$wbMessageBuffer = $tempMessage;
// }

// // function batchDoQueries(){
// // 	global $batchQueries;
// // 	$query = implode(' UNION ',$batchQueries);
// // 	echo $query;
// // 	$result = wbDB::runQuery($query);
// // 	while($row = mysql_fetch_assoc($result)){
// // 		echo '<h4>row</h4>';
// // 		echo showArray($row);
// // 	}
// // }


