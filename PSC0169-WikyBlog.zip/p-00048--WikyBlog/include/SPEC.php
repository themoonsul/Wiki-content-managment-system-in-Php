<?php


defined('WikyBlog') or die("Not an entry point...");

class SPEC{
	var $owner;
	var $title;
	var $links = array();
	var $pluginTitle;
	var $script = false;
	var $userlevel;
	
	function getOwner(&$pathArray){
		global $page;
		
		
		$this->pluginTitle = implode('/',$pathArray['path']);
		$this->pluginTitle = toStorage($this->title,true);
		
		$this->title = implode('/',$pathArray['path']);
		$this->title = wbStrtolower($this->title);
		
		//$this->title= str_replace('_','',$this->title);
		//$this->title = str_replace(' ','',$this->title);
		
		$this->getScript();
		
		//
		//	get data2? for this title
		//
		switch($this->title){
			
			/* 
			// going to leave these alone for now
			case 'templates':
			case 'setpreference':
			case 'preferences':
			*/
			
			//case 'arrange':
			case 'linkgroups':
			case 'links':
			case 'tabs':
				$page->sessionData2 = true;
			break;
			
		}
		
		return $pathArray['owner'];
	}
	
	function getScript(){
		global $wbTables, $wbPluginDir, $wbPluginSpace,$page;
		wbLang::getFile('SPEC');
		
		//
		$query = 'SELECT `plugin_space`, `plugin_dir`, `script`, `userlevel` FROM '.$wbTables['config_links'];
		$query .= ' WHERE `link` = "'.$this->title.'" ';
		$query .= ' AND `userlevel` < 5 ';
		$query .= ' AND `enabled` > 0 ';
		$query .= ' LIMIT 1 OFFSET 0';
		$result = wbDB::runQuery($query);
		$num = mysql_num_rows($result);	
		if( $num === 1 ){
			$row = mysql_fetch_assoc($result);
			
			if( !empty($row['plugin_space']) ){
				$wbPluginDir = $row['plugin_dir'];
				$page->effectiveSpace = $wbPluginSpace = $row['plugin_space'];
			}
			$this->userlevel = (int)$row['userlevel'];
			$this->script = $row['script'];
		}
	}
		
	function getStep1(&$pathArray){}
	
	function getStep2(){
		global $page,$pageOwner,$langA, $wbTables, $wbPluginDir, $wbPluginSpace, $wbAdminUser;
		
		$getTitle = $this->title;
		
		//doesn't have the privs
		if( isAdmin(false) ){
			//admin
		}elseif( $_SESSION['userlevel'] < $this->userlevel ){
			message('NOT_OWNER');
			$this->script = false;
			$getTitle = '';
		}


		if( $this->script ){
			
			rootInclude($this->script);
			
		}else{
		
			switch($getTitle){
				
				// case 'searchmaps':
				// 	includeFile('search/Maps.php');
				// break;
				
				// case 'checkwatch':
				// 	includeFile('special/WatchCheck.php');
				// break;
	
				case 'credits':
					$page->contentA['Credits'] = includeFileContents('special/Credits.php');
				break;
				case '';
					includeFile('special/ControlPanel.php');
				break;
				default:
					message('UNDEFINED_SPECIAL_PAGE',$this->title);
					includeFile('special/ControlPanel.php');
				break;
			}
		}
		
		$page->regLink($langA['control_panel'],'/Special/'.$pageOwner['username'].'/ControlPanel');
		if( isAdmin(false) ){
			$page->regLink($langA['administration'],'/Special/'.$wbAdminUser.'/ControlPanel?a');
			//$page->regLink($langA['administration'],'/Admin/'.$wbAdminUser.'/ControlPanel');
		}
	}
}
